//============================================================================
// Name        : RD_AHG.cpp
// Version     :
// Copyright   : Your copyright notice
// Description : C++, Ansi-style
//============================================================================

#include "RD/AHG/JSON/JSON_AHG.hpp"
#include "RD/GHA/JSON/JSON_GHA.hpp"
#include "RD/TIMER/TIMER_PARES.hpp"
#include "RD/DVSTATUS/DeviceStatus.hpp"
#include "RD/SCENEDELAY/SCENE_DELAY.hpp"

#include "RD/MQTT/MQTT.hpp"

#include "RD/ShareData.hpp"

string HCId = "";

using namespace std;

pthread_t JsonAHG;
pthread_t JsonGHA;
pthread_t QueueDataBase;
pthread_t ThreadMqttLocal;
pthread_t ThreadUDP;

int main() {
	char mac[20] = {0};
	GetMacAddress(mac);
	macHC = mac;
	TopicMultiHC = "SHARE_LOCAL/"+macHC;
	if(CheckFile("/etc/config/hcInfo") == false)
	{
		ExeCMD("touch /etc/config/hcInfo");
		ExeCMD("uci add hcInfo master");
		ExeCMD("uci commit");
	}

	GetHcMasterInfo();

	InitDeviceTypeList();
	pthread_create(&threadTimer, NULL, CallEvent, &CheckHCL);

	pthread_create(&CallSceneDelay, NULL, SceneDelay, NULL);

	pthread_create(&JsonAHG, NULL, AHG_MQTT, NULL);

	pthread_create(&JsonGHA, NULL, GHA_MQTT, NULL);

	pthread_create(&QueueDataBase, NULL, DB, NULL);

	pthread_create(&DeviceOnlineOffline, NULL, DeviceOnline, NULL);

	pthread_create(&ThreadMqttLocal, NULL, MqttLocal, &dataConnectMqtt);

	if(HcMasterInfo.Ip != "" && HcMasterInfo.PassMqtt != ""){
		string GetStatusHC = "ping -c3 " + HcMasterInfo.Ip;
		int result = system(GetStatusHC.c_str());
		if (result == 0)
		{
			pthread_create(&ThreadMqttMaster, NULL, MqttMaster, NULL);
		}
	}

	while(1){
		sleep (10);
	}
	return 0;
}
