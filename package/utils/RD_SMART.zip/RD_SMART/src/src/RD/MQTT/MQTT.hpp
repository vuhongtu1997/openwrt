/*
 * MQTT.hpp
 *
 *  Created on: Apr 12, 2021
 *      Author: rd
 */

#ifndef RD_MQTT_MQTT_HPP_
#define RD_MQTT_MQTT_HPP_

#include "../../RD/AHG/JSON/JSON_AHG.hpp"
#include "../../RD/GHA/JSON/JSON_GHA.hpp"
#include "../../RD/TIMER/TIMER_PARES.hpp"
#include "../../RD/ShareData.hpp"

//bien mqtt
//#define mqtt_host 			"10.10.10.1"
#define mqtt_username 		"RD"
#define mqtts_port 			8883
#define mqtt_port			1883

#define CONNECT_BROKER_LOCAL			1
#define CONNECT_BROKER_MASTER			2

typedef struct{
	string mqttHost;
	int typeConnect;
}t_connectMqtt;

extern t_connectMqtt dataConnectMqtt;

extern struct mosquitto *mosq;
extern struct mosquitto *mosqMaster;

bool CheckFile (const std::string& name);

/*-----------------------------------------------MQTT---------------------------------------------------------*/
//connect MQTT
void ConnectCallback(struct mosquitto *mosq, void *obj, int rc);
void ConnectCallbackMaster(struct mosquitto *mosq, void *obj, int rc);

//MQTT take data
void MessageCallback(struct mosquitto *mosq, void *obj, const struct mosquitto_message *message);

//MQTT public msg
int MqttSend(struct mosquitto *mosq, char *msg);
int MqttSendGW2Logic(struct mosquitto *mosq, char *msg);
int MqttSendAPP(struct mosquitto *mosq, char *msg, bool writeLog);

int MqttSendMutiHC(struct mosquitto *mosq, char *msg, bool writeLog);

void* MqttLocal(void *argv);
void* MqttMaster(void *argv);

#endif /* RD_MQTT_MQTT_HPP_ */
