/*
 * MQTT.cpp
 *
 *  Created on: Apr 12, 2021
 */

#include "MQTT.hpp"
#include "../ShareData.hpp"
#include "queue"

int run = 1;
struct mosquitto *mosq;
struct mosquitto *mosqMaster;

t_connectMqtt dataConnectMqtt = {"10.10.10.1", CONNECT_BROKER_LOCAL};

int connectMqttLocal = 1;

bool CheckFile(const std::string &name)
{
	if (FILE *file = fopen(name.c_str(), "r"))
	{
		fclose(file);
		return true;
	}
	else
	{
		return false;
	}
}

// connect MQTT
void ConnectCallback(struct mosquitto *mosq, void *obj, int rc)
{
	if (rc)
	{
		printf("ERROR WITH RESULT CODE: %d !!!\n", rc);
		exit(-1);
	}
	while (true)
	{
		if (pthread_mutex_trylock(&mutexLog) == 0)
		{
			WriteIntoLog("<SYSTEM>", "CONNECT MQTT SUCCESS!!!");
			pthread_mutex_unlock(&mutexLog);
			break;
		}
		usleep(3000);
	}
	cout << "CONNECT MQTT SUCCESS!!!" << endl;
	mosquitto_subscribe(mosq, NULL, "HC.CONTROL", 2); // subscribe topic APP
	mosquitto_subscribe(mosq, NULL, "RD_STATUS", 2);  // subscribe topic GW
}

void ConnectCallbackMaster(struct mosquitto *mosq, void *obj, int rc)
{
	if (rc)
	{
		printf("ERROR WITH RESULT CODE: %d !!!\n", rc);
		// exit(-1);
	}
	while (true)
	{
		if (pthread_mutex_trylock(&mutexLog) == 0)
		{
			WriteIntoLog("<SYSTEM>", "CONNECT MQTT MASTER SUCCESS!!!");
			pthread_mutex_unlock(&mutexLog);
			break;
		}
		usleep(3000);
	}
	mosquitto_subscribe(mosqMaster, NULL, "SHARE_LOCAL/+", 2); // subscribe topic APP
	cout << "CONNECT MQTT MASTER SUCCESS!!!" << endl;
	MqttSendMutiHC(mosq, "vuhongtu", true);
}

// MQTT public GW
#define MAXDATA_RD_CONTROL 1024
int MqttSend(struct mosquitto *mosq, char *msg)
{
	mosquitto_publish(mosq, NULL, "RD_CONTROL", strlen(msg), msg, 2, 0); // public
	return 0;
}

int MqttSendGW2Logic(struct mosquitto *mosq, char *msg)
{
	mosquitto_publish(mosq, NULL, "RD_STATUS", strlen(msg), msg, 2, 0); // public
	return 0;
}

// MQTT public APP
int MqttSendAPP(struct mosquitto *mosq, char *msg, bool writeLog)
{
	mosquitto_publish(mosq, NULL, "HC.CONTROL.RESPONSE", strlen(msg), msg, 2, 0); // public
	if (writeLog)
	{
		while (true)
		{
			if (pthread_mutex_trylock(&mutexLog) == 0)
			{
				WriteIntoLog("<HC -> APP>", msg);
				pthread_mutex_unlock(&mutexLog);
				break;
			}
			usleep(3000);
		}
	}
	return 0;
}

int MqttSendMutiHC(struct mosquitto *mosq, char *msg, bool writeLog)
{
	mosquitto_publish(mosq, NULL, TopicMultiHC.c_str(), strlen(msg), msg, 2, 0); // public
	if (writeLog)
	{
		while (true)
		{
			if (pthread_mutex_trylock(&mutexLog) == 0)
			{
				WriteIntoLog("<HC -> APP>", msg);
				pthread_mutex_unlock(&mutexLog);
				break;
			}
			usleep(3000);
		}
	}
	return 0;
}

// MQTT data sub topic
void MessageCallback(struct mosquitto *mosq, void *obj, const struct mosquitto_message *message)
{
	char *msg = (char *)message->payload;
	// cout << message->topic << " ----- " << msg << endl;
	try
	{
		if (strcmp(message->topic, "HC.CONTROL") == 0)
		{
			sendMsgMultiHc = true;
			JsonParseApp(msg);
		}
		else if (strcmp(message->topic, "RD_STATUS") == 0)
		{
			JsonParseGw(msg);
		}
	}
	catch (exception &e)
	{
	}
}

vector<string> splitString(string str, char splitter)
{
	vector<string> result;
	string current = "";
	for (size_t i = 0; i < str.size(); i++)
	{
		if (str[i] == splitter)
		{
			if (current != "")
			{
				result.push_back(current);
				current = "";
			}
			continue;
		}
		current += str[i];
	}
	if (current.size() != 0)
		result.push_back(current);
	return result;
}

void MessageCallbackMaster(struct mosquitto *mosq, void *obj, const struct mosquitto_message *message)
{
	char *msg = (char *)message->payload;
	cout << "Master send: " << msg << endl;
	string TempTopic = message->topic;
	vector<string> topics = splitString(TempTopic, '/');
	cout << "topic size: " << topics.size() << "  msg: "<< msg << " topic: " << topics[1] << " mac hc: " + macHC<< endl;
	if (topics[1] != macHC)
	{
		try
		{
			sendMsgMultiHc = false;
			JsonParseApp(msg);
		}
		catch (exception &e)
		{
		}
	}
}

void CreateMqttLocal(string mqttHost)
{
	bool CheckMqtt = false;
	CheckMqtt = CheckFile("/etc/PassMqtt.txt");
	char PassMqtt[100] = {0};
	if (CheckMqtt)
	{
		FILE *file;
		file = fopen("/etc/PassMqtt.txt", "r");
		if (!file)
		{
			cout << "Can not open this file" << endl;
		}
		else
		{
			cout << "File is open" << endl;
		}
		fgets(PassMqtt, 100, file);
		fclose(file);
	}

	char clientid[24] = "Client_RD";
	int rc = 0;

	mosquitto_lib_init();

	memset(clientid, 0, 24);
	snprintf(clientid, 23, "mysql_log_%d", getpid());
	mosq = mosquitto_new(clientid, true, 0);
	if (mosq)
	{
		if (CheckMqtt == false)
		{
			cout << "check file MQTT: " << CheckMqtt << endl;
			rc = mosquitto_tls_set(mosq, "/etc/mosquitto/ca.crt", NULL, NULL, NULL, NULL);
			rc = mosquitto_tls_insecure_set(mosq, false);
			rc = mosquitto_connect(mosq, const_cast<char *>(mqttHost.c_str()), mqtts_port, 60);
		}
		else
		{
			rc = mosquitto_username_pw_set(mosq, mqtt_username, PassMqtt);
			rc = mosquitto_connect(mosq, const_cast<char *>(mqttHost.c_str()), mqtt_port, 60);
		}
		sleep(1);

		mosquitto_connect_callback_set(mosq, ConnectCallback);
		mosquitto_message_callback_set(mosq, MessageCallback);
		while (true)
		{
			rc = mosquitto_loop(mosq, 3, 1);
			if (rc != MOSQ_ERR_SUCCESS)
			{
				printf("mosquitto_set failed, %s\n", mosquitto_strerror(rc));
				sleep(5);
				mosquitto_reconnect(mosq);
			}
			usleep(5000);
		}

		mosquitto_destroy(mosq);
	}
	mosquitto_lib_cleanup();
}

void CreateMqttMaster(string mqttHost)
{
	int rc = 0;

	// mosquitto_lib_init();

	memset(const_cast<char *>(HcMasterInfo.Mac.c_str()), 0, 24);
	snprintf(const_cast<char *>(HcMasterInfo.Mac.c_str()), 23, "mysql_log_%d", getpid());
	mosqMaster = mosquitto_new(NULL, true, 0);
	if (mosqMaster)
	{
		rc = mosquitto_username_pw_set(mosqMaster, mqtt_username, HcMasterInfo.PassMqtt.c_str());
		rc = mosquitto_connect(mosqMaster, HcMasterInfo.Ip.c_str(), mqtt_port, 60);
		sleep(1);

		mosquitto_connect_callback_set(mosqMaster, ConnectCallbackMaster);
		mosquitto_message_callback_set(mosqMaster, MessageCallbackMaster);
		while (true)
		{
			rc = mosquitto_loop(mosqMaster, 3, 1);
			if (rc != MOSQ_ERR_SUCCESS)
			{
				printf("mosquitto_set failed, %s\n", mosquitto_strerror(rc));
				sleep(5);
				mosquitto_reconnect(mosqMaster);
			}
			usleep(5000);
		}

		mosquitto_destroy(mosqMaster);
	}
	mosquitto_lib_cleanup();
}

void *MqttLocal(void *argv)
{
	t_connectMqtt *CheckConnect = (t_connectMqtt *)argv;
	CreateMqttLocal(CheckConnect->mqttHost);
	return 0;
}

void *MqttMaster(void *argv)
{
	cout << "create mqtt master" << endl;
	ThreadMqttMasterId = pthread_self();
	CreateMqttMaster(HcMasterInfo.Ip);
	return 0;
}
