#include "ringBufferData.h"


ringbuffer_t queuSend2Database;