#ifndef RINGBUFFERDATA_H
#define RINGBUFFERDATA_H

#include "RingBuffer.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include <string.h>

#define MAXLENGTHSTRING_QDB (1024)
#define MAXITEM_QDB         (1024)

typedef struct ringBufferData_QueueDatabase_t
{
    char data[MAXLENGTHSTRING_QDB];
} ringBufferData_QueueDatabase_t;

extern ringbuffer_t queuSend2Database;

#ifdef __cplusplus
    extern
}
#endif

#endif // RINGBUFFERDATA_H
