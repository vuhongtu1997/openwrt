/*
 * GHA_RSP_REMOTE.cpp
 *
 *  Created on: Jan 9, 2022
 *      Author: rd
 */

#include "GHA_RSP_REMOTE.hpp"

#if REMOVE_ARR_SCENE_DELAY
static void InitArr(){
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutexSceneDelay) == 0){
			for(int k=0; k<SIZE_SCENE_DELAY; k++){
				for(int m=0; m<6; m++){
					ArrSceneDelay[k][m] = -1;
				}
				cout << endl;
			}
			IndexSceneDaleyCurrent = 0;
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutexSceneDelay);
			break;
		}
		usleep (3000);
	}
}
#endif

void RspRemote(struct mosquitto *mosq, char * jobj){
	Document document;
	document.Parse(jobj);
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	int SceneUnicastIdButtonRSP = DATA["SCENEID"].GetInt();
	string StrButtonId = DATA["BUTTON_VALUE"].GetString();
	int TempButtonId = 0;
	if(StrButtonId.compare("BUTTON_1")==0){
		TempButtonId = 11;
	}
	else if(StrButtonId.compare("BUTTON_2")==0){
		TempButtonId = 12;
	}
	else if(StrButtonId.compare("BUTTON_3")==0){
		TempButtonId = 13;
	}
	else if(StrButtonId.compare("BUTTON_4")==0){
		TempButtonId = 14;
	}
	else if(StrButtonId.compare("BUTTON_5")==0){
		TempButtonId = 15;
	}
	else if(StrButtonId.compare("BUTTON_6")==0){
		TempButtonId = 16;
	}
	json.StartObject();
		json.Key("CMD");json.String("REMOTE");
		json.Key("DATA");
		json.StartObject();
			json.Key("DEVICE_ID");
			string deviceId = GetUUId(mosq, adr);
			json.String(const_cast<char*>(deviceId.c_str()));
			json.Key("BUTTON_VALUE");json.Int(TempButtonId);
			json.Key("MODE_VALUE");json.Int(DATA["MODE_VALUE"].GetInt());
		json.EndObject();
	json.EndObject();
	cout << sendToApp.GetString() << endl;
	string s = sendToApp.GetString();
	MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	string checkScene = "SELECT EventTriggerId FROM EventTrigger WHERE SceneUnicastID ="+to_string(SceneUnicastIdButtonRSP)+";";
	CONTROLSL="";
	DB_ReadGHA(mosq, "CONTROL", checkScene);
	string SceneId = CONTROLSL;
	if(SceneUnicastIdButtonRSP != 0){
		CONTROLSL = "";
		string sql = "SELECT EventTriggerId FROM EventTriggerID WHERE SceneUnicastID = "+ to_string(SceneUnicastIdButtonRSP)+";";
		DB_ReadGHA(mosq, "CONTROL", sql);
		SceneIdRSP = CONTROLSL;
		#if LOG_ACTIONS
		SendLogScene(SceneIdRSP);
		#endif
		ADRSL = -1;
		string CheckTypeScene = "SELECT EventTriggerTypeId FROM EventTrigger WHERE SceneUnicastID = "+ to_string(SceneUnicastIdButtonRSP)+";";
		DB_ReadGHA(mosq, "ADR", CheckTypeScene);
		int TypeScene = ADRSL;
		// cout << "TypeScene: "<< TypeScene << endl;
		if(TypeScene == 10){
			#if REMOVE_ARR_SCENE_DELAY
			InitArr();
			#endif
			GetDvSceneDelayInput(SceneId);
			GetGrSceneDelayInput(SceneId);
		}
		else{
			TimeWaitRSP = GetSecondTimeNow();
			SceneUnicastIdRSP = SceneUnicastIdButtonRSP;
			while(pthread_mutex_trylock(&mutexDvOnline) != 0){
				usleep (3000);
			}
			FlagRSP = true;
			StrCmdRsp = DVValue;
			string GetStatus = "SELECT DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue"
				" FROM EventTriggerOutputDeviceSetupValue WHERE EventTriggerId = '"+SceneIdRSP+"';";
			// cout << GetStatus << endl;
			DB_ReadGHA(mosq, "GET_STATUS_SCENE", GetStatus);
			pthread_mutex_unlock(&mutexDvOnline);
			FlagSceneRSP = true;
		}
	}
}

void RspRemotePairing(struct mosquitto *mosq, char * jobj){
	Document document;
	document.Parse(jobj);
	if (document.IsObject()){
		if(document.HasMember("DATA") && document["DATA"].IsObject()){
			const Value& DATA = document["DATA"];
			if (DATA.HasMember("DEVICE_UNICAST_ID") && DATA["DEVICE_UNICAST_ID"].IsInt() &&
				DATA.HasMember("BUTTON_VALUE") && DATA["BUTTON_VALUE"].IsString() &&
				DATA.HasMember("MODE_VALUE") && DATA["MODE_VALUE"].IsInt() &&
				DATA.HasMember("SCENEID") && DATA["SCENEID"].IsInt()) 
			{
				uint16_t deviceUnicastId = DATA["DEVICE_UNICAST_ID"].GetInt();
				string deviceId = GetUUId(NULL, deviceUnicastId);
				string buttonId = DATA["BUTTON_VALUE"].GetString();
				int DeviceAttId = 0;
				if(buttonId.compare("BUTTON_1")==0){
					DeviceAttId = 126;
				}
				if(buttonId.compare("BUTTON_2")==0){
					DeviceAttId = 127;
				}
				if(buttonId.compare("BUTTON_4")==0){
					DeviceAttId = 128;
				}
				if(buttonId.compare("BUTTON_8")==0){
					DeviceAttId = 129;
				}
				if(buttonId.compare("BUTTON_3")==0){
					DeviceAttId = 130;
				}
				if(buttonId.compare("BUTTON_5")==0){
					DeviceAttId = 131;
				}
				if(buttonId.compare("BUTTON_9")==0){
					DeviceAttId = 132;
				}
				if(buttonId.compare("BUTTON_6")==0){
					DeviceAttId = 133;
				}
				if(buttonId.compare("BUTTON_10")==0){
					DeviceAttId = 134;
				}
				if(buttonId.compare("BUTTON_12")==0){
					DeviceAttId = 135;
				}
				if(buttonId.compare("BUTTON_16")==0){
					DeviceAttId = 137;
				}
				if(buttonId.compare("BUTTON_32")==0){
					DeviceAttId = 138;
				}
				if(buttonId.compare("BUTTON_24")==0){
					DeviceAttId = 139;
				}
				if(buttonId.compare("BUTTON_48")==0){
					DeviceAttId = 140;
				}
				int mode = DATA["MODE_VALUE"].GetInt();
				uint16_t sceneId = DATA["SCENEID"].GetInt();

				uint16_t type = TYPE_DEVICE(deviceId);

				StringBuffer sendToApp;
				Writer<StringBuffer> json(sendToApp);
				json.StartObject();
					json.Key("CMD");json.String("REMOTE");
					json.Key("DATA");
					json.StartObject();
						json.Key("DEVICE_ID");
						json.String(const_cast<char*>(deviceId.c_str()));
						json.Key("DEVICE_TYPE_ID"); json.Int(type);
						json.Key("BUTTON_VALUE");json.Int(DeviceAttId);
						json.Key("MODE_VALUE");json.Int(mode);
					json.EndObject();
				json.EndObject();
				cout << sendToApp.GetString() << endl;
				string s = sendToApp.GetString();
				MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
				string checkScene = "SELECT EventTriggerId FROM EventTrigger WHERE SceneUnicastID ="+to_string(sceneId)+";";
				CONTROLSL="";
				DB_ReadGHA(mosq, "CONTROL", checkScene);
				string SceneId = CONTROLSL;
				
				if(sceneId != 0){
					CONTROLSL = "";
					string sql = "SELECT EventTriggerId FROM EventTriggerID WHERE SceneUnicastID = "+ to_string(sceneId)+";";
					DB_ReadGHA(mosq, "CONTROL", sql);
					SceneIdRSP = CONTROLSL;
					#if LOG_ACTIONS
					SendLogScene(SceneIdRSP);
					#endif
					ADRSL = -1;
					string CheckTypeScene = "SELECT EventTriggerTypeId FROM EventTrigger WHERE SceneUnicastID = "+ to_string(sceneId)+";";
					DB_ReadGHA(mosq, "ADR", CheckTypeScene);
					int TypeScene = ADRSL;
					// cout << "TypeScene: "<< TypeScene << endl;
					if(TypeScene == 10){
						#if REMOVE_ARR_SCENE_DELAY
						InitArr();
						#endif
						GetDvSceneDelayInput(SceneId);
						GetGrSceneDelayInput(SceneId);
					}
					else{
						TimeWaitRSP = GetSecondTimeNow();
						SceneUnicastIdRSP = sceneId;
						while(pthread_mutex_trylock(&mutexDvOnline) != 0){
							usleep (3000);
						}
						FlagRSP = true;
						StrCmdRsp = DVValue;
						string GetStatus = "SELECT DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue"
							" FROM EventTriggerOutputDeviceSetupValue WHERE EventTriggerId = '"+SceneIdRSP+"';";
						// cout << GetStatus << endl;
						DB_ReadGHA(mosq, "GET_STATUS_SCENE", GetStatus);
						pthread_mutex_unlock(&mutexDvOnline);
						FlagSceneRSP = true;
					}
				}
			}
		}
	}
}

void RspSetSceneRemote(struct mosquitto *mosq, char* jobj,string typeRemote){
	Document document;
	document.Parse(jobj);
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	string buttonID = DATA["BUTTONID"].GetString();
	int modeID = DATA["MODEID"].GetInt();
	int sceneID = DATA["SCENEID"].GetInt();
	if(1){
		json.StartObject();
			json.Key("CMD");json.String("SCENE_FOR_REMOTE");
			json.Key("DATA");
			json.StartObject();
				json.Key("DEVICE_ID");
				string DEVICE_ID = GetUUId(mosq, adr);
				json.String(const_cast<char*>(DEVICE_ID.c_str()));
				json.Key("BUTTON_VALUE");json.String(const_cast<char*>(buttonID.c_str()));
				json.Key("MODE_VALUE");json.Int(modeID);
				json.Key("SCENE_ID");
				string checkScene = "SELECT EventTriggerId FROM EventTrigger WHERE SceneUnicastID ="+to_string(sceneID)+";";
				CONTROLSL="";
				DB_ReadGHA(mosq, "CONTROL", checkScene);
				json.String(const_cast<char*>(CONTROLSL.c_str()));
			json.EndObject();
		json.EndObject();

		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}

void RspDelSceneRemote(struct mosquitto *mosq, char* jobj,string typeRemote){
	Document document;
	document.Parse(jobj);
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	string buttonID = DATA["BUTTONID"].GetString();
	int modeID = DATA["MODEID"].GetInt();
	string valueCmd = "";
	json.StartObject();
		json.Key("CMD");json.String("DELETE_SCENE_FOR_REMOTE");
		json.Key("DATA");
		json.StartObject();
			json.Key("DEVICE_ID");
			string DEVICE_ID = GetUUId(mosq, adr);
			json.String(const_cast<char*>(DEVICE_ID.c_str()));
			json.Key("BUTTON_VALUE");json.String(const_cast<char*>(buttonID.c_str()));
			json.Key("MODE_VALUE");json.Int(modeID);
			json.Key("SCENE_ID");json.String(const_cast<char*>(sceneIdDelRemote.c_str()));
		json.EndObject();
	json.EndObject();
	cout << sendToApp.GetString() << endl;
	string s = sendToApp.GetString();
	MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
}

void RspScreenTouch(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int SceneUnicastIdButtonRSP = DATA["SCENEID"].GetInt();
	string checkScene = "SELECT EventTriggerId FROM EventTrigger WHERE SceneUnicastID ="+to_string(SceneUnicastIdButtonRSP)+";";
	CONTROLSL="";
	DB_ReadGHA(mosq, "CONTROL", checkScene);
	string SceneId = CONTROLSL;
	if(SceneUnicastIdButtonRSP != 0){
		CONTROLSL = "";
		string sql = "SELECT EventTriggerId FROM EventTriggerID WHERE SceneUnicastID = "+ to_string(SceneUnicastIdButtonRSP)+";";
		DB_ReadGHA(mosq, "CONTROL", sql);
		SceneIdRSP = CONTROLSL;
		#if LOG_ACTIONS
		SendLogScene(SceneIdRSP);
		#endif
		ADRSL = -1;
		string CheckTypeScene = "SELECT EventTriggerTypeId FROM EventTrigger WHERE SceneUnicastID = "+ to_string(SceneUnicastIdButtonRSP)+";";
		DB_ReadGHA(mosq, "ADR", CheckTypeScene);
		int TypeScene = ADRSL;
		if(TypeScene == 10){
			GetDvSceneDelayInput(SceneId);
			GetGrSceneDelayInput(SceneId);
		}
		else{
			TimeWaitRSP = GetSecondTimeNow();
			bool FlagCheckLock = false;
			while (FlagCheckLock == false){
				if(pthread_mutex_trylock(&mutexDvOnline) == 0){
					FlagRSP = true;
					StrCmdRsp = DVValue;
					string GetStatus = "SELECT DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue"
						" FROM EventTriggerOutputDeviceSetupValue WHERE EventTriggerId = '"+SceneIdRSP+"';";
					DB_ReadGHA(mosq, "GET_STATUS_SCENE", GetStatus);
					FlagCheckLock = true;
					pthread_mutex_unlock(&mutexDvOnline);
				}
				usleep (3000);
			}
		}
	}
}

void RspGroup(char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int GroupUnicastIdButtonRSP = DATA["GROUPID"].GetInt();
	const Value& PROPERTIES = DATA["PROPERTIES"];
	TimeWaitRSP = GetSecondTimeNow();
	while(pthread_mutex_trylock(&mutexDvOnline) != 0){
		usleep (3000);
	}
	FlagRSP = true;
	StrCmdRsp = DVValue;
	pthread_mutex_unlock(&mutexDvOnline);
	for(rapidjson::SizeType i = 0; i < PROPERTIES.Size(); i++){
		string TypeDV = "";
		int ID = PROPERTIES[i]["ID"].GetInt();
		if(ID == 1 || ID == 2){
			IndexArrayCheck = 0;
			string sql = "SELECT GroupingDeviceMapping.DeviceUnicastId FROM GroupingDeviceMapping INNER JOIN Device ON Device.DeviceUnicastId = GroupingDeviceMapping.DeviceUnicastId"
					" WHERE GroupingDeviceMapping.GroupUnicastId = "+ to_string(GroupUnicastIdButtonRSP)+" AND Device.CategoryId NOT LIKE '13%';";
			// cout << sql << endl;
			DB_ReadGHA(mosq, "GET_ARRAY", sql);
		}
		else if(ID >= 3){
			IndexArrayCheck = 0;
			string sql = "SELECT GroupingDeviceMapping.DeviceUnicastId FROM GroupingDeviceMapping INNER JOIN Device ON Device.DeviceUnicastId = GroupingDeviceMapping.DeviceUnicastId"
					" WHERE GroupingDeviceMapping.GroupUnicastId = "+ to_string(GroupUnicastIdButtonRSP)+" AND Device.CategoryId NOT LIKE '12%';";
			// cout << sql << endl;
			DB_ReadGHA(mosq, "GET_ARRAY", sql);
		}
		else if(ID == 0){
			IndexArrayCheck = 0;
			string sql = "SELECT GroupingDeviceMapping.DeviceUnicastId FROM GroupingDeviceMapping INNER JOIN Device ON Device.DeviceUnicastId = GroupingDeviceMapping.DeviceUnicastId"
					" WHERE GroupingDeviceMapping.GroupUnicastId = "+ to_string(GroupUnicastIdButtonRSP)+" AND Device.CategoryId LIKE '1%';";
			// cout << sql << endl;
			DB_ReadGHA(mosq, "GET_ARRAY", sql);
		}
		int VALUE = PROPERTIES[i]["VALUE"].GetInt();
		bool FlagCheckLock = false;
		while (FlagCheckLock == false){
			if(pthread_mutex_trylock(&mutexDvOnline) == 0){
				for(int j=0; j<IndexArrayCheck; j++){
					int IndexDvOnline = 0;
					IndexDvOnline = SearchDeviceCheckOnline(ArrayCheck[j]);
					if(T_DeviceCheckOnline[IndexDvOnline].CurrentStatus == STATUS_ONLINE){
						QueueMsgRSP(ArrayCheck[j], ID, VALUE, 0);
					}
				}
				FlagCheckLock = true;
				pthread_mutex_unlock(&mutexDvOnline);
				break;
			}
			usleep (3000);
		}
	}
}

void RspSwitchModeDevice(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int GroupUnicastIdRSP = DATA["GROUPID"].GetInt();
	int MODE = DATA["MODE"].GetInt();
	TimeWaitRSP = GetSecondTimeNow();
	IndexArrayCheck = 0;
	if(GroupUnicastIdRSP != 65535){
		string sql = "SELECT DeviceUnicastId FROM GroupingDeviceMapping WHERE GroupUnicastId = "+ to_string(GroupUnicastIdRSP)+";";
		DB_ReadGHA(mosq, "GET_ARRAY", sql);
	}
	else{
		string sql = "SELECT DeviceUnicastId FROM Device WHERE CategoryId LIKE '1%';";
		DB_ReadGHA(mosq, "GET_ARRAY", sql);
	}
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutexDvOnline) == 0 && pthread_mutex_trylock(&mutexUpdateDvValue) == 0){
			FlagRSP = true;
			StrCmdRsp = DVValue;
			for(int j=0; j<IndexArrayCheck; j++){
				int IndexDvOnline = SearchDeviceCheckOnline(ArrayCheck[j]);
				if(IndexDvOnline != -1 && T_DeviceCheckOnline[IndexDvOnline].CurrentStatus == STATUS_ONLINE){
					int IndexDvGetStatus = SearchDeviceUpdateValue(ArrayCheck[j]);
					for(int k=1; k<=(T_Device[IndexDvGetStatus].AttDevice[0]/2);k++){
						if(MODE == REMOTE_MUL_SWITCH_CCT){
							if(T_Device[IndexDvGetStatus].AttDevice[k*2-1] == 2 || T_Device[IndexDvGetStatus].AttDevice[k*2-1] == 1){
								QueueMsgRSP(ArrayCheck[j], T_Device[IndexDvGetStatus].AttDevice[k*2-1], T_Device[IndexDvGetStatus].AttDevice[k*2], 2);
							}
						}
						else if(MODE == REMOTE_MUL_SWITCH_RGB){
							if(T_Device[IndexDvGetStatus].AttDevice[k*2-1] == 3 || T_Device[IndexDvGetStatus].AttDevice[k*2-1] == 4 || T_Device[IndexDvGetStatus].AttDevice[k*2-1]){
								QueueMsgRSP(ArrayCheck[j], T_Device[IndexDvGetStatus].AttDevice[k*2-1], T_Device[IndexDvGetStatus].AttDevice[k*2], 2);
							}
						}
					}
				}
			}
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutexDvOnline);
			pthread_mutex_unlock(&mutexUpdateDvValue);
		}
		usleep (3000);
	}
}
