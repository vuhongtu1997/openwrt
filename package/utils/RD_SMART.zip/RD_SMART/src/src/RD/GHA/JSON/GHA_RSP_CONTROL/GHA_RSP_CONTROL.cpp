/*
 * GHA_RSP_CONTROL.cpp
 *
 *  Created on: Jan 8, 2022
 *      Author: rd
 */

#include "GHA_RSP_CONTROL.hpp"

void RspOnOff(struct mosquitto *mosq, char* jobj){
	TimeWaitRSP = GetSecondTimeNow();
	while(pthread_mutex_trylock(&mutexDvOnline) != 0){
		usleep (3000);
	}
	FlagRSP = true;
	StrCmdRsp = DVValue;
	pthread_mutex_unlock(&mutexDvOnline);
	FlagSceneRSP = false;
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int deviceUnicast = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(deviceUnicast) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	string TempDeviceId = CONTROLSL;
	ADRSL = -1;
	sql = "SELECT CategoryId FROM Device WHERE DeviceUnicastId = " + to_string(deviceUnicast) + ";";
	DB_ReadGHA(mosq, "ADR", sql);
	int TempDeviceTypeId = ADRSL;
	string deviceId = "";
	if(deviceUnicast>0 && deviceUnicast<49152 && TempDeviceId.compare("") != 0){
		int sendToCloud = 0;
		int value = DATA["VALUE_ONOFF"].GetInt();
		if (TempDeviceTypeId == SWITCH_RGB_1 || TempDeviceTypeId == SWITCH_RGB_1_NL	||
				TempDeviceTypeId == SWITCH_RGB_2 || TempDeviceTypeId == SWITCH_RGB_3 ||
				TempDeviceTypeId == SWITCH_RGB_4 || TempDeviceTypeId == CDT_1_NL ||
				TempDeviceTypeId == CDT_1 || TempDeviceTypeId == CDT_2 ||
				TempDeviceTypeId == CDT_3 || TempDeviceTypeId == CDT_4 ||
				TempDeviceTypeId == CDT_1_N || TempDeviceTypeId == CDT_2_N ||
				TempDeviceTypeId == SWITCH_RGB_1N || TempDeviceTypeId == SWITCH_RGB_2N ||
				TempDeviceTypeId == SWITCH_RGB_3N || TempDeviceTypeId == SWITCH_RGB_4N ||
				TempDeviceTypeId == SWITCH_RGB_1N_V || TempDeviceTypeId == SWITCH_RGB_2N_V ||
				TempDeviceTypeId == SWITCH_RGB_3N_V || TempDeviceTypeId == SWITCH_RGB_4N_V ||
				TempDeviceTypeId == SWITCH_RGB_1_V || TempDeviceTypeId == SWITCH_RGB_2_V || 
				TempDeviceTypeId == SWITCH_RGB_3_V || TempDeviceTypeId == SWITCH_RGB_4_V || 
				TempDeviceTypeId == SOCKET_SWITCH_1 || TempDeviceTypeId == SWITCH_ON_OFF || TempDeviceTypeId == SWITCH_ON_OFF_INPUT ||
				TempDeviceTypeId == CT_AT_2N || TempDeviceTypeId == CT_AT_3N ||
				TempDeviceTypeId == CT_AT_5N || TempDeviceTypeId == CDT_3_N ||
				TempDeviceTypeId == SWITCH_RGB_BLEWF_1 || TempDeviceTypeId == SWITCH_RGB_BLEWF_2 ||
				TempDeviceTypeId == SWITCH_RGB_BLEWF_3 || TempDeviceTypeId == SWITCH_RGB_BLEWF_4 ||
				TempDeviceTypeId == CDT_BLEWF_1 || TempDeviceTypeId == CDT_BLEWF_2 || TempDeviceTypeId == CDT_BLEWF_3) {	
			ADRSL = -1;
			sql = "SELECT ParentDeviceUnicastId FROM SubDevice WHERE ChildDeviceUnicastId = " + to_string(deviceUnicast) + ";";
			DB_ReadGHA(mosq, "ADR", sql);
			int tempParentUnicast = ADRSL;
			int buttonId = 11;
			if (tempParentUnicast > 0)
			{
				buttonId = buttonId - tempParentUnicast + deviceUnicast;
			}
			StringBuffer sendToApp;
			Writer<StringBuffer> json(sendToApp);
			json.StartObject();
				json.Key("CMD");json.String("DEVICE");
				json.Key("DATA");
				json.StartArray();
				json.StartObject();
					json.Key("DEVICE_ID");
					deviceId = GetUUId(mosq, deviceUnicast);
					json.String(const_cast<char*>(deviceId.c_str()));
					json.Key("PROPERTIES");
					json.StartArray();
					json.StartObject();
					json.Key("ID");json.Int(0);
					json.Key("VALUE");json.Int(value);
					json.EndObject();
					json.StartObject();
					json.Key("ID");json.Int(buttonId);
					json.Key("VALUE");json.Int(value);
					json.EndObject();
					json.StartObject();
					json.Key("ID");json.Int(61);
					json.Key("VALUE");json.Int(1);
					json.EndObject();
					json.EndArray();
					json.EndObject();
				json.EndArray();
			json.EndObject();
			cout << sendToApp.GetString() << endl;
			string s = sendToApp.GetString();
			MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
			UpdateDeviceAttributeValue(deviceId, deviceUnicast, 0, value);
		}
		else
		{
			QueueMsgRSP(deviceUnicast, 0, value, 0);
		}
		Event(mosq, jobj);
	}
}

/*TODO: DONE*/
void RspCCT(struct mosquitto *mosq, char* jobj){
	TimeWaitRSP = GetSecondTimeNow();
	while(pthread_mutex_trylock(&mutexDvOnline) != 0){
		usleep (3000);
	}
	FlagRSP = true;
	StrCmdRsp = DVValue;
	pthread_mutex_unlock(&mutexDvOnline);
	FlagSceneRSP = false;
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt()-1;
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(adr) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	if(adr>0 && adr<49152 && CONTROLSL.compare("") != 0){
		int value = DATA["VALUE_CCT"].GetInt();
		QueueMsgRSP(adr, 2, value, 0);
		QueueMsgRSP(adr, 71, 0, 0);
	}
}

/*TODO: DONE*/
void RspDim(struct mosquitto *mosq, char* jobj){
	TimeWaitRSP = GetSecondTimeNow();
	while(pthread_mutex_trylock(&mutexDvOnline) != 0){
		usleep (3000);
	}
	FlagRSP = true;
	StrCmdRsp = DVValue;
	pthread_mutex_unlock(&mutexDvOnline);
	FlagSceneRSP = false;
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int deviceUnicast = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(deviceUnicast) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	if(deviceUnicast>0 && deviceUnicast<49152 && CONTROLSL.compare("") != 0){
		int value = DATA["VALUE_DIM"].GetInt();
		if(value == 0){
			QueueMsgRSP(deviceUnicast, 0, 0, 0);
		}
		else{
			QueueMsgRSP(deviceUnicast, 1, value, 0);
		}
	}
}

/*TODO: DONE*/
void RspHSL(struct mosquitto *mosq, char* jobj){
	TimeWaitRSP = GetSecondTimeNow();
	while(pthread_mutex_trylock(&mutexDvOnline) != 0){
		usleep (3000);
	}
	FlagRSP = true;
	StrCmdRsp = DVValue;
	pthread_mutex_unlock(&mutexDvOnline);
	FlagSceneRSP = false;
	FlagHSLRSP = false;
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(adr) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	CONTROLSL = "";
	DB_ReadGHA(mosq, "CONTROL", sql);
	if(adr>0 && adr<49152 && CONTROLSL.compare("") != 0){
		int TemValue = 0;
		int H = DATA["VALUE_H"].GetInt();
		int S = DATA["VALUE_S"].GetInt();
		QueueMsgRSP(adr, 3, H, 0);
		QueueMsgRSP(adr, 4, S, 0);
		QueueMsgRSP(adr, 71, 1, 0);
		// bool FlagCheckLock = false;
		// while (FlagCheckLock == false){
		// 	if(pthread_mutex_trylock(&mutexUpdateDvValue) == 0){
		// 		int IndexDv = SearchDeviceUpdateValue(adr);
		// 		for (int i = 1; i <= (T_Device[IndexDv].AttDevice[0]/2); i++) {
		// 			if (T_Device[IndexDv].AttDevice[i*2-1]==5) {
		// 				TemValue = T_Device[IndexDv].AttDevice[i*2];
		// 				break;
		// 			}
		// 		}
		// 		FlagCheckLock = true;
		// 		pthread_mutex_unlock(&mutexUpdateDvValue);
		// 		break;
		// 	}
		// 	usleep (3000);
		// }
		int L = DATA["VALUE_L"].GetInt();
		// QueueMsgRSP(adr, 5, TemValue, 0);
		QueueMsgRSP(adr, 5, L, 0);
	}
}

void RspModeRGB(struct mosquitto *mosq, char* jobj){
	TimeWaitRSP = GetSecondTimeNow();
	while(pthread_mutex_trylock(&mutexDvOnline) != 0){
		usleep (3000);
	}
	FlagRSP = true;
	StrCmdRsp = DVValue;
	pthread_mutex_unlock(&mutexDvOnline);
	FlagSceneRSP = false;
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int deviceUnicast = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(deviceUnicast) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	if(deviceUnicast>0 && deviceUnicast<49152 && CONTROLSL.compare("") != 0){
		int value = DATA["SRGBID"].GetInt();
		CONTROLSL = "";
		string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(deviceUnicast) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
		DB_ReadGHA(mosq, "CONTROL", sql);
		QueueMsgRSP(deviceUnicast, 23, value, 0);
	}
}

void RspSwitch(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int deviceUnicast = DATA["DEVICE_UNICAST_ID"].GetInt();
	if(deviceUnicast>0 && deviceUnicast<49152 && CONTROLSL.compare("") != 0){
		int value = DATA["RELAY_STATUS"].GetInt();
		int DeviceAttId = 0;
		int RELAY_ID = DATA["RELAY_ID"].GetInt();
		if(RELAY_ID == 1){
			DeviceAttId = 11;
		}
		else if(RELAY_ID == 2){
			DeviceAttId = 12;
		}
		else if(RELAY_ID == 3){
			DeviceAttId = 13;
		}
		else if(RELAY_ID == 4){
			DeviceAttId = 14;
		}
		ADRSL = -1;
		string sql = "SELECT CategoryId FROM Device WHERE DeviceUnicastId = " + to_string(deviceUnicast) + ";";
		DB_ReadGHA(mosq, "ADR", sql);
		int TempDeviceTypeId = ADRSL;
		if (TempDeviceTypeId > 22011)
		{
			DeviceAttId = 0;
			deviceUnicast =+ RELAY_ID-1;
		}
		CONTROLSL = "";
		sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(deviceUnicast) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
		DB_ReadGHA(mosq, "CONTROL", sql);
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
			json.Key("CMD");json.String("DEVICE");
			json.Key("DATA");
			json.StartArray();
			json.StartObject();
				json.Key("DEVICE_ID");
				string deviceId = GetUUId(mosq, deviceUnicast);
				json.String(const_cast<char*>(deviceId.c_str()));
				json.Key("PROPERTIES");
				json.StartArray();
				json.StartObject();
				json.Key("ID");json.Int(DeviceAttId);
				json.Key("VALUE");json.Int(value);
				json.EndObject();
				json.EndArray();
				json.EndObject();
			json.EndArray();
		json.EndObject();
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
		QueueMsgRSP(deviceUnicast, DeviceAttId, value, 1);
	}
}

void RspControl(struct mosquitto *mosq, char* jobj){
	bool FlagCheckDevice = false;
	Document document;
	document.Parse(jobj);
	string Cmd = document["CMD"].GetString();
	const Value& DATA = document["DATA"];
	int DeviceUnicast = DATA["DEVICE_UNICAST_ID"].GetInt();
	string DeviceId = GetUUId(mosq, DeviceUnicast);
	if(DATA.HasMember("BUTTON_ID")){
		FlagCheckDevice = true;
		int TempButtonId = DATA["BUTTON_ID"].GetInt();
		if(TempButtonId > 11 && TempButtonId < 17){
			DeviceId = to_string(TempButtonId) + DeviceId.substr(2, (DeviceId.length()-2));
		}
	}
	const Value& PROPERTIES = DATA["PROPERTIES"];
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	json.StartObject();
	json.Key("CMD");
	if(Cmd.compare("DEVICE_CONTROL")==0){
		json.String("DEVICE");
	}
	else if(Cmd.compare("DEVICE_CALIB")==0){
		json.String("DEVICE_CALIB");
	}
	json.Key("DATA");
	json.StartArray();
	json.StartObject();
	json.Key("DEVICE_ID");
	json.String(const_cast<char*>(DeviceId.c_str()));
	json.Key("PROPERTIES");
	json.StartArray();
	for (rapidjson::SizeType i = 0; i < PROPERTIES.Size(); i++){
		int ID = PROPERTIES[i]["ID"].GetInt();
		int VALUE = PROPERTIES[i]["VALUE"].GetInt();
		if (ID == 56)
		{
			VALUE = 1;
		}
		json.StartObject();
		json.Key("ID");json.Int(ID);
		json.Key("VALUE");json.Int(VALUE);
		json.EndObject();
		switch (ID)
		{
			case 55:
				json.StartObject();
				json.Key("ID");json.Int(54);
				json.Key("VALUE");json.Int(0);
				json.EndObject();
				json.StartObject();
				json.Key("ID");json.Int(56);
				json.Key("VALUE");json.Int(0);
				json.EndObject();
			break;
			case 54:
				json.StartObject();
				json.Key("ID");json.Int(55);
				json.Key("VALUE");json.Int(0);
				json.EndObject();
				json.StartObject();
				json.Key("ID");json.Int(56);
				json.Key("VALUE");json.Int(0);
				json.EndObject();
			break;
			case 56:
				json.StartObject();
				json.Key("ID");json.Int(54);
				json.Key("VALUE");json.Int(0);
				json.EndObject();
				json.StartObject();
				json.Key("ID");json.Int(55);
				json.Key("VALUE");json.Int(0);
				json.EndObject();
			break;
		}
		if(FlagCheckDevice == false){
			QueueMsgRSP(DeviceUnicast, ID, VALUE, 1);
		}
	}
	json.EndArray();
	json.EndObject();
	json.EndArray();
	json.EndObject();
	cout << sendToApp.GetString() << endl;
	string s = sendToApp.GetString();
	MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
}

void RspCurtain(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	string CMD = document["CMD"].GetString();
	const Value& DATA = document["DATA"];
	int DeviceUnicast = DATA["DEVICE_UNICAST_ID"].GetInt();
	int VALUE = DATA["PERCENT"].GetInt();
	int ButtonId = 0;
	bool HasButton = false;
	string sql = "SELECT CategoryId FROM Device WHERE DeviceUnicastId = " + to_string(DeviceUnicast) + ";";
	DB_ReadGHA(mosq, "ADR", sql);
	int DeviceTypeId = ADRSL;
	if(DATA.HasMember("BUTTONID")){
		HasButton = true;
		ButtonId  = DATA["BUTTONID"].GetInt();
		switch (ButtonId)
		{
			case 0:
				ButtonId = 55;
			break;
			case 1:
				ButtonId = 54;
			break;
			case 2:
				ButtonId = 56;
			break;
		}
	}
	int ValueButton = 1;
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	json.StartObject();
	json.Key("CMD");
	json.String("DEVICE");
	json.Key("DATA");
	json.StartArray();
	json.StartObject();
	json.Key("DEVICE_ID");
	string DeviceId = GetUUId(mosq, DeviceUnicast);
	json.String(const_cast<char*>(DeviceId.c_str()));
	json.Key("PROPERTIES");
	json.StartArray();
		json.StartObject();
		json.Key("ID");json.Int(57);
		json.Key("VALUE");json.Int(VALUE);
		json.EndObject();
		if(HasButton){
			json.StartObject();
			json.Key("ID");json.Int(ButtonId);
			json.Key("VALUE");json.Int(ValueButton);
			json.EndObject();
			switch (ButtonId)
			{
				case 55:
					json.StartObject();
					json.Key("ID");json.Int(54);
					json.Key("VALUE");json.Int(0);
					json.EndObject();
					json.StartObject();
					json.Key("ID");json.Int(56);
					json.Key("VALUE");json.Int(0);
					json.EndObject();
				break;
				case 54:
					json.StartObject();
					json.Key("ID");json.Int(55);
					json.Key("VALUE");json.Int(0);
					json.EndObject();
					json.StartObject();
					json.Key("ID");json.Int(56);
					json.Key("VALUE");json.Int(0);
					json.EndObject();
				break;
				case 56:
					json.StartObject();
					json.Key("ID");json.Int(54);
					json.Key("VALUE");json.Int(0);
					json.EndObject();
					json.StartObject();
					json.Key("ID");json.Int(55);
					json.Key("VALUE");json.Int(0);
					json.EndObject();
				break;
			}
		}
		else
		{
			json.StartObject();
			json.Key("ID");json.Int(56);
			json.Key("VALUE");json.Int(1);
			json.EndObject();
			json.StartObject();
			json.Key("ID");json.Int(54);
			json.Key("VALUE");json.Int(0);
			json.EndObject();
			json.StartObject();
			json.Key("ID");json.Int(55);
			json.Key("VALUE");json.Int(0);
			json.EndObject();
		}
	json.EndArray();
	json.EndObject();
	json.EndArray();
	json.EndObject();
	cout << sendToApp.GetString() << endl;
	string s = sendToApp.GetString();
	MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	QueueMsgRSP(DeviceUnicast, 57, VALUE, 1);
}

void RspControlSceneDelay(char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];

	TimeWaitRSP = GetSecondTimeNow();
	while(pthread_mutex_trylock(&mutexDvOnline) != 0){
		usleep (3000);
	}
	FlagRSP = true;
	StrCmdRsp = DVValue;
	pthread_mutex_unlock(&mutexDvOnline);
	if(DATA.HasMember("UNICAST_ID")){
		int UnicastId = DATA["UNICAST_ID"].GetInt();
		const Value& PROPERTIES = DATA["PROPERTIES"];
		for(rapidjson::SizeType i = 0; i < PROPERTIES.Size(); i++){
			string TypeDV = "";
			int ID = PROPERTIES[i]["ID"].GetInt();
			int VALUE = PROPERTIES[i]["VALUE"].GetInt();
			if(UnicastId >= 49152){
				if(ID == 1 || ID == 2){
					IndexArrayCheck = 0;
					string sql = "SELECT GroupingDeviceMapping.DeviceUnicastId FROM GroupingDeviceMapping INNER JOIN Device ON Device.DeviceUnicastId = GroupingDeviceMapping.DeviceUnicastId"
							" WHERE GroupingDeviceMapping.GroupUnicastId = "+ to_string(UnicastId)+" AND Device.CategoryId NOT LIKE '13%';";
					DB_ReadGHA(mosq, "GET_ARRAY", sql);
				}
				else if(ID >= 3){
					IndexArrayCheck = 0;
					string sql = "SELECT GroupingDeviceMapping.DeviceUnicastId FROM GroupingDeviceMapping INNER JOIN Device ON Device.DeviceUnicastId = GroupingDeviceMapping.DeviceUnicastId"
							" WHERE GroupingDeviceMapping.GroupUnicastId = "+ to_string(UnicastId)+" AND Device.CategoryId NOT LIKE '12%';";
					DB_ReadGHA(mosq, "GET_ARRAY", sql);
				}
				else if(ID == 0){
					IndexArrayCheck = 0;
					string sql = "SELECT GroupingDeviceMapping.DeviceUnicastId FROM GroupingDeviceMapping INNER JOIN Device ON Device.DeviceUnicastId = GroupingDeviceMapping.DeviceUnicastId"
							" WHERE GroupingDeviceMapping.GroupUnicastId = "+ to_string(UnicastId)+" AND Device.CategoryId LIKE '1%';";
					DB_ReadGHA(mosq, "GET_ARRAY", sql);
				}
				bool FlagCheckLock = false;
				while (FlagCheckLock == false){
					if(pthread_mutex_trylock(&mutexDvOnline) == 0){
						for(int j=0; j<IndexArrayCheck; j++){
							int IndexDvOnline = 0;
							IndexDvOnline = SearchDeviceCheckOnline(ArrayCheck[j]);
							if(T_DeviceCheckOnline[IndexDvOnline].CurrentStatus == STATUS_ONLINE){
								QueueMsgRSP(ArrayCheck[j], ID, VALUE, 0);
							}
						}
						FlagCheckLock = true;
						pthread_mutex_unlock(&mutexDvOnline);
						break;
					}
					usleep (3000);
				}
			}
			else{
				bool FlagCheckLock = false;
				while (FlagCheckLock == false){
					if(pthread_mutex_trylock(&mutexDvOnline) == 0){
							int IndexDvOnline = 0;
							IndexDvOnline = SearchDeviceCheckOnline(UnicastId);
							if(T_DeviceCheckOnline[IndexDvOnline].CurrentStatus == STATUS_ONLINE){
								QueueMsgRSP(UnicastId, ID, VALUE, 0);
							}
						FlagCheckLock = true;
						pthread_mutex_unlock(&mutexDvOnline);
						break;
					}
					usleep (3000);
				}
			}
		}
	}
	if(DATA.HasMember("SCENE_UNICAST_ID")){
		int SceneUnicastId = DATA["SCENE_UNICAST_ID"].GetInt();
		string SceneId = CONTROLSL;
		if(SceneUnicastId != 0){
			TimeWaitRSP = GetSecondTimeNow();
			CONTROLSL = "";
			string sql = "SELECT EventTriggerId FROM EventTriggerID WHERE SceneUnicastID = "+ to_string(SceneUnicastId)+";";
			// cout << sql << endl;
			DB_ReadGHA(mosq, "CONTROL", sql);
			SceneIdRSP = CONTROLSL;
			SceneUnicastIdRSP = SceneUnicastId;
			while(pthread_mutex_trylock(&mutexDvOnline) != 0){
				usleep (3000);
			}
			FlagRSP = true;
			StrCmdRsp = DVValue;
			pthread_mutex_unlock(&mutexDvOnline);
			FlagSceneRSP = true;
			bool FlagCheckLock = false;
			while (FlagCheckLock == false){
				if(pthread_mutex_trylock(&mutexDvOnline) == 0){
					string GetStatus = "SELECT DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue"
						" FROM EventTriggerOutputDeviceSetupValue WHERE EventTriggerId = '"+SceneIdRSP+"';";
					// cout << GetStatus << endl;
					DB_ReadGHA(mosq, "GET_STATUS_SCENE", GetStatus);
					FlagCheckLock = true;
					pthread_mutex_unlock(&mutexDvOnline);
				}
				usleep (3000);
			}
		}
	}
}

void RspSetupStartStatus(struct mosquitto *mosq, char* jobj)
{
	FlagSceneRSP = false;
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int deviceUnicast = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(deviceUnicast) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	string TempDeviceId = CONTROLSL;
	if(deviceUnicast>0 && deviceUnicast<49152 && TempDeviceId.compare("") != 0){
		int value = DATA["STATUS"].GetInt();
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
			json.Key("CMD");json.String("DEVICE");
			json.Key("DATA");
			json.StartArray();
			json.StartObject();
				json.Key("DEVICE_ID");
				string deviceId = GetUUId(mosq, deviceUnicast);
				json.String(const_cast<char*>(deviceId.c_str()));
				json.Key("PROPERTIES");
				json.StartArray();
				json.StartObject();
				json.Key("ID");json.Int(76);
				json.Key("VALUE");json.Int(value);
				json.EndObject();
				json.EndArray();
				json.EndObject();
			json.EndArray();
		json.EndObject();
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}

void RspSetupModeInput(struct mosquitto *mosq, char* jobj)
{
	FlagSceneRSP = false;
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int deviceUnicast = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(deviceUnicast) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	string TempDeviceId = CONTROLSL;
	if(deviceUnicast>0 && deviceUnicast<49152 && TempDeviceId.compare("") != 0){
		int value = DATA["MODE"].GetInt();
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
			json.Key("CMD");json.String("DEVICE");
			json.Key("DATA");
			json.StartArray();
			json.StartObject();
				json.Key("DEVICE_ID");
				string deviceId = GetUUId(mosq, deviceUnicast);
				json.String(const_cast<char*>(deviceId.c_str()));
				json.Key("PROPERTIES");
				json.StartArray();
				json.StartObject();
				json.Key("ID");json.Int(125);
				json.Key("VALUE");json.Int(value);
				json.EndObject();
				json.EndArray();
				json.EndObject();
			json.EndArray();
		json.EndObject();
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}

/**
 * TODO: recheck rsp
*/
void RspHeatLampMode(struct mosquitto *mosq, char* jobj)
{
	FlagSceneRSP = false;
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int deviceUnicast = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(deviceUnicast) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	string TempDeviceId = CONTROLSL;
	if(deviceUnicast>0 && deviceUnicast<49152 && TempDeviceId.compare("") != 0){
		int status = DATA["STATUS"].GetInt();
		int mode = -1;
		int statusLight = -1;
		int coolingfan = -1;
		int fan = -1;
		int heating = -1;
		switch (status)
		{
			case 128:
				mode = 4;
				fan = 0;
				statusLight = 0;
				coolingfan = 0;
				heating = 0;
			break;
			case 1:
				fan = 0;
				statusLight = 1;
				coolingfan = 0;
				heating = 0;
			break;
			case 2:
				fan = 1;
				statusLight = 0;
				coolingfan = 0;
				heating = 0;
			break;
			case 4:
				fan = 0;
				statusLight = 0;
				coolingfan = 1;
				heating = 0;
			break;
			case 24:
				mode = 1;
				fan = 0;
				statusLight = 0;
				coolingfan = 1;
				heating = 2;
			break;
			case 8:
				mode = 2;
				fan = 0;
				statusLight = 0;
				coolingfan = 1;
				heating = 1;
			break;
			case 32:
				mode = 3;
				fan = 0;
				statusLight = 0;
				coolingfan = 1;
				heating = 2;
			break;
			case 25:
				mode = 1;
				fan = 0;
				statusLight = 1;
				coolingfan = 1;
				heating = 2;
			break;
			case 9:
				mode = 2;
				fan = 0;
				statusLight = 0;
				coolingfan = 1;
				heating = 1;
			break;
			case 33:
				mode = 3;
				fan = 1;
				statusLight = 1;
				coolingfan = 1;
				heating = 2;
			break;
			case 5:			
				fan = 0;
				statusLight = 1;
				coolingfan = 1;
				heating = 0;
			break;
			case 3:
				fan = 1;
				statusLight = 1;
				coolingfan = 0;
				heating = 0;
			break;
			case 6:
				fan = 1;
				statusLight = 0;
				coolingfan = 1;
				heating = 0;
			break;
			case 7:
				fan = 1;
				statusLight = 1;
				coolingfan = 1;
				heating = 0;
			case 37:
				mode = 3;
				fan = 1;
				statusLight = 1;
				coolingfan = 0;
				heating = 0;
			case 22:
				mode = 3;
				fan = 1;
				statusLight = 0;
				coolingfan = 0;
				heating = 0;
			break;
		}
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
			json.Key("CMD");json.String("DEVICE");
			json.Key("DATA");
			json.StartArray();
			json.StartObject();
				json.Key("DEVICE_ID");
				string deviceId = GetUUId(mosq, deviceUnicast);
				json.String(const_cast<char*>(deviceId.c_str()));
				json.Key("PROPERTIES");
				json.StartArray();				
				if (mode > -1){
					json.StartObject();
					json.Key("ID");json.Int(141);
					json.Key("VALUE");json.Int(mode);
					json.EndObject();
				}
				if (fan > -1){
					json.StartObject();
					json.Key("ID");json.Int(142);
					json.Key("VALUE");json.Int(fan);
					json.EndObject();
				}
				if (coolingfan > -1){
					json.StartObject();
					json.Key("ID");json.Int(143);
					json.Key("VALUE");json.Int(coolingfan);
					json.EndObject();
				}
				if (statusLight > -1){
					json.StartObject();
					json.Key("ID");json.Int(144);
					json.Key("VALUE");json.Int(statusLight);
					json.EndObject();
				}
				if (heating > -1){
					json.StartObject();
					json.Key("ID");json.Int(148);
					json.Key("VALUE");json.Int(heating);
					json.EndObject();
				}
				json.EndArray();
				json.EndObject();
			json.EndArray();
		json.EndObject();
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
		UpdateDeviceAttributeValue(deviceId, deviceUnicast, 142, fan);
		UpdateDeviceAttributeValue(deviceId, deviceUnicast, 141, mode);
		UpdateDeviceAttributeValue(deviceId, deviceUnicast, 143, coolingfan);
		UpdateDeviceAttributeValue(deviceId, deviceUnicast, 144, statusLight);
		UpdateDeviceAttributeValue(deviceId, deviceUnicast, 148, heating);
	}
}

void RspHeatLampOutput(struct mosquitto *mosq, char* jobj)
{
	FlagSceneRSP = false;
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int deviceUnicast = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(deviceUnicast) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	string TempDeviceId = CONTROLSL;
	if(deviceUnicast>0 && deviceUnicast<49152 && TempDeviceId.compare("") != 0)
	{
		int status = DATA["STATUS"].GetInt();
		int light = status & 1;
		int fan = status >> 1 & 1;
		int coolingfan = status  >> 2 & 1;
		int heating1 = status >> 3 & 1;
		int heating2 = status >> 4 & 1;
		int heating = heating1;
		if(heating2 == 1)
			heating = 2;
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
			json.Key("CMD");json.String("DEVICE");
			json.Key("DATA");
			json.StartArray();
			json.StartObject();
				json.Key("DEVICE_ID");
				string deviceId = GetUUId(mosq, deviceUnicast);
				json.String(const_cast<char*>(deviceId.c_str()));
				json.Key("PROPERTIES");
				json.StartArray();
					json.StartObject();
					json.Key("ID");json.Int(142);
					json.Key("VALUE");json.Int(fan);
					json.EndObject();
					json.StartObject();
					json.Key("ID");json.Int(143);
					json.Key("VALUE");json.Int(coolingfan);
					json.EndObject();
					json.StartObject();
					json.Key("ID");json.Int(144);
					json.Key("VALUE");json.Int(light);
					json.EndObject();
					json.StartObject();
					json.Key("ID");json.Int(148);
					json.Key("VALUE");json.Int(heating);
					json.EndObject();
				json.EndArray();
				json.EndObject();
			json.EndArray();
		json.EndObject();
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
		UpdateDeviceAttributeValue(deviceId, deviceUnicast, 142, fan);
		UpdateDeviceAttributeValue(deviceId, deviceUnicast, 143, coolingfan);
		UpdateDeviceAttributeValue(deviceId, deviceUnicast, 144, light);
		UpdateDeviceAttributeValue(deviceId, deviceUnicast, 148, heating);
	}
}

void RspHeatLampTimeOff(struct mosquitto *mosq, char* jobj)
{
	FlagSceneRSP = false;
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int deviceUnicast = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(deviceUnicast) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	string TempDeviceId = CONTROLSL;
	if(deviceUnicast>0 && deviceUnicast<49152 && TempDeviceId.compare("") != 0){
		int value = DATA["STATUS"].GetInt();
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
			json.Key("CMD");json.String("DEVICE");
			json.Key("DATA");
			json.StartArray();
			json.StartObject();
				json.Key("DEVICE_ID");
				string deviceId = GetUUId(mosq, deviceUnicast);
				json.String(const_cast<char*>(deviceId.c_str()));
				json.Key("PROPERTIES");
				json.StartArray();
				json.StartObject();
				json.Key("ID");json.Int(145);
				json.Key("VALUE");json.Int(value);
				json.EndObject();
				json.EndArray();
				json.EndObject();
			json.EndArray();
		json.EndObject();
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}

void RspHeatLampTimeDry(struct mosquitto *mosq, char* jobj)
{
	FlagSceneRSP = false;
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int deviceUnicast = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(deviceUnicast) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	string TempDeviceId = CONTROLSL;
	if(deviceUnicast>0 && deviceUnicast<49152 && TempDeviceId.compare("") != 0){
		int value = DATA["STATUS"].GetInt();
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
			json.Key("CMD");json.String("DEVICE");
			json.Key("DATA");
			json.StartArray();
			json.StartObject();
				json.Key("DEVICE_ID");
				string deviceId = GetUUId(mosq, deviceUnicast);
				json.String(const_cast<char*>(deviceId.c_str()));
				json.Key("PROPERTIES");
				json.StartArray();
				json.StartObject();
				json.Key("ID");json.Int(146);
				json.Key("VALUE");json.Int(value);
				json.EndObject();
				json.EndArray();
				json.EndObject();
			json.EndArray();
		json.EndObject();
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}

void RspHeatLampPeriodDry(struct mosquitto *mosq, char* jobj)
{
	FlagSceneRSP = false;
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int deviceUnicast = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(deviceUnicast) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	string TempDeviceId = CONTROLSL;
	if(deviceUnicast>0 && deviceUnicast<49152 && TempDeviceId.compare("") != 0){
		int value = DATA["STATUS"].GetInt();
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
			json.Key("CMD");json.String("DEVICE");
			json.Key("DATA");
			json.StartArray();
			json.StartObject();
				json.Key("DEVICE_ID");
				string deviceId = GetUUId(mosq, deviceUnicast);
				json.String(const_cast<char*>(deviceId.c_str()));
				json.Key("PROPERTIES");
				json.StartArray();
				json.StartObject();
				json.Key("ID");json.Int(147);
				json.Key("VALUE");json.Int(value);
				json.EndObject();
				json.EndArray();
				json.EndObject();
			json.EndArray();
		json.EndObject();
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}
