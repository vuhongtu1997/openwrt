/*
 * GHA_RSP_SENSOR.cpp
 *
 *  Created on: Jan 9, 2022
 *      Author: rd
 */

#include "GHA_RSP_SENSOR.hpp"

void RspLux(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(adr) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	if(adr>0 && adr<49152 && CONTROLSL.compare("") != 0){
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
			json.Key("CMD");json.String("DEVICE");
			json.Key("DATA");
			json.StartArray();
			json.StartObject();
				json.Key("DEVICE_ID");
				string deviceId = GetUUId(mosq, adr);
				json.String(const_cast<char*>(deviceId.c_str()));
				json.Key("DEVICE_UNICAST_ID");
				json.Int(adr);
				json.Key("PROPERTIES");
				json.StartArray();
				json.StartObject();
				json.Key("ID");json.Int(9);
				json.Key("VALUE");json.Int(DATA["LUX_VALUE"].GetInt());
				json.EndObject();
				json.EndArray();
				json.EndObject();
			json.EndArray();
		json.EndObject();
		QueueMsgRSP(adr, LIGHT_VALUE, DATA["LUX_VALUE"].GetInt(), 1);
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}

void RspPir(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(adr) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	int SceneUnicastIdPirRSP = DATA["SCENEID"].GetInt();
	if(adr>0 && adr<49152 && CONTROLSL.compare("") != 0){
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
			json.Key("CMD");json.String("DEVICE");
			json.Key("DATA");
			json.StartArray();
			json.StartObject();
				json.Key("DEVICE_ID");
				string deviceId = GetUUId(mosq, adr);
				json.String(const_cast<char*>(deviceId.c_str()));
				json.Key("DEVICE_UNICAST_ID");
				json.Int(adr);
				json.Key("PROPERTIES");
				json.StartArray();
				json.StartObject();
				json.Key("ID");json.Int(10);
				json.Key("VALUE");json.Int(DATA["PIR_VALUE"].GetInt());
				json.EndObject();
				json.EndArray();
			json.EndObject();
			json.EndArray();
		json.EndObject();
		QueueMsgRSP(adr, PIR_VALUE, DATA["PIR_VALUE"].GetInt(), 1);
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
		string checkScene = "SELECT EventTriggerId FROM EventTrigger WHERE SceneUnicastID ="+to_string(SceneUnicastIdPirRSP)+";";
		CONTROLSL="";
		DB_ReadGHA(mosq, "CONTROL", checkScene);
		string SceneId = CONTROLSL;
		if(SceneUnicastIdPirRSP != 0){
			ADRSL = -1;
			string CheckTypeScene = "SELECT EventTriggerTypeId FROM EventTrigger WHERE SceneUnicastID = "+ to_string(SceneUnicastIdPirRSP)+";";
			DB_ReadGHA(mosq, "ADR", CheckTypeScene);
			int TypeScene = ADRSL;
			if(TypeScene == 10){
				GetDvSceneDelayInput(SceneId);
				GetGrSceneDelayInput(SceneId);
			}
			else{
				TimeWaitRSP = GetSecondTimeNow();
				CONTROLSL = "";
				string sql = "SELECT EventTriggerId FROM EventTriggerID WHERE SceneUnicastID = "+ to_string(SceneUnicastIdPirRSP)+";";
				DB_ReadGHA(mosq, "CONTROL", sql);
				SceneIdRSP = CONTROLSL;
				SceneUnicastIdRSP = SceneUnicastIdPirRSP;
				while(pthread_mutex_trylock(&mutexDvOnline) != 0){
					usleep (3000);
				}
				FlagRSP = true;
				StrCmdRsp = DVValue;
				string GetStatus = "SELECT DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue"
					" FROM EventTriggerOutputDeviceSetupValue WHERE EventTriggerId = '"+SceneIdRSP+"';";
				// cout << GetStatus << endl;
				DB_ReadGHA(mosq, "GET_STATUS_SCENE", GetStatus);
				pthread_mutex_unlock(&mutexDvOnline);
				FlagSceneRSP = true;
			}
		}
	}
}

void RspSetScenePir(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	int type = DATA["TYPE"].GetInt();
	if(type ==2){
		json.StartObject();
			json.Key("CMD");
			json.String("SCENE_FOR_SENSOR_LIGHT_PIR");
			json.Key("DATA");
			json.StartObject();
				json.Key("DEVICE_ID");
				string DEVICE_ID = GetUUId(mosq, adr);
				json.String(const_cast<char*>(DEVICE_ID.c_str()));
				json.Key("SCENE_ID");json.String(const_cast<char*>(scenebeforePir.c_str()));
				json.Key("EVENT_TRIGGER_ID");json.String(const_cast<char*>(scenebeforePir.c_str()));
				json.Key("LUX");
				json.StartArray();
				 json.Int(lowlux);
				 json.Int(highlux);
				json.EndArray();
				json.Key("AFTER_PIR_SCENE_ID");json.String(const_cast<char*>(sceneafterPir.c_str()));
			json.EndObject();
		json.EndObject();
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}

void RspSetActionTime(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	int time = DATA["TIME"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(adr) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	if(adr>0 && adr<49152 && CONTROLSL.compare("") != 0){
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
			json.Key("CMD");json.String("DEVICE");
			json.Key("DATA");
			json.StartArray();
			json.StartObject();
				json.Key("DEVICE_ID");
				string deviceId = GetUUId(mosq, adr);
				json.String(const_cast<char*>(deviceId.c_str()));
				json.Key("DEVICE_UNICAST_ID");
				json.Int(adr);
				json.Key("PROPERTIES");
				json.StartArray();
				json.StartObject();
				json.Key("ID");json.Int(ACTION_TIME_PIR);
				json.Key("VALUE");json.Int(time);
				json.EndObject();
				json.EndArray();
				json.EndObject();
			json.EndArray();
		json.EndObject();
		QueueMsgRSP(adr, ACTION_TIME_PIR, time, 1);
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}

void RspDelScenePir(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	json.StartObject();
	 json.Key("CMD");json.String("REMOVE_SCENE_FOR_SENSOR_LIGHT_PIR");
	 json.Key("DATA");
	 json.StartObject();
		json.Key("DEVICE_ID");
		string DEVICE_ID = GetUUId(mosq, adr);
		json.String(const_cast<char*>(DEVICE_ID.c_str()));
		json.Key("EVENT_TRIGGER_ID");
		string checkScene = "SELECT EventTriggerId FROM EventTrigger WHERE SceneUnicastID = "+to_string(DATA["SCENEID"].GetInt())+";";
		cout<<"SQL: "<<checkScene<<endl;
		CONTROLSL="";
		DB_ReadGHA(mosq, "CONTROL", checkScene);
		string Scene = CONTROLSL;
		json.String(const_cast<char*>(Scene.c_str()));
	json.EndObject();
	json.EndObject();

	cout << sendToApp.GetString() << endl;
	string s = sendToApp.GetString();
	MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
}

void RspPower(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(adr) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	if(adr>0 && adr<49152 && CONTROLSL.compare("") != 0){
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
			json.Key("CMD");json.String("DEVICE");
			json.Key("DATA");
			json.StartArray();
			json.StartObject();
				json.Key("DEVICE_ID");
				string deviceId = GetUUId(mosq, adr);
				json.String(const_cast<char*>(deviceId.c_str()));
				json.Key("DEVICE_UNICAST_ID");
				json.Int(adr);
				json.Key("PROPERTIES");
				json.StartArray();
				json.StartObject();
				json.Key("ID");json.Int(8);
				json.Key("VALUE");json.Int(DATA["POWER_VALUE"].GetInt());
				json.EndObject();
				json.EndArray();
			json.EndObject();
			json.EndArray();
		json.EndObject();
		QueueMsgRSP(adr, 8, DATA["POWER_VALUE"].GetInt(), 1);
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}

void RspSmoke(struct mosquitto* mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(adr) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	if(adr>0 && adr<49152 && CONTROLSL.compare("") != 0){
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
			json.Key("CMD");json.String("DEVICE");
			json.Key("DATA");
			json.StartArray();
			json.StartObject();
				json.Key("DEVICE_ID");
				string deviceId = GetUUId(mosq, adr);
				json.String(const_cast<char*>(deviceId.c_str()));
				json.Key("DEVICE_UNICAST_ID");
				json.Int(adr);
				json.Key("PROPERTIES");
				json.StartArray();
				json.StartObject();
				json.Key("ID");json.Int(58);
				json.Key("VALUE");json.Int(DATA["SMOKE_VALUE"].GetInt());
				json.EndObject();
				json.StartObject();
				json.Key("ID");json.Int(60);
				json.Key("VALUE");json.Int(DATA["LOW_BATTERY"].GetInt());
				json.EndObject();
				json.EndArray();
				json.EndObject();
			json.EndArray();
		json.EndObject();
		QueueMsgRSP(adr, 58, DATA["SMOKE_VALUE"].GetInt(), 1);
		QueueMsgRSP(adr, 60, DATA["LOW_BATTERY"].GetInt(), 1);
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}

void RspDoor(struct mosquitto* mosq, char * jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(adr) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	if(adr>0 && adr<49152 && CONTROLSL.compare("") != 0){
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
		json.Key("CMD");json.String("DEVICE");
		json.Key("DATA");
		json.StartArray();
		json.StartObject();
			json.Key("DEVICE_ID");
			string deviceId = GetUUId(mosq, adr);
			json.String(const_cast<char*>(deviceId.c_str()));
			json.Key("DEVICE_UNICAST_ID");
			json.Int(adr);
			json.Key("PROPERTIES");
			json.StartArray();
			if(DATA.HasMember("HANG_VALUE")){
				json.StartObject();
				json.Key("ID");json.Int(24);
				json.Key("VALUE");json.Int(DATA["HANG_VALUE"].GetInt());
				json.EndObject();
				QueueMsgRSP(adr, 24, DATA["HANG_VALUE"].GetInt(), 1);
			}
			if(DATA.HasMember("DOOR_VALUE")){
				json.StartObject();
				json.Key("ID");json.Int(59);
				json.Key("VALUE");json.Int(DATA["DOOR_VALUE"].GetInt());
				json.EndObject();
				QueueMsgRSP(adr, 59, DATA["DOOR_VALUE"].GetInt(), 1);
			}
			json.EndArray();
			json.EndObject();
			json.EndArray();
		json.EndObject();
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}

void RspPm(struct mosquitto* mosq, char * jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(adr) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	if(adr>0 && adr<49152 && CONTROLSL.compare("") != 0){
		if(DATA.HasMember("PM2.5_VALUE") && DATA.HasMember("PM1_VALUE") && DATA.HasMember("PM10_VALUE")){
			StringBuffer sendToApp;
			Writer<StringBuffer> json(sendToApp);
			json.StartObject();
				json.Key("CMD");json.String("DEVICE");
				json.Key("DATA");
				json.StartArray();
				json.StartObject();
					json.Key("DEVICE_ID");
					string deviceId = GetUUId(mosq, adr);
					json.String(const_cast<char*>(deviceId.c_str()));
					json.Key("DEVICE_UNICAST_ID");
					json.Int(adr);
					json.Key("PROPERTIES");
					json.StartArray();
						json.StartObject();
						json.Key("ID");json.Int(18);
						json.Key("VALUE");json.Int(DATA["PM2.5_VALUE"].GetInt());
						json.EndObject();
						json.StartObject();
						json.Key("ID");json.Int(20);
						json.Key("VALUE");json.Int(DATA["PM1_VALUE"].GetInt());
						json.EndObject();
						json.StartObject();
						json.Key("ID");json.Int(19);
						json.Key("VALUE");json.Int(DATA["PM10_VALUE"].GetInt());
						json.EndObject();
						QueueMsgRSP(adr, 18, DATA["PM2.5_VALUE"].GetInt(), 1);
						QueueMsgRSP(adr, 20, DATA["PM1_VALUE"].GetInt(), 1);
						QueueMsgRSP(adr, 19, DATA["PM10_VALUE"].GetInt(), 1);
					json.EndArray();
					json.EndObject();
				json.EndArray();
			json.EndObject();

			cout << sendToApp.GetString() << endl;
			string s = sendToApp.GetString();
			MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
		}
	}
}

void PushTempHumToScreenTouch(int Temp, int Hum, int DeviceAdrIntoRoom){
//	IndexArrayCheck = 0;
//	CONTROLSL = "";
//	string sql = "SELECT RoomId FROM Device WHERE DeviceUnicastId = " + to_string(DeviceAdrIntoRoom) + " AND RoomId IS NOT NULL;";
//	DB_ReadGHA(mosq, "CONTROL", sql);
//	string RoomId = CONTROLSL;
//	if(RoomId != ""){
//		string GetAdrScreenTouch = "SELECT DeviceUnicastId FROM Device WHERE RoomId = '"+RoomId+"' AND CategoryId = 23003;";
//		cout << GetAdrScreenTouch << endl;
//		DB_ReadGHA(mosq, "GET_ARRAY", GetAdrScreenTouch);
//		for(int i=0; i<IndexArrayCheck; i++){
//			StringBuffer sendToGW;
//			Writer<StringBuffer> json(sendToGW);
//			json.StartObject();
//			json.Key("CMD");json.String("WEATHER_IN_SCREEN_TOUCH");
//			json.Key("DATA");
//				json.StartObject();
//				json.Key("DEVICE_UNICAST_ID");
//				json.Int(ArrayCheck[i]);
//				json.Key("TEMPERATURE");
//				json.Int(Temp);
//				json.Key("HUMIDITY");
//				json.Int(Hum);
//				json.EndObject();
//			json.EndObject();
//			string s = sendToGW.GetString();
//			char sendT[s.length()+1] = {0};
//			strcpy(sendT, s.c_str());
//			MqttSend(mosq, sendT);
//			WriteIntoLog("<HC -> GW>", s);
//		}
//	}
	IndexArrayCheck = 0;
	string GetAdrScreenTouch = "SELECT DeviceUnicastId FROM Device WHERE RoomId IS (SELECT RoomId FROM Device WHERE DeviceUnicastId = "
					+ to_string(DeviceAdrIntoRoom) + ") AND CategoryId = 23003;";
	// cout << GetAdrScreenTouch << endl;
	DB_ReadGHA(mosq, "GET_ARRAY", GetAdrScreenTouch);
	for(int i=0; i<IndexArrayCheck; i++){
		StringBuffer sendToGW;
		Writer<StringBuffer> json(sendToGW);
		json.StartObject();
		json.Key("CMD");json.String("WEATHER_IN_SCREEN_TOUCH");
		json.Key("DATA");
			json.StartObject();
			json.Key("DEVICE_UNICAST_ID");
			json.Int(ArrayCheck[i]);
			json.Key("TEMPERATURE");
			json.Int(Temp);
			json.Key("HUMIDITY");
			json.Int(Hum);
			json.EndObject();
		json.EndObject();
		string s = sendToGW.GetString();
		MqttSend(mosq, const_cast<char*>(s.c_str()));
	}
}

void RspTempHum(struct mosquitto* mosq, char * jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(adr) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	// cout << sql << endl;
	DB_ReadGHA(mosq, "CONTROL", sql);
	if(adr>0 && adr<49152 && CONTROLSL.compare("") != 0){
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
			json.Key("CMD");json.String("DEVICE");
			json.Key("DATA");
			json.StartArray();
			json.StartObject();
				json.Key("DEVICE_ID");
				string deviceId = GetUUId(mosq, adr);
				json.String(const_cast<char*>(deviceId.c_str()));
				json.Key("DEVICE_UNICAST_ID");
				json.Int(adr);
				json.Key("PROPERTIES");
				json.StartArray();
				if(DATA.HasMember("TEMPERATURE_VALUE")){
					json.StartObject();
					json.Key("ID");json.Int(21);
					json.Key("VALUE");json.Int(DATA["TEMPERATURE_VALUE"].GetInt());
					json.EndObject();
					
					QueueMsgRSP(adr, 21, DATA["TEMPERATURE_VALUE"].GetInt(), 1);
					
				}
				if(DATA.HasMember("HUMIDITY_VALUE")){
					json.StartObject();
					json.Key("ID");json.Int(22);
					json.Key("VALUE");json.Int(DATA["HUMIDITY_VALUE"].GetInt());
					json.EndObject();
					QueueMsgRSP(adr, 22, DATA["HUMIDITY_VALUE"].GetInt(), 1);
					
				}
				json.EndArray();
				json.EndObject();
			json.EndArray();
		json.EndObject();
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
		
		PushTempHumToScreenTouch(DATA["TEMPERATURE_VALUE"].GetInt(), DATA["HUMIDITY_VALUE"].GetInt(), adr);
	}
}

void RspActionModePir(struct mosquitto *mosq, char* jobj)
{
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(adr) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	if(adr>0 && adr<49152 && CONTROLSL.compare("") != 0){
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
		json.Key("CMD");json.String("DEVICE");
		json.Key("DATA");
		json.StartArray();
		json.StartObject();
			json.Key("DEVICE_ID");
			string deviceId = GetUUId(mosq, adr);
			json.String(const_cast<char*>(deviceId.c_str()));
			json.Key("DEVICE_UNICAST_ID");
			json.Int(adr);
			json.Key("PROPERTIES");
			json.StartArray();
			json.StartObject();
			json.Key("ID");json.Int(ACTION_MODE_PIR);
			json.Key("VALUE");json.Int(DATA["MODE"].GetInt());
			json.EndObject();
			QueueMsgRSP(adr, ACTION_MODE_PIR, DATA["MODE"].GetInt(), 1);
			json.EndArray();
			json.EndObject();
			json.EndArray();
		json.EndObject();
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}

void RspSensorSensi(struct mosquitto *mosq, char* jobj)
{
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(adr) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	if(adr>0 && adr<49152 && CONTROLSL.compare("") != 0){
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
		json.Key("CMD");json.String("DEVICE");
		json.Key("DATA");
		json.StartArray();
		json.StartObject();
			json.Key("DEVICE_ID");
			string deviceId = GetUUId(mosq, adr);
			json.String(const_cast<char*>(deviceId.c_str()));
			json.Key("DEVICE_UNICAST_ID");
			json.Int(adr);
			json.Key("PROPERTIES");
			json.StartArray();
			json.StartObject();
			json.Key("ID");json.Int(SENSOR_SENSI);
			json.Key("VALUE");json.Int(DATA["VALUE"].GetInt());
			json.EndObject();
			QueueMsgRSP(adr, SENSOR_SENSI, DATA["VALUE"].GetInt(), 1);
			json.EndArray();
			json.EndObject();
			json.EndArray();
		json.EndObject();
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}

void RspPirLightStartUp(struct mosquitto *mosq, char* jobj)
{
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(adr) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	int pirValue = DATA["PIR_VALUE"].GetInt();
	int lightValue = DATA["LUX_VALUE"].GetInt();
	if((adr>0) && (adr<49152) && (CONTROLSL != "")){
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
		json.Key("CMD");json.String("DEVICE");
		json.Key("DATA");
		json.StartArray();
		json.StartObject();
			json.Key("DEVICE_ID");
			string deviceId = GetUUId(mosq, adr);
			json.String(const_cast<char*>(deviceId.c_str()));
			json.Key("DEVICE_UNICAST_ID");
			json.Int(adr);
			json.Key("PROPERTIES");
			json.StartArray();
			json.StartObject();
			json.Key("ID");json.Int(PIR_VALUE);
			json.Key("VALUE");json.Int(pirValue);
			json.EndObject();
			json.StartObject();
			json.Key("ID");json.Int(LIGHT_VALUE);
			json.Key("VALUE");json.Int(lightValue);
			json.EndObject();
			json.EndArray();
			json.EndObject();
			json.EndArray();
		json.EndObject();
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		QueueMsgRSP(adr, LIGHT_VALUE, lightValue, 1);
		QueueMsgRSP(adr, PIR_VALUE, pirValue, 1);
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}

void RspSetCountDownPirLight(struct mosquitto *mosq, char* jobj)
{
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(adr) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	int time = DATA["TIME"].GetInt();
	if(adr>0 && adr<49152 && CONTROLSL.compare("") != 0){
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
		json.Key("CMD");json.String("DEVICE");
		json.Key("DATA");
		json.StartArray();
		json.StartObject();
			json.Key("DEVICE_ID");
			string deviceId = GetUUId(mosq, adr);
			json.String(const_cast<char*>(deviceId.c_str()));
			json.Key("DEVICE_UNICAST_ID");
			json.Int(adr);
			json.Key("PROPERTIES");
			json.StartArray();
			json.StartObject();
			json.Key("ID");json.Int(COUNTDOWN);
			json.Key("VALUE");json.Int(time);
			json.EndObject();
			json.EndArray();
			json.EndObject();
			json.EndArray();
		json.EndObject();
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}

void RspSetDistance(struct mosquitto *mosq, char* jobj)
{
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(adr) + " AND DeviceTypeId = "+to_string(DEVICE_BLE)+";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	int time = DATA["VALUE"].GetInt();
	if(adr>0 && adr<49152 && CONTROLSL.compare("") != 0){
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
		json.Key("CMD");json.String("DEVICE");
		json.Key("DATA");
		json.StartArray();
		json.StartObject();
			json.Key("DEVICE_ID");
			string deviceId = GetUUId(mosq, adr);
			json.String(const_cast<char*>(deviceId.c_str()));
			json.Key("DEVICE_UNICAST_ID");
			json.Int(adr);
			json.Key("PROPERTIES");
			json.StartArray();
			json.StartObject();
			json.Key("ID");json.Int(DISTANCE);
			json.Key("VALUE");json.Int(time);
			json.EndObject();
			json.EndArray();
			json.EndObject();
			json.EndArray();
		json.EndObject();
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}