/*
 * GHA_RSP_CONTROL.hpp
 *
 *  Created on: Jan 8, 2022
 *      Author: rd
 */

#ifndef SRC_RD_GHA_JSON_GHA_RSP_CONTROL_GHA_RSP_CONTROL_HPP_
#define SRC_RD_GHA_JSON_GHA_RSP_CONTROL_GHA_RSP_CONTROL_HPP_

#include <iostream>
#include "../JSON_GHA.hpp"

#define BTN_OPEN    54
#define BTN_CLOSE   55
#define BTN_PAUSE   56

void RspOnOff(struct mosquitto *mosq, char* jobj);
void RspCCT(struct mosquitto *mosq, char* jobj);
void RspDim(struct mosquitto *mosq, char* jobj);
void RspHSL(struct mosquitto *mosq, char* jobj);
void RspSwitch(struct mosquitto *mosq, char* jobj);
void RspModeRGB(struct mosquitto *mosq, char* jobj);
void RspControl(struct mosquitto *mosq, char* jobj);
void RspCurtain(struct mosquitto *mosq, char* jobj);
void RspControlSceneDelay(char* jobj);
void RspSetupStartStatus(struct mosquitto *mosq, char* jobj);
void RspSetupModeInput(struct mosquitto *mosq, char* jobj);
void RspHeatLampMode(struct mosquitto *mosq, char* jobj);
void RspHeatLampOutput(struct mosquitto *mosq, char* jobj);
void RspHeatLampTimeOff(struct mosquitto *mosq, char* jobj);
void RspHeatLampTimeDry(struct mosquitto *mosq, char* jobj);
void RspHeatLampPeriodDry(struct mosquitto *mosq, char* jobj);

#endif /* SRC_RD_GHA_JSON_GHA_RSP_CONTROL_GHA_RSP_CONTROL_HPP_ */
