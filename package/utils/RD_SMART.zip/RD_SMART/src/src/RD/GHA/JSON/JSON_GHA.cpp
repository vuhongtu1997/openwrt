/*
 * JSON_GHA.cpp
 *
 *  Created on: Apr 10, 2021
 *      Author: rd
 */

#include "JSON_GHA.hpp"
#include "../../MQTT/MQTT.hpp"

int typeIsSuccess = -1;

int ArrDvRSP[256][20] = {0};
int IndexArrDvRSP = 0;
int TimeWaitRSP = 0;
bool FlagRSP = false;
string StrCmdRsp = "";
bool FlagHSLRSP = false;
bool FlagSceneRSP = false;
string SceneIdRSP = "";
int SceneUnicastIdRSP = 0;
int ArrayCheck[256] = {0};
int IndexArrayCheck = 0;
vector<int> DeviceAddRoomSuccess;

int ArrInfoDvSceneDelayInput[256][4] = {0};
int IndexSceneDelayInput = 0;

string arrayDeviceId[200];

vector<t_SubDevice> SubDevice;

//--------------------------------------------------------DB--------------------------------------------

int ADRSL;
string CONTROLSL = "";
int attributeId_CallScene[16];
int attributeValue_CallScene[16];
int numAttributeId = 0;
static int SQLCALLSCENE(void *data, int argc, char **argv, char **axColName)
{
	try
	{
		string deviceId_CallScene = (const char *)(argv[0]);
		int deviceUnicast_CallScene = atoi((const char *)argv[1]);
		attributeId_CallScene[numAttributeId] = atoi((const char *)argv[2]);
		attributeValue_CallScene[numAttributeId] = atoi((const char *)argv[3]);
		// cout << deviceId_CallScene << ":" << deviceUnicast_CallScene << ":" << attributeId_CallScene[numAttributeId] << ":" << attributeValue_CallScene[numAttributeId] << endl;
		numAttributeId++;
	}
	catch (exception &e)
	{
	}
	return 0;
}

static int GET_STATUS_SCENE(void *data, int argc, char **argv, char **axColName)
{
	try
	{
		int IndexDvOnline = 0;
		IndexDvOnline = SearchDeviceCheckOnline(atoi((const char *)argv[0]));
		if (T_DeviceCheckOnline[IndexDvOnline].CurrentStatus == STATUS_ONLINE)
		{
			QueueMsgRSP(atoi((const char *)argv[0]), atoi((const char *)argv[1]), atoi((const char *)argv[2]), 0);
			// cout << atoi((const char *)argv[0]) << " : " << atoi((const char *)argv[1]) << " : " << atoi((const char *)argv[2]) << endl;
		}
	}
	catch (exception &e)
	{
	}
	return 0;
}

static int SQLADR(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		ADRSL = -1;
		ADRSL = atoi((const char *)argv[0]);
	}
	catch (exception &e)
	{
	}
	return 0;
}

static int SQLCONTROL(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		CONTROLSL = "";
		CONTROLSL = (const char *)(argv[0]);
	}
	catch (exception &e)
	{
	}
	return 0;
}
int indexGetDevId = 0;
static int GetDeviceId(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		arrayDeviceId[indexGetDevId] = (const char *)(argv[0]);
		indexGetDevId++;
	}
	catch (exception &e)
	{
	}
	return 0;
}

static int GET_ARRAY(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		ArrayCheck[IndexArrayCheck] = atoi((const char *)argv[0]);
		IndexArrayCheck++;
	}
	catch (exception &e)
	{
	}
	return 0;
}

static int CheckSceneDelay(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		ArrInfoDvSceneDelayInput[IndexSceneDelayInput][0] = atoi((const char *)argv[0]);
		ArrInfoDvSceneDelayInput[IndexSceneDelayInput][1] = atoi((const char *)argv[1]);
		ArrInfoDvSceneDelayInput[IndexSceneDelayInput][2] = atoi((const char *)argv[2]);
		ArrInfoDvSceneDelayInput[IndexSceneDelayInput][3] = atoi((const char *)argv[3]);
		IndexSceneDelayInput++;
	}
	catch (exception &e)
	{
	}
	return 0;
}

static int GET_SUBDEVICE(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		t_SubDevice TempSubDevice;
		TempSubDevice.ParentDeviceId = (const char *)(argv[0]);
		TempSubDevice.ChildDeviceId = (const char *)(argv[1]);
		TempSubDevice.ChildDeviceUnicastId = atoi((const char *)argv[2]);
		SubDevice.push_back(TempSubDevice);
	}
	catch (exception &e)
	{
	}
	return 0;
}

int DB_ReadGHA(struct mosquitto *mosq, string control, string sql)
{
	sqlite3 *DB;
	int exit = 0;
	do
	{
		exit = sqlite3_open("/root/rd.Sqlite", &DB);
		usleep(1000);
	} while (exit != SQLITE_OK);
	char *messaggeError;
	string code;
	if (control.compare("ADR") == 0)
	{
		while (sqlite3_exec(DB, const_cast<char *>(sql.c_str()), SQLADR, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("CONTROL") == 0)
	{
		while (sqlite3_exec(DB, const_cast<char *>(sql.c_str()), SQLCONTROL, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
		code = CONTROLSL;
	}
	else if (control.compare("CALLSCENE") == 0)
	{
		while (sqlite3_exec(DB, const_cast<char *>(sql.c_str()), SQLCALLSCENE, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("GET_STATUS_SCENE") == 0)
	{
		while (sqlite3_exec(DB, const_cast<char *>(sql.c_str()), GET_STATUS_SCENE, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("GET_ARRAY_DEVICEID") == 0)
	{
		while (sqlite3_exec(DB, const_cast<char *>(sql.c_str()), GetDeviceId, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("GET_ARRAY") == 0)
	{
		while (sqlite3_exec(DB, const_cast<char *>(sql.c_str()), GET_ARRAY, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("CHECK_SCENE_DELAY") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), CheckSceneDelay, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("GET_SUBDEVICE") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), GET_SUBDEVICE, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	sqlite3_close(DB);
	return (0);
}

//----------------------------------------------------------------------------------------------------
void SendTimeScreenTouch(struct mosquitto *mosq, char *jobj)
{
	Document document;
	document.Parse(jobj);
	const Value &DATA = document["DATA"];
	int deviceUnicast = DATA["DEVICE_UNICAST_ID"].GetInt();
	time_t now = time(0);
	tm *ltm = localtime(&now);
	int current_year = 1900 + ltm->tm_year;
	int current_month = 1 + ltm->tm_mon;
	int current_hour = ltm->tm_hour;
	int current_minute = ltm->tm_min;
	int current_second = ltm->tm_sec;
	int current_day = ltm->tm_mday;
	int current_date = 1 + ltm->tm_wday;
	// cout << "data date: " << current_date << endl;
	if (current_date == 1)
	{
		current_date = 8;
	}
	// cout << current_year << ":" << current_month << ":" << current_hour << ":" << current_minute << ":" << current_date << endl;
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	json.StartObject();
	json.Key("CMD");
	json.String("TIME_SCREEN_TOUCH");
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(deviceUnicast);
	json.Key("HOUR");
	json.Int(current_hour);
	json.Key("MINUTE");
	json.Int(current_minute);
	json.Key("SECOND");
	json.Int(current_second);
	json.EndObject();
	json.EndObject();
	cout << sendToApp.GetString() << endl;
	string s = sendToApp.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));

	StringBuffer sendToApp1;
	Writer<StringBuffer> json1(sendToApp1);
	json1.StartObject();
	json1.Key("CMD");
	json1.String("DATE_SCREEN_TOUCH");
	json1.Key("DATA");
	json1.StartObject();
	json1.Key("DEVICE_UNICAST_ID");
	json1.Int(deviceUnicast);
	json1.Key("YEAR");
	json1.Int(current_year);
	json1.Key("MONTH");
	json1.Int(current_month);
	json1.Key("DATE");
	json1.Int(current_day);
	json1.Key("DAY");
	json1.Int(current_date);
	json1.EndObject();
	json1.EndObject();

	cout << sendToApp1.GetString() << endl;
	string s1 = sendToApp1.GetString();
	MqttSend(mosq, const_cast<char *>(s1.c_str()));
}
void SendWeatherScreenTouch(struct mosquitto *mosq, char *jobj)
{
	pthread_mutex_lock(&mutex);
	Document document;
	document.Parse(jobj);
	const Value &DATA = document["DATA"];
	int deviceUnicast = DATA["DEVICE_UNICAST_ID"].GetInt();
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	json.StartObject();
	json.Key("CMD");
	json.String("WEATHER_OUT_SCREEN_TOUCH");
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(deviceUnicast);
	json.Key("STATUS");
	json.Int(screenTouch_statusOutWeather);
	json.Key("TEMPERATURE");
	json.Int(screenTouch_tempOutWeather);
	json.EndObject();
	json.EndObject();

	cout << sendToApp.GetString() << endl;
	string s = sendToApp.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
	pthread_mutex_unlock(&mutex);
}

void DeviceUpdateStatus(char *jobj)
{
	Document document;
	document.Parse(jobj);
	const Value &DATA = document["DATA"];
	int deviceUnicast = DATA["DEVICE_UNICAST_ID"].GetInt();
	bool FlagCheckLock = false;
	while (FlagCheckLock == false)
	{
		if (pthread_mutex_trylock(&mutexDvOnline) == 0)
		{
			int IndexDvOnline = 0;
			IndexDvOnline = SearchDeviceCheckOnline(deviceUnicast);
			if (IndexDvOnline >= 0)
			{
				T_DeviceCheckOnline[IndexDvOnline].TimeCheck = GetSecondTimeNow();
				T_DeviceCheckOnline[IndexDvOnline].PreviousStatus = T_DeviceCheckOnline[IndexDvOnline].CurrentStatus;
				T_DeviceCheckOnline[IndexDvOnline].CurrentStatus = STATUS_ONLINE;
				if (T_DeviceCheckOnline[IndexDvOnline].PreviousStatus == STATUS_OFFLINE)
				{
					string DeviceId = GetUUId(mosq, deviceUnicast);
					StringBuffer sendToApp;
					Writer<StringBuffer> json(sendToApp);
					json.StartObject();
					json.Key("CMD");
					json.String("DEVICE");
					json.Key("DATA");
					json.StartArray();
					json.StartObject();
					json.Key("DEVICE_ID");
					json.String(const_cast<char *>(DeviceId.c_str()));
					json.Key("PROPERTIES");
					json.StartArray();
					json.StartObject();
					json.Key("ID");
					json.Int(62);
					json.Key("VALUE");
					json.Int(STATUS_ONLINE);
					json.EndObject();
					json.EndArray();
					json.EndObject();
					json.EndArray();
					json.EndObject();
					string s = sendToApp.GetString();
					cout << s << endl;
					MqttSendAPP(mosq, const_cast<char *>(s.c_str()), true);
				}
			}
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutexDvOnline);
			break;
		}
		usleep(3000);
	}
	if (DATA.HasMember("PROPERTIES"))
	{
		const Value &PROPERTIES = DATA["PROPERTIES"];
		for (rapidjson::SizeType i = 0; i < PROPERTIES.Size(); i++)
		{
			const Value &a = PROPERTIES[i];
			int ID = a["ID"].GetInt();
			int VALUE = a["VALUE"].GetInt();
			if (ID == 1 && VALUE == 0)
			{
				ID = 0;
				VALUE = 0;
			}
			int TemValue = -1;
			while (pthread_mutex_trylock(&mutexUpdateDvValue) != 0)
			{
				usleep(3000);
			}
			int IndexDv = SearchDeviceUpdateValue(deviceUnicast);
			for (int i = 1; i <= (T_Device[IndexDv].AttDevice[0] / 2); i++)
			{
				if (ID == T_Device[IndexDv].AttDevice[i * 2 - 1])
				{
					TemValue = T_Device[IndexDv].AttDevice[i * 2];
					break;
				}
			}
			pthread_mutex_unlock(&mutexUpdateDvValue);
			if (TemValue != VALUE)
			{
				if (ID == 1 && VALUE == 0)
				{
					QueueMsgRSP(deviceUnicast, 0, 0, 0);
				}
				else if (ID == 5)
				{
					if (TemValue == -1)
					{
						TemValue = VALUE;
					}
					int H = -1;
					int S = -1;
					bool FlagCheckLock = false;
					while (FlagCheckLock == false)
					{
						if (pthread_mutex_trylock(&mutexUpdateDvValue) == 0)
						{
							int IndexDv = SearchDeviceUpdateValue(deviceUnicast);
							for (int j = 1; j <= (T_Device[IndexDv].AttDevice[0] / 2); j++)
							{
								if (T_Device[IndexDv].AttDevice[j * 2 - 1] == 5)
								{
									T_Device[IndexDv].AttDevice[j * 2] = TemValue;
								}
								else if (T_Device[IndexDv].AttDevice[j * 2 - 1] == 4)
								{
									S = T_Device[IndexDv].AttDevice[j * 2];
								}
								else if (T_Device[IndexDv].AttDevice[j * 2 - 1] == 3)
								{
									H = T_Device[IndexDv].AttDevice[j * 2];
								}
							}
							FlagCheckLock = true;
							pthread_mutex_unlock(&mutexUpdateDvValue);
							break;
						}
						usleep(3000);
					}
					QueueMsgRSP(deviceUnicast, 3, H, 2);
					QueueMsgRSP(deviceUnicast, 4, S, 2);
					if (TemValue != 0)
					{
						QueueMsgRSP(deviceUnicast, 5, TemValue, 0);
					}
				}
				else
				{
					QueueMsgRSP(deviceUnicast, ID, VALUE, 0);
				}
			}
		}
	}
}

void Check_CMD_GWtoHC(struct mosquitto *mosq, char *jobj)
{
	Document document;
	document.Parse(jobj);
	if (document.IsObject())
	{
		if (document.HasMember("CMD"))
		{
			string cmd = document["CMD"].GetString();
			if (cmd.compare("RESETNODE") == 0)
			{
				RspResetNode(mosq, jobj);
			}
			else if (cmd.compare("ONOFF") == 0)
			{
				RspOnOff(mosq, jobj);
			}
			else if (cmd.compare("CCT") == 0)
			{
				RspCCT(mosq, jobj);
			}
			else if (cmd.compare("DIM") == 0)
			{
				RspDim(mosq, jobj);
			}
			else if (cmd.compare("HSL") == 0)
			{
				RspHSL(mosq, jobj);
			}
			else if (cmd.compare("SWITCH") == 0 || cmd.compare("CONTROL_SWITCH") == 0)
			{
				RspSwitch(mosq, jobj);
				Event(mosq, jobj);
			}
			else if (cmd.compare("CALLMODE_RGB") == 0)
			{
				RspModeRGB(mosq, jobj);
			}
			else if (cmd.compare("ADDGROUP") == 0)
			{
				RspAddGroup(mosq, jobj);
			}
			else if (cmd.compare("DELGROUP") == 0)
			{
				RspDelGroup(mosq, jobj);
			}
			else if (cmd.compare("CALLSCENE") == 0)
			{
				RspCallScene(mosq, jobj);
			}
			else if (cmd.compare("ADDSCENE_REMOTE_DC") == 0)
			{
				RspSetSceneRemote(mosq, jobj, "DC");
			}
			else if (cmd.compare("ADDSCENE_REMOTE_AC") == 0)
			{
				RspSetSceneRemote(mosq, jobj, "AC");
			}
			else if (cmd.compare("DELSCENE_REMOTE_DC") == 0)
			{
				RspDelSceneRemote(mosq, jobj, "DC");
			}
			else if (cmd.compare("DELSCENE_REMOTE_AC") == 0)
			{
				RspDelSceneRemote(mosq, jobj, "AC");
			}
			else if (cmd.compare("ADDSCENE_LIGHT_PIR_SENSOR") == 0)
			{
				RspSetScenePir(mosq, jobj);
			}
			else if (cmd.compare("DELSCENE_LIGHT_PIR_SENSOR") == 0)
			{
				RspDelScenePir(mosq, jobj);
			}
			else if (cmd.compare("LIGHT_SENSOR") == 0)
			{
				RspLux(mosq, jobj);
				Event(mosq, jobj);
			}
			else if (cmd.compare("PIR_SENSOR") == 0)
			{
				RspPir(mosq, jobj);
				Event(mosq, jobj);
			}
			else if (cmd.compare("POWER_STATUS") == 0)
			{
				RspPower(mosq, jobj);
			}
			else if (cmd.compare("REMOTE") == 0)
			{
				RspRemote(mosq, jobj);
				Event(mosq, jobj);
			}
			else if (cmd.compare("REMOTE_PAIRING") == 0)
			{
				RspRemotePairing(mosq, jobj);
				Event(mosq, jobj);
			}
			else if (cmd.compare("SMOKE_SENSOR") == 0)
			{
				RspSmoke(mosq, jobj);
				Event(mosq, jobj);
			}
			else if (cmd.compare("DOOR_SENSOR") == 0)
			{
				RspDoor(mosq, jobj);
				Event(mosq, jobj);
			}
			else if (cmd.compare("PM_SENSOR") == 0)
			{
				RspPm(mosq, jobj);
				Event(mosq, jobj);
			}
			else if (cmd.compare("TEMPERATURE_HUMIDITY") == 0)
			{
				RspTempHum(mosq, jobj);
				Event(mosq, jobj);
			}
			else if (cmd.compare("STOP") == 0)
			{
				MqttSendAPP(mosq, jobj, true);
			}
			else if (cmd.compare("STOP_SCAN_PAIRING_DEVICE") == 0)
			{
				MqttSendAPP(mosq, jobj, true);
			}
			else if (cmd.compare("ADDSCENE") == 0)
			{
				RspAddScene(mosq, jobj);
			}
			else if (cmd.compare("DELSCENE") == 0)
			{
				RspDelScene(mosq, jobj);
			}
			else if (cmd.compare("SCREEN_TOUCH_REQUEST_TIME") == 0)
			{
				SendTimeScreenTouch(mosq, jobj);
			}
			else if (cmd.compare("SCREEN_TOUCH_REQUEST_TEMP_HUM") == 0)
			{
				SendWeatherScreenTouch(mosq, jobj);
			}
			else if (cmd.compare("NEW_DEVICE") == 0)
			{
				NewDevice(mosq, jobj);
			}
			else if (cmd.compare("NEW_CHILD_DEVICE") == 0)
			{
				NewChildDevice(mosq, jobj);
			}
			else if (cmd.compare("SCREEN_TOUCH") == 0)
			{
				RspScreenTouch(mosq, jobj);
			}
			else if (cmd.compare("ADJUST_GROUP") == 0)
			{
				RspGroup(jobj);
			}
			else if (cmd.compare("UPDATE") == 0)
			{
				DeviceUpdateStatus(jobj);
			}
			else if (cmd.compare("REMOTE_MUL_SWITCH_STATUS") == 0)
			{
				RspSwitchModeDevice(mosq, jobj);
			}
			else if (cmd.compare("DEVICE_CONTROL") == 0)
			{
				RspControl(mosq, jobj);
			}
			else if (cmd.compare("CURTAIN_PRESS") == 0 || cmd.compare("CURTAIN_PRESS_END") == 0)
			{
				RspCurtain(mosq, jobj);
			}
			else if (cmd.compare("CONTROL") == 0)
			{
				RspControlSceneDelay(jobj);
			}
			else if (cmd.compare("TIME_ACTION_PIR") == 0)
			{
				RspSetActionTime(mosq, jobj);
			}
			else if (cmd.compare("TAP_TO_RUN") == 0 || cmd.compare("ACTIVE_RULE") == 0)
			{
				Event(mosq, jobj);
			}
			else if (cmd.compare("BACKUP") == 0)
			{
				BackupHCRSP(jobj);
			}
			else if (cmd.compare("MODE_ACTION_PIR") == 0)
			{
				RspActionModePir(mosq, jobj);
			}
			else if (cmd.compare("FACE") == 0)
			{
				RspFace(mosq, jobj);
				Event(mosq, jobj);
			}
			else if (cmd.compare("ZONE") == 0)
			{
				RspZone(mosq, jobj);
				Event(mosq, jobj);
			}
			else if (cmd.compare("SENSOR_SENSI") == 0)
			{
				RspSensorSensi(mosq, jobj);
			}
			else if (cmd.compare("PIR_SENSOR_STARTUP") == 0)
			{
				RspPirLightStartUp(mosq, jobj);
			}
			else if (cmd.compare("SWITCH_COUNTDOWN") == 0)
			{
				RspSetCountDownPirLight(mosq, jobj);
			}
			else if (cmd.compare("SET_DISTANCE_RADA") == 0)
			{
				RspSetDistance(mosq, jobj);
			}
			else if (cmd.compare("STATUS_STARTUP") == 0)
			{
				RspSetupStartStatus(mosq, jobj);
			}
			else if (cmd.compare("MODE_INPUT_SWITCH_ONOFF") == 0)
			{
				RspSetupModeInput(mosq, jobj);
			}
			else if (cmd.compare("AIRCONDITIONLIGHT_STATUS_MODE") == 0)
			{
				RspHeatLampMode(mosq, jobj);
			}
			else if (cmd.compare("AIRCONDITIONLIGHT_STATUS_LOAD") == 0)
			{
				RspHeatLampOutput(mosq, jobj);
			}
			else if (cmd.compare("TIMER_0FF_AIRCONDITIONLIGHT") == 0)
			{
				RspHeatLampTimeOff(mosq, jobj);
			}	
			else if (cmd.compare("TIMER_DRY_AIRCONDITIONLIGHT") == 0)
			{
				RspHeatLampTimeDry(mosq, jobj);
			}	
			else if (cmd.compare("PERIOD_DRY_AIRCONDITIONLIGHT") == 0)
			{
				RspHeatLampPeriodDry(mosq, jobj);
			}							
			else
			{
				cout << "CMD ERRO" << endl;
			}
		}
	}
	else
	{
		cout << "Message error" << endl;
	}
}
//---------------ADD, RESET DEVICE-------------------------------------------------------

void DelDeviceDB(int TempDeviceUnicastId)
{
	string DeviceTable = "DELETE FROM DEVICE WHERE DeviceUnicastId = " + to_string(TempDeviceUnicastId) + ";";
	DB_Write(DeviceTable);
	string SubDevice = "DELETE FROM SubDevice WHERE DeviceUnicastId = " + to_string(TempDeviceUnicastId) + ";";
	DB_Write(DeviceTable);
	string DeviceAttributeValue = "DELETE FROM DeviceAttributeValue WHERE DeviceUnicastId = " + to_string(TempDeviceUnicastId) + ";";
	DB_Write(DeviceAttributeValue);
	string Eventtrigerinputdevicemapping = "DELETE FROM EventTriggerInputDeviceMapping WHERE DeviceUnicastId = " + to_string(TempDeviceUnicastId) + ";";
	DB_Write(Eventtrigerinputdevicemapping);
	string Eventtriggerdeviceinputsetupvalue = "DELETE FROM EventTriggerInputDeviceSetupValue WHERE DeviceUnicastId = " + to_string(TempDeviceUnicastId) + ";";
	DB_Write(Eventtriggerdeviceinputsetupvalue);
	string Eventtriggeroutputdevicemapping = "DELETE FROM EventTriggerOutputDeviceMapping WHERE DeviceUnicastId = " + to_string(TempDeviceUnicastId) + ";";
	DB_Write(Eventtriggeroutputdevicemapping);
	string Eventtriggeroutputdevicesetupvalue = "DELETE FROM EventTriggerOutputDeviceSetupValue WHERE DeviceUnicastId = " + to_string(TempDeviceUnicastId) + ";";
	DB_Write(Eventtriggeroutputdevicesetupvalue);
	string Groupingdevicemapping = "DELETE FROM GroupingDeviceMapping WHERE DeviceUnicastId = " + to_string(TempDeviceUnicastId) + ";";
	DB_Write(Groupingdevicemapping);
}

void DeleteOldDevice(int TempDeviceUnicastId)
{
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	json.StartObject();
	json.Key("CMD");
	json.String("RESETNODE");
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.StartArray();
	json.Int(TempDeviceUnicastId);
	json.EndArray();
	json.EndObject();
	json.EndObject();
	cout << sendToApp.GetString() << endl;
	string s = sendToApp.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
	DelDeviceDB(TempDeviceUnicastId);
	bool FlagCheckLock = false;
	while (FlagCheckLock == false)
	{
		if (pthread_mutex_trylock(&mutexUpdateDvValue) == 0 && pthread_mutex_trylock(&mutexDvOnline) == 0)
		{
			int IndexDvCheckOnline = SearchDeviceCheckOnline(TempDeviceUnicastId);
			int IndexDvGetStatus = SearchDeviceUpdateValue(TempDeviceUnicastId);
			if (IndexDvGetStatus != -1)
			{
				DeleteRowDvValue(T_Device, IndexDvGetStatus);
			}
			if (IndexDvCheckOnline != -1)
			{
				DeleteRowDvCheckOnline(T_DeviceCheckOnline, IndexDvCheckOnline);
			}
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutexUpdateDvValue);
			pthread_mutex_unlock(&mutexDvOnline);
			break;
		}
		usleep(3000);
	}
}

void InsertDevceToRam(int TempDeviceUnicastId, string TempDeviceId, int TempCategoryId, string TempFirmVersion, bool TempSubDevice)
{
	bool FlagCheckLock = false;
	while (FlagCheckLock == false)
	{
		if (pthread_mutex_trylock(&mutexUpdateDvValue) == 0 && pthread_mutex_trylock(&mutexDvOnline) == 0)
		{
			t_Device T_TempDevice = {0};
			T_TempDevice.DeviceUnicastID = TempDeviceUnicastId;
			T_TempDevice.DeviceUUID = TempDeviceId;
			T_TempDevice.TypeDevice = TempCategoryId;
			T_TempDevice.AttDevice[0] = 0;
			if (TempCategoryId / 10000 == 1 || TempCategoryId / 1000 == 21)
			{
				T_TempDevice.AttDevice[0] = 2;
				T_TempDevice.AttDevice[1] = 0;
				T_TempDevice.AttDevice[2] = 1;
			}
			T_Device.push_back(T_TempDevice);
			if (TempCategoryId / 10000 == 1 || TempCategoryId / 1000 == 21 || TempCategoryId / 1000 == 22)
			{
				if (TempSubDevice == false)
				{
					int TimeStart = GetSecondTimeNow();
					t_DeviceCheckOnline T_TempDeviceCheckOnline = {0};
					T_TempDeviceCheckOnline.DeviceUnicastID = TempDeviceUnicastId;
					T_TempDeviceCheckOnline.TimeCheck = TimeStart;
					T_TempDeviceCheckOnline.CurrentStatus = STATUS_ONLINE;
					T_TempDeviceCheckOnline.PreviousStatus = STATUS_OFFLINE;
					T_TempDeviceCheckOnline.TypeDevice = TempCategoryId;
					T_TempDeviceCheckOnline.DeviceUUID = TempDeviceId;
					T_TempDeviceCheckOnline.FirmVersion = TempFirmVersion;
					T_DeviceCheckOnline.push_back(T_TempDeviceCheckOnline);
					timeOffLine = TimeCheckOnline() * 2 + 60;
				}
			}
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutexUpdateDvValue);
			pthread_mutex_unlock(&mutexDvOnline);
			break;
		}
		usleep(3000);
	}
}
//{
//   "CMD": "NEW_CHILD_DEVICE",
//   "DATA": {
//     "PARENT_DEVICE_ID": "b717f8d86f1843c0ae4669c32998f653",
//     "DEVICE_ID": "b717f8d86f1843c0ae4669c32998f653",
//     "DEVICE_UNICAST_ID": 2,
//     "BUTTON_ID":11,
//     "DEVICE_TYPE_ID": 23002,
//     "MAC_ADDRESS": "AB:DE:EF",
//     "FIRMWARE_VERSION": "1.0.2",
//     "DEVICE_KEY": "b717f8d86f1843c0ae4669c32998f653",
//     "NET_KEY": "b717f8d86f1843c0ae4669c32998f653",
//     "APP_KEY": "b717f8d86f1843c0ae4669c32998f653"
//   }
//}

string AddSubDevice(t_SendSubDevice TempSubDevice)
{
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	json.StartObject();
	json.Key("CMD");
	json.String("NEW_CHILD_DEVICE");
	json.Key("DATA");
	json.StartObject();
	json.Key("PARENT_DEVICE_ID");
	json.String(TempSubDevice.ParentDeviceId.c_str());
	json.Key("DEVICE_ID");
	json.String(TempSubDevice.ChildDeviceId.c_str());
	json.Key("DEVICE_UNICAST_ID");
	json.Int(TempSubDevice.ChildDeviceUnicastId);
	json.Key("BUTTON_ID");
	json.Int(TempSubDevice.ButtonId);
	json.Key("DEVICE_TYPE_ID");
	json.Int(TempSubDevice.DeviceTypeId);
	json.Key("MAC_ADDRESS");
	json.String(TempSubDevice.MacAddr.c_str());
	json.Key("FIRMWARE_VERSION");
	json.String(TempSubDevice.FirmVersion.c_str());
	json.Key("DEVICE_KEY");
	json.String(TempSubDevice.DeviceKey.c_str());
	json.Key("NET_KEY");
	json.String(TempSubDevice.NetKey.c_str());
	json.Key("APP_KEY");
	json.String(TempSubDevice.AppKey.c_str());
	json.EndObject();
	json.EndObject();
	cout << sendToApp.GetString() << endl;
	string s = sendToApp.GetString();
	return s;
}

/*TODO: DONE*/
void NewDevice(struct mosquitto *mosq, char *jobj)
{
	Document document;
	document.Parse(jobj);
	if (document.IsObject())
	{
		string cmd;
		if (document.HasMember("CMD"))
		{
			cmd = document["CMD"].GetString();
			if (cmd.compare("NEW_DEVICE") == 0)
			{
				const Value &DATA = document["DATA"];
				if (DATA.HasMember("DEVICE_UNICAST_ID") && DATA.HasMember("DEVICE_ID") && DATA.HasMember("DEVICE_KEY") && DATA.HasMember("NET_KEY") && DATA.HasMember("APP_KEY") && DATA.HasMember("DEVICE_TYPE_ID"))
				{
					t_SendSubDevice TempSendSubDevice;
					int DeviceUnicastId = DATA["DEVICE_UNICAST_ID"].GetInt();
					string NewDevicevId = TempSendSubDevice.ParentDeviceId = DATA["DEVICE_ID"].GetString();
					string DeviceKey = TempSendSubDevice.DeviceKey = DATA["DEVICE_KEY"].GetString();
					string NetKey = TempSendSubDevice.NetKey = DATA["NET_KEY"].GetString();
					string AppKey = TempSendSubDevice.AppKey = DATA["APP_KEY"].GetString();
					string Mac = TempSendSubDevice.MacAddr = DATA["MAC_ADDRESS"].GetString();
					string FirmVersion = TempSendSubDevice.FirmVersion = DATA["FIRMWARE_VERSION"].GetString();
					int CategoryId = TempSendSubDevice.DeviceTypeId = DATA["DEVICE_TYPE_ID"].GetInt();
					// cout << "TP1 newdev" << endl;
					if (CategoryId != 81101 && CategoryId != 81102)
					{
						// cout << "TP2 newdev" << endl;
						MqttSendAPP(mosq, jobj, true);
						ADRSL = -1;
						string sql = "SELECT DeviceUnicastId FROM Device WHERE DeviceId = '" + NewDevicevId + "' AND DeviceTypeId = 1;";
						DB_ReadGHA(mosq, "ADR", sql);
						int OlDvUnicastId = ADRSL;
						if (OlDvUnicastId > 1)
						{
							DeleteOldDevice(OlDvUnicastId);
							string sql = "SELECT ParentDeviceId, ChildDeviceId, ChildDeviceUnicastId FROM SubDevice WHERE ParentDeviceId = '" + NewDevicevId + "';";
							DB_ReadGHA(mosq, "GET_SUBDEVICE", sql);
							if (CategoryId == SWITCH_RGB_2 || CategoryId == SWITCH_RGB_3 ||
								CategoryId == SWITCH_RGB_4 || CategoryId == SCENE_AC_RGB ||
								CategoryId == SWITCH_RGB_2_V ||	CategoryId == SWITCH_RGB_3_V ||
								CategoryId == SWITCH_RGB_4_V || CategoryId == SWITCH_RGB_2N ||
								CategoryId == SWITCH_RGB_3N || CategoryId == SWITCH_RGB_4N ||
								CategoryId == SWITCH_RGB_2N_V || CategoryId == SWITCH_RGB_3N_V ||
								CategoryId == SWITCH_RGB_4N_V || CategoryId == CDT_2 ||
								CategoryId == CDT_3 || CategoryId == CDT_4 ||
								CategoryId == CDT_2_N || CategoryId == CDT_3_N ||
								CategoryId == SCENE_AC_RGB_V ||	CategoryId == CT_AT_2N ||
								CategoryId == CT_AT_3N || CategoryId == CT_AT_5N ||
								CategoryId == SWITCH_RGB_BLEWF_2 ||	CategoryId == SWITCH_RGB_BLEWF_3 ||
								CategoryId == SWITCH_RGB_BLEWF_4 ||	CategoryId == CDT_BLEWF_2 || CategoryId == CDT_BLEWF_3)
							{
								for (t_SubDevice &TempItem : SubDevice)
								{
									if (CategoryId == SCENE_AC_RGB || CategoryId == SCENE_AC_RGB_V)
									{
										DelDeviceDB(TempItem.ChildDeviceUnicastId);
									}
									else
									{
										DeleteOldDevice(TempItem.ChildDeviceUnicastId);
									}
									SubDevice.pop_back();
								}
							}
						}
						int Time = GetSecondTimeNow();
						int Day = SetDay();
						string AddDevice = "INSERT OR REPLACE INTO DEVICE (DeviceId, DeviceUnicastId, AppKey, NetKey, DeviceKey, DeviceTypeId, CategoryId, UpdateDay, UpdateTime, MacAddress ,FirmwareVersion, Owner)"
										   "values( '" +
										   NewDevicevId + "'," + to_string(DeviceUnicastId) + ",'" + AppKey + "','" + NetKey + "','" + DeviceKey + "'," + to_string(DEVICE_BLE) + "," + to_string(CategoryId) + ", " + to_string(Day) + ", " + to_string(Time) + ",'" + Mac + "','" + FirmVersion + "', 1);";
						cout << AddDevice << endl;
						DB_Write(AddDevice);
						InsertDevceToRam(DeviceUnicastId, NewDevicevId, CategoryId, FirmVersion, false);
						// cout << "Add device to RAM success" << endl;
						if (CategoryId == SWITCH_RGB_2 || CategoryId == SWITCH_RGB_3 ||
								CategoryId == SWITCH_RGB_4 || CategoryId == SCENE_AC_RGB ||
								CategoryId == SWITCH_RGB_2_V ||	CategoryId == SWITCH_RGB_3_V ||
								CategoryId == SWITCH_RGB_4_V || CategoryId == SWITCH_RGB_2N ||
								CategoryId == SWITCH_RGB_3N || CategoryId == SWITCH_RGB_4N ||
								CategoryId == SWITCH_RGB_2N_V || CategoryId == SWITCH_RGB_3N_V ||
								CategoryId == SWITCH_RGB_4N_V || CategoryId == CDT_2 ||
								CategoryId == CDT_3 || CategoryId == CDT_4 ||
								CategoryId == CDT_2_N || CategoryId == CDT_3_N ||
								CategoryId == SCENE_AC_RGB_V ||	CategoryId == CT_AT_2N ||
								CategoryId == CT_AT_3N || CategoryId == CT_AT_5N ||
								CategoryId == SWITCH_RGB_BLEWF_2 ||	CategoryId == SWITCH_RGB_BLEWF_3 ||
								CategoryId == SWITCH_RGB_BLEWF_4 ||	CategoryId == CDT_BLEWF_2 || CategoryId == CDT_BLEWF_3)
						{
							if (CategoryId == SWITCH_RGB_2 || CategoryId == CDT_2 || CategoryId == SWITCH_RGB_2_V ||
								CategoryId == SWITCH_RGB_2N_V || CategoryId == SWITCH_RGB_2N || CategoryId == CT_AT_2N || CategoryId == CDT_2_N ||
								CategoryId == SWITCH_RGB_BLEWF_2 || CategoryId == CDT_BLEWF_2)
							{
								for (int i = 1; i < 2; i++)
								{
									TempSendSubDevice.ButtonId = 11 + i;
									int TempDeviceUnicastId = TempSendSubDevice.ChildDeviceUnicastId = DeviceUnicastId + i;
									string StrTempDeviceUnicastId = to_string(TempDeviceUnicastId);
									string TempDeviceId = GenerateUUID().substr(StrTempDeviceUnicastId.length(), GenerateUUID().length() - StrTempDeviceUnicastId.length());
									TempDeviceId = TempSendSubDevice.ChildDeviceId = StrTempDeviceUnicastId + TempDeviceId;
									string AddDevice = "INSERT OR REPLACE INTO DEVICE (DeviceId, DeviceUnicastId, AppKey, NetKey, DeviceKey, DeviceTypeId, CategoryId, UpdateDay, UpdateTime, MacAddress ,FirmwareVersion, Owner) "
													   "values ( '" +
													   TempDeviceId + "'," + to_string(TempDeviceUnicastId) + ",'" + AppKey + "','" + NetKey + "','" + DeviceKey + "'," + to_string(DEVICE_BLE) + "," + to_string(CategoryId) + ", " + to_string(Day) + ", " + to_string(Time) + ",'" + Mac + "','" + FirmVersion + "', 1);";
									cout << AddDevice << endl;
									DB_Write(AddDevice);
									AddDevice = "INSERT OR REPLACE INTO SubDevice (ParentDeviceId, ParentDeviceUnicastId, ChildDeviceId, ChildDeviceUnicastId) "
												"values ( '" +
												NewDevicevId + "', " + to_string(DeviceUnicastId) + ", '" + TempDeviceId + "'," + to_string(TempDeviceUnicastId) + ");";
									cout << AddDevice << endl;
									DB_Write(AddDevice);
									string SendtoApp = AddSubDevice(TempSendSubDevice);
									MqttSendAPP(mosq, const_cast<char *>(SendtoApp.c_str()), true);
									InsertDevceToRam(TempDeviceUnicastId, TempDeviceId, CategoryId, FirmVersion, true);
								}
							}
							else if (CategoryId == SWITCH_RGB_3 || CategoryId == CDT_3 || CategoryId == SWITCH_RGB_3_V ||
									CategoryId == SWITCH_RGB_3N_V || CategoryId == SWITCH_RGB_3N || CategoryId == CT_AT_3N  || CategoryId == CDT_3_N ||
									CategoryId == SWITCH_RGB_BLEWF_3 || CategoryId == CDT_BLEWF_3)
							{
								for (int i = 1; i < 3; i++)
								{
									TempSendSubDevice.ButtonId = 11 + i;
									int TempDeviceUnicastId = TempSendSubDevice.ChildDeviceUnicastId = DeviceUnicastId + i;
									string StrTempDeviceUnicastId = to_string(TempDeviceUnicastId);
									string TempDeviceId = GenerateUUID().substr(StrTempDeviceUnicastId.length(), GenerateUUID().length() - StrTempDeviceUnicastId.length());
									TempDeviceId = TempSendSubDevice.ChildDeviceId = StrTempDeviceUnicastId + TempDeviceId;
									string AddDevice = "INSERT OR REPLACE INTO DEVICE (DeviceId, DeviceUnicastId, AppKey, NetKey, DeviceKey, DeviceTypeId, CategoryId, UpdateDay, UpdateTime, MacAddress ,FirmwareVersion, Owner) "
													   "values ( '" +
													   TempDeviceId + "'," + to_string(TempDeviceUnicastId) + ",'" + AppKey + "','" + NetKey + "','" + DeviceKey + "'," + to_string(DEVICE_BLE) + "," + to_string(CategoryId) + ", " + to_string(Day) + ", " + to_string(Time) + ",'" + Mac + "','" + FirmVersion + "', 1);";
									DB_Write(AddDevice);
									AddDevice = "INSERT OR REPLACE INTO SubDevice (ParentDeviceId, ParentDeviceUnicastId, ChildDeviceId, ChildDeviceUnicastId) "
												"values ( '" +
												NewDevicevId + "', " + to_string(DeviceUnicastId) + ", '" + TempDeviceId + "'," + to_string(TempDeviceUnicastId) + ");";
									cout << AddDevice << endl;
									DB_Write(AddDevice);
									string SendtoApp = AddSubDevice(TempSendSubDevice);
									MqttSendAPP(mosq, const_cast<char *>(SendtoApp.c_str()), true);
									InsertDevceToRam(TempDeviceUnicastId, TempDeviceId, CategoryId, FirmVersion, true);
								}
							}
							else if (CategoryId == SWITCH_RGB_4 || CategoryId == CDT_4 || CategoryId == SWITCH_RGB_4_V || CategoryId == SWITCH_RGB_4N_V || CategoryId == SWITCH_RGB_4N || CategoryId == SWITCH_RGB_BLEWF_4)
							{
								for (int i = 1; i < 4; i++)
								{
									TempSendSubDevice.ButtonId = 11 + i;
									int TempDeviceUnicastId = TempSendSubDevice.ChildDeviceUnicastId = DeviceUnicastId + i;
									string StrTempDeviceUnicastId = to_string(TempDeviceUnicastId);
									string TempDeviceId = GenerateUUID().substr(StrTempDeviceUnicastId.length(), GenerateUUID().length() - StrTempDeviceUnicastId.length());
									TempDeviceId = TempSendSubDevice.ChildDeviceId = StrTempDeviceUnicastId + TempDeviceId;
									string AddDevice = "INSERT OR REPLACE INTO DEVICE (DeviceId, DeviceUnicastId, AppKey, NetKey, DeviceKey, DeviceTypeId, CategoryId, UpdateDay, UpdateTime, MacAddress ,FirmwareVersion, Owner) "
													   "values ( '" +
													   TempDeviceId + "'," + to_string(TempDeviceUnicastId) + ",'" + AppKey + "','" + NetKey + "','" + DeviceKey + "'," + to_string(DEVICE_BLE) + "," + to_string(CategoryId) + ", " + to_string(Day) + ", " + to_string(Time) + ",'" + Mac + "','" + FirmVersion + "', 1);";
									cout << AddDevice << endl;
									DB_Write(AddDevice);
									AddDevice = "INSERT OR REPLACE INTO SubDevice (ParentDeviceId, ParentDeviceUnicastId, ChildDeviceId, ChildDeviceUnicastId) "
												"values ( '" +
												NewDevicevId + "', " + to_string(DeviceUnicastId) + ", '" + TempDeviceId + "'," + to_string(TempDeviceUnicastId) + ");";
									cout << AddDevice << endl;
									DB_Write(AddDevice);
									string SendtoApp = AddSubDevice(TempSendSubDevice);
									MqttSendAPP(mosq, const_cast<char *>(SendtoApp.c_str()), true);
									InsertDevceToRam(TempDeviceUnicastId, TempDeviceId, CategoryId, FirmVersion, true);
								}
							}
							else if (CategoryId == CT_AT_5N)
							{
								for (int i = 1; i < 5; i++)
								{
									TempSendSubDevice.ButtonId = 11 + i;
									int TempDeviceUnicastId = TempSendSubDevice.ChildDeviceUnicastId = DeviceUnicastId + i;
									string StrTempDeviceUnicastId = to_string(TempDeviceUnicastId);
									string TempDeviceId = GenerateUUID().substr(StrTempDeviceUnicastId.length(), GenerateUUID().length() - StrTempDeviceUnicastId.length());
									TempDeviceId = TempSendSubDevice.ChildDeviceId = StrTempDeviceUnicastId + TempDeviceId;
									string AddDevice = "INSERT OR REPLACE INTO DEVICE (DeviceId, DeviceUnicastId, AppKey, NetKey, DeviceKey, DeviceTypeId, CategoryId, UpdateDay, UpdateTime, MacAddress ,FirmwareVersion, Owner) "
													   "values ( '" +
													   TempDeviceId + "'," + to_string(TempDeviceUnicastId) + ",'" + AppKey + "','" + NetKey + "','" + DeviceKey + "'," + to_string(DEVICE_BLE) + "," + to_string(CategoryId) + ", " + to_string(Day) + ", " + to_string(Time) + ",'" + Mac + "','" + FirmVersion + "', 1);";
									cout << AddDevice << endl;
									DB_Write(AddDevice);
									AddDevice = "INSERT OR REPLACE INTO SubDevice (ParentDeviceId, ParentDeviceUnicastId, ChildDeviceId, ChildDeviceUnicastId) "
												"values ( '" +
												NewDevicevId + "', " + to_string(DeviceUnicastId) + ", '" + TempDeviceId + "'," + to_string(TempDeviceUnicastId) + ");";
									cout << AddDevice << endl;
									DB_Write(AddDevice);
									string SendtoApp = AddSubDevice(TempSendSubDevice);
									MqttSendAPP(mosq, const_cast<char *>(SendtoApp.c_str()), true);
									InsertDevceToRam(TempDeviceUnicastId, TempDeviceId, CategoryId, FirmVersion, true);
								}
							}
							else if (CategoryId == SCENE_AC_RGB || CategoryId == SCENE_AC_RGB_V)
							{
								for (int i = 1; i < 6; i++)
								{
									TempSendSubDevice.ButtonId = 11 + i;
									TempSendSubDevice.ChildDeviceUnicastId = DeviceUnicastId;
									string StrTempDeviceUnicastId = to_string(DeviceUnicastId);
									string TempDeviceId = NewDevicevId.substr(2, (NewDevicevId.length() - 2));
									TempDeviceId = TempSendSubDevice.ChildDeviceId = to_string(TempSendSubDevice.ButtonId) + TempDeviceId;
									string AddDevice = "INSERT OR REPLACE INTO DEVICE (DeviceId, DeviceUnicastId, AppKey, NetKey, DeviceKey, DeviceTypeId, CategoryId, UpdateDay, UpdateTime, MacAddress ,FirmwareVersion, Owner) "
													   "values ( '" +
													   TempDeviceId + "'," + to_string(DeviceUnicastId) + ",'" + AppKey + "','" + NetKey + "','" + DeviceKey + "'," + to_string(DEVICE_BLE) + "," + to_string(CategoryId) + ", " + to_string(Day) + ", " + to_string(Time) + ",'" + Mac + "','" + FirmVersion + "', 1);";
									cout << AddDevice << endl;
									DB_Write(AddDevice);
									AddDevice = "INSERT OR REPLACE INTO SubDevice (ParentDeviceId, ParentDeviceUnicastId, ChildDeviceId, ChildDeviceUnicastId) "
												"values ( '" +
												NewDevicevId + "', " + to_string(DeviceUnicastId) + ", '" + TempDeviceId + "'," + to_string(DeviceUnicastId) + ");";
									cout << AddDevice << endl;
									DB_Write(AddDevice);
									string SendtoApp = AddSubDevice(TempSendSubDevice);
									MqttSendAPP(mosq, const_cast<char *>(SendtoApp.c_str()), true);
								}
							}
						}
					}
				}
			}
		}
	}
}

void NewChildDevice(struct mosquitto *mosq, char *jobj)
{
	Document document;
	document.Parse(jobj);
	if (document.IsObject())
	{
		if (document.HasMember("DATA") && document["DATA"].IsObject())
		{
			const Value &data = document["DATA"];
			if (data.HasMember("DEVICE_UNICAST_PARENT") && data["DEVICE_UNICAST_PARENT"].IsInt() &&
				data.HasMember("DEVICE_UNICAST_ID") && data["DEVICE_UNICAST_ID"].IsInt() &&
				data.HasMember("DEVICE_ID") && data["DEVICE_ID"].IsString() &&
				data.HasMember("DEVICE_TYPE_ID") && data["DEVICE_TYPE_ID"].IsInt() &&
				data.HasMember("MAC_ADDRESS") && data["MAC_ADDRESS"].IsString() &&
				data.HasMember("FIRMWARE_VERSION") && data["FIRMWARE_VERSION"].IsString())
			{
				uint16_t deviceUnicastParent = data["DEVICE_UNICAST_PARENT"].GetInt();
				uint16_t deviceUnicastChild = data["DEVICE_UNICAST_ID"].GetInt();
				string deviceIdChild = data["DEVICE_ID"].GetString();
				uint16_t deviceTypeId = data["DEVICE_TYPE_ID"].GetInt();
				string mac = data["MAC_ADDRESS"].GetString();
				string firmwareVersion = data["FIRMWARE_VERSION"].GetString();
				if (deviceTypeId == SEFTPOWER_REMOTE_1 || deviceTypeId == SEFTPOWER_REMOTE_2 || deviceTypeId == SEFTPOWER_REMOTE_3)
				{
					CONTROLSL = "";
					string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(deviceUnicastParent) + " AND DeviceTypeId = 1;";
					DB_ReadGHA(mosq, "CONTROL", sql);
					string deviceParentId = CONTROLSL;
					// cout << "TP1:**************: deviceParent: " << deviceParentId << endl;

					CONTROLSL = "";
					string sql1 = "SELECT ParentDeviceId FROM SubDevice WHERE ChildDeviceId = '" + deviceIdChild + "';";
					DB_ReadGHA(mosq, "CONTROL", sql1);
					string deviceParentInDb = CONTROLSL;
					// cout << "TP2:**************: deviceParentInDb: " << deviceParentInDb << endl;

					t_SendSubDevice TempSendSubDevice;
					TempSendSubDevice.ParentDeviceId = deviceParentId;
					TempSendSubDevice.ChildDeviceId = deviceIdChild;
					TempSendSubDevice.ChildDeviceUnicastId = deviceUnicastChild;
					TempSendSubDevice.ButtonId = 11;
					TempSendSubDevice.DeviceTypeId = deviceTypeId;
					TempSendSubDevice.MacAddr = mac;
					TempSendSubDevice.FirmVersion = firmwareVersion;
					TempSendSubDevice.DeviceKey = "";
					TempSendSubDevice.NetKey = "";
					TempSendSubDevice.AppKey = "";

					string SendtoApp = AddSubDevice(TempSendSubDevice);
					MqttSendAPP(mosq, const_cast<char *>(SendtoApp.c_str()), true);

					// cout << "********************************: " << deviceParentInDb << endl;
					if ((deviceParentInDb != "") && (deviceParentInDb != deviceParentId))
					{
						uint16_t addrParentInDb = DEVICE_UNICAST_ID(deviceParentInDb);
						string getChildDeviceUnicastOld = "Select ChildDeviceUnicastId From SubDevice Where ParentDeviceId = '" + deviceParentInDb + "' AND ChildDeviceId = '" + deviceIdChild + "';";
						// cout << "**************" << getChildDeviceUnicastOld << endl;
						DB_ReadGHA(mosq, "ADR", getChildDeviceUnicastOld);
						uint16_t childDeviceUnicastOld = ADRSL;
						// cout << "**************" << childDeviceUnicastOld << endl;
						StringBuffer delNode;
						Writer<StringBuffer> json(delNode);
						json.StartObject();
						json.Key("CMD");
						json.String("RESET_CHILD_DEVICE");
						json.Key("DATA");
						json.StartArray();
						json.StartObject();
						json.Key("DEVICE_UNICAST_PARENT");
						json.Int(addrParentInDb);
						json.Key("DEVICE_UNICAST_ID");
						json.Int(childDeviceUnicastOld);
						json.EndObject();
						json.EndArray();
						json.EndObject();
						string s1 = delNode.GetString();
						MqttSend(mosq, const_cast<char *>(s1.c_str()));

						string SubDeviceChild = "DELETE FROM SubDevice WHERE ChildDeviceId = '" + deviceIdChild + "';";
						cout << "TP1: " << SubDeviceChild << endl;
						DB_Write(SubDeviceChild);
						string deviceAttributeValue = "DELETE FROM DeviceAttributeValue WHERE DeviceId = '" + deviceIdChild + "';";
						DB_Write(deviceAttributeValue);
						string eventtrigerinputdevicemapping = "DELETE FROM EventTriggerInputDeviceMapping WHERE DeviceId = '" + deviceIdChild + "';";
						DB_Write(eventtrigerinputdevicemapping);
						string eventtriggerdeviceinputsetupvalue = "DELETE FROM EventTriggerInputDeviceSetupValue WHERE DeviceId = '" + deviceIdChild + "';";
						DB_Write(eventtriggerdeviceinputsetupvalue);
						string eventtriggeroutputdevicemapping = "DELETE FROM EventTriggerOutputDeviceMapping WHERE DeviceId = '" + deviceIdChild + "';";
						DB_Write(eventtriggeroutputdevicemapping);
						string eventtriggeroutputdevicesetupvalue = "DELETE FROM EventTriggerOutputDeviceSetupValue WHERE DeviceId = '" + deviceIdChild + "';";
						DB_Write(eventtriggeroutputdevicesetupvalue);
					}

					string AddDevice = "INSERT OR REPLACE INTO SubDevice (ParentDeviceId, ParentDeviceUnicastId, ChildDeviceId, ChildDeviceUnicastId) "
									   "values ( '" + deviceParentId + "', " + to_string(deviceUnicastParent) + ", '" + deviceIdChild + "'," + to_string(deviceUnicastChild) + ");";
					// cout << "*************" << AddDevice << endl;
					DB_Write(AddDevice);

					int Time = GetSecondTimeNow();
					int Day = SetDay();
					AddDevice = "INSERT OR REPLACE INTO DEVICE (DeviceId, DeviceUnicastId, AppKey, NetKey, DeviceKey, DeviceTypeId, CategoryId, UpdateDay, UpdateTime, MacAddress ,FirmwareVersion, Owner) "
								"values ( '" +
								deviceIdChild + "'," + to_string(deviceUnicastChild) + ",'" + TempSendSubDevice.AppKey + "','" + TempSendSubDevice.NetKey + "','" + TempSendSubDevice.DeviceKey + "'," + to_string(DEVICE_BLE) + "," + to_string(TempSendSubDevice.DeviceTypeId) + ", " + to_string(Day) + ", " + to_string(Time) + ",'" + TempSendSubDevice.MacAddr + "','" + TempSendSubDevice.FirmVersion + "', 1);";
					// cout << AddDevice << endl;
					DB_Write(AddDevice);
					InsertDevceToRam(deviceUnicastChild, deviceIdChild, deviceTypeId, firmwareVersion, true);
				}
			}
		}
	}
}

void SendReultResetNode()
{
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	json.StartObject();
	json.Key("CMD");
	json.String("RESET_NODE");
	json.Key("DATA");
	json.StartObject();
	json.Key("SUCCESS");
	json.StartArray();
	for (int i = 0; i < numDeviceResetSuccess; i++)
	{
		CONTROLSL = "";
		string sql22 = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(deviceResetSuccess[i]) + " AND DeviceTypeId = 1;";
		cout << "SQL: " << sql22 << endl;
		DB_ReadGHA(mosq, "CONTROL", sql22);
		string deviceId = CONTROLSL;
		json.String(const_cast<char *>(deviceId.c_str()));

		string Device = "DELETE FROM Device WHERE DeviceUnicastId = " + to_string(deviceResetSuccess[i]) + ";";
		DB_Write(Device);
		string SubDevice = "DELETE FROM SubDevice WHERE ParentDeviceUnicastId = " + to_string(deviceResetSuccess[i]) + ";";
		DB_Write(SubDevice);
		string SubDeviceChild = "DELETE FROM SubDevice WHERE ChildDeviceUnicastId = " + to_string(deviceResetSuccess[i]) + ";";
		DB_Write(SubDeviceChild);
		string deviceAttributeValue = "DELETE FROM DeviceAttributeValue WHERE DeviceUnicastId = " + to_string(deviceResetSuccess[i]) + ";";
		DB_Write(deviceAttributeValue);
		string eventtrigerinputdevicemapping = "DELETE FROM EventTriggerInputDeviceMapping WHERE DeviceUnicastId = " + to_string(deviceResetSuccess[i]) + ";";
		DB_Write(eventtrigerinputdevicemapping);
		string eventtriggerdeviceinputsetupvalue = "DELETE FROM EventTriggerInputDeviceSetupValue WHERE DeviceUnicastId = " + to_string(deviceResetSuccess[i]) + ";";
		DB_Write(eventtriggerdeviceinputsetupvalue);
		string eventtriggeroutputdevicemapping = "DELETE FROM EventTriggerOutputDeviceMapping WHERE DeviceUnicastId = " + to_string(deviceResetSuccess[i]) + ";";
		DB_Write(eventtriggeroutputdevicemapping);
		string eventtriggeroutputdevicesetupvalue = "DELETE FROM EventTriggerOutputDeviceSetupValue WHERE DeviceUnicastId = " + to_string(deviceResetSuccess[i]) + ";";
		DB_Write(eventtriggeroutputdevicesetupvalue);
		string groupingdevicemapping = "DELETE FROM GroupingDeviceMapping WHERE DeviceUnicastId = " + to_string(deviceResetSuccess[i]) + ";";
		DB_Write(groupingdevicemapping);
	}
	json.EndArray();
	json.Key("FAILED");
	json.StartArray();
	for (int i = 0; i < numDeviceReset; i++)
	{
		int CheckFailed = 0;
		for (int j = 0; j < numDeviceResetSuccess; j++)
		{
			if (deviceReset[i] != deviceResetSuccess[j])
			{
				CheckFailed++;
			}
		}
		// cout << "check failed: " << CheckFailed << endl;
		if (CheckFailed == numDeviceResetSuccess)
		{
			CONTROLSL = "";
			string sql22 = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(deviceReset[i]) + " AND DeviceTypeId = 1;";
			DB_ReadGHA(mosq, "CONTROL", sql22);
			string deviceId = CONTROLSL;
			json.String(const_cast<char *>(deviceId.c_str()));
		}
	}
	json.EndArray();
	json.EndObject();
	json.EndObject();
	cout << sendToApp.GetString() << endl;
	string s = sendToApp.GetString();
	MqttSendAPP(mosq, const_cast<char *>(s.c_str()), true);
	ResetDataResetNode();
}

/*TODO: Done*/
void RspResetNode(struct mosquitto *mosq, char *jobj)
{
	pthread_mutex_lock(&mutex);
	Document document;
	document.Parse(jobj);
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	const Value &DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	numDeviceResetSuccess++;
	deviceResetSuccess[numDeviceResetSuccess - 1] = adr;
	CONTROLSL = "";
	TimeOut = GetSecondTimeNow();
	string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(adr) + " AND DeviceTypeId = 1;";
	DB_ReadGHA(mosq, "CONTROL", sql);
	if (numDeviceResetSuccess == numDeviceReset)
	{
		if (isResetNode)
		{
			SendReultResetNode();
		}
	}
	bool FlagCheckLock = false;
	while (FlagCheckLock == false)
	{
		if (pthread_mutex_trylock(&mutexUpdateDvValue) == 0 && pthread_mutex_trylock(&mutexDvOnline) == 0)
		{
			int IndexDvCheckOnline = SearchDeviceCheckOnline(adr);
			int IndexDvGetStatus = SearchDeviceUpdateValue(adr);
			if (IndexDvGetStatus != -1)
			{
				DeleteRowDvValue(T_Device, IndexDvGetStatus);
			}
			if (IndexDvCheckOnline != -1)
			{
				DeleteRowDvCheckOnline(T_DeviceCheckOnline, IndexDvCheckOnline);
			}
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutexUpdateDvValue);
			pthread_mutex_unlock(&mutexDvOnline);
			break;
		}
		usleep(3000);
	}
	pthread_mutex_unlock(&mutex);
}

void RspAddRoom(struct mosquitto *mosq, char* jobj)
{
	Document document;
	document.Parse(jobj);
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	const Value &DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	int status = DATA["STATUS"].GetInt();
	if (status == 1)
	DeviceAddRoomSuccess.push_back(adr);
}

void UpdateDeviceValue(int DeviceUnicastId, int AttributeId, int AttributeValue)
{
	bool FlagCheckLock = false;
	while (FlagCheckLock == false)
	{
		if (pthread_mutex_trylock(&mutexUpdateDvValue) == 0)
		{
			int IndexDevice = -1;
			bool FlagCompareDVAttId = false;
			IndexDevice = SearchDeviceUpdateValue(DeviceUnicastId);
			for (int i = 1; i <= (T_Device[IndexDevice].AttDevice[0] / 2); i++)
			{
				if (AttributeId == T_Device[IndexDevice].AttDevice[i * 2 - 1])
				{
					FlagCompareDVAttId = true;
					T_Device[IndexDevice].AttDevice[i * 2] = AttributeValue;
					break;
				}
			}
			if (FlagCompareDVAttId == false)
			{
				T_Device[IndexDevice].AttDevice[T_Device[IndexDevice].AttDevice[0] + 1] = AttributeId;
				T_Device[IndexDevice].AttDevice[T_Device[IndexDevice].AttDevice[0] + 2] = AttributeValue;
				T_Device[IndexDevice].AttDevice[0] = T_Device[IndexDevice].AttDevice[0] + 2;
			}
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutexUpdateDvValue);
		}
		usleep(3000);
	}
}

void UpdateDeviceValueRSP(int DeviceUnicastId, int AttributeId, int AttributeValue)
{
	if (IndexArrDvRSP <= 256)
	{
		bool FlagCompareDVUnicast = false;
		bool FlagCompareDVAttId = false;
		for (int i = 0; i <= IndexArrDvRSP; i++)
		{
			if (DeviceUnicastId == ArrDvRSP[i][0])
			{
				for (int j = 0; j < (ArrDvRSP[i][1] / 2); j++)
				{
					if (AttributeId == ArrDvRSP[i][(j + 1) * 2])
					{
						FlagCompareDVAttId = true;
						FlagCompareDVUnicast = true;
						ArrDvRSP[i][(j + 1) * 2 + 1] = AttributeValue;
						break;
					}
				}
				if (FlagCompareDVAttId == false)
				{
					ArrDvRSP[i][1] = ArrDvRSP[i][1] + 2;
					ArrDvRSP[i][ArrDvRSP[i][1]] = AttributeId;
					ArrDvRSP[i][ArrDvRSP[i][1] + 1] = AttributeValue;
					FlagCompareDVUnicast = true;
					break;
				}
			}
		}
		if (FlagCompareDVUnicast == false)
		{
			ArrDvRSP[IndexArrDvRSP][0] = DeviceUnicastId;
			ArrDvRSP[IndexArrDvRSP][1] = ArrDvRSP[IndexArrDvRSP][1] + 2;
			ArrDvRSP[IndexArrDvRSP][ArrDvRSP[IndexArrDvRSP][1]] = AttributeId;
			ArrDvRSP[IndexArrDvRSP][ArrDvRSP[IndexArrDvRSP][1] + 1] = AttributeValue;
			IndexArrDvRSP++;
		}
	}
}

void QueueMsgRSP(int DeviceUnicastId, int AttributeId, int AttributeValue, int TypeUpdate)
{
	if (TypeUpdate == 0)
	{
		UpdateDeviceValue(DeviceUnicastId, AttributeId, AttributeValue);
		UpdateDeviceValueRSP(DeviceUnicastId, AttributeId, AttributeValue);
	}
	else if (TypeUpdate == 1)
	{
		UpdateDeviceValue(DeviceUnicastId, AttributeId, AttributeValue);
	}
	else if (TypeUpdate == 2)
	{
		UpdateDeviceValueRSP(DeviceUnicastId, AttributeId, AttributeValue);
	}
}

void UpdateDeviceAttributeValue(string DeviceId, int DeviceUnicastId, int AttId, int AttValue)
{
	UpdateDeviceValue(DeviceUnicastId, AttId, AttValue);
	string UpdateDeviceValueIntoDeviceAttValue = "INSERT OR REPLACE INTO DeviceAttributeValue (DeviceId, DeviceUnicastId, DeviceAttributeId, Value, UpdateTime) "
											"values ('" +DeviceId + "', " + to_string(DeviceUnicastId) + ", " + to_string(AttId) + ", " + to_string(AttValue) + ", "+ to_string(GetTimrStamp()) +");";
	QueueDB.push(UpdateDeviceValueIntoDeviceAttValue);
	bool FlagCheckLock = false;
	while (FlagCheckLock == false)
	{
		if (pthread_mutex_trylock(&mutexDvOnline) == 0)
		{
			int IndexDvOnline = SearchDeviceCheckOnline(DeviceUnicastId);
			if (IndexDvOnline >= 0)
			{
				T_DeviceCheckOnline[IndexDvOnline].TimeCheck = GetSecondTimeNow();
				T_DeviceCheckOnline[IndexDvOnline].PreviousStatus = T_DeviceCheckOnline[IndexDvOnline].CurrentStatus;
				T_DeviceCheckOnline[IndexDvOnline].CurrentStatus = STATUS_ONLINE;
				if (T_DeviceCheckOnline[IndexDvOnline].PreviousStatus == STATUS_OFFLINE)
				{
					StringBuffer sendToApp;
					Writer<StringBuffer> json(sendToApp);
					json.StartObject();
					json.Key("CMD");
					json.String("DEVICE");
					json.Key("DATA");
					json.StartArray();
					json.StartObject();
					json.Key("DEVICE_ID");
					json.String(const_cast<char *>(DeviceId.c_str()));
					json.Key("PROPERTIES");
					json.StartArray();
					json.StartObject();
					json.Key("ID");
					json.Int(62);
					json.Key("VALUE");
					json.Int(STATUS_ONLINE);
					json.EndObject();
					json.EndArray();
					json.EndObject();
					json.EndArray();
					json.EndObject();
					string s = sendToApp.GetString();
					MqttSendAPP(mosq, const_cast<char *>(s.c_str()), true);
				}
			}
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutexDvOnline);
			break;
		}
		usleep(3000);
	}
}

//--------------GROUP-------------------------------------------------------------------
/*
 * Sửa lại phần mảng gửi xuống của phần ROOM
 * Trong bảng EventTrigerID và bảng GROUPID có thêm cột IsSuccess dùng để phân biệt các group và scene nào bị táo động trong qua trình cài đặt phòng
 * IsSuccess = 0: Scene/Group bị thay đổi 1->0 khi nhận được bản tin ROOM (úng với từng group/scene)
 * IsSuccess = 1: Scene/Group xử lý xong quá trình liên qua tói ROOM sẽ cập nhật lại IsSuccess 0->1
 */

void SendResultRoom()
{
	string CmdRSP = "";
	if (IsProcessRoom == CREATE_ROOM)
	{
		CmdRSP = "CREATE_ROOM";
	}
	else if (IsProcessRoom == ADD_DEVICE_TO_ROOM)
	{
		CmdRSP = "ADD_DEVICE_TO_ROOM";
	}
	else if (IsProcessRoom == REMOVE_DEVICE_FROM_ROOM)
	{
		CmdRSP = "REMOVE_DEVICE_FROM_ROOM";
	}
	else if (IsProcessRoom == DELETE_ROOM)
	{
		CmdRSP = "DELETE_ROOM";
	}
	for (int i = 0; i < 48; i++)
	{
		if (DeviceSceneRoom[i][0] == 0)
		{
			break;
		}
		for (int j = 0; j < 256; j++)
		{
			if (DeviceSceneRoom[i][j] == 0)
			{
				break;
			}
			// cout << DeviceSceneRoom[i][j] << " : ";
		}
		// cout << endl;
	}
	// cout << "-----------------------------------" << endl;
	for (int i = 0; i < 48; i++)
	{
		if (DeviceRoomSceneSuccess[i][0] == 0)
		{
			break;
		}
		for (int j = 0; j < 256; j++)
		{
			if (DeviceRoomSceneSuccess[i][j] == 0)
			{
				break;
			}
			// cout << DeviceRoomSceneSuccess[i][j] << " : ";
		}
		// cout << endl;
	}
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	json.StartObject();
	json.Key("CMD");
	json.String(const_cast<char *>(CmdRSP.c_str()));
	json.Key("DATA");
	json.StartObject();
	json.Key("GROUPS");
	json.StartArray();
	for (int i = 0; i < 48; i++)
	{
		if (DeviceGroupRoom[i][0] == 0 && DeviceAddRoomSuccess.size() == 0)
		{
			break;
		}
		if (DeviceGroupRoom[i][0] > 0 || DeviceAddRoomSuccess.size() > 0)
		{
			CONTROLSL = "";
			string CheckGroupId = "SELECT GroupingId FROM GROUPING WHERE GroupUnicastId = " + to_string(DeviceGroupRoom[i][0]) + ";";
			DB_ReadGHA(mosq, "CONTROL", CheckGroupId);
			string GROUPID = CONTROLSL;
			for (int j = 0; j < 48; j++)
			{
				if (DeviceGroupRoom[i][0] == DeviceRoomGroupSuccess[j][0] || DeviceAddRoomSuccess.size() > 0)
				{
					json.StartObject();
					json.Key("GROUP_ID");
					json.String(const_cast<char *>(GROUPID.c_str()));
					json.Key("GROUP_UNICAST_ID");
					json.Int(DeviceGroupRoom[i][0]);
					json.Key("SUCCESS");
					json.StartArray();
					for (int k = 1; k < 256; k++)
					{
						if (DeviceRoomGroupSuccess[j][k] == 0)
						{
							break;
						}
						else
						{
							CONTROLSL = "";
							string ChecKDvId = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(DeviceRoomGroupSuccess[j][k]) + ";";
							DB_ReadGHA(mosq, "CONTROL", ChecKDvId);
							json.String(CONTROLSL.c_str());
						}
					}
					json.EndArray();
					json.Key("FAILED");
					json.StartArray();
					for (int k = 1; k < 256; k++)
					{
						if (DeviceGroupRoom[j][k] == 0)
						{
							break;
						}
						else
						{
							bool CheckDV = false;
							for (int t = 1; t < 256; t++)
							{
								if (DeviceGroupRoom[j][k] == DeviceRoomGroupSuccess[j][t])
								{
									CheckDV = true;
									break;
								}
							}
							if (CheckDV == false)
							{
								CONTROLSL = "";
								string ChecKDvId = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(DeviceGroupRoom[j][k]) + ";";
								DB_ReadGHA(mosq, "CONTROL", ChecKDvId);
								json.String(CONTROLSL.c_str());
							}
							if (IsProcessRoom == REMOVE_DEVICE_FROM_ROOM)
							{
								string delDeviceGr = "DELETE FROM GroupingDeviceMapping WHERE GroupingId = '" + GROUPID + "' AND DeviceUnicastId = " + to_string(DeviceGroupRoom[j][k]) + ";";
								// cout << delDeviceGr << endl;
								DB_Write(delDeviceGr);
							}
						}
					}
					json.EndArray();
					json.EndObject();
					break;
				}
			}
			if (IsProcessRoom == DELETE_ROOM)
			{
				// string delGroupid = "UPDATE GROUPID SET ValueCreate = 0 WHERE GroupingId = '"+GROUPID+"';";
				// DB_Write(delGroupid);
				//						string creGroup1 = "DELETE FROM GROUPING WHERE GroupingId = '"+GROUPID+"';";
				//						DB_Write(creGroup1);
				string delDeviceGr = "DELETE FROM GroupingDeviceMapping WHERE GroupingId = '" + GROUPID + "';";
				DB_Write(delDeviceGr);
			}
			// string updateGroupSucces = "UPDATE GROUPID SET IsSuccess = -1 WHERE GroupingId = '"+GROUPID+"';";
			// DB_Write(updateGroupSucces);
		}
	}
	json.EndArray();
	json.Key("SCENES");
	json.StartArray();
	for (int i = 0; i < 48; i++)
	{
		if (DeviceSceneRoom[i][0] == 0)
		{
			break;
		}
		else
		{
			CONTROLSL = "";
			string sql12 = "SELECT EventTriggerId FROM EventTriggerID WHERE SceneUnicastID = " + to_string(DeviceSceneRoom[i][0]) + ";";
			DB_ReadGHA(mosq, "CONTROL", sql12);
			string SCENEID = CONTROLSL;
			for (int j = 0; j < 48; j++)
			{
				if (DeviceSceneRoom[i][0] == DeviceRoomSceneSuccess[j][0])
				{
					json.StartObject();
					json.Key("SCENE_ID");
					json.String(const_cast<char *>(SCENEID.c_str()));
					json.Key("SCENE_UNICAST_ID");
					json.Int(DeviceSceneRoom[j][0]);
					json.Key("SUCCESS");
					json.StartArray();
					for (int k = 1; k < 256; k++)
					{
						if (DeviceRoomSceneSuccess[j][k] == 0)
						{
							break;
						}
						else
						{
							CONTROLSL = "";
							string ChecKDvId = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(DeviceRoomSceneSuccess[j][k]) + ";";
							DB_ReadGHA(mosq, "CONTROL", ChecKDvId);
							json.String(CONTROLSL.c_str());
						}
					}
					json.EndArray();
					json.Key("FAILED");
					json.StartArray();
					for (int k = 1; k < 256; k++)
					{
						if (DeviceSceneRoom[j][k] == 0)
						{
							break;
						}
						else
						{
							bool CheckDV = false;
							for (int t = 1; t < 256; t++)
							{
								if (DeviceSceneRoom[j][k] == DeviceRoomSceneSuccess[j][t])
								{
									CheckDV = true;
									break;
								}
							}
							if (CheckDV == false)
							{
								CONTROLSL = "";
								string ChecKDvId = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(DeviceSceneRoom[j][k]) + ";";
								DB_ReadGHA(mosq, "CONTROL", ChecKDvId);
								json.String(CONTROLSL.c_str());
							}
							if (IsProcessRoom == REMOVE_DEVICE_FROM_ROOM)
							{
								string delDV = "delete from EventTriggerOutputDeviceSetupValue where  EventTriggerId = '" + SCENEID + "' and DeviceUnicastId = " + to_string(DeviceSceneRoom[i][k]) + ";";
								// cout << delDV << endl;
								DB_Write(delDV);
								string delD = "delete from EventTriggerOutputDeviceMapping where EventTriggerId = '" + SCENEID + "' and DeviceUnicastId = " + to_string(DeviceSceneRoom[i][k]) + ";";
								// cout << delD << endl;
								DB_Write(delD);
							}
						}
					}
					json.EndArray();
					json.EndObject();
					break;
				}
			}
			if (IsProcessRoom == DELETE_ROOM)
			{
				string delD = "delete from EventTriggerOutputDeviceMapping where EventTriggerId = '" + SCENEID + "';";
				DB_Write(delD);
				string delDV = "delete from EventTriggerOutputDeviceSetupValue where EventTriggerId = '" + SCENEID + "';";
				DB_Write(delDV);
			}
		}
	}
	json.EndArray();
	json.EndObject();
	json.EndObject();
	//	cout << sendToApp.GetString() << endl;
	string s = sendToApp.GetString();
	MqttSendAPP(mosq, const_cast<char *>(s.c_str()), true);
	ResetDataRoom();
	string UpdateRoom = "UPDATE QueueMsgRsp SET Msg = '" + s + "' WHERE Msg = '1';";
	//	cout << UpdateRoom << endl;
	DB_Write(UpdateRoom);
}

void SendResultGroup(string groupId, int groupUnicastId)
{
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	json.StartObject();
	json.Key("CMD");
	if (IsProcessGroup == CREATE_GROUP)
	{
		json.String("CREATE_GROUP");
	}
	else if (IsProcessGroup == ADD_DEVICE_TO_GROUP)
	{
		json.String("ADD_DEVICE_TO_GROUP");
	}
	else if (IsProcessGroup == REMOVE_DEVICE_FROM_GROUP)
	{
		json.String("DELETE_DEVICE_FROM_GROUP");
	}
	else if (IsProcessGroup == DELETE_GROUP)
	{
		json.String("DELETE_GROUP");
	}
	for (int j = 0; j < 256; j++)
	{
		if (DeviceGroup[j] == 0)
		{
			break;
		}
		// cout << DeviceGroup[j] << " : ";
	}
	// cout << endl;
	for (int j = 0; j < 256; j++)
	{
		if (DeviceGroupSuccess[j] == 0)
		{
			break;
		}
		// cout << DeviceGroupSuccess[j] << " : ";
	}
	// cout << endl;
	json.Key("DATA");
	json.StartObject();
	json.Key("GROUP_ID");
	json.String(const_cast<char *>(groupId.c_str()));
	json.Key("GROUP_UNICAST_ID");
	json.Int(groupUnicastId);
	json.Key("SUCCESS");
	json.StartArray();
	for (int i = 0; i < numDeviceGroupSuccess; i++)
	{
		CONTROLSL = "";
		string sql22 = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(DeviceGroupSuccess[i]) + " AND DeviceTypeId = 1;";
		// cout << "SQL: " << sql22 << endl;
		DB_ReadGHA(mosq, "CONTROL", sql22);
		string deviceId = CONTROLSL;
		if (IsProcessGroup == REMOVE_DEVICE_FROM_GROUP || IsProcessGroup == DELETE_GROUP)
		{
			string DelDVIntoGroupingDeviceMapping = "DELETE FROM GroupingDeviceMapping WHERE DeviceId= '" + deviceId + "' AND GroupingId = '" + groupId + "';";
			DB_Write(DelDVIntoGroupingDeviceMapping);
		}
		json.String(const_cast<char *>(deviceId.c_str()));
	}
	json.EndArray();
	json.Key("FAILED");
	json.StartArray();
	for (int i = 0; i < numDeviceGroup; i++)
	{
		bool CheckDeviceSuccess = false;
		for (int j = 0; j < numDeviceGroupSuccess; j++)
		{
			if (DeviceGroup[i] == DeviceGroupSuccess[j])
			{
				CheckDeviceSuccess = true;
				break;
			}
		}
		if (CheckDeviceSuccess == false)
		{
			CONTROLSL = "";
			string sql22 = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(DeviceGroup[i]) + " AND DeviceTypeId = 1;";
			// cout << "SQL: " << sql22 << endl;
			DB_ReadGHA(mosq, "CONTROL", sql22);
			string deviceId = CONTROLSL;
			json.String(const_cast<char *>(deviceId.c_str()));
		}
	}
	json.EndArray();
	json.EndObject();
	json.EndObject();
	cout << sendToApp.GetString() << endl;
	string s = sendToApp.GetString();
	MqttSendAPP(mosq, const_cast<char *>(s.c_str()), true);
	ResetDataGroup();
}
// int rspNumGroup = 0;
void RspAddGroup(struct mosquitto *mosq, char *jobj)
{
	bool FlagCheckLock = false;
	while (FlagCheckLock == false)
	{
		if (pthread_mutex_trylock(&mutex) == 0)
		{
			Document document;
			document.Parse(jobj);
			StringBuffer sendToApp;
			Writer<StringBuffer> json(sendToApp);
			const Value &DATA = document["DATA"];
			int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
			int GROUP = DATA["GROUP_UNICAST_ID"].GetInt();
			CONTROLSL = "";
			if (DATA.HasMember("ELEMENT_UNICAST_ID") && DATA["ELEMENT_UNICAST_ID"].IsInt())
			{
				int temp = DATA["ELEMENT_UNICAST_ID"].GetInt();
				if (temp > 0)
				{
					adr = temp;
				}
			}
			string sql11 = "SELECT GroupingId FROM GROUPING WHERE GroupUnicastId = " + to_string(GROUP) + ";";
			DB_ReadGHA(mosq, "CONTROL", sql11);
			string groupId = CONTROLSL;
			if (IsProcessGroup != 0)
			{
				DeviceGroupSuccess[numDeviceGroupSuccess] = adr;
				numDeviceGroupSuccess++;
			}
			TimeOut = GetSecondTimeNow();
			if (IsProcessRoom != 0)
			{
				numDeviceGroupRoomSuccess++;
				bool CheckDV = false;
				int IndexGroup = -1;
				for (int i = 0; i < 48; i++)
				{
					if (DeviceRoomGroupSuccess[i][0] == GROUP)
					{
						CheckDV = true;
						for (int j = 0; j < 256; j++)
						{
							if (DeviceRoomGroupSuccess[i][j] == 0)
							{
								DeviceRoomGroupSuccess[i][j] = adr;
								break;
							}
						}
						break;
					}
					if (DeviceRoomGroupSuccess[i][0] == 0)
					{
						IndexGroup = i;
						break;
					}
				}
				if (CheckDV == false)
				{
					DeviceRoomGroupSuccess[IndexGroup][0] = GROUP;
					DeviceRoomGroupSuccess[IndexGroup][1] = adr;
				}
			}
			if (numDeviceGroupSuccess == (numDeviceGroup))
			{
				if (IsProcessGroup != 0 && IsProcessDone == true)
				{
					SendResultGroup(ShareGroupId, ShareGroupUnicastId);
					IsProcessDone = false;
					TimeOut = 0;
				}
			}
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutex);
			break;
		}
		usleep(3000);
	}
}

void RspDelGroup(struct mosquitto *mosq, char *jobj)
{
	bool FlagCheckLock = false;
	while (FlagCheckLock == false)
	{
		if (pthread_mutex_trylock(&mutex) == 0)
		{
			Document document;
			document.Parse(jobj);
			StringBuffer sendToApp;
			Writer<StringBuffer> json(sendToApp);
			const Value &DATA = document["DATA"];
			int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
			int GROUP = DATA["GROUP_UNICAST_ID"].GetInt();
			if (DATA.HasMember("ELEMENT_UNICAST_ID") && DATA["ELEMENT_UNICAST_ID"].IsInt())
			{
				int temp = DATA["ELEMENT_UNICAST_ID"].GetInt();
				if (temp > 0)
				{
					adr = temp;
				}
			}
			if (IsProcessGroup != 0)
			{
				DeviceGroupSuccess[numDeviceGroupSuccess] = adr;
				numDeviceGroupSuccess++;
			}
			TimeOut = GetSecondTimeNow();
			if (IsProcessRoom != 0)
			{
				numDeviceGroupRoomSuccess++;
				bool CheckDV = false;
				int IndexGroup = -1;
				for (int i = 0; i < 48; i++)
				{
					if (DeviceRoomGroupSuccess[i][0] == GROUP)
					{
						CheckDV = true;
						for (int j = 0; j < 256; j++)
						{
							if (DeviceRoomGroupSuccess[i][j] == 0)
							{
								DeviceRoomGroupSuccess[i][j] = adr;
								break;
							}
						}
						break;
					}
					if (DeviceRoomGroupSuccess[i][0] == 0)
					{
						IndexGroup = i;
						break;
					}
				}
				if (CheckDV == false)
				{
					DeviceRoomGroupSuccess[IndexGroup][0] = GROUP;
					DeviceRoomGroupSuccess[IndexGroup][1] = adr;
				}
			}
			if (numDeviceGroupSuccess == (numDeviceGroup))
			{
				if (IsProcessGroup != 0 && IsProcessDone == true)
				{
					SendResultGroup(ShareGroupId, ShareGroupUnicastId);
					IsProcessDone = false;
					TimeOut = 0;
				}
			}
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutex);
			break;
		}
		usleep(3000);
	}
}

//--------------SCENE--------------------------------------------------------------------
/*TODO: DONE*/
void RspCallScene(struct mosquitto *mosq, char *jobj)
{
	TimeWaitRSP = GetSecondTimeNow();
	Document document;
	while (pthread_mutex_trylock(&mutexDvOnline) != 0)
	{
		usleep(3000);
	}
	FlagRSP = true;
	StrCmdRsp = DVValue;
	pthread_mutex_unlock(&mutexDvOnline);
	document.Parse(jobj);
	const Value &DATA = document["DATA"];
	int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
	int value = DATA["SCENEID"].GetInt();
	CONTROLSL = "";
	string sql = "SELECT EventTriggerId FROM EventTriggerID WHERE SceneUnicastID = " + to_string(value) + ";";
	DB_ReadGHA(mosq, "CONTROL", sql);
	string TempSceneIdRsp = CONTROLSL;
	string deviceId = GetUUId(mosq, adr);
	numAttributeId = 0;
	if (value != SceneUnicastIdRSP)
	{
		SceneIdRSP = TempSceneIdRsp;
		SceneUnicastIdRSP = value;
		FlagSceneRSP = true;
	}
	string selectAttributeCallscene =
		"SELECT DeviceId,DeviceUnicastId,DeviceAttributeId,DeviceAttributeValue from EventTriggerOutputDeviceSetupValue WHERE EventTriggerId = '" + TempSceneIdRsp + "' AND DeviceUnicastId = " + to_string(adr) + ";";
	// cout << "SQL: " << selectAttributeCallscene << endl;
	DB_ReadGHA(mosq, "CALLSCENE", selectAttributeCallscene);
	for (int i = 0; i < numAttributeId; i++)
	{
		if (attributeId_CallScene[i] == 3)
		{
			FlagHSLRSP = true;
		}
		// cout << adr << attributeId_CallScene[i] << attributeValue_CallScene[i] << endl;
		QueueMsgRSP(adr, attributeId_CallScene[i], attributeValue_CallScene[i], 0);
	}
}
void SendResultScene(string pSceneId, int pSceneUnicastId)
{
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	json.StartObject();
	json.Key("CMD");
	if (IsProcessScene == CREATE_SCENE)
	{
		json.String("CREATE_SCENE");
	}
	else if (IsProcessScene == EDIT_SCENE)
	{
		json.String("EDIT_SCENE");
	}
	else if (IsProcessScene == REMOVE_DEVICE_FROM_SCENE)
	{
		json.String("REMOVE_DEVICE_FROM_SCENE");
	}
	else if (IsProcessScene == DELETE_SCENE)
	{
		json.String("DELETE_SCENE");
	}
	json.Key("DATA");
	json.StartObject();
	json.Key("SCENE_ID");
	json.String(const_cast<char *>(pSceneId.c_str()));
	json.Key("SCENE_UNICAST_ID");
	json.Int(pSceneUnicastId);
	json.Key("SUCCESS");
	json.StartArray();
	for (int i = 0; i < numDeviceSceneSuccess; i++)
	{
		CONTROLSL = "";
		string sql22 = "SELECT DeviceId FROM Device WHERE DeviceUnicastId= " + to_string(DeviceSceneSuccess[i]) + ";";
		DB_ReadGHA(mosq, "CONTROL", sql22);
		string deviceId = CONTROLSL;
		if (IsProcessScene == DELETE_SCENE || IsProcessScene == REMOVE_DEVICE_FROM_SCENE)
		{
			string DelDVIntoEventTriggerOutputDeviceMapping = "DELETE FROM EventTriggerOutputDeviceMapping WHERE DeviceId= '" + deviceId + "' AND EventTriggerId = '" + pSceneId + "';";
			DB_Write(DelDVIntoEventTriggerOutputDeviceMapping);
			string DelDVIntoEventTriggerOutputDeviceSetupValue = "DELETE FROM EventTriggerOutputDeviceSetupValue WHERE DeviceId= '" + deviceId + "' AND EventTriggerId = '" + pSceneId + "';";
			DB_Write(DelDVIntoEventTriggerOutputDeviceSetupValue);
		}
		json.String(const_cast<char *>(deviceId.c_str()));
	}
	json.EndArray();
	json.Key("FAILED");
	json.StartArray();
	for (int i = 0; i < numDeviceScene; i++)
	{
		bool CheckFailed = false;
		for (int j = 0; j < numDeviceSceneSuccess; j++)
		{
			if (DeviceScene[i] == DeviceSceneSuccess[j])
			{
				CheckFailed = true;
				break;
			}
		}
		if (CheckFailed == false)
		{
			CONTROLSL = "";
			string sql22 = "SELECT DeviceId FROM Device WHERE DeviceUnicastId= " + to_string(DeviceScene[i]) + ";";
			DB_ReadGHA(mosq, "CONTROL", sql22);
			string deviceId = CONTROLSL;
			// cout << "DeviceUnicastfail: " << DeviceScene[i] << "DeviceId: " << deviceId << endl;
			json.String(const_cast<char *>(deviceId.c_str()));
		}
	}
	json.EndArray();
	json.EndObject();
	json.EndObject();
	cout << sendToApp.GetString() << endl;
	string s = sendToApp.GetString();
	MqttSendAPP(mosq, const_cast<char *>(s.c_str()), true);
	ResetDataScene();
}

void RspAddScene(struct mosquitto *mosq, char *jobj)
{
	bool FlagCheckLock = false;
	while (FlagCheckLock == false)
	{
		if (pthread_mutex_trylock(&mutex) == 0)
		{
			Document document;
			document.Parse(jobj);
			StringBuffer sendToApp;
			Writer<StringBuffer> json(sendToApp);
			const Value &DATA = document["DATA"];
			int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
			int sceneUnicastRsp = DATA["SCENEID"].GetInt();
			CONTROLSL = "";
			string sql11 = "SELECT EventTriggerId FROM EventTrigger WHERE SceneUnicastID  = " + to_string(sceneUnicastRsp) + ";";
			// cout << "SQL: " << sql11 << endl;
			DB_ReadGHA(mosq, "CONTROL", sql11);
			string SceneId = CONTROLSL;
			if (IsProcessScene != 0)
			{
				DeviceSceneSuccess[numDeviceSceneSuccess] = adr;
				numDeviceSceneSuccess++;
			}
			TimeOut = GetSecondTimeNow();
			if (IsProcessRoom != 0)
			{
				numDeviceSceneRoomSuccess++;
				bool CheckDV = false;
				int IndexScene = -1;
				for (int i = 0; i < 48; i++)
				{
					if (DeviceRoomSceneSuccess[i][0] == sceneUnicastRsp)
					{
						CheckDV = true;
						for (int j = 0; j < 256; j++)
						{
							if (DeviceRoomSceneSuccess[i][j] == 0)
							{
								DeviceRoomSceneSuccess[i][j] = adr;
								break;
							}
						}
						break;
					}
					if (DeviceRoomSceneSuccess[i][0] == 0)
					{
						IndexScene = i;
						break;
					}
				}
				if (CheckDV == false)
				{
					DeviceRoomSceneSuccess[IndexScene][0] = sceneUnicastRsp;
					DeviceRoomSceneSuccess[IndexScene][1] = adr;
				}
			}
			// cout << "numDeviceAddSceneSuccess " << numDeviceSceneRoomSuccess << endl;
			// cout << "numDeviceAddScene " << numDeviceSceneRoom << endl;
			if (numDeviceScene == numDeviceSceneSuccess)
			{
				if (IsProcessScene != 0 && IsProcessDone == true)
				{
					SendResultScene(ShareSceneId, ShareSceneUnicastId);
					TimeOut = 0;
					IsProcessDone = false;
				}
			}
			if (numDeviceSceneRoom == numDeviceSceneRoomSuccess)
			{
				if (IsProcessRoom != 0 && IsProcessDone == true)
				{
					SendResultRoom();
					TimeOut = 0;
					IsProcessDone = false;
				}
			}
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutex);
			break;
		}
		usleep(3000);
	}
}

void RspDelScene(struct mosquitto *mosq, char *jobj)
{
	bool FlagCheckLock = false;
	while (FlagCheckLock == false)
	{
		if (pthread_mutex_trylock(&mutex) == 0)
		{
			Document document;
			document.Parse(jobj);
			StringBuffer sendToApp;
			Writer<StringBuffer> json(sendToApp);
			const Value &DATA = document["DATA"];
			int adr = DATA["DEVICE_UNICAST_ID"].GetInt();
			int sceneUnicastRsp = DATA["SCENEID"].GetInt();
			CONTROLSL = "";
			string sql11 = "SELECT EventTriggerId FROM EventTrigger WHERE SceneUnicastID  = " + to_string(sceneUnicastRsp) + ";";
			DB_ReadGHA(mosq, "CONTROL", sql11);
			string SceneId = CONTROLSL;
			TimeOut = GetSecondTimeNow();
			if (IsProcessScene != 0)
			{
				DeviceSceneSuccess[numDeviceSceneSuccess] = adr;
				numDeviceSceneSuccess++;
			}
			if (IsProcessRoom != 0)
			{
				numDeviceSceneRoomSuccess++;
				bool CheckDV = false;
				int IndexScene = -1;
				for (int i = 0; i < 48; i++)
				{
					if (DeviceRoomSceneSuccess[i][0] == sceneUnicastRsp)
					{
						CheckDV = true;
						for (int j = 0; j < 256; j++)
						{
							if (DeviceRoomSceneSuccess[i][j] == 0)
							{
								DeviceRoomSceneSuccess[i][j] = adr;
								break;
							}
						}
						break;
					}
					if (DeviceRoomSceneSuccess[i][0] == 0)
					{
						IndexScene = i;
						break;
					}
				}
				if (CheckDV == false)
				{
					DeviceRoomSceneSuccess[IndexScene][0] = sceneUnicastRsp;
					DeviceRoomSceneSuccess[IndexScene][1] = adr;
				}
			}
			// cout << "so dv scene: " << numDeviceSceneRoom << " ------- so dv scene thanh cong: " << numDeviceSceneRoomSuccess << endl;
			if (numDeviceScene == numDeviceSceneSuccess)
			{
				if (IsProcessScene != 0 && IsProcessDone == true)
				{
					SendResultScene(ShareSceneId, ShareSceneUnicastId);
					TimeOut = 0;
					IsProcessDone = false;
				}
			}
			if (numDeviceSceneRoom == numDeviceSceneRoomSuccess)
			{
				if (IsProcessRoom != 0 && IsProcessDone == true)
				{
					SendResultRoom();
					TimeOut = 0;
					IsProcessDone = false;
				}
			}
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutex);
			break;
		}
		usleep(3000);
	}
}

bool isCreateScene = false;
int checkGroupId = 9;

void CheckTimeoutSendCmdRoom()
{
	bool FlagCheckLock = false;
	while (FlagCheckLock == false)
	{
		if (pthread_mutex_trylock(&mutex) == 0)
		{
			if (IsProcessRoom != 0 && IsProcessDone == true)
			{
				if ((GetSecondTimeNow() - TimeOut) >= 15)
				{
					// cout << "vao tu time out room" << endl;
					SendResultRoom();
					TimeOut = 0;
					IsProcessDone = false;
				}
			}
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutex);
			break;
		}
		usleep(3000);
	}
}

void CheckTimeoutGroup()
{
	if (IsProcessGroup != 0 && IsProcessDone == true)
	{
		if ((GetSecondTimeNow() - TimeOut) >= 4)
		{
			bool FlagCheckLock = false;
			while (FlagCheckLock == false)
			{
				if (pthread_mutex_trylock(&mutex) == 0)
				{
					SendResultGroup(ShareGroupId, ShareGroupUnicastId);
					IsProcessDone = false;
					FlagCheckLock = true;
					pthread_mutex_unlock(&mutex);
					break;
				}
				usleep(3000);
			}
		}
	}
}
void CheckTimeoutScene()
{
	pthread_mutex_unlock(&mutex);
	if (IsProcessScene != 0 && IsProcessDone == true)
	{
		if ((GetSecondTimeNow() - TimeOut) >= 4)
		{
			bool FlagCheckLock = false;
			while (FlagCheckLock == false)
			{
				if (pthread_mutex_trylock(&mutex) == 0)
				{
					SendResultScene(ShareSceneId, ShareSceneUnicastId);
					IsProcessDone = false;
					FlagCheckLock = true;
					pthread_mutex_unlock(&mutex);
					break;
				}
				usleep(3000);
			}
		}
	}
}

void checkTimeoutResetNode()
{
	pthread_mutex_lock(&mutex);
	if (isResetNode)
	{
		if ((GetSecondTimeNow() - TimeOut) >= 4)
		{
			SendReultResetNode();
			TimeOut = 0;
		}
	}
	pthread_mutex_unlock(&mutex);
}

void DeviceRSP(bool specialHC)
{
	bool FlagCheckLock = false;
	while (FlagCheckLock == false)
	{
		if (pthread_mutex_trylock(&mutexDvOnline) == 0)
		{
			if (FlagRSP == true && IndexArrDvRSP > 0)
			{
				if ((StrCmdRsp.compare(DVUpdateValue) == 0) || ((GetSecondTimeNow() - TimeWaitRSP) >= 4))
				{
					StringBuffer SendToApp;
					Writer<StringBuffer> json(SendToApp);
					json.StartObject();
					json.Key("CMD");
					json.String(const_cast<char *>(StrCmdRsp.c_str()));
					json.Key("DATA");
					json.StartArray();
					int IndexDvOnline = 0;
					for (int i = 0; i < IndexArrDvRSP; i++)
					{
						json.StartObject();
						string DeviceId = GetUUId(mosq, ArrDvRSP[i][0]);
						json.Key("DEVICE_ID");
						json.String(const_cast<char *>(DeviceId.c_str()));
						json.Key("DEVICE_UNICAST_ID");
						json.Int(ArrDvRSP[i][0]);
						IndexDvOnline = SearchDeviceCheckOnline(ArrDvRSP[i][0]);
						if (IndexDvOnline >= 0)
						{
							T_DeviceCheckOnline[IndexDvOnline].TimeCheck = GetSecondTimeNow();
							T_DeviceCheckOnline[IndexDvOnline].PreviousStatus = T_DeviceCheckOnline[IndexDvOnline].CurrentStatus;
							T_DeviceCheckOnline[IndexDvOnline].CurrentStatus = STATUS_ONLINE;
							if (T_DeviceCheckOnline[IndexDvOnline].PreviousStatus == STATUS_OFFLINE)
							{
								StringBuffer sendToApp;
								Writer<StringBuffer> json(sendToApp);
								json.StartObject();
								json.Key("CMD");
								json.String("DEVICE");
								json.Key("DATA");
								json.StartArray();
								json.StartObject();
								json.Key("DEVICE_ID");
								json.String(const_cast<char *>(DeviceId.c_str()));
								json.Key("PROPERTIES");
								json.StartArray();
								json.StartObject();
								json.Key("ID");
								json.Int(62);
								json.Key("VALUE");
								json.Int(STATUS_ONLINE);
								json.EndObject();
								json.EndArray();
								json.EndObject();
								json.EndArray();
								json.EndObject();
								string s = sendToApp.GetString();
								cout << s << endl;
								MqttSendAPP(mosq, const_cast<char *>(s.c_str()), true);
							}
						}
						json.Key("PROPERTIES");
						json.StartArray();
						for (int j = 0; j < ArrDvRSP[i][1] / 2; j++)
						{
							json.StartObject();
							json.Key("ID");
							json.Int(ArrDvRSP[i][(j + 1) * 2]);
							json.Key("VALUE");
							json.Int(ArrDvRSP[i][(j + 1) * 2 + 1]);
							json.EndObject();
							string UpdateDeviceValueIntoDeviceAttValue = "INSERT OR REPLACE INTO DeviceAttributeValue (DeviceId, DeviceUnicastId, DeviceAttributeId, Value, UpdateTime) "
																		 "values ('" +
																		 DeviceId + "', " + to_string(ArrDvRSP[i][0]) + ", " + to_string(ArrDvRSP[i][(j + 1) * 2]) + ", " + to_string(ArrDvRSP[i][(j + 1) * 2 + 1]) + ", "+ to_string(GetTimrStamp()) +");";
							QueueDB.push(UpdateDeviceValueIntoDeviceAttValue);
						}
						json.StartObject();
						json.Key("ID");
						json.Int(62);
						json.Key("VALUE");
						json.Int(STATUS_ONLINE);
						json.EndObject();
						json.EndArray();
						json.EndObject();
					}
					json.EndArray();
					json.EndObject();
					string s = SendToApp.GetString();
					cout << s << endl;
					MqttSendAPP(mosq, const_cast<char *>(s.c_str()), true);
					if (specialHC)
					{
						MqttSend(mosq, "{\"CMD\":\"CCT\",\"ACK\":false,\"TIME\":0,\"DATA\":{\"DEVICE_UNICAST_ID\":65535,\"VALUE_CCT\":28}}");
					}
					for (int dem1 = 0; dem1 < IndexArrDvRSP; dem1++)
					{
						for (int dem2 = 0; dem2 <= ArrDvRSP[dem1][1] + 1; dem2++)
						{
							ArrDvRSP[dem1][dem2] = 0;
						}
					}
					IndexArrDvRSP = 0;
					FlagRSP = false;
					StrCmdRsp = "";
					FlagHSLRSP = false;
					TimeWaitRSP = 0;
				}
			}
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutexDvOnline);
			break;
		}
		usleep(3000);
	}
}

void SceneRSP()
{
	if ((GetSecondTimeNow() - TimeWaitRSP) >= 2 && FlagSceneRSP == true)
	{
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
		json.Key("CMD");
		json.String("SCENE");
		json.Key("DATA");
		json.StartObject();
		json.Key("SCENE_ID");
		json.String(const_cast<char *>(SceneIdRSP.c_str()));
		json.Key("SCENE_UNICAST_ID");
		json.Int(SceneUnicastIdRSP);
		json.EndObject();
		json.EndObject();
		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSendAPP(mosq, const_cast<char *>(s.c_str()), true);
		FlagSceneRSP = false;
	}
}

void BackupHCRSP(char *jobj)
{
	MqttSendAPP(mosq, jobj, true);
}

void SapxepSceneDelayInput(int IndexSapxep)
{
	int TempIndex = IndexSceneDaleyCurrent + IndexSapxep + 1;
	if (TempIndex > SIZE_SCENE_DELAY - 1)
	{
		TempIndex = TempIndex - SIZE_SCENE_DELAY;
	}
	int TempIndexNext = TempIndex + 1;
	if (TempIndexNext > SIZE_SCENE_DELAY - 1)
	{
		TempIndexNext = TempIndexNext - SIZE_SCENE_DELAY;
	}
	for (int k = 0; k < SIZE_SCENE_DELAY; k++)
	{
		ArrSceneDelay[TempIndexNext][0] = ArrSceneDelay[TempIndex][0];
		ArrSceneDelay[TempIndexNext][1] = ArrSceneDelay[TempIndex][1];
		ArrSceneDelay[TempIndexNext][2] = ArrSceneDelay[TempIndex][2];
		ArrSceneDelay[TempIndexNext][3] = ArrSceneDelay[TempIndex][3];
		ArrSceneDelay[TempIndexNext][4] = ArrSceneDelay[TempIndex][4];
		ArrSceneDelay[TempIndexNext][5] = ArrSceneDelay[TempIndex][5];
	}
}

void GetDvSceneDelayInput(string SceneId)
{
	IndexSceneDelayInput = 0;
	string CheckSceneDelay = "SELECT DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time FROM EventTriggerOutputDeviceSetupValue"
							 " WHERE EventTriggerId = '" +
							 SceneId + "' ORDER BY Time ASC, DeviceAttributeId DESC;";
	// cout << CheckSceneDelay << endl;
	DB_ReadGHA(mosq, "CHECK_SCENE_DELAY", CheckSceneDelay);
	for (int i = 0; i < IndexSceneDelayInput; i++)
	{
		ArrInfoDvSceneDelayInput[i][3] += GetSecondTimeNow();
		if (ArrInfoDvSceneDelayInput[i][3] > 86400)
		{
			ArrInfoDvSceneDelayInput[i][3] = ArrInfoDvSceneDelayInput[i][3] - 86400;
		}
		// cout << ArrInfoDvSceneDelayInput[i][3] << endl;
		int TypeUnicast = 0;
		if (ArrInfoDvSceneDelayInput[i][0] > 49152)
		{
			TypeUnicast = 2;
		}
		else
		{
			TypeUnicast = 1;
		}
		bool FlagCheckLock = false;
		while (FlagCheckLock == false)
		{
			if (pthread_mutex_trylock(&mutexSceneDelay) == 0)
			{
				FlagCheckSceneDelay = true;
				for (int j = 0; j < SIZE_SCENE_DELAY; j++)
				{
					int TempIndex = -1;
					TempIndex = IndexSceneDaleyCurrent + j + 1;
					if (TempIndex >= SIZE_SCENE_DELAY)
					{
						TempIndex = TempIndex - SIZE_SCENE_DELAY;
					}
					if (ArrInfoDvSceneDelayInput[i][3] < ArrSceneDelay[TempIndex][4])
					{
						SapxepSceneDelayInput(j);
						ArrSceneDelay[TempIndex][0] = TypeUnicast;
						ArrSceneDelay[TempIndex][1] = ArrInfoDvSceneDelayInput[i][0];
						ArrSceneDelay[TempIndex][2] = ArrInfoDvSceneDelayInput[i][1];
						ArrSceneDelay[TempIndex][3] = ArrInfoDvSceneDelayInput[i][2];
						ArrSceneDelay[TempIndex][4] = ArrInfoDvSceneDelayInput[i][3];
						ArrSceneDelay[TempIndex][5] = 1;
						break;
					}
					else if (ArrSceneDelay[TempIndex][4] == -1)
					{
						// cout << TempIndex << endl;
						ArrSceneDelay[TempIndex][0] = TypeUnicast;
						ArrSceneDelay[TempIndex][1] = ArrInfoDvSceneDelayInput[i][0];
						ArrSceneDelay[TempIndex][2] = ArrInfoDvSceneDelayInput[i][1];
						ArrSceneDelay[TempIndex][3] = ArrInfoDvSceneDelayInput[i][2];
						ArrSceneDelay[TempIndex][4] = ArrInfoDvSceneDelayInput[i][3];
						ArrSceneDelay[TempIndex][5] = 1;
						break;
					}
				}
				for (int k = 0; k < SIZE_SCENE_DELAY; k++)
				{
					if (ArrSceneDelay[k][0] == -1)
					{
						break;
					}
					for (int m = 0; m < 6; m++)
					{
						// cout << ArrSceneDelay[k][m] << " -- ";
					}
					// cout << endl;
				}
				FlagCheckLock = true;
				pthread_mutex_unlock(&mutexSceneDelay);
				break;
			}
			usleep(3000);
		}
	}
}

void GetGrSceneDelayInput(string SceneId)
{
	IndexSceneDelayInput = 0;
	string CheckSceneDelay = "SELECT GroupUnicastId, DeviceAttributeId, DeviceAttributeValue, Time FROM EventTriggerOutputGroupingSetupValue"
							 " WHERE EventTriggerId = '" +
							 SceneId + "' ORDER BY Time ASC, DeviceAttributeId DESC;";
	// cout << CheckSceneDelay << endl;
	DB_ReadGHA(mosq, "CHECK_SCENE_DELAY", CheckSceneDelay);
	for (int i = 0; i < IndexSceneDelayInput; i++)
	{
		ArrInfoDvSceneDelayInput[i][3] += GetSecondTimeNow();
		if (ArrInfoDvSceneDelayInput[i][3] > 86400)
		{
			ArrInfoDvSceneDelayInput[i][3] = ArrInfoDvSceneDelay[i][3] - 86400;
		}
		// cout << ArrInfoDvSceneDelayInput[i][3] << endl;
		int TypeUnicast = 0;
		if (ArrInfoDvSceneDelayInput[i][0] > 49152)
		{
			TypeUnicast = 2;
		}
		else
		{
			TypeUnicast = 1;
		}
		bool FlagCheckLock = false;
		while (FlagCheckLock == false)
		{
			if (pthread_mutex_trylock(&mutexSceneDelay) == 0)
			{
				FlagCheckSceneDelay = true;
				for (int j = 0; j < SIZE_SCENE_DELAY; j++)
				{
					int TempIndex = -1;
					TempIndex = IndexSceneDaleyCurrent + j + 1;
					if (TempIndex >= SIZE_SCENE_DELAY)
					{
						TempIndex = TempIndex - SIZE_SCENE_DELAY;
					}
					if (ArrInfoDvSceneDelayInput[i][3] < ArrSceneDelay[TempIndex][4])
					{
						SapxepSceneDelayInput(j);
						ArrSceneDelay[TempIndex][0] = TypeUnicast;
						ArrSceneDelay[TempIndex][1] = ArrInfoDvSceneDelayInput[i][0];
						ArrSceneDelay[TempIndex][2] = ArrInfoDvSceneDelayInput[i][1];
						ArrSceneDelay[TempIndex][3] = ArrInfoDvSceneDelayInput[i][2];
						ArrSceneDelay[TempIndex][4] = ArrInfoDvSceneDelayInput[i][3];
						ArrSceneDelay[TempIndex][5] = 1;
						break;
					}
					else if (ArrSceneDelay[TempIndex][4] == -1)
					{
						// cout << TempIndex << endl;
						ArrSceneDelay[TempIndex][0] = TypeUnicast;
						ArrSceneDelay[TempIndex][1] = ArrInfoDvSceneDelayInput[i][0];
						ArrSceneDelay[TempIndex][2] = ArrInfoDvSceneDelayInput[i][1];
						ArrSceneDelay[TempIndex][3] = ArrInfoDvSceneDelayInput[i][2];
						ArrSceneDelay[TempIndex][4] = ArrInfoDvSceneDelayInput[i][3];
						ArrSceneDelay[TempIndex][5] = 1;
						break;
					}
				}
				for (int k = 0; k < SIZE_SCENE_DELAY; k++)
				{
					if (ArrSceneDelay[k][0] == -1)
					{
						break;
					}
					for (int m = 0; m < 6; m++)
					{
						// cout << ArrSceneDelay[k][m];
					}
					// cout << endl;
				}
				FlagCheckLock = true;
				pthread_mutex_unlock(&mutexSceneDelay);
				break;
			}
			usleep(3000);
		}
	}
}

string GetUUId(struct mosquitto *mosq, int adr)
{
	CONTROLSL = "";
	string UUId = "SELECT DeviceId from Device WHERE DeviceUnicastId = " + to_string(adr) + "  AND DeviceTypeID = 1 LIMIT 1;";
	DB_ReadGHA(mosq, "CONTROL", UUId);
	return CONTROLSL;
}

int SetDay()
{
	time_t now = time(0);
	tm *ltm = localtime(&now);
	// gán biến

	// ngày
	int day = ltm->tm_mday;
	int month = 1 + ltm->tm_mon;
	int year = 1900 + ltm->tm_year;
	string d, m;

	if (day < 10)
	{
		d = "0" + to_string(day);
	}
	else
	{
		d = to_string(day);
	}
	if (month < 10)
	{
		m = "0" + to_string(month);
	}
	else
	{
		m = to_string(month);
	}

	string timeNow = to_string(year) + m + d;
	// cout << "Ngày: " << timeNow << " "
	// 	 << "GHA" << endl;
	int x;
	stringstream geek(timeNow);
	geek >> x;
	return x;
}
