/*
 * JSON_GHA.cpp
 *
 *  Created on: Apr 10, 2021
 */

#include "../GHA/JSON/JSON_GHA.hpp"
#include "../AHG/JSON/JSON_AHG.hpp"

bool b = true;
int abc = 0;

bool checkHC() {
	FILE *file;
	file = fopen("/etc/SpecialHC.txt", "r");
	if(!file){
		cout << "Can not open this file" << endl;
		return false;
	}
	else{
		cout << "File is open" << endl;
		fclose(file);
		return true;
	}
}

int JsonParseGw(char * jobj){
	GHA_Msg.push(jobj);
	return 0;
}

void* GHA_MQTT(void *argv){
	bool send_massage = false;
	// bool specialHC = checkHC();
	while(1){
//		char Item_Pop[MAXLENGTHSTRING_RSP_TO_DEVICE] = {0};
		string Item_Pop = "";
//		if(pthread_mutex_trylock(&mutexRSP_DV) == 0)//dung
//		{
//			if (ringBuffer_IsEmpty(&queueRSP_DV) != true){
//				ringBuffer_Pop(&queueRSP_DV, Item_Pop);
//
//			}
//			else{
//			}
			if(!GHA_Msg.empty()){
				Item_Pop = GHA_Msg.front();
				send_massage = true;
				GHA_Msg.pop();
			}
//			pthread_mutex_unlock(&mutexRSP_DV);
//		}
		if(send_massage == true){
			send_massage = false;
			Check_CMD_GWtoHC(mosq, const_cast<char*>(Item_Pop.c_str()));
			// cout << "MESS_OUT: "<< Item_Pop << endl;
		}
		CheckTimeoutSendCmdRoom();
		CheckTimeoutGroup();
		CheckTimeoutScene();
//		checkTimeoutResetNode();
		DeviceRSP(false);
		SceneRSP();
		usleep (10000);
	}
	return 0;
}
