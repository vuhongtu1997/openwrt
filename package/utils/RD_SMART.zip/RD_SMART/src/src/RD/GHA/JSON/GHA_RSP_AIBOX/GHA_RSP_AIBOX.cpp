#include "GHA_RSP_AIBOX.hpp"

void RspFace(struct mosquitto *mosq, char* jobj)
{
    Document document;
	document.Parse(jobj);
    const Value& DATA = document["DATA"];
    if(DATA.HasMember("ID") && DATA["ID"].IsString()){
        string id = DATA["ID"].GetString();
        StringBuffer sendToApp;
        Writer<StringBuffer> json(sendToApp);
        json.StartObject();
            json.Key("CMD");json.String("DEVICE");
            json.Key("DATA");
            json.StartArray();
            json.StartObject();
                json.Key("DEVICE_ID");
                json.String(const_cast<char*>(id.c_str()));
                json.Key("PROPERTIES");
                json.StartArray();
                json.StartObject();
                json.Key("ID");json.Int(119);
                json.Key("VALUE");json.Int(1);
                json.EndObject();
                json.EndArray();
                json.EndObject();
            json.EndArray();
        json.EndObject();
        cout << sendToApp.GetString() << endl;
        string s = sendToApp.GetString();
        MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
    }
}

void RspZone(struct mosquitto *mosq, char* jobj)
{
    Document document;
	document.Parse(jobj);
    const Value& DATA = document["DATA"];
    if(DATA.HasMember("ID") && DATA["ID"].IsString() && 
        DATA.HasMember("ZONE_VALUE") && DATA["ZONE_VALUE"].IsInt()){
        string id = DATA["ID"].GetString();
        int temp_value = DATA["ID"].GetInt();
        if (temp_value == 1)
        {
            StringBuffer sendToApp;
            Writer<StringBuffer> json(sendToApp);
            json.StartObject();
                json.Key("CMD");json.String("DEVICE");
                json.Key("DATA");
                json.StartArray();
                json.StartObject();
                    json.Key("DEVICE_ID");
                    json.String(const_cast<char*>(id.c_str()));
                    json.Key("PROPERTIES");
                    json.StartArray();
                    json.StartObject();
                    json.Key("ID");json.Int(113);
                    json.Key("VALUE");json.Int(temp_value);
                    json.EndObject();
                    json.EndArray();
                    json.EndObject();
                json.EndArray();
            json.EndObject();
            cout << sendToApp.GetString() << endl;
            string s = sendToApp.GetString();
            MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
        }
    }
}