/*
 * GHA_RSP_SENSOR.hpp
 *
 *  Created on: Jan 9, 2022
 *      Author: rd
 */

#ifndef SRC_RD_GHA_JSON_GHA_RSP_SENSOR_GHA_RSP_SENSOR_HPP_
#define SRC_RD_GHA_JSON_GHA_RSP_SENSOR_GHA_RSP_SENSOR_HPP_

#include <iostream>
#include "../JSON_GHA.hpp"

#define ACTION_TIME_PIR		17
#define ACTION_MODE_PIR		70
#define SENSOR_SENSI		75
#define PIR_VALUE   		10
#define LIGHT_VALUE   		9
#define COUNTDOWN   		25
#define DISTANCE       		124

void RspLux(struct mosquitto *mosq, char* jobj);
void RspPir(struct mosquitto *mosq, char* jobj);
void RspSetScenePir(struct mosquitto *mosq, char* jobj);
void RspSetActionTime(struct mosquitto *mosq, char* jobj);
void RspDelScenePir(struct mosquitto *mosq, char* jobj);
void RspPower(struct mosquitto *mosq, char* jobj);
void RspSmoke(struct mosquitto* mosq, char * jobj);
void RspDoor(struct mosquitto* mosq, char * jobj);
void RspPm(struct mosquitto* mosq, char * jobj);
void RspTempHum(struct mosquitto* mosq, char * jobj);
void RspActionModePir(struct mosquitto *mosq, char* jobj);
void RspSensorSensi(struct mosquitto *mosq, char* jobj);
void RspPirLightStartUp(struct mosquitto *mosq, char* jobj);
void RspSetCountDownPirLight(struct mosquitto *mosq, char* jobj);
void RspSetDistance(struct mosquitto *mosq, char* jobj);

#endif /* SRC_RD_GHA_JSON_GHA_RSP_SENSOR_GHA_RSP_SENSOR_HPP_ */
