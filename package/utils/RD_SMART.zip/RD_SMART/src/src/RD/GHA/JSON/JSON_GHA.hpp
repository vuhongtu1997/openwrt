/*
 * JSON_GHA.hpp
 *
 *  Created on: Apr 10, 2021
 */

#ifndef RD_JSON_JSON_GHA_HPP_
#define RD_JSON_JSON_GHA_HPP_

#include "../../ShareData.hpp"
#include "GHA_RSP_CONTROL/GHA_RSP_CONTROL.hpp"
#include "GHA_RSP_SENSOR/GHA_RSP_SENSOR.hpp"
#include "GHA_RSP_REMOTE/GHA_RSP_REMOTE.hpp"
#include "GHA_RSP_AIBOX/GHA_RSP_AIBOX.hpp"

using namespace std;
using namespace rapidjson;

#define DVUpdateValue		"DEVICE_UPDATE"
#define DVValue		"DEVICE"

extern int ArrDvRSP[256][20];
extern string SceneIdRSP;
extern int IndexArrDvRSP;
extern int TimeWaitRSP;
extern bool FlagRSP;
extern string StrCmdRsp;
extern bool FlagHSLRSP;
extern bool FlagSceneRSP;
extern int ArrayCheck[256];
extern int IndexArrayCheck;
extern string CONTROLSL;
extern int ADRSL;
extern int SceneUnicastIdRSP;

extern int ArrInfoDvSceneDelayInput[256][4];
extern int IndexSceneDelayInput;

typedef struct{
	string ParentDeviceId;
	string ChildDeviceId;
	int ChildDeviceUnicastId;
}t_SubDevice;

typedef struct{
	string ParentDeviceId;
	string ChildDeviceId;
	int ChildDeviceUnicastId;
	int ButtonId;
	int DeviceTypeId;
	string MacAddr;
	string FirmVersion;
	string DeviceKey;
	string NetKey;
	string AppKey;
}t_SendSubDevice;

extern vector<t_SubDevice> SubDevice;

void* GHA_MQTT(void *argv);

/*-----------------------------------------------GW-------------------------------------------------------------*/

int JsonParseGw(char * jobj);
void Check_CMD_GWtoHC(struct mosquitto *mosq, char* jobj);
void NewDevice(struct mosquitto *mosq, char* jobj);
void NewChildDevice(struct mosquitto *mosq, char* jobj);
string GetUUId(struct mosquitto *mosq, int adr);

int SetDay();

void RspAddGroup(struct mosquitto *mosq, char* jobj);
void RspDelGroup(struct mosquitto *mosq, char* jobj);
void RspCallScene(struct mosquitto *mosq, char* jobj);
void RspAddScene(struct mosquitto *mosq, char* jobj);
void RspDelScene(struct mosquitto *mosq, char* jobj);
void RspResetNode(struct mosquitto *mosq, char* jobj);
void RspAddRoom(struct mosquitto *mosq, char* jobj);

void SendReultResetNode();
void SendResultRoom();
void SendResultGroup(string groupId, int groupUnicastId);
void SendResultScene(string pSceneId, int pSceneUnicastId);

void CheckTimeoutSendCmdRoom();
void CheckTimeoutGroup();
void CheckTimeoutScene();
void checkTimeoutResetNode();

void DeviceRSP(bool specialHC);
void DeviceUpdateStatus(char* jobj);
void QueueMsgRSP(int DeviceUnicastId, int AttributeId, int AttributeValue, int TypeUpdate);
void UpdateDeviceAttributeValue(string DeviceId, int DeviceUnicastId, int AttId, int AttValue);
void SceneRSP();
void BackupHCRSP(char* jobj);

void SapxepSceneDelayInput(int IndexSapxep);
void GetDvSceneDelayInput(string SceneId);
void GetGrSceneDelayInput(string SceneId);

int DB_ReadGHA(struct mosquitto *mosq,string control, string sql);


#endif /* RD_JSON_JSON_GHA_HPP_ */
