/*
 * GHA_RSP_REMOTE.hpp
 *
 *  Created on: Jan 9, 2022
 *      Author: rd
 */

#ifndef SRC_RD_GHA_JSON_GHA_RSP_REMOTE_GHA_RSP_REMOTE_HPP_
#define SRC_RD_GHA_JSON_GHA_RSP_REMOTE_GHA_RSP_REMOTE_HPP_

#include <iostream>
#include "../JSON_GHA.hpp"

#define REMOTE_MUL_UP						1
#define REMOTE_MUL_DOWN						2
#define REMOTE_MUL_MODE_DIM					0
#define REMOTE_MUL_MODE_CCT					1
#define REMOTE_MUL_MODE_RGB					2
#define REMOTE_MUL_SWITCH_CCT				0
#define REMOTE_MUL_SWITCH_RGB				1
#define REMOTE_MUL_SCENE_EN					1
#define REMOTE_MUL_SCENE_DIS				2
#define REMOTE_MUL_TIMER_EN					1
#define REMOTE_MUL_TIMER_DIS				2

using namespace std;

void RspRemote(struct mosquitto *mosq, char * jobj);
void RspRemotePairing(struct mosquitto *mosq, char * jobj);
void RspSetSceneRemote(struct mosquitto *mosq, char* jobj,string typeRemote);
void RspDelSceneRemote(struct mosquitto *mosq, char* jobj,string typeRemote);
void RspScreenTouch(struct mosquitto *mosq, char* jobj);
void RspGroup(char* jobj);
void RspSwitchModeDevice(struct mosquitto *mosq, char* jobj);

#endif /* SRC_RD_GHA_JSON_GHA_RSP_REMOTE_GHA_RSP_REMOTE_HPP_ */
