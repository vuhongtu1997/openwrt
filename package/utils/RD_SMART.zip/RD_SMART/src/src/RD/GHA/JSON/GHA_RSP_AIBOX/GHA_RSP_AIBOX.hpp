#include <iostream>
#include "../JSON_GHA.hpp"

void RspFace(struct mosquitto *mosq, char* jobj);
void RspZone(struct mosquitto *mosq, char* jobj);