/*
 * DeviceStatus.hpp
 *
 *  Created on: Dec 14, 2021
 *      Author: rd
 */

#ifndef SRC_RD_DVSTATUS_DEVICESTATUS_HPP_
#define SRC_RD_DVSTATUS_DEVICESTATUS_HPP_

#include "../ShareData.hpp"
#include "../MQTT/MQTT.hpp"

extern pthread_t DeviceOnlineOffline;
extern pthread_t DeviceOnlineOffline_tmp;
void GetNumDeviceCheckStatus();
void AutoUpdateDev();
void RestartThreadDeviceOnlineOffline();
void* DeviceOnline(void *argv);

#endif /* SRC_RD_DVSTATUS_DEVICESTATUS_HPP_ */
