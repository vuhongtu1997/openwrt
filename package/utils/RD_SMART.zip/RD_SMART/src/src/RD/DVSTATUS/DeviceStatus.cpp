#include "DeviceStatus.hpp"

pthread_t DeviceOnlineOffline;

void GetNumDeviceCheckValue(){
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutexUpdateDvValue) == 0){
			string GetDevice = "SELECT DeviceId, DeviceUnicastId, CategoryId FROM Device WHERE CategoryId NOT LIKE '23%' ORDER BY DeviceUnicastId ASC;";
			DB_Read("GET_DEVICE_UNICAST_CHECK_VALUE",GetDevice);
			string GetDormitoryId = "SELECT DormitoryId FROM UserData;";
			DB_Read("GET_DOMITORYID",GetDormitoryId);
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutexUpdateDvValue);
			break;
		}
		usleep (3000);
	}
	string GetDeviceValue = "SELECT DeviceUnicastId, DeviceAttributeId, Value FROM DeviceAttributeValue;";
	// cout << GetDeviceValue << endl;
	DB_Read("GET_DEVICE_VALUE",GetDeviceValue);
	for(unsigned int i=0;i< T_Device.size();i++){
			string DeviceId = T_Device[i].DeviceUUID;
			// cout << DeviceId;
			// for(int j=1; j<T_Device[i].AttDevice[0]/2;j++){
			// 	cout << " | " << T_Device[i].AttDevice[j*2-1];
			// 	cout << " | " <<T_Device[i].AttDevice[j*2];
			// }
			// cout << endl;
	}
}

void GetNumDeviceCheckOnline(){
	bool DVUPDATE_FlagCheckLock = true;
	while(DVUPDATE_FlagCheckLock){
		if(pthread_mutex_trylock(&mutexDvOnline) == 0){
			string GetDevice = "SELECT DISTINCT DeviceUnicastId, CategoryId, FirmwareVersion, DeviceId FROM Device Where CategoryId NOT LIKE '23%' AND CategoryId NOT LIKE '3%' AND CategoryId NOT LIKE '4%' AND CategoryId NOT LIKE '8%' AND DeviceId NOT IN (SELECT ChildDeviceId FROM SubDevice) ORDER BY DeviceUnicastId ASC;";
			DB_Read("GET_DEVICE_CHECK_ONLINE",GetDevice);
			int TimeStart = GetSecondTimeNow();
			for (unsigned int i=0; i<T_DeviceCheckOnline.size(); i++){
				T_DeviceCheckOnline[i].TimeCheck = TimeStart;
				T_DeviceCheckOnline[i].CurrentStatus  = STATUS_ONLINE;
				T_DeviceCheckOnline[i].PreviousStatus = STATUS_OFFLINE;
			}
			timeOffLine = TimeCheckOnline()*2 + 60;
			DVUPDATE_FlagCheckLock = false;
			pthread_mutex_unlock(&mutexDvOnline);
			break;
		}
		usleep (3000);
	}
}

void GetNumDeviceCheckStatus(){
	GetNumDeviceCheckValue();
	GetNumDeviceCheckOnline();
}

static void MsgCheckStatusDv(int DeviceUnicast, int TypeDevice, string Version){
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");json.String("UPDATE");
	json.Key("DATA");
	json.StartArray();
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(DeviceUnicast);
	json.Key("TYPE_DV");
	json.Int(TypeDevice);
	json.Key("VERSION");
	json.String(const_cast<char*>(Version.c_str()));
	json.EndObject();
	json.EndArray();
	json.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char*>(s.c_str()));
}

void AutoUpdateDev(int &Time, int TimeNow, bool &FlagSync, int TimeOffline){
	int	timeCheckOff = (timeOffLine/2);
	// cout << timeCheckOff << " -- " << timeOffLine << " -- "
	// 		<< Time << " -- " << (TimeNow - Time)
	// 		<< " -- " << TimeNow << " -- " << T_DeviceCheckOnline.size()
	// 		<< " -- " << TimeCheckOnline() << endl;
	if(abs(TimeNow-Time) >= timeCheckOff){
		for (int i=0; i<T_DeviceCheckOnline.size(); i++){
			MsgCheckStatusDv(T_DeviceCheckOnline[i].DeviceUnicastID, T_DeviceCheckOnline[i].TypeDevice, T_DeviceCheckOnline[i].FirmVersion);
		}
		Time = TimeNow;
		if(FlagSync == true){
			Time = TimeOffline;
			FlagSync = false;
		}
		StrCmdRsp = DVUpdateValue;
		FlagRSP = true;
	}
}

pthread_t DeviceOnlineOffline_tmp;
void* DeviceOnline(void *argv){
	DeviceOnlineOffline_tmp = pthread_self();
	GetNumDeviceCheckStatus();
	int TimeCheckCurrent = 0;
	int TimeCurrentSendHeartBeat = 0;
	bool flagsync = false;
	while(true){
		if(pthread_mutex_trylock(&mutexDvOnline) == 0){
			if(T_DeviceCheckOnline.size()){
				int TimeNow = GetSecondTimeNow();
				if(abs(TimeNow - TimeCheckCurrent) >= timeOffLine){
					bool FlagSendMsg = false;
					StringBuffer sendToApp;
					Writer<StringBuffer> json(sendToApp);
					json.StartObject();
					json.Key("CMD");json.String("DEVICE");
					json.Key("DATA");
					json.StartArray();
					for(int i=0; i<T_DeviceCheckOnline.size(); i++){
						// cout <<  timeOffLine << " -- " << (TimeNow-T_DeviceCheckOnline[i].TimeCheck) << endl;
						if(TimeNow > T_DeviceCheckOnline[i].TimeCheck){
							if(TimeNow-T_DeviceCheckOnline[i].TimeCheck > timeOffLine){
								T_DeviceCheckOnline[i].PreviousStatus = T_DeviceCheckOnline[i].CurrentStatus;
								T_DeviceCheckOnline[i].CurrentStatus = STATUS_OFFLINE;
								if(T_DeviceCheckOnline[i].CurrentStatus == STATUS_OFFLINE && T_DeviceCheckOnline[i].PreviousStatus == STATUS_ONLINE){
										json.StartObject();
										string DeviceId = T_DeviceCheckOnline[i].DeviceUUID;
										json.Key("DEVICE_ID");
										json.String(const_cast<char*>(DeviceId.c_str()));
										json.Key("PROPERTIES");
										json.StartArray();
										json.StartObject();
										json.Key("ID");json.Int(62);
										json.Key("VALUE");json.Int(STATUS_OFFLINE);
										json.EndObject();
										json.EndArray();
										json.EndObject();
										FlagSendMsg = true;
									// }
								}
							}
						}
						else if(TimeNow < T_DeviceCheckOnline[i].TimeCheck){
							if((86400+TimeNow-T_DeviceCheckOnline[i].TimeCheck) > timeOffLine){
								T_DeviceCheckOnline[i].PreviousStatus = T_DeviceCheckOnline[i].CurrentStatus;
								T_DeviceCheckOnline[i].CurrentStatus = STATUS_OFFLINE;
								if(T_DeviceCheckOnline[i].CurrentStatus == STATUS_OFFLINE && T_DeviceCheckOnline[i].PreviousStatus == STATUS_ONLINE){
									json.StartObject();
									string DeviceId = T_DeviceCheckOnline[i].DeviceUUID;
									json.Key("DEVICE_ID");
									json.String(const_cast<char*>(DeviceId.c_str()));
									json.Key("PROPERTIES");
									json.StartArray();
									json.StartObject();
									json.Key("ID");json.Int(62);
									json.Key("VALUE");json.Int(STATUS_OFFLINE);
									json.EndObject();
									json.EndArray();
									json.EndObject();
									FlagSendMsg = true;
								}
							}
						}
						if(T_DeviceCheckOnline[i].PreviousStatus == STATUS_OFFLINE && T_DeviceCheckOnline[i].CurrentStatus == STATUS_ONLINE){
							json.StartObject();
							string DeviceId = T_DeviceCheckOnline[i].DeviceUUID;
							json.Key("DEVICE_ID");
							json.String(const_cast<char*>(DeviceId.c_str()));
							json.Key("PROPERTIES");
							json.StartArray();
							json.StartObject();
							json.Key("ID");json.Int(62);
							json.Key("VALUE");json.Int(STATUS_ONLINE);
							json.EndObject();
							json.EndArray();
							json.EndObject();
							FlagSendMsg = true;
						}
					}
					json.EndArray();
					json.EndObject();
					string s = sendToApp.GetString();
					cout << s << endl;
					if(FlagSendMsg == true){
						MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
					}
					TimeCheckCurrent = TimeNow;
					flagsync = true;
				}
				AutoUpdateDev(TimeCurrentSendHeartBeat, TimeNow, flagsync, TimeCheckCurrent);
			}
			pthread_mutex_unlock(&mutexDvOnline);
		}
		while(pthread_mutex_trylock(&mutexUDP) != 0){
			usleep (3000);
		}
		pthread_mutex_unlock(&mutexUDP);
		sleep(5);
	}
	pthread_exit(NULL);
}

void RestartThreadDeviceOnlineOffline(){
	pthread_cancel(DeviceOnlineOffline_tmp);
	// cout << "-----> Exit" << endl;
	pthread_join(DeviceOnlineOffline, NULL);
	// cout << "-----> Start" << endl;
	sleep (10);
	pthread_create(&DeviceOnlineOffline, NULL, DeviceOnline, NULL);
}
