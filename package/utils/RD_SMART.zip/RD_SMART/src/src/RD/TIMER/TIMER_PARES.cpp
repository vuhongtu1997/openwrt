#include "TIMER_PARES.hpp"
#include "../AHG/JSON/JSON_AHG.hpp"
#include "../../RD/MQTT/MQTT.hpp"

using namespace std;
pthread_t threadTimer;

string EventTriggerId;
int HasReRpeater = -1;
int TimeDelay = 0;

vector <t_arrHCL> QueueHCL;
vector <int> QueueTempArrTime;
vector <int> QueueTime;

int TimerOver;
string to_strings;

//---------------------------
int LOGIC_RULE_ID = 3;
bool CheckTime = false;
int UNICAST = 0;
int ValueInput = -1;
int FlagCheckRuleAnd = false;
bool HasButtonInRule = false;
int NumberOfButtonInRuleAnd = 0;
bool UpdateHasRepeater = false;

//StringBuffer sendGW;
//Writer<StringBuffer> jsonS(sendGW);

char* CheckType;
int ADRTIMER;

int NumberOfRuleInputAnd = 0;

/*-----------------------------------------------DATABASE---------------------------------------------------------*/
/*{
  "CMD": "RULE_LOG",
  "DATA": [
    {
      "ruleId": "00000000-0000-0000-0000-000000000000",
      "ruleTypeId": 1,
      "ruleName": "string",
      "dormitoryId": "00000000-0000-0000-0000-000000000000",
      "endUserId": "00000000-0000-0000-0000-000000000000",
      "statusId": 1,
      "createdAt": "1970-01-01T00:00:00.000Z"
    }
  ]
}*/
void SendLogRule(struct mosquitto *mosq, string ruleId){
	string getLogRule = "SELECT EventTrigger.EventTriggerId, EventTrigger.EventTriggerTypeId, EventTrigger.StatusID, UserData.DormitoryId FROM EventTrigger, UserData WHERE EventTrigger.EventTriggerId = '"+ruleId+"';";
	DBRULE(mosq, "GET_RULE_LOG", getLogRule);
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
		json.Key("CMD");json.String("RULE_LOG");
		json.Key("DATA");
		json.StartArray();
			json.StartObject();
			json.Key("ruleId"); json.String(const_cast<char*>(ruleId.c_str()));
			json.Key("ruleTypeId"); json.Int(ruleLog.EventTriggerTypeId);
			json.Key("dormitoryId"); json.String(const_cast<char*>(ruleLog.DormitoryId.c_str()));
			json.Key("statusId"); json.Int(ruleLog.StatusId);
			json.Key("createdAt"); json.String(const_cast<char*>(currentISO8601LocalTime().c_str()));
			json.EndObject();
		json.EndArray();
	json.EndObject();
	string s = sendToGW.GetString();
	cout << s << endl;
	MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
}

static void ControlCurtain(struct mosquitto *mosq, int DVUnicaseID, int AttID, int AttValue){
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
		json.Key("CMD");json.String("DEVICE_CONTROL");
		json.Key("TYPE_DEV"),json.Int(22006);
		json.Key("DATA");
		json.StartObject();
			json.Key("DEVICE_UNICAST_ID");json.Int(DVUnicaseID);
			json.Key("PROPERTIES");
			json.StartArray();
			json.StartObject();
			json.Key("ID");
			json.Int(AttID);
			json.Key("VALUE");
			json.Int(AttValue);
			json.EndObject();
			json.EndArray();
		json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char*>(s.c_str()));
}

int Hue = -1;
int Station = -1;
int Lightness = -1;
static int RULEDEVICE(void *data, int argc, char **argv, char **azColName){
	int Transition = atoi((const char*) argv[3]);
	int ID = atoi((const char*) argv[1]);
	int DvUnicast = atoi((const char*) argv[0]);
	int Value = atoi((const char*) argv[2]);
	string deviceId = (const char*) argv[4];
	#if LOG_ACTIONS
	SendLogDevice(deviceId);
	#endif
	while (true){
		if(pthread_mutex_trylock(&mutexLog) == 0){
			WriteIntoLog("<"+EventTriggerId+" -> OutputDevice>","DeviceUnicast: " + to_string(DvUnicast) + " Properties: " + to_string(ID) + " Value: " + to_string(Value));
			pthread_mutex_unlock(&mutexLog);
			break;
		}
		usleep (3000);
	}
	if(ID == ATTRIBUTE_CCT){
		DvUnicast ++;
	}
	if((ID == ATTRIBUTE_HUE)||(ID == ATTRIBUTE_SATURATION)||(ID == ATTRIBUTE_LIGHTNESS)){
		if(ID == ATTRIBUTE_HUE){
			Hue = Value;
		}else if(ID == ATTRIBUTE_SATURATION){
			Station = Value;
		}else if(ID == ATTRIBUTE_LIGHTNESS){
			Lightness = Value;
		}
		if(Hue >= 0 && Station >= 0 && Lightness >= 0){
			StringBuffer sendGW;
			Writer<StringBuffer> json(sendGW);
			json.StartObject();
			json.Key("CMD");json.String("HSL");
			json.Key("TIME");json.Int(Transition);
			json.Key("ACK");json.Bool(false);
			json.Key("DATA");
			json.StartObject();
			json.Key("DEVICE_UNICAST_ID");json.Int(DvUnicast);
			json.Key("VALUE_H");json.Int(Hue);
			json.Key("VALUE_S");json.Int(Station);
			json.Key("VALUE_L");json.Int(Lightness);
			json.EndObject();
			json.EndObject();
			string s = sendGW.GetString();
			cout<<s<<endl;
			MqttSend(mosq, const_cast<char*>(s.c_str()));
			Hue = -1;
			Station = -1;
			Lightness = -1;
		}
	}
	else if(ID==23){
		StringBuffer sendToGW;
		Writer<StringBuffer> json(sendToGW);
		json.StartObject();
		json.Key("CMD");json.String("CALLMODE_RGB");
		json.Key("ACK");json.Bool(false);
		json.Key("DATA");
		json.StartObject();
		json.Key("DEVICE_UNICAST_ID");
		json.StartArray();
		json.Int(DvUnicast);
		json.EndArray();
		json.Key("SRGBID");json.Int(Value);
		json.EndObject();
		json.EndObject();
		string s = sendToGW.GetString();
		MqttSend(mosq, const_cast<char*>(s.c_str()));
	}
	else if(ID == 12 || ID == 13 || ID == 14 || ID == 11){
		ADRTIMER = -1;
		string GetTypeDv = "Select CategoryId from Device where DeviceUnicastId = "+to_string(DvUnicast)+";";
		DBRULE(mosq, "ADR", GetTypeDv);
		int TypeDV = ADRTIMER;
		StringBuffer sendToGW;
		Writer<StringBuffer> jsonAHG(sendToGW);
		jsonAHG.StartObject();
		jsonAHG.Key("CMD");jsonAHG.String("CONTROL_SWITCH");
		jsonAHG.Key("TYPE"); jsonAHG.Int(TypeDV);
		jsonAHG.Key("DATA");
		jsonAHG.StartObject();
		jsonAHG.Key("DEVICE_UNICAST_ID");jsonAHG.Int(DvUnicast);
		jsonAHG.Key("SWITCH_STATUS");
		jsonAHG.StartObject();
		if (ID == 11){
			jsonAHG.Key("RELAY1");
		}
		else if (ID == 12){
			jsonAHG.Key("RELAY2");
		}
		else if (ID == 13){
			jsonAHG.Key("RELAY3");
		}
		else if (ID == 14){
			jsonAHG.Key("RELAY4");
		}
		jsonAHG.Int(Value);
		jsonAHG.EndObject();
		jsonAHG.EndObject();
		jsonAHG.EndObject();
		string s = sendToGW.GetString();
		MqttSend(mosq, const_cast<char*>(s.c_str()));
	}
	else if(ID == 54 || ID == 55 || ID == 56 || ID == 57 || ID == 63){
		ControlCurtain(mosq, DvUnicast, ID, Value);
	}
	else
	{
		string keyControl[3] = {"VALUE_ONOFF","VALUE_DIM","VALUE_CCT"};
		string keyCmd[3]    = {"ONOFF","DIM","CCT"};
		StringBuffer sendGW;
		Writer<StringBuffer> json(sendGW);
		json.StartObject();
		json.Key("CMD");json.String(keyCmd[ID].c_str());
		json.Key("TIME");json.Int(Transition);
		json.Key("ACK");json.Bool(false);
		json.Key("DATA");
		json.StartObject();
		json.Key("DEVICE_UNICAST_ID");json.Int(DvUnicast);
		json.Key(keyControl[ID].c_str());json.Int(Value);
		json.EndObject();
		json.EndObject();
		string s = sendGW.GetString();
		cout<<s<<endl;
		MqttSend(mosq, const_cast<char*>(s.c_str()));
	}
	return 0;
}

static int RULEGROUP(void *data, int argc, char **argv, char **azColName){
	// cout << "INTO RULEGROUP"<<endl;
	int Transition = atoi((const char*) argv[3]);
	int ID = atoi((const char*) argv[1]);
	int DvUnicast = atoi((const char*) argv[0]);
	int Value = atoi((const char*) argv[2]);
	string groupId = (const char*) argv[4];
	#if LOG_ACTIONS
	SendLogGroup(groupId);
	#endif
	while (true){
		if(pthread_mutex_trylock(&mutexLog) == 0){
			WriteIntoLog("<"+EventTriggerId+" -> OutputGroup>","GroupUnicast: " + to_string(DvUnicast) + " Properties: " + to_string(ID) + " Value: " + to_string(Value));
			pthread_mutex_unlock(&mutexLog);
			break;
		}
		usleep (3000);
	}
	if((ID == ATTRIBUTE_HUE)||(ID == ATTRIBUTE_SATURATION)||(ID == ATTRIBUTE_LIGHTNESS)){
		if(ID == ATTRIBUTE_HUE){
			Hue = Value;
		}else if(ID == ATTRIBUTE_SATURATION){
			Station = Value;
		}else if(ID == ATTRIBUTE_LIGHTNESS){
			Lightness = Value;
		}
		if(Hue >= 0 && Station >= 0 && Lightness >= 0){
			StringBuffer sendGW;
			Writer<StringBuffer> json(sendGW);
			json.StartObject();
			json.Key("CMD");json.String("HSL");
			json.Key("TIME");json.Int(Transition);
			json.Key("ACK");json.Bool(false);
			json.Key("DATA");
			json.StartObject();
			json.Key("DEVICE_UNICAST_ID");json.Int(DvUnicast);
			json.Key("VALUE_H");json.Int(Hue);
			json.Key("VALUE_S");json.Int(Station);
			json.Key("VALUE_L");json.Int(Lightness);
			json.EndObject();
			json.EndObject();
			string s = sendGW.GetString();
			cout<<s<<endl;
			MqttSend(mosq, const_cast<char*>(s.c_str()));
			Hue = -1;
			Station = -1;
			Lightness = -1;
		}
	}
	else{
		string keyControl[3] = {"VALUE_ONOFF","VALUE_DIM","VALUE_CCT"};
		string keyCmd[3]    = {"ONOFF","DIM","CCT"};
		StringBuffer sendGW;
		Writer<StringBuffer> json(sendGW);
		json.StartObject();
		json.Key("CMD");json.String(keyCmd[ID].c_str());
		json.Key("TIME");json.Int(Transition);
		json.Key("ACK");json.Bool(false);
		json.Key("DATA");
		json.StartObject();
		json.Key("DEVICE_UNICAST_ID");json.Int(DvUnicast);
		json.Key(keyControl[ID].c_str());json.Int(Value);
		json.EndObject();
		json.EndObject();
		string s = sendGW.GetString();
		cout<<s<<endl;
		MqttSend(mosq, const_cast<char*>(s.c_str()));
	}
	return 0;
}

static void SapxepSceneDelay(int IndexSapxep){
	int TempIndex = IndexSceneDaleyCurrent+IndexSapxep+1;
	if(TempIndex > SIZE_SCENE_DELAY-1){
		TempIndex = TempIndex - SIZE_SCENE_DELAY;
	}
	int TempIndexNext = TempIndex + 1;
	if(TempIndexNext > SIZE_SCENE_DELAY-1){
		TempIndexNext = TempIndexNext - SIZE_SCENE_DELAY;
	}
	for(int k=0; k<SIZE_SCENE_DELAY; k++){
		ArrSceneDelay[TempIndexNext][0] = ArrSceneDelay[TempIndex][0];
		ArrSceneDelay[TempIndexNext][1] = ArrSceneDelay[TempIndex][1];
		ArrSceneDelay[TempIndexNext][2] = ArrSceneDelay[TempIndex][2];
		ArrSceneDelay[TempIndexNext][3] = ArrSceneDelay[TempIndex][3];
		ArrSceneDelay[TempIndexNext][4] = ArrSceneDelay[TempIndex][4];
		ArrSceneDelay[TempIndexNext][5] = ArrSceneDelay[TempIndex][5];
	}
}

void GetDvSceneDelay(string SceneId, int Delay){
	IndexSceneDelay = 0;
	string CheckSceneDelay = "SELECT DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time FROM EventTriggerOutputDeviceSetupValue"
			" WHERE EventTriggerId = '"	+ SceneId + "' ORDER BY Time ASC, DeviceUnicastId ASC, DeviceAttributeId DESC;";
	// cout << CheckSceneDelay << endl;
	DB_Read( "CHECK_SCENE_DELAY", CheckSceneDelay);
	for(int i=0; i<IndexSceneDelay; i++){
		ArrInfoDvSceneDelay[i][3] += GetSecondTimeNow()+1+Delay;
		if(ArrInfoDvSceneDelay[i][3] > 86400){
			ArrInfoDvSceneDelay[i][3] = ArrInfoDvSceneDelay[i][3] - 86400;
		}
		// cout << ArrInfoDvSceneDelay[i][3] << endl;
		int TypeUnicast = 0;
		if(ArrInfoDvSceneDelay[i][0] > 49152){
			TypeUnicast = 2;
		}
		else{
			TypeUnicast = 1;
		}
		bool FlagCheckLock = false;
		while (FlagCheckLock == false){
			if(pthread_mutex_trylock(&mutexSceneDelay) == 0){
				FlagCheckSceneDelay = true;
				for(int j=0; j<SIZE_SCENE_DELAY; j++){
					int TempIndex = -1;
					TempIndex = IndexSceneDaleyCurrent+j+1;
					if(TempIndex >= SIZE_SCENE_DELAY){
						TempIndex = TempIndex - SIZE_SCENE_DELAY;
					}
					if(ArrInfoDvSceneDelay[i][3] < ArrSceneDelay[TempIndex][4]){
						SapxepSceneDelay(j);
						ArrSceneDelay[TempIndex][0] = TypeUnicast;
						ArrSceneDelay[TempIndex][1] = ArrInfoDvSceneDelay[i][0];
						ArrSceneDelay[TempIndex][2] = ArrInfoDvSceneDelay[i][1];
						ArrSceneDelay[TempIndex][3] = ArrInfoDvSceneDelay[i][2];
						ArrSceneDelay[TempIndex][4] = ArrInfoDvSceneDelay[i][3];
						ArrSceneDelay[TempIndex][5] = 1;
						break;
					}
					else if(ArrSceneDelay[TempIndex][4] == -1){
						// cout << TempIndex << endl;
						ArrSceneDelay[TempIndex][0] = TypeUnicast;
						ArrSceneDelay[TempIndex][1] = ArrInfoDvSceneDelay[i][0];
						ArrSceneDelay[TempIndex][2] = ArrInfoDvSceneDelay[i][1];
						ArrSceneDelay[TempIndex][3] = ArrInfoDvSceneDelay[i][2];
						ArrSceneDelay[TempIndex][4] = ArrInfoDvSceneDelay[i][3];
						ArrSceneDelay[TempIndex][5] = 1;
						break;
					}
				}
				FlagCheckLock = true;
				pthread_mutex_unlock(&mutexSceneDelay);
				break;
			}
			usleep (3000);
		}
	}
}

void GetGrSceneDelay(string SceneId, int Delay){
	IndexSceneDelay = 0;
	string CheckSceneDelay = "SELECT GroupUnicastId, DeviceAttributeId, DeviceAttributeValue, Time FROM EventTriggerOutputGroupingSetupValue"
			" WHERE EventTriggerId = '"	+ SceneId + "' ORDER BY Time ASC, GroupUnicastId ASC, DeviceAttributeId DESC;";
	DB_Read( "CHECK_SCENE_DELAY", CheckSceneDelay);
	for(int i=0; i<IndexSceneDelay; i++){
		ArrInfoDvSceneDelay[i][3] += GetSecondTimeNow()+1+Delay;
		if(ArrInfoDvSceneDelay[i][3] > 86400){
			ArrInfoDvSceneDelay[i][3] = ArrInfoDvSceneDelay[i][3] - 86400;
		}
		int TypeUnicast = 0;
		if(ArrInfoDvSceneDelay[i][0] > 49152){
			TypeUnicast = 2;
		}
		else{
			TypeUnicast = 1;
		}
		bool FlagCheckLock = false;
		while (FlagCheckLock == false){
			if(pthread_mutex_trylock(&mutexSceneDelay) == 0){
				FlagCheckSceneDelay = true;
				for(int j=0; j<SIZE_SCENE_DELAY; j++){
					int TempIndex = -1;
					TempIndex = IndexSceneDaleyCurrent+j+1;
					if(TempIndex >= SIZE_SCENE_DELAY){
						TempIndex = TempIndex - SIZE_SCENE_DELAY;
					}
					if(ArrInfoDvSceneDelay[i][3] < ArrSceneDelay[TempIndex][4]){
						SapxepSceneDelay(j);
						ArrSceneDelay[TempIndex][0] = TypeUnicast;
						ArrSceneDelay[TempIndex][1] = ArrInfoDvSceneDelay[i][0];
						ArrSceneDelay[TempIndex][2] = ArrInfoDvSceneDelay[i][1];
						ArrSceneDelay[TempIndex][3] = ArrInfoDvSceneDelay[i][2];
						ArrSceneDelay[TempIndex][4] = ArrInfoDvSceneDelay[i][3];
						ArrSceneDelay[TempIndex][5] = 1;
						break;
					}
					else if(ArrSceneDelay[TempIndex][4] == -1){
						// cout << TempIndex << endl;
						ArrSceneDelay[TempIndex][0] = TypeUnicast;
						ArrSceneDelay[TempIndex][1] = ArrInfoDvSceneDelay[i][0];
						ArrSceneDelay[TempIndex][2] = ArrInfoDvSceneDelay[i][1];
						ArrSceneDelay[TempIndex][3] = ArrInfoDvSceneDelay[i][2];
						ArrSceneDelay[TempIndex][4] = ArrInfoDvSceneDelay[i][3];
						ArrSceneDelay[TempIndex][5] = 1;
						break;
					}
				}
				for(int k=0; k<SIZE_SCENE_DELAY; k++){
					if(ArrSceneDelay[k][0]==-1){
						break;
					}
					for(int m=0; m<6; m++){
						// cout << ArrSceneDelay[k][m];
					}
					// cout << endl;
				}
				FlagCheckLock = true;
				pthread_mutex_unlock(&mutexSceneDelay);
				break;
			}
			usleep (3000);
		}
	}
}

void AddSceneIntoArrCallScene(int SceneUnicastId, int Delay){
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutexSceneDelay) == 0){
			FlagCheckSceneDelay = true;
			Delay += GetSecondTimeNow()+1;
			for(int j=0; j<SIZE_SCENE_DELAY; j++){
				int TempIndex = -1;
				TempIndex = IndexSceneDaleyCurrent+j+1;
				if(TempIndex >= SIZE_SCENE_DELAY){
					TempIndex = TempIndex - SIZE_SCENE_DELAY;
				}
				if(Delay < ArrSceneDelay[TempIndex][4]){
					SapxepSceneDelay(j);
					ArrSceneDelay[TempIndex][0] = 3;
					ArrSceneDelay[TempIndex][1] = SceneUnicastId;
					ArrSceneDelay[TempIndex][2] = 0;
					ArrSceneDelay[TempIndex][3] = 0;
					ArrSceneDelay[TempIndex][4] = Delay;
					ArrSceneDelay[TempIndex][5] = 1;
					// cout << "Insert into index: " << TempIndex << endl;
					break;
				}
				else if(ArrSceneDelay[TempIndex][4] == -1){
					cout << TempIndex << endl;
					ArrSceneDelay[TempIndex][0] = 3;
					ArrSceneDelay[TempIndex][1] = SceneUnicastId;
					ArrSceneDelay[TempIndex][2] = 0;
					ArrSceneDelay[TempIndex][3] = 0;
					ArrSceneDelay[TempIndex][4] = Delay;
					ArrSceneDelay[TempIndex][5] = 1;
					// cout << "Insert into index: " << TempIndex << endl;
					break;
				}
			}
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutexSceneDelay);
			break;
		}
		usleep (3000);
	}
}

static int RULESCENE(void *data, int argc, char **argv, char **azColName){
	int adr = atoi((const char*) argv[0]);
	int times = atoi((const char*) argv[1]);
	string SceneId = (const char*) argv[2];
	ADR = -1;
	string CheckTypeScene = "SELECT EventTriggerTypeId FROM EventTrigger WHERE EventTriggerId = '"+SceneId+"';";
	// cout << CheckTypeScene << endl;
	DB_Read( "ADR", CheckTypeScene);
	int TypeScene = ADR;
	while (true){
		if(pthread_mutex_trylock(&mutexLog) == 0){
			WriteIntoLog("<"+EventTriggerId+" -> OutputScene>","SceneUnicast: " + to_string(adr));
			pthread_mutex_unlock(&mutexLog);
			break;
		}
		usleep (3000);
	}
	#if LOG_ACTIONS
	SendLogScene(SceneId);
	#endif
	if(TypeScene == 10){
		GetDvSceneDelay(SceneId, times);
		GetGrSceneDelay(SceneId, times);
	}
	else{
		AddSceneIntoArrCallScene(adr, times);
	}
	return 0;
}

#if REMOVE_ARR_SCENE_DELAY
static void InitArr(){
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutexSceneDelay) == 0){
			for(int k=0; k<SIZE_SCENE_DELAY; k++){
				for(int m=0; m<6; m++){
					ArrSceneDelay[k][m] = -1;
				}
				cout << endl;
			}
			IndexSceneDaleyCurrent = 0;
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutexSceneDelay);
			break;
		}
		usleep (3000);
	}
}
#endif

static void GetInfoControl(string RuleId){
	#if REMOVE_ARR_SCENE_DELAY
	InitArr();
	#endif
	if (sendMsgMultiHc)
	{
		string msg = "{\"CMD\":\"ACTIVE_RULE\",\"DATA\":{\"EVENT_TRIGGER_ID\":\""+RuleId+"\"}}";
		MqttSendMutiHC(mosqMaster, const_cast<char*>(msg.c_str()), true);
	}
	sendMsgMultiHc = true;
	string DEVICE = "SELECT EventTriggerOutputDeviceSetupValue.DeviceUnicastId, EventTriggerOutputDeviceSetupValue.DeviceAttributeId, EventTriggerOutputDeviceSetupValue.DeviceAttributeValue, EventTrigger.FADE_IN, EventTriggerOutputDeviceSetupValue.DeviceId"
			" FROM EventTriggerOutputDeviceSetupValue INNER JOIN EventTrigger"
			" ON EventTrigger.EventTriggerId = EventTriggerOutputDeviceSetupValue.EventTriggerId"
			" WHERE EventTriggerOutputDeviceSetupValue.EventTriggerId = '"+RuleId+"' ORDER BY EventTriggerOutputDeviceSetupValue.DeviceAttributeId;";
	// cout << DEVICE << endl;
	DBRULE(mosq, "RULEDEVICE", DEVICE);
	// cout << "RULE DEVICE "<< endl;
	string GROUPING = "SELECT EventTriggerOutputGroupingSetupValue.GroupUnicastId, EventTriggerOutputGroupingSetupValue.DeviceAttributeId, EventTriggerOutputGroupingSetupValue.DeviceAttributeValue, EventTrigger.FADE_IN, EventTriggerOutputGroupingSetupValue.GroupingId"
			" FROM EventTriggerOutputGroupingSetupValue INNER JOIN EventTrigger"
			" ON EventTrigger.EventTriggerId = EventTriggerOutputGroupingSetupValue.EventTriggerId"
			" WHERE EventTriggerOutputGroupingSetupValue.EventTriggerId = '"+RuleId+"' ORDER BY EventTriggerOutputGroupingSetupValue.DeviceAttributeId DESC;";
	// cout << "RULEGROUP: " <<GROUPING<< endl;
	DBRULE(mosq, "RULEGROUP", GROUPING);

	string SCENE = "SELECT EventTriggerOutputSceneMapping.SceneUnicastID, EventTriggerOutputSceneMapping.Time, EventTriggerOutputSceneMapping.SceneId FROM EventTriggerOutputSceneMapping INNER JOIN EventTrigger "
			"ON EventTrigger.EventTriggerId = EventTriggerOutputSceneMapping.EventTriggerId "
			"WHERE EventTriggerOutputSceneMapping.EventTriggerId = '"+RuleId+"' AND EventTriggerOutputSceneMapping.SceneUnicastID IS NOT NULL ORDER BY EventTriggerOutputSceneMapping.Time ASC;";
	// cout << "RULESCENE: " <<SCENE<< endl;
	DBRULE(mosq, "RULESCENE", SCENE);
}

static int CHECK_HCL(void *data, int argc, char **argv, char **azColName){
	EventTriggerId = (const char*) argv[0];
	string GROUPING = "SELECT EventTriggerOutputGroupingSetupValue.GroupUnicastId, EventTriggerOutputGroupingSetupValue.DeviceAttributeId, EventTriggerOutputGroupingSetupValue.DeviceAttributeValue, EventTriggerOutputGroupingSetupValue.Fade, EventTriggerOutputGroupingSetupValue.GroupingId "
			"FROM EventTriggerOutputGroupingSetupValue INNER JOIN EventTrigger ON EventTrigger.EventTriggerId = EventTriggerOutputGroupingSetupValue.EventTriggerId "
			"WHERE EventTriggerOutputGroupingSetupValue.EventTriggerId = '"+EventTriggerId+"' AND (EventTriggerOutputGroupingSetupValue.Time = '" + StringParseTime(TimerOver) + "' OR EventTriggerOutputGroupingSetupValue.Time = '" + StringParseTimeOld(TimerOver) + "') ORDER BY EventTriggerOutputGroupingSetupValue.DeviceAttributeId DESC;";
	// cout << GROUPING << endl;
	DBRULE(mosq, "RULEGROUP", GROUPING);
	return 0;
}

static int CHECK_RULE(void *data, int argc, char **argv, char **azColName){
	HasReRpeater = -1;
	EventTriggerId = (const char*) argv[0];
	HasReRpeater = atoi((const char*) argv[1]);
	string TimeCheck = StringParseTime(TimerOver);
	string TimeCheckOld = StringParseTimeOld(TimerOver);
	SendLogRule(mosq, EventTriggerId);
	while (true){
		if(pthread_mutex_trylock(&mutexLog) == 0){
			WriteIntoLog("<HC Active Rule>", EventTriggerId);
			pthread_mutex_unlock(&mutexLog);
			break;
		}
		usleep (3000);
	}
	string DEVICE =
			"SELECT EventTriggerOutputDeviceSetupValue.DeviceUnicastId, EventTriggerOutputDeviceSetupValue.DeviceAttributeId, EventTriggerOutputDeviceSetupValue.DeviceAttributeValue, EventTrigger.FADE_IN, EventTriggerOutputDeviceSetupValue.DeviceId"
					" FROM EventTriggerOutputDeviceSetupValue INNER JOIN EventTrigger"
					" ON EventTrigger.EventTriggerId = EventTriggerOutputDeviceSetupValue.EventTriggerId"
					" WHERE EventTriggerOutputDeviceSetupValue.EventTriggerId = '"+EventTriggerId+"'"
					" AND (EventTriggerOutputDeviceSetupValue.Time = '" + TimeCheck + "' OR EventTriggerOutputDeviceSetupValue.Time = '" + TimeCheckOld + "')"
					" ORDER BY EventTriggerOutputDeviceSetupValue.DeviceAttributeId DESC;";
	DBRULE(mosq, "RULEDEVICE", DEVICE);
	// cout << "RULE DEVICE: " + DEVICE << endl;
	string GROUPING =
			"SELECT EventTriggerOutputGroupingSetupValue.GroupUnicastId, EventTriggerOutputGroupingSetupValue.DeviceAttributeId, EventTriggerOutputGroupingSetupValue.DeviceAttributeValue, EventTrigger.FADE_IN, EventTriggerOutputGroupingSetupValue.GroupingId"
					" FROM EventTriggerOutputGroupingSetupValue INNER JOIN EventTrigger"
					" ON EventTrigger.EventTriggerId = EventTriggerOutputGroupingSetupValue.EventTriggerId"
					" WHERE EventTriggerOutputGroupingSetupValue.EventTriggerId = '"+EventTriggerId+"'"
					" AND (EventTriggerOutputGroupingSetupValue.Time = '" + TimeCheck + "' OR EventTriggerOutputGroupingSetupValue.Time = '" + TimeCheckOld + "')"
					" ORDER BY EventTriggerOutputGroupingSetupValue.DeviceAttributeId DESC;";
	DBRULE(mosq, "RULEGROUP", GROUPING);
	// cout << "RULEGROUP: " + GROUPING<< endl;
	string SCENE =
			"SELECT EventTriggerOutputSceneMapping.SceneUnicastId, EventTriggerOutputSceneMapping.Time, EventTriggerOutputSceneMapping.SceneId FROM EventTriggerOutputSceneMapping INNER JOIN EventTrigger "
					"ON EventTrigger.EventTriggerId = EventTriggerOutputSceneMapping.EventTriggerId "
					"WHERE EventTriggerOutputSceneMapping.EventTriggerId = '" + EventTriggerId + "' "
					"AND (EventTrigger.StartAt = '"	+ TimeCheck + "' OR EventTrigger.EndAt = '" + TimeCheck	+ "' OR EventTrigger.StartAt = '"	+ TimeCheckOld + "' OR EventTrigger.EndAt = '" + TimeCheckOld + "')"
					" AND EventTriggerOutputSceneMapping.SceneUnicastID IS NOT NULL ORDER BY EventTriggerOutputSceneMapping.Time ASC;";
	DBRULE(mosq, "RULESCENE", SCENE);
	// cout << "RULESCENE: " + SCENE<< endl;
	cout<<"get out check rule"<<endl;
	return 0;
}

static int CHECK_RULE_ID(void *data, int argc, char **argv, char **azColName){
	EventTriggerId = (const char*) argv[0];
	int att = atoi((const char *) argv[3]);
	int tpye_compare = atoi((const char *) argv[4]);
	int value = atoi((const char *) argv[5]);
	int value1 = 0;
	if(tpye_compare == 7){
		value1 = atoi((const char *) argv[6]);
	}
	if((tpye_compare == 1 && value == ValueInput) || (tpye_compare == 4 && ValueInput <= value) ||
			(tpye_compare == 6 && ValueInput >= value) || (tpye_compare == 7 && ValueInput >= value && ValueInput <= value1)){
		LOGIC_RULE_ID = 10;
		string RULE = "SELECT EventTriggerId,LogicalOperatorID FROM EventTrigger WHERE EventTriggerId = '"+EventTriggerId+"' AND StatusID = 1;";
		if(att == 11 || att == 12 || att == 13 || att == 14 || att == 15 || att == 16){
			HasButtonInRule = true;
		}
		DBRULE(mosq, "LOGIC_RULE", RULE);
	}
	return 0;
}

static void ControlOutputRule(string RuleId){
	string CHECK_RULE = "SELECT * FROM EventTriggerInputDeviceSetupValue WHERE EventTriggerId = '" + RuleId + "' AND EventTriggerInputDeviceSetupValue.DeviceAttributeValue IS NOT NULL ;";
	DBRULE(mosq, "RULE_INPUT_AND", CHECK_RULE);
	string CHECK_BUTTON_IN_RULE = "SELECT * from EventTriggerInputDeviceSetupValue INNER JOIN Device ON EventTriggerInputDeviceSetupValue.DeviceId =  Device.DeviceId WHERE EventTriggerId = '" + RuleId + "'AND Device.CategoryId LIKE '23%';";
	NumberOfButtonInRuleAnd = 0;
	DBRULE(mosq, "CHECK_BUTTON_IN_RULE", CHECK_BUTTON_IN_RULE);
	if(NumberOfButtonInRuleAnd > 0){
		NumberOfRuleInputAnd = NumberOfRuleInputAnd-NumberOfButtonInRuleAnd;
	}
	if(FlagCheckRuleAnd == NumberOfRuleInputAnd && NumberOfButtonInRuleAnd == 1 && HasButtonInRule == true){
		SendLogRule(mosq, RuleId);
		while (true){
			if(pthread_mutex_trylock(&mutexLog) == 0){
				WriteIntoLog("<HC Active Rule>", RuleId);
				pthread_mutex_unlock(&mutexLog);
				break;
			}
			usleep (3000);
		}
		GetInfoControl(RuleId);
		HasButtonInRule = false;
	}
	else if(FlagCheckRuleAnd == NumberOfRuleInputAnd && NumberOfButtonInRuleAnd == 0){
		SendLogRule(mosq, RuleId);
		while (true){
			if(pthread_mutex_trylock(&mutexLog) == 0){
				WriteIntoLog("<HC Active Rule>", RuleId);
				pthread_mutex_unlock(&mutexLog);
				break;
			}
			usleep (3000);
		}
		GetInfoControl(RuleId);
		HasButtonInRule = false;
	}
}

static int CHECK_TIME(void *data, int argc, char **argv, char **azColName){
	string TimeStart = (const char*) argv[0];
	string TimeEnd = (const char*) argv[1];
	int HasRepeater = atoi((const char*) argv[2]);
	int TimeNow = GetSecondTimeNow();
	int IntTimeStart = IntParseTime(const_cast<char*>(TimeStart.c_str()));
	int IntTimeEnd = IntParseTime(const_cast<char*>(TimeEnd.c_str()));
	if(IntTimeEnd < IntTimeStart){
		if(TimeNow >= IntTimeStart && TimeNow >= IntTimeEnd){
			CheckTime = true;
		}
		if(TimeNow <= IntTimeStart && TimeNow <= IntTimeEnd){
			CheckTime = true;
		}
	}
	if(TimeNow >= IntTimeStart && TimeNow <= IntTimeEnd){
		CheckTime = true;
	}
	if(CheckTime == true && HasRepeater == 0)
	{
		UpdateHasRepeater = true;
	}
	return 0;
}

static int LOGIC_RULE(void *data, int argc, char **argv, char **azColName){
	LOGIC_RULE_ID = atoi((const char*) argv[1]);
	EventTriggerId = (const char*) argv[0];
	if(LOGIC_RULE_ID == LOGIG_RULE_INPUT_OR || LOGIC_RULE_ID == LOGIG_RULE_INPUT_OR_TIME){
		if(LOGIC_RULE_ID == LOGIG_RULE_INPUT_OR){
			SendLogRule(mosq, EventTriggerId);
			while (true){
				if(pthread_mutex_trylock(&mutexLog) == 0){
					WriteIntoLog("<HC Active Rule>", EventTriggerId);
					pthread_mutex_unlock(&mutexLog);
					break;
				}
				usleep (3000);
			}
			GetInfoControl(EventTriggerId);
			HasButtonInRule = false;
		}
		else{
			string CHECK_RULE = "SELECT StartAt, EndAt, HasRepeater FROM EventTrigger WHERE EventTriggerId = '" + EventTriggerId + "';";
			DBRULE(mosq, "CHECK_TIME", CHECK_RULE);
			if (UpdateHasRepeater == false && CheckTime)
			{
				CheckTime = false;
				string weekDayss = GetDayOfWeek();
				string CHECK_RULE = "SELECT StartAt, EndAt, HasRepeater FROM EventTrigger WHERE EventTriggerId = '" + EventTriggerId + "' AND " + weekDayss +" = " + '1'+ " ;";
				DBRULE(mosq, "CHECK_TIME", CHECK_RULE);
			}
			if(CheckTime == true){
				SendLogRule(mosq, EventTriggerId);
				while (true){
					if(pthread_mutex_trylock(&mutexLog) == 0){
						WriteIntoLog("<HC Active Rule>", EventTriggerId);
						pthread_mutex_unlock(&mutexLog);
						break;
					}
					usleep (3000);
				}
				GetInfoControl(EventTriggerId);
				HasButtonInRule = false;
			}
		}
	}
	else if(LOGIC_RULE_ID == LOGIG_RULE_INPUT_AND || LOGIC_RULE_ID == LOGIG_RULE_INPUT_AND_TIME){
		if(LOGIC_RULE_ID == 1){
			ControlOutputRule(EventTriggerId);
		}
		else{
			string CHECK_RULE = "SELECT StartAt, EndAt, HasRepeater FROM EventTrigger WHERE EventTriggerId = '" + EventTriggerId + "';";
			DBRULE(mosq, "CHECK_TIME", CHECK_RULE);
			if (UpdateHasRepeater == false && CheckTime)
			{
				CheckTime = false;
				string weekDayss = GetDayOfWeek();
				string CHECK_RULE = "SELECT StartAt, EndAt, HasRepeater FROM EventTrigger WHERE EventTriggerId = '" + EventTriggerId + "' AND " + weekDayss +" = " + '1'+ " ;";
				DBRULE(mosq, "CHECK_TIME", CHECK_RULE);
			}
			if(CheckTime == true){
				ControlOutputRule(EventTriggerId);
			}
		}
	}
	CheckTime = false;
	return 0;
}

static int CHECK_BUTTON_IN_RULE(void *data, int argc, char **argv, char **azColName){
	NumberOfButtonInRuleAnd ++;
	return 0;
}

static int RULE_INPUT_AND(void *data, int argc, char **argv, char **azColName){
	NumberOfRuleInputAnd ++;
	int DeviceUnicastInputRule = atoi((const char *) argv[2]);
	int DeviceAttInputRule = atoi((const char *) argv[3]);
	int TypeCompare = atoi((const char *) argv[4]);
	int Value = atoi((const char *) argv[5]);
	int Value1 = 0;
	int Value2 = 0;
	if(TypeCompare == 7){
		Value1 = atoi((const char *) argv[6]);
	}
	int IndexDeviceGetValue = SearchDeviceUpdateValue(DeviceUnicastInputRule);
	for (int i = 1; i <= (T_Device[IndexDeviceGetValue].AttDevice[0]/2); i++) {
		if (DeviceAttInputRule == T_Device[IndexDeviceGetValue].AttDevice[i*2-1]) {
			Value2 = T_Device[IndexDeviceGetValue].AttDevice[i*2];
			break;
		}
	}
	if((TypeCompare == 1 && Value2 == Value) || (TypeCompare == 4 && Value <= Value2) ||
			(TypeCompare == 6 && Value >= Value2) || (TypeCompare == 7 && Value1 >= Value2 && Value <= Value2)){
		FlagCheckRuleAnd ++;
	}
	return 0;
}

static int CallbackSQLTimeRule(void *data, int argc, char **argv, char **azColName){
	string a;
//	for(int i = 0; i<argc; i++){
			a = (const char*) argv[0];
				if(a.compare("") != 0){
//			jsonS.Int(IntParseTime(const_cast<char*>(a.c_str())));
			// cout << a <<endl;
			QueueTime.push_back(IntParseTime(const_cast<char*>(a.c_str())));
		}
//	}
	return 0;
}

static int CallbackSQLTimeHCL(void *data, int argc, char **argv, char **azColName){
	string a;
//	for(int i = 0; i<argc; i++){
		a = (const char*) argv[0];
		// cout << "Time string call rule: " << a << endl;
		if(a.compare("") != 0){
//			jsonS.Int(IntParseTime(const_cast<char*>(a.c_str())));
//			QueueHCL.push_back(IntParseTime(const_cast<char*>(a.c_str())));
		}
//	}
	return 0;
}

static int TIME_CONTROL_HCL(void *data, int argc, char **argv, char **azColName){
	t_arrHCL TempCheckHCL;
	TempCheckHCL.DeviceAttributeId = atoi((const char *) argv[1]);
	TempCheckHCL.DeviceAttributeValue = atoi((const char *) argv[2]);
	TempCheckHCL.Fade = atoi((const char *) argv[3]);
	TempCheckHCL.GroupUnicastId = atoi((const char *) argv[0]);
	TempCheckHCL.Time = IntParseTime(const_cast<char*>((const char *) argv[5]));
	QueueHCL.push_back(TempCheckHCL);
	return 0;
}

static int CallbackSQL(void *data, int argc, char **argv, char **azColName){
	for(int i = 0; i<argc; i++){
		string a = (const char*) argv[i];
		CheckType = const_cast<char*>(a.c_str());
	}
	return 0;
}

static int CallbackSQLID(void *data, int argc, char **argv, char **azColName){
	for(int i = 0; i<argc; i++){
		ADRTIMER = atoi((const char *)argv[i]);
	}
	return 0;
}

static int CHECK_TAP_TO_RUN(void *data, int argc, char **argv, char **azColName){
	int LogicalOperatorID = atoi((const char *) argv[6]);
	EventTriggerId = (const char*) argv[0];
	if(LogicalOperatorID == LOGIC_RULE_TIME || LogicalOperatorID == TAP_TO_RUN){
		string DEVICE =
				"SELECT EventTriggerOutputDeviceSetupValue.DeviceUnicastId, EventTriggerOutputDeviceSetupValue.DeviceAttributeId, EventTriggerOutputDeviceSetupValue.DeviceAttributeValue, EventTrigger.FADE_IN, EventTriggerOutputDeviceSetupValue.DeviceId"
						" FROM EventTriggerOutputDeviceSetupValue INNER JOIN EventTrigger"
						" ON EventTrigger.EventTriggerId = EventTriggerOutputDeviceSetupValue.EventTriggerId"
						" WHERE EventTriggerOutputDeviceSetupValue.EventTriggerId = '"+EventTriggerId+"'"
						" ORDER BY EventTriggerOutputDeviceSetupValue.DeviceAttributeId DESC;";
		DBRULE(mosq, "RULEDEVICE", DEVICE);
		// cout << "RULE DEVICE: " + DEVICE << endl;
		string GROUPING =
				"SELECT EventTriggerOutputGroupingSetupValue.GroupUnicastId, EventTriggerOutputGroupingSetupValue.DeviceAttributeId, EventTriggerOutputGroupingSetupValue.DeviceAttributeValue, EventTrigger.FADE_IN, EventTriggerOutputGroupingSetupValue.GroupingId"
						" FROM EventTriggerOutputGroupingSetupValue INNER JOIN EventTrigger"
						" ON EventTrigger.EventTriggerId = EventTriggerOutputGroupingSetupValue.EventTriggerId"
						" WHERE EventTriggerOutputGroupingSetupValue.EventTriggerId = '"+EventTriggerId+"'"
						" ORDER BY EventTriggerOutputGroupingSetupValue.DeviceAttributeId DESC;";
		DBRULE(mosq, "RULEGROUP", GROUPING);
		// cout << "RULEGROUP: " + GROUPING<< endl;
		string SCENE =
				"SELECT EventTriggerOutputSceneMapping.SceneUnicastId, EventTriggerOutputSceneMapping.Time, EventTriggerOutputSceneMapping.SceneId FROM EventTriggerOutputSceneMapping INNER JOIN EventTrigger "
						"ON EventTrigger.EventTriggerId = EventTriggerOutputSceneMapping.EventTriggerId "
						"WHERE EventTriggerOutputSceneMapping.EventTriggerId = '" + EventTriggerId + "' "
						" AND EventTriggerOutputSceneMapping.SceneUnicastID IS NOT NULL ORDER BY EventTriggerOutputSceneMapping.Time ASC;";
		DBRULE(mosq, "RULESCENE", SCENE);
	}
	else if(LogicalOperatorID > LOGIC_RULE_TIME){
		GetInfoControl(EventTriggerId);
	}
	return 0;
}

static int GET_RULE_LOG(void *data, int argc, char **argv, char **azColName){
	ruleLog.EventTriggerId = (const char*) argv[0];
	ruleLog.EventTriggerTypeId = atoi((const char*) argv[1]);
	ruleLog.StatusId = atoi((const char*) argv[2]);
	ruleLog.DormitoryId = (const char*) argv[3];
	return 0;
}

int DBRULE(struct mosquitto *mosq, string control, string sql) {
	sqlite3* DB;
	int exit = 0;
	do {
			exit = sqlite3_open("/root/rd.Sqlite", &DB);
			usleep (10000);
		} while (exit != SQLITE_OK);
	char* messaggeError;
		if(control == "STARTAT"){
		while((sqlite3_exec(DB, const_cast<char*>(sql.c_str()), CallbackSQLTimeRule, 0, &messaggeError)) != SQLITE_OK){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if(control == "STARTAT_NOREPEATE") {
		while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), CallbackSQLTimeRule, 0, &messaggeError)!=SQLITE_OK){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if(control == "ENDAT") {
		while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), CallbackSQLTimeRule, 0, &messaggeError)!=SQLITE_OK){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if(control == "ENDAT_NOREPEATE") {
		while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), CallbackSQLTimeRule, 0, &messaggeError)!=SQLITE_OK){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if(control == "TIME_HCL") {
		while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), CallbackSQLTimeRule, 0, &messaggeError)!=SQLITE_OK){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if(control == "HCL") {
		while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), CallbackSQLTimeHCL, 0, &messaggeError)!=SQLITE_OK){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if(control == "TIME_CONTROL_HCL") {
		while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), TIME_CONTROL_HCL, 0, &messaggeError)!=SQLITE_OK){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if(control == "CHECKTYPE") {
		while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), CallbackSQL, 0, &messaggeError)!=SQLITE_OK ){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if(control == "ADR") {
		while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), CallbackSQLID, 0, &messaggeError)!=SQLITE_OK ){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if(control == "CHECK_RULE") {
		while((sqlite3_exec(DB, const_cast<char*>(sql.c_str()), CHECK_RULE, 0, &messaggeError))!=SQLITE_OK ){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if(control == "CHECK_HCL") {
		while((sqlite3_exec(DB, const_cast<char*>(sql.c_str()), CHECK_HCL, 0, &messaggeError))!=SQLITE_OK ){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if(control == "RULEDEVICE") {
		while((sqlite3_exec(DB, const_cast<char*>(sql.c_str()), RULEDEVICE, 0, &messaggeError))!=SQLITE_OK ){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if(control == "RULEGROUP") {
		while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), RULEGROUP, 0, &messaggeError)!=SQLITE_OK ){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if(control == "RULESCENE") {
		while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), RULESCENE, 0, &messaggeError)!=SQLITE_OK ){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if (control == "CHECK_RULE_ID") {
		while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), CHECK_RULE_ID, 0, &messaggeError)!=SQLITE_OK ){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if (control == "LOGIC_RULE") {
		while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), LOGIC_RULE, 0, &messaggeError)!=SQLITE_OK ){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if (control == "RULE_INPUT_AND") {
		while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), RULE_INPUT_AND, 0, &messaggeError)!=SQLITE_OK ){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if (control == "CHECK_BUTTON_IN_RULE") {
		while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), CHECK_BUTTON_IN_RULE, 0, &messaggeError)!=SQLITE_OK ){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if (control == "CHECK_TIME") {
		while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), CHECK_TIME, 0, &messaggeError)!=SQLITE_OK ){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if (control == "CHECK_TAP_TO_RUN"){
		while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), CHECK_TAP_TO_RUN, 0, &messaggeError)!=SQLITE_OK ){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	else if (control == "GET_RULE_LOG"){
		while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), GET_RULE_LOG, 0, &messaggeError)!=SQLITE_OK ){
			sqlite3_free(messaggeError);
			usleep (10000);
		}
	}
	sqlite3_close(DB);
		return (0);
}

int DB_Write_Time(string sql) {
	sqlite3* DB;
	int exit = 0;
	do {
		exit = sqlite3_open("/root/rd.Sqlite", &DB);
		usleep (10000);
	} while (exit != SQLITE_OK);
	char* messaggeError = 0;
	while(sqlite3_exec(DB, const_cast<char*>(sql.c_str()), NULL, 0, &messaggeError) != SQLITE_OK){
		sqlite3_free(messaggeError);
		usleep (10000);
	}
	sqlite3_close(DB);
		return (0);
}


//---------------------------------------------------------------------------------------CALL EVENT

void ResetThread(){ // @suppress("No return")
	cout<<"RESET"<<endl;
	sleep(1);
	pthread_cancel(threadTimer_tmp);
	pthread_join(threadTimer, NULL);
	pthread_create(&threadTimer, NULL, CallEvent, &CheckHCL);
	sleep (2);
}

int Event(struct mosquitto *mosq, char * jobj){ // @suppress("No return")
	Document document;
	document.Parse(jobj);
	NumberOfRuleInputAnd = 0;
	FlagCheckRuleAnd = 0;
	HasButtonInRule = false;
	if(document.HasMember("CMD")){
		TimeDelay = 0;
		string Cmd = document["CMD"].GetString();
		if (Cmd.compare("REMOTE") == 0) {
			UNICAST = 0;
			const Value& DATA = document["DATA"];
			UNICAST = DATA["DEVICE_UNICAST_ID"].GetInt();
			string BUTTONID = DATA["BUTTON_VALUE"].GetString();
			ValueInput = DATA["MODE_VALUE"].GetInt();
			int DeviceAttId = 0;
			if(BUTTONID.compare("BUTTON_1")==0){
				DeviceAttId = 11;
			}
			if(BUTTONID.compare("BUTTON_2")==0){
				DeviceAttId = 12;
			}
			if(BUTTONID.compare("BUTTON_3")==0){
				DeviceAttId = 13;
			}
			if(BUTTONID.compare("BUTTON_4")==0){
				DeviceAttId = 14;
			}
			if(BUTTONID.compare("BUTTON_5")==0){
				DeviceAttId = 15;
			}
			if(BUTTONID.compare("BUTTON_6")==0){
				DeviceAttId = 16;
			}
			string CHECK_EVENT = "SELECT * FROM EventTriggerInputDeviceSetupValue WHERE DeviceUnicastId = "+to_string(UNICAST)+" AND DeviceAttributeId = "+to_string(DeviceAttId)+";";
			DBRULE(mosq, "CHECK_RULE_ID", CHECK_EVENT);
		}
		else if (Cmd.compare("REMOTE_PAIRING") == 0) {
			UNICAST = 0;
			const Value& DATA = document["DATA"];
			UNICAST = DATA["DEVICE_UNICAST_ID"].GetInt();
			string BUTTONID = DATA["BUTTON_VALUE"].GetString();
			ValueInput = DATA["MODE_VALUE"].GetInt();
			int DeviceAttId = 0;
			if(BUTTONID.compare("BUTTON_1")==0){
				DeviceAttId = 126;
			}
			if(BUTTONID.compare("BUTTON_2")==0){
				DeviceAttId = 127;
			}
			if(BUTTONID.compare("BUTTON_4")==0){
				DeviceAttId = 128;
			}
			if(BUTTONID.compare("BUTTON_8")==0){
				DeviceAttId = 129;
			}
			if(BUTTONID.compare("BUTTON_3")==0){
				DeviceAttId = 130;
			}
			if(BUTTONID.compare("BUTTON_5")==0){
				DeviceAttId = 131;
			}
			if(BUTTONID.compare("BUTTON_9")==0){
				DeviceAttId = 132;
			}
			if(BUTTONID.compare("BUTTON_6")==0){
				DeviceAttId = 133;
			}
			if(BUTTONID.compare("BUTTON_10")==0){
				DeviceAttId = 134;
			}
			if(BUTTONID.compare("BUTTON_12")==0){
				DeviceAttId = 135;
			}
			if(BUTTONID.compare("BUTTON_16")==0){
				DeviceAttId = 137;
			}
			if(BUTTONID.compare("BUTTON_32")==0){
				DeviceAttId = 138;
			}
			if(BUTTONID.compare("BUTTON_24")==0){
				DeviceAttId = 139;
			}
			if(BUTTONID.compare("BUTTON_48")==0){
				DeviceAttId = 140;
			}

			string CHECK_EVENT = "SELECT * FROM EventTriggerInputDeviceSetupValue WHERE DeviceUnicastId = "+to_string(UNICAST)+" AND DeviceAttributeId = "+to_string(DeviceAttId)+";";
			DBRULE(mosq, "CHECK_RULE_ID", CHECK_EVENT);
		}
		else if(Cmd.compare("LIGHT_SENSOR")==0){
			const Value& DATA = document["DATA"];
			UNICAST = 0;
			UNICAST = DATA["DEVICE_UNICAST_ID"].GetInt();
			ValueInput = DATA["LUX_VALUE"].GetInt();
			string CHECK_EVENT = "SELECT * FROM EventTriggerInputDeviceSetupValue WHERE DeviceUnicastId = "+to_string(UNICAST)+" AND DeviceAttributeId = 9;";
			DBRULE(mosq, "CHECK_RULE_ID", CHECK_EVENT);
		}
		else if(Cmd.compare("DOOR_SENSOR")==0){
			const Value& DATA = document["DATA"];
			UNICAST = 0;
			UNICAST = DATA["DEVICE_UNICAST_ID"].GetInt();
			if(DATA.HasMember("DOOR_VALUE")){
				ValueInput = DATA["DOOR_VALUE"].GetInt();
				string CHECK_EVENT = "SELECT * FROM EventTriggerInputDeviceSetupValue WHERE DeviceUnicastId = "+to_string(UNICAST)+" AND DeviceAttributeId = 59;";
				DBRULE(mosq, "CHECK_RULE_ID", CHECK_EVENT);
			}
		}
		else if(Cmd.compare("SMOKE_SENSOR")==0){
			const Value& DATA = document["DATA"];
			UNICAST = 0;
			UNICAST = DATA["DEVICE_UNICAST_ID"].GetInt();
			ValueInput = DATA["SMOKE_VALUE"].GetInt();
			string CHECK_EVENT = "SELECT * FROM EventTriggerInputDeviceSetupValue WHERE DeviceUnicastId = "+to_string(UNICAST)+" AND DeviceAttributeId = 58;";
			// cout << CHECK_EVENT << endl;
			DBRULE(mosq, "CHECK_RULE_ID", CHECK_EVENT);
		}
		else if(Cmd.compare("POWER_STATUS")==0){
			const Value& DATA = document["DATA"];
			UNICAST = 0;
			UNICAST = DATA["DEVICE_UNICAST_ID"].GetInt();
			ValueInput = DATA["POWER_VALUE"].GetInt();
			string CHECK_EVENT = "SELECT * FROM EventTriggerInputDeviceSetupValue WHERE DeviceUnicastId = "+to_string(UNICAST)+" AND DeviceAttributeId = 8;";
			// cout << CHECK_EVENT << endl;
			DBRULE(mosq, "CHECK_RULE_ID", CHECK_EVENT);
		}
		else if(Cmd.compare("TEMPERATURE_HUMIDITY")==0){
			const Value& DATA = document["DATA"];
			UNICAST = 0;
			UNICAST = DATA["DEVICE_UNICAST_ID"].GetInt();
			ValueInput = DATA["TEMPERATURE_VALUE"].GetInt();
			string CHECK_EVENT1 = "SELECT * FROM EventTriggerInputDeviceSetupValue WHERE DeviceUnicastId = "+to_string(UNICAST)+" AND DeviceAttributeId = 22;";
			cout<<CHECK_EVENT1<<endl;
			DBRULE(mosq, "CHECK_RULE_ID", CHECK_EVENT1);
			ValueInput = DATA["HUMIDITY_VALUE"].GetInt();
			string CHECK_EVENT2 = "SELECT * FROM EventTriggerInputDeviceSetupValue WHERE DeviceUnicastId = "+to_string(UNICAST)+" AND DeviceAttributeId = 21;";
			cout<<CHECK_EVENT2<<endl;
			DBRULE(mosq, "CHECK_RULE_ID", CHECK_EVENT2);
		}
		else if(Cmd.compare("PM_SENSOR")==0){
			const Value& DATA = document["DATA"];
			UNICAST = 0;
			UNICAST = DATA["DEVICE_UNICAST_ID"].GetInt();
			if(DATA.HasMember("PM2.5_VALUE") && DATA.HasMember("PM1_VALUE") && DATA.HasMember("PM10_VALUE")){
				ValueInput = DATA["PM2.5_VALUE"].GetInt();
				string CHECK_EVENT = "SELECT * FROM EventTriggerInputDeviceSetupValue WHERE DeviceUnicastId = "+to_string(UNICAST)+" AND DeviceAttributeId = 18;";
				DBRULE(mosq, "CHECK_RULE_ID", CHECK_EVENT);
			}
		}
		else if(Cmd.compare("PIR_SENSOR")==0){
			const Value& DATA = document["DATA"];
			UNICAST = 0;
			UNICAST = DATA["DEVICE_UNICAST_ID"].GetInt();
			ValueInput = DATA["PIR_VALUE"].GetInt();
			string CHECK_EVENT = "SELECT * FROM EventTriggerInputDeviceSetupValue WHERE DeviceUnicastId = "+to_string(UNICAST)+" AND DeviceAttributeId = 10;";
			// cout << CHECK_EVENT << endl;
			DBRULE(mosq, "CHECK_RULE_ID", CHECK_EVENT);
		}
		else if(Cmd.compare("SWITCH")==0 || Cmd.compare("CONTROL_SWITCH")==0){
			const Value& DATA = document["DATA"];
			UNICAST = 0;
			UNICAST = DATA["DEVICE_UNICAST_ID"].GetInt();
			int RELAY_ID = DATA["RELAY_ID"].GetInt();
			ValueInput = DATA["RELAY_STATUS"].GetInt();
			int type = TYPE_DEVICE(UNICAST);
			int AttId = 0;
			if(RELAY_ID == 1){
				AttId = 11;
			} 
			if(RELAY_ID == 2){
				AttId = 12;
			} 
			if(RELAY_ID == 3){
				AttId = 13;
			} 
			if(RELAY_ID == 4){
				AttId = 14;
			}
			if (type > 22011)
			{
				UNICAST =+ RELAY_ID - 1;
				AttId = 0;
			}
			string CHECK_EVENT = "SELECT * FROM EventTriggerInputDeviceSetupValue WHERE DeviceUnicastId = "+to_string(UNICAST)+" AND DeviceAttributeId = "+to_string(AttId)+";";
			DBRULE(mosq, "CHECK_RULE_ID", CHECK_EVENT);
		}
		else if(Cmd.compare("TAP_TO_RUN")==0 || Cmd.compare("ACTIVE_RULE")==0){
			const Value& DATA = document["DATA"];
			string EVENT_TRIGGER_ID = DATA["EVENT_TRIGGER_ID"].GetString();
			string CheckRule = "SELECT * FROM EventTrigger WHERE EventTriggerId = '"+EVENT_TRIGGER_ID+"';";
			DBRULE(mosq, "CHECK_TAP_TO_RUN", CheckRule);
		}
		else if(Cmd.compare("ONOFF")==0){
			const Value& DATA = document["DATA"];
			UNICAST = 0;
			UNICAST = DATA["DEVICE_UNICAST_ID"].GetInt();
			if(DATA.HasMember("VALUE_ONOFF")){
				ValueInput = DATA["VALUE_ONOFF"].GetInt();
				string CHECK_EVENT = "SELECT * FROM EventTriggerInputDeviceSetupValue WHERE DeviceUnicastId = "+to_string(UNICAST)+" AND DeviceAttributeId = 0;";
				// cout << CHECK_EVENT << endl;
				DBRULE(mosq, "CHECK_RULE_ID", CHECK_EVENT);
			}
		}
		else if(Cmd.compare("FACE")==0){
			const Value& DATA = document["DATA"];
			UNICAST = 0;
			ValueInput = UNICAST = DATA["DEVICE_UNICAST_ID"].GetInt();
			if(DATA.HasMember("FACE_VALUE")){
				string CHECK_EVENT = "SELECT * FROM EventTriggerInputDeviceSetupValue WHERE DeviceUnicastId = "+to_string(UNICAST)+" AND DeviceAttributeId = 119;";
				DBRULE(mosq, "CHECK_RULE_ID", CHECK_EVENT);
			}
		}
		else if(Cmd.compare("ZONE")==0){
			const Value& DATA = document["DATA"];
			UNICAST = 0;
			if(DATA["DEVICE_UNICAST_ID"].IsInt()){
				ValueInput = UNICAST = DATA["DEVICE_UNICAST_ID"].GetInt();
			}
			if(DATA.HasMember("ZONE_VALUE")){
				if(DATA["ZONE_VALUE"].IsInt()){
					int Event = DATA["ZONE_VALUE"].GetInt();
					string CHECK_EVENT = "SELECT * FROM EventTriggerInputDeviceSetupValue WHERE DeviceUnicastId = "+to_string(UNICAST)+" AND DeviceAttributeId = "+to_string(Event+112)+";";
					DBRULE(mosq, "CHECK_RULE_ID", CHECK_EVENT);
				}
			}
		}
		if (UpdateHasRepeater)
		{
			UpdateHasRepeater = false;
			string sql = "UPDATE EventTrigger SET StatusID = 0 WHERE EventTriggerId= '"+EventTriggerId+"';";
			DB_Write_Time(sql);
		}
		return 0;
	}
	return 0;
}

int findNearestTime (int time, int TimeArray[], int length){
	int ReturnValue = -1;
	for (int i = 0; i < length-1; i++){
		if((time > TimeArray[i]) && time <= TimeArray[i +1]){
			ReturnValue = i;
		}
	}
	return ReturnValue;
}

//static void WriteCmd(char const *command){
//	FILE *file;
//	msg_rsp = "";
//	stringstream msg;
//	char msg_line[255]={0};
//	file = popen(command, "r");
//	if(file==NULL){
//		puts("lỗi");
//		exit(1);
//	}
//	fgets(msg_line, 255, file);
//	msg_rsp += msg_line;
//	while(1){
//		fgets(msg_line, 255, file);
//		if(feof(file)){
//			break;
//		}
//		msg_rsp += msg_line;
//	}
//	pclose(file);
//}

//static void ResetWatchDog(int &a){
//	if(a > 5){
//		a = 0;
//		WriteCmd("true > /etc/rd_wtachdog/watchdog0");
//		WriteCmd("echo \"1\" >> /etc/rd_wtachdog/watchdog0");
//	}
//}

void ControlHCL(vector<t_arrHCL> TemControlHCL, t_checkHCL *TempCheckHCL){
	int TimeCheckControl = IntParseTime(const_cast<char*>((const char *) TempCheckHCL->Time.c_str()));
	// cout << "Time control HCL: " << TimeCheckControl << endl;
	int IndexCheck = -1;
	for(unsigned int i=0; i<TemControlHCL.size(); i++){
		// cout << TemControlHCL[i].GroupUnicastId << "|" << TemControlHCL[i].DeviceAttributeId << "|" << TemControlHCL[i].DeviceAttributeValue << "|" << TemControlHCL[i].Fade << "|" << TemControlHCL[i].Time <<endl;
		if(i == 0){
			if(TimeCheckControl < TemControlHCL[i].Time){
				// cout << "time check HCL: " <<TemControlHCL[i].Time << endl;
				IndexCheck = i;
				break;
			}
		}
		else{
			if(TimeCheckControl > TemControlHCL[i-1].Time && TimeCheckControl < TemControlHCL[i].Time){
				// cout << "time check HCL: " <<TemControlHCL[i].Time << " ---- " << TemControlHCL[i-1].Time << endl;
				IndexCheck = i;
				break;
			}
		}
	}
	if(IndexCheck != -1){
		int TempGroupUnicastId = TemControlHCL[IndexCheck].GroupUnicastId;
		int TempCCT = 0;
		int TempDim = 0;
		float Temp = ((((float)abs(TimeCheckControl-TemControlHCL[IndexCheck-1].Time))/((float)abs(TemControlHCL[IndexCheck-1].Time-TemControlHCL[IndexCheck].Time)))*
				((float)abs(TemControlHCL[IndexCheck+1].DeviceAttributeValue-TemControlHCL[IndexCheck-1].DeviceAttributeValue)));
		if(TemControlHCL[IndexCheck+1].DeviceAttributeValue > TemControlHCL[IndexCheck-1].DeviceAttributeValue){
			TempDim = Temp + TemControlHCL[IndexCheck-1].DeviceAttributeValue;
		}
		if(TemControlHCL[IndexCheck+1].DeviceAttributeValue <= TemControlHCL[IndexCheck-1].DeviceAttributeValue){
			TempDim = TemControlHCL[IndexCheck-1].DeviceAttributeValue - Temp;
		}
		// cout << "% CCT: " << (((float)abs(TimeCheckControl-TemControlHCL[IndexCheck-1].Time))/((float)abs(TemControlHCL[IndexCheck-1].Time-TemControlHCL[IndexCheck].Time))) << endl;
		// cout << "Delta CCT: " << TempCCT << endl;
		Temp = (((float)abs(TimeCheckControl-TemControlHCL[IndexCheck-1].Time))/((float)abs(TemControlHCL[IndexCheck-1].Time-TemControlHCL[IndexCheck].Time)))*
				((float)abs(TemControlHCL[IndexCheck].DeviceAttributeValue-TemControlHCL[IndexCheck-2].DeviceAttributeValue));
		if(TemControlHCL[IndexCheck].DeviceAttributeValue > TemControlHCL[IndexCheck-2].DeviceAttributeValue){
			TempCCT = Temp + TemControlHCL[IndexCheck-2].DeviceAttributeValue;
		}
		if(TemControlHCL[IndexCheck].DeviceAttributeValue <= TemControlHCL[IndexCheck-2].DeviceAttributeValue){
			TempCCT = TemControlHCL[IndexCheck-2].DeviceAttributeValue - Temp;
		}
		// cout << "% DIM: " << (((float)abs(TimeCheckControl-TemControlHCL[IndexCheck-1].Time))/((float)abs(TemControlHCL[IndexCheck-1].Time-TemControlHCL[IndexCheck].Time))) << endl;
		// cout << "Delta DIM: " << TempDim << endl;
		string ControlCCT = "{\"CMD\":\"CCT\",\"ACK\":true,\"DATA\":{\"DEVICE_UNICAST_ID\":"+ to_string(TempGroupUnicastId) +",\"VALUE_CCT\":"+ to_string(TempCCT) +"}}";
		MqttSend(mosq, const_cast<char*>(ControlCCT.c_str()));
		string ControlDim = "{\"CMD\":\"DIM\",\"ACK\":true,\"DATA\":{\"DEVICE_UNICAST_ID\":"+ to_string(TempGroupUnicastId) +",\"VALUE_DIM\":"+ to_string(TempDim) +"}}";
		MqttSend(mosq, const_cast<char*>(ControlDim.c_str()));
		TempCheckHCL->Status = false;
	}
	QueueHCL.clear();
}

void InstertDeviceValueIntoDeviceValue(int TempTimeOver){
	if(TempTimeOver == TIME_UPDATE){
		bool FlagCheckLock = false;
		while (FlagCheckLock == false){
			if(pthread_mutex_trylock(&mutexUpdateDvValue) == 0){
				for (int i = 0; i < 256; i++) {
					int TempDeviceUnicastId = T_Device[i].DeviceUnicastID;
					string TempDeviceUUId = T_Device[i].DeviceUUID;
					for (int j = 1; j <= (T_Device[i].AttDevice[0]/2); j++) {
						int TempAttriButeId = T_Device[i].AttDevice[j];
						j++;
						int TempValue = T_Device[i].AttDevice[j];
						string UpdateDeviceValueIntoDeviceAttValue = "INSERT OR REPLACE INTO DeviceAttributeValue (DeviceId, DeviceUnicastId, DeviceAttributeId, Value, UpdateTime) "
								"values ('"+TempDeviceUUId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempAttriButeId)+", "+to_string(TempValue)+", "+ to_string(GetTimrStamp()) +");";
						QueueDB.push(UpdateDeviceValueIntoDeviceAttValue);
					}
					FlagCheckLock = true;
				}
				pthread_mutex_unlock(&mutexUpdateDvValue);
			}
			usleep (3000);
		}
	}
}

pthread_t threadTimer_tmp;
void* CallEvent(void *argv){
	// cout<<"Bắt đầu !"<<endl;
	threadTimer_tmp = pthread_self();
	t_checkHCL *CheckControlHCL = (t_checkHCL *)argv;
	while(true){
		TimerOver = 0;
		QueueTime.clear();
		string weekDayss = GetDayOfWeek();
		string sqlStart = "SELECT DISTINCT StartAt FROM EventTrigger WHERE StatusID = 1 AND " + weekDayss +" = " + '1'+ " AND EventTriggerTypeId = 2 AND LogicalOperatorID = -1 AND StartAt IS NOT NULL;";
		// cout << sqlStart << endl;
		DBRULE(mosq, "STARTAT", sqlStart);
		string sqlStartNoRepeate = "SELECT DISTINCT StartAt FROM EventTrigger WHERE StatusID = 1 AND HasRepeater = 0 AND EventTriggerTypeId = 2 AND LogicalOperatorID = -1 AND StartAt IS NOT NULL;";
		// cout << sqlStartNoRepeate << endl;
		DBRULE(mosq, "STARTAT_NOREPEATE", sqlStartNoRepeate);
		string sqlEnd = "SELECT DISTINCT EndAt FROM EventTrigger WHERE StatusID = 1 AND " + weekDayss +" = " + '1'+ " AND EventTriggerTypeId = 2 AND LogicalOperatorID = -1 AND EndAt IS NOT NULL;";
		// cout << sqlEnd << endl;
		DBRULE(mosq, "ENDAT", sqlEnd);
		string sqlEndNoRepeate = "SELECT DISTINCT EndAt FROM EventTrigger WHERE StatusID = 1 AND HasRepeater = 0 AND EventTriggerTypeId = 2 AND LogicalOperatorID = -1 AND EndAt IS NOT NULL;";
		// cout << sqlEndNoRepeate << endl;
		DBRULE(mosq, "ENDAT_NOREPEATE", sqlEndNoRepeate);
		string sqlHCL = "SELECT DISTINCT Time FROM EventTriggerOutputGroupingSetupValue INNER JOIN EventTrigger "
				"ON EventTrigger.EventTriggerId = EventTriggerOutputGroupingSetupValue.EventTriggerId WHERE EventTrigger.StatusID = 1 AND EventTrigger.EventTriggerTypeId = 4 AND EventTriggerOutputGroupingSetupValue.Time IS NOT NULL;";
		// cout << sqlHCL << endl;
		DBRULE(mosq, "TIME_HCL", sqlHCL);
		sort(QueueTime.begin(), QueueTime.end());
		for(unsigned int i=0; i<QueueTime.size(); i++){
			for(unsigned int j=i+1; j<QueueTime.size(); j++){
				if(QueueTime[i]==QueueTime[j]){
					QueueTime.erase(QueueTime.begin()+j);
				}
			}
		}
		if(CheckControlHCL->Status == true){
			sqlHCL = "SELECT EventTriggerOutputGroupingSetupValue.GroupUnicastId, EventTriggerOutputGroupingSetupValue.DeviceAttributeId, EventTriggerOutputGroupingSetupValue.DeviceAttributeValue, EventTriggerOutputGroupingSetupValue.Fade, EventTriggerOutputGroupingSetupValue.GroupingId, EventTriggerOutputGroupingSetupValue.Time "
					"FROM EventTriggerOutputGroupingSetupValue INNER JOIN EventTrigger ON EventTrigger.EventTriggerId = EventTriggerOutputGroupingSetupValue.EventTriggerId WHERE EventTriggerOutputGroupingSetupValue.EventTriggerId = '"+CheckControlHCL->EvenTriggerId+"';";
			// cout << sqlHCL << endl;
			DBRULE(mosq, "TIME_CONTROL_HCL", sqlHCL);
			for(unsigned int i=0; i<QueueHCL.size(); i++){
				for(unsigned int j=i+1; j<QueueHCL.size(); j++){
					if(QueueHCL[i].Time >= QueueHCL[j].Time){
						t_arrHCL TemEleHCL;
						TemEleHCL = QueueHCL[i];
						QueueHCL[i] = QueueHCL[j];
						QueueHCL[j] = TemEleHCL;
					}
				}
			}
			for(unsigned int i=0; i<QueueHCL.size(); i++){
				// cout << QueueHCL[i].GroupUnicastId << "|" << QueueHCL[i].DeviceAttributeId << "|" << QueueHCL[i].DeviceAttributeValue << "|" << QueueHCL[i].Fade << "|" << QueueHCL[i].Time <<endl;
			}
			ControlHCL(QueueHCL, CheckControlHCL);
		}
		TimerOver = GetSecondTimeNow();
		int lengtArr = QueueTime.size();
		for(int i = 0; i< lengtArr; i++){
			// cout << QueueTime[i] << "-"<< endl;
		}
				if(lengtArr > 0){
			if(lengtArr > 0 && TimerOver < QueueTime[lengtArr - 1]){
				for(int i = 0; i< lengtArr; i++){
					TimerOver = GetSecondTimeNow();
					if(TimerOver <= QueueTime[i]){
						while (TimerOver < QueueTime[i]){
							sleep(1);
							TimerOver = GetSecondTimeNow();
						}
						TimerOver = QueueTime[i];
						string sql = "SELECT EventTriggerId, HasRepeater FROM EventTrigger "
								"WHERE EventTriggerTypeId = 2 AND (EventTrigger.StartAt = '" + StringParseTime(TimerOver) + "' OR EventTrigger.EndAt = '" + StringParseTime(TimerOver) + "') AND EventTriggerTypeId = 2;";
						DBRULE(mosq, "CHECK_RULE", sql);
						sql = "SELECT EventTriggerId, HasRepeater FROM EventTrigger "
								"WHERE EventTriggerTypeId = 2 AND (EventTrigger.StartAt = '" + StringParseTimeOld(TimerOver) + "' OR EventTrigger.EndAt = '" + StringParseTimeOld(TimerOver) + "') AND EventTriggerTypeId = 2;";
						DBRULE(mosq, "CHECK_RULE", sql);
						if(HasReRpeater == 0){
							sql = "UPDATE EventTrigger SET StatusID = 0 WHERE EventTriggerId= '"+EventTriggerId+"';";
							DB_Write_Time(sql);
							HasReRpeater = -1;
						}
//						if(CheckControlHCL->Status == true){
							sql = "SELECT DISTINCT EventTriggerOutputGroupingSetupValue.EventTriggerId FROM EventTriggerOutputGroupingSetupValue INNER JOIN EventTrigger "
									"ON EventTrigger.EventTriggerId = EventTriggerOutputGroupingSetupValue.EventTriggerId "
									"WHERE EventTrigger.StatusID = 1 AND EventTrigger.EventTriggerTypeId = 4 AND (EventTriggerOutputGroupingSetupValue.Time = '" + StringParseTime(TimerOver) + "' OR EventTriggerOutputGroupingSetupValue.Time = '" + StringParseTimeOld(TimerOver) + "');";
							cout<<sql<<endl;
							DBRULE(mosq, "CHECK_HCL", sql);
//						}
					}
				}
			}
			else if((lengtArr > 0 && TimerOver > QueueTime[lengtArr - 1]) || (lengtArr == 0)){
				while((TimerOver > QueueTime[lengtArr - 1]) || (lengtArr == 0)){
					if((TimerOver > GetSecondTimeNow())){
						break;
					}
					TimerOver = GetSecondTimeNow();
					sleep(1);
				}
			}
		}
		else{
			while(true){
				if((TimerOver > GetSecondTimeNow())){
					break;
				}
				TimerOver = GetSecondTimeNow();
				sleep(1);
			}
		}
	}
	return NULL;
}

int IntParseTime(char* a){
	char h[4] = {0};
	char m[4] = {0};
	char s[4] = {0};
	int temp = 0;
	int timer;
	unsigned int LenghtInputTime = strlen(a);
	int k = 0;
	for(unsigned int i=0; i<LenghtInputTime; i++){
		if(a[i] == '\0'){
			break;
		}
		if(a[i] == ':'){
			temp++;
			k = i;
		}
		else{
			if(temp == 0){
				h[i] = a[i];
			}
			else if(temp == 1){
				m[i-(k+1)] = a[i];
			}
			else if(temp == 2){
				s[i-(k+1)] = a[i];
			}
		}
	}
	timer = atoi(h)* 3600 + atoi(m)* 60 + atoi(s);

	return timer;
}

string StringParseTime(int a){
	int h = a/3600;
	int m = (a%3600)/60;
	int s = (a%3600)%60;
	string timerCheck = to_string(h) + ":" + to_string(m) + ":" + to_string(s);
	return timerCheck;
}

string StringParseTimeOld(int a){
	int h = a/3600;
	int m = (a%3600)/60;
	string timerCheck = to_string(h) + ":" + to_string(m);
	return timerCheck;
}

string GetDayOfWeek(){
	string weekDays;
	time_t now = time(0);
	tm *ltm = localtime(&now);

	int w = 1 + ltm->tm_wday;
	//Day in Week
	switch(w){
		case 1:
			weekDays = "EachSunday";
			break;
		case 2:
			weekDays = "EachMonday";
			break;
		case 3:
			weekDays = "EachTuesday";
			break;
		case 4:
			weekDays = "EachWednesday";
			break;
		case 5:
			weekDays = "EachThursday";
			break;
		case 6:
			weekDays = "EachFriday";
			break;
		case 7:
			weekDays = "EachSaturday";
			break;
		default:
			break;
	}
	return weekDays;
}

void DeleteElement(int a[], int &n, int ViTriXoa){
    for(int i = ViTriXoa; i < n; i++){
        a[i] = a[i + 1];
    }
    n--;
}

void FilterArr(int a[], int &n)
{
    for(int i = 0; i < n; i++){
        for(int j = i + 1; j < n; j++){
            if(a[i] == a[j]){
            	DeleteElement(a, n, j);
                j--;
            }
        }
    }
}
