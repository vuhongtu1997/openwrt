/*
 * TIMER_PARES.hpp
 *
 *  Created on: Apr 14, 2021
 *      Author: rd
 */

#ifndef RD_TIMER_TIMER_PARES_HPP_
#define RD_TIMER_TIMER_PARES_HPP_

#include "../ShareData.hpp"
#include <algorithm>

#define LOGIG_RULE_INPUT_OR				0
#define LOGIG_RULE_INPUT_AND			1
#define LOGIG_RULE_INPUT_OR_TIME		2
#define LOGIG_RULE_INPUT_AND_TIME		3

using namespace std;
using namespace rapidjson;

extern string EventTriggerId;
extern int HasReRpeater;
extern pthread_t threadTimer;
extern pthread_t threadTimer_tmp;

typedef struct{
	int GroupUnicastId;
	int DeviceAttributeId;
	int DeviceAttributeValue;
	int Fade;
	int Time;
}t_arrHCL;

extern vector <t_arrHCL> QueueHCL;
extern vector <int> QueueTempArrTime;
extern vector <int> QueueTime;

void* CallEvent(void *argv);
void ResetThread();
int Event(struct mosquitto *mosq, char * jobj);
int IntParseTime(char* a);
string StringParseTime(int a);
string StringParseTimeOld(int a);
string GetDayOfWeek();
void FilterArr(int a[], int &n);
char* checkControlTimer(struct mosquitto *mosq, int idControl);
void SendLogRule(struct mosquitto *mosq, string ruleId);

int DBRULE(struct mosquitto *mosq, string control, string sql);
int DB_Write_Time(string sql);

#endif /* RD_TIMER_TIMER_PARES_HPP_ */
