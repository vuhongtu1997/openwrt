/*
 * AHG_CONFIG_SCENE.cpp
 *
 *  Created on: Dec 23, 2021
 *      Author: rd
 */

#include <iostream>
#include "AHG_CONFIG_SCENE.hpp"

void CreateScene(struct mosquitto *mosq, char* jobj){
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutex) == 0){
			if(IsProcessDone == false){
				ResetDataScene();
				IsProcessScene = CREATE_SCENE;
				FlagCheckLock = true;
			}
			pthread_mutex_unlock(&mutex);
		}
		usleep (3000);
	}
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int EVENT_TRIGGER_TYPE_ID = 3;
	if(DATA.HasMember("DEVICES") && DATA.HasMember("SCENE_ID")){
		string EVENT_TRIGGER_ID = DATA["SCENE_ID"].GetString();
		int SceneUnicastId = CreateSceneUnicastId();
		string creGroupID = "INSERT OR REPLACE INTO EventTriggerID (SceneUnicastID, EventTriggerId, ValueCreate, IsSuccess)"
				" values ("+ to_string(SceneUnicastId) + ",'"+ EVENT_TRIGGER_ID +"', 1, -1); ";
		DB_Write( creGroupID);
		string addEvent = "INSERT OR REPLACE INTO EventTrigger (EventTriggerId, GroupId, EventTriggerTypeId, SceneUnicastID, "
				"HasTimer, Priority, StartAt, EndAt) "
				"values ('" + EVENT_TRIGGER_ID + "', '" + EVENT_TRIGGER_ID + "', " + to_string(EVENT_TRIGGER_TYPE_ID) + ", " + to_string(SceneUnicastId) + ","
						"0,1,'','');";
		DB_Write( addEvent);
		const Value& DEVICES = DATA["DEVICES"];
		while (true){
			if(pthread_mutex_trylock(&mutex) == 0){
				ShareSceneId = EVENT_TRIGGER_ID;
				ShareSceneUnicastId = SceneUnicastId;
				numDeviceScene = DEVICES.Size();
				pthread_mutex_unlock(&mutex);
				break;
			}
			usleep (3000);
		}
		idx_dv = 0;
		for (rapidjson::SizeType i = 0; i < DEVICES.Size(); i++){
			const Value& a = DEVICES[i];
			const Value& d = a["IDS"];
			list<string> Lst_Dv;
			for (rapidjson::SizeType j = 0; j < d.Size(); j++){
				const Value& e = d[j];
				string DEVICE_ID = e.GetString();
				Lst_Dv.push_back(DEVICE_ID);
			}
			for (list<string>::iterator it = Lst_Dv.begin(); it !=Lst_Dv.end(); it++){
				string DEVICE_ID = (*it);
				int DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
				while (true){
					if(pthread_mutex_trylock(&mutex) == 0){
						DeviceScene[idx_dv] = DEVICE_UNICAST;
						TimeOut = GetSecondTimeNow();
						pthread_mutex_unlock(&mutex);
						break;
					}
					usleep (3000);
				}
				idx_dv++;
				const Value& PROPERTIES = a["PROPERTIES"];
				string addDeviceS = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, IsSuccess, typerun) "
						"values ('"+EVENT_TRIGGER_ID+"', '"+DEVICE_ID+"', "+to_string(DEVICE_UNICAST)+", 1, 0);";
				DB_Write( addDeviceS);
				if(DEVICE_UNICAST != 0){
					if(PROPERTIES.Size() > 1){
						SendDVAddScene(DEVICE_UNICAST, SceneUnicastId, ADD_SCENE_CCT, 0);
						for (rapidjson::SizeType i = 0; i < PROPERTIES.Size(); i++){
							const Value& b = PROPERTIES[i];
							int ID = b["ID"].GetInt();
							int VALUE = b["VALUE"].GetInt();
							string addDeviceS = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
									"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
									"values ('"+EVENT_TRIGGER_ID+"', '"+DEVICE_ID+"', "+to_string(DEVICE_UNICAST)+", "+to_string(ID)+", "+to_string(VALUE)+", '0:0');";
							PushMsgToQueueDb_AHG(addDeviceS);
						}
					}
					else if(PROPERTIES.Size() == 1){
						const Value& b = PROPERTIES[0];
						int ID = b["ID"].GetInt();
						int VALUE = b["VALUE"].GetInt();
						if(ID==23){
							SendDVAddScene(DEVICE_UNICAST, SceneUnicastId, ADD_SCENE_RGB, VALUE);
						}
						else{
							SendDVAddScene(DEVICE_UNICAST, SceneUnicastId, ADD_SCENE_CCT, VALUE);
						}

						string addDeviceS = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
								"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
								"values ('"+EVENT_TRIGGER_ID+"', '"+DEVICE_ID+"', "+to_string(DEVICE_UNICAST)+", "+to_string(ID)+", "+to_string(VALUE)+", '0:0');";
						// cout << addDeviceS << endl;
						PushMsgToQueueDb_AHG(addDeviceS);
					}
				}
			}
			Lst_Dv.clear();
		}
		while (true){
			if(pthread_mutex_trylock(&mutex) == 0){
				IsProcessDone = true;
				pthread_mutex_unlock(&mutex);
				break;
			}
			usleep (3000);
		}
	}
}

void EditScene(struct mosquitto *mosq, char* jobj){
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutex) == 0){
			if(IsProcessDone == false){
				ResetDataScene();
				IsProcessScene = EDIT_SCENE;
				FlagCheckLock = true;
			}
			pthread_mutex_unlock(&mutex);
		}
		usleep (3000);
	}
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	int EVENT_TRIGGER_TYPE_ID = 3;
	if(DATA.HasMember("DEVICES") && DATA.HasMember("SCENE_ID")){
		string EVENT_TRIGGER_ID = DATA["SCENE_ID"].GetString();
		string START_AT, END_AT;
		int SCENE_UNICAST = SCENE_UNICAST_ID(EVENT_TRIGGER_ID);
		if(SCENE_UNICAST == 0){
			SCENE_UNICAST = CreateSceneUnicastId();
		}
		string EditScene = "INSERT OR REPLACE INTO EventTrigger (EventTriggerId, GroupId, EventTriggerTypeId, SceneUnicastID, "
					"HasTimer, Priority, StartAt, EndAt) "
					"values ('" + EVENT_TRIGGER_ID + "', '" + EVENT_TRIGGER_ID + "', " + to_string(EVENT_TRIGGER_TYPE_ID) + ", " + to_string(SCENE_UNICAST) + ","
							"0,3,'" + START_AT + "','" + END_AT + "');";
		DB_Write( EditScene);
		const Value& DEVICES = DATA["DEVICES"];
		while (true){
			if(pthread_mutex_trylock(&mutex) == 0){
				ShareSceneId = EVENT_TRIGGER_ID;
				ShareSceneUnicastId = SCENE_UNICAST;
				numDeviceScene = DEVICES.Size();
				pthread_mutex_unlock(&mutex);
				break;
			}
			usleep (3000);
		}
		idx_dv = 0;
		for (rapidjson::SizeType i = 0; i < DEVICES.Size(); i++){
			const Value& a = DEVICES[i];
			const Value& d = a["IDS"];
			list<string> Lst_Dv;
			for (rapidjson::SizeType j = 0; j < d.Size(); j++){
				const Value& e = d[j];
				string DEVICE_ID = e.GetString();
				Lst_Dv.push_back(DEVICE_ID);
			}
			for (list<string>::iterator it = Lst_Dv.begin(); it !=Lst_Dv.end(); it++){
				string DEVICE_ID = *it;
				int DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
				while (true){
					if(pthread_mutex_trylock(&mutex) == 0){
						DeviceScene[idx_dv] = DEVICE_UNICAST;
						TimeOut = GetSecondTimeNow();
						pthread_mutex_unlock(&mutex);
						break;
					}
					usleep (3000);
				}
				idx_dv++;
				if(DEVICE_UNICAST != 0){
					string addDeviceS = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, IsSuccess, typerun) "
						"values ('"+EVENT_TRIGGER_ID+"', '"+DEVICE_ID+"', "+to_string(DEVICE_UNICAST)+", 1, 0);";
					DB_Write( addDeviceS);
					const Value& PROPERTIES = a["PROPERTIES"];
					if(PROPERTIES.Size() > 1){
						SendEditScene(DEVICE_UNICAST, SCENE_UNICAST, ADD_SCENE_CCT, 0);
						for (rapidjson::SizeType i = 0; i < PROPERTIES.Size(); i++){
							const Value& b = PROPERTIES[i];
							int ID = b["ID"].GetInt();
							int VALUE = b["VALUE"].GetInt();
							string AddDeviceSeceneStt = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
									"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
									"values ('"+EVENT_TRIGGER_ID+"', '"+DEVICE_ID+"', "+to_string(DEVICE_UNICAST)+", "+to_string(ID)+", "+to_string(VALUE)+", '0:0');";
							PushMsgToQueueDb_AHG(AddDeviceSeceneStt);
						}
					}
					else if(PROPERTIES.Size() == 1){
						const Value& b = PROPERTIES[0];
						int ID = b["ID"].GetInt();
						int VALUE = b["VALUE"].GetInt();
						if(ID==23){
							SendEditScene(DEVICE_UNICAST, SCENE_UNICAST, ADD_SCENE_RGB, VALUE);
						}
						else if(ID==0){
							SendEditScene(DEVICE_UNICAST, SCENE_UNICAST, ADD_SCENE_CCT, 0);
						}
						string AddDeviceSeceneStt = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
								"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
								"values ('"+EVENT_TRIGGER_ID+"', '"+DEVICE_ID+"', "+to_string(DEVICE_UNICAST)+", "+to_string(ID)+", "+to_string(VALUE)+", '0:0');";
						PushMsgToQueueDb_AHG(AddDeviceSeceneStt);
					}
				}
			}
			Lst_Dv.clear();
		}
		while (true){
			if(pthread_mutex_trylock(&mutex) == 0){
				IsProcessDone = true;
				pthread_mutex_unlock(&mutex);
				break;
			}
			usleep (3000);
		}
	}
}

void DelScene(struct mosquitto *mosq, char* jobj){
	MqttSend(mosq, DEL_LIST_SCENE);
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutex) == 0){
			if(IsProcessDone == false){
				ResetDataScene();
				IsProcessScene = DELETE_SCENE;
				FlagCheckLock = true;
			}
			pthread_mutex_unlock(&mutex);
		}
		usleep (3000);
	}
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	string EVENT_TRIGGER_ID = DATA["SCENE_ID"].GetString();
	numDvUnicastDelScene = 0;
	string adr = "SELECT DeviceUnicastId FROM EventTriggerOutputDeviceMapping WHERE EventTriggerId = '"+EVENT_TRIGGER_ID+"';";
	DB_Read( "DEL_SCENE", adr);
	ADR = -1;
	string checkAdrS = "SELECT SceneUnicastID FROM EventTrigger where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
	DB_Read( "ADR", checkAdrS);
	int SceneUnicastId = ADR;
	while (true){
		if(pthread_mutex_trylock(&mutex) == 0){
			ShareSceneId = EVENT_TRIGGER_ID;
			ShareSceneUnicastId = SceneUnicastId;
			numDeviceScene = numDvUnicastDelScene;
			pthread_mutex_unlock(&mutex);
			break;
		}
		usleep (3000);
	}
	for(int i=0; i< numDvUnicastDelScene; i++){
		string adr = "SELECT DeviceAttributeId FROM EventTriggerOutputDeviceSetupValue WHERE EventTriggerId = '"+EVENT_TRIGGER_ID+"' AND DeviceUnicastId = "+to_string(ArrDvUnicast[i])+" ORDER BY DeviceAttributeId ASC;";
		TYPE_DV = 0;
		DB_Read( "TYPE_DEVICE", adr);
		while (true){
			if(pthread_mutex_trylock(&mutex) == 0){
				DeviceScene[i] = DeviceDelScene[i];
				TimeOut = GetSecondTimeNow();
				pthread_mutex_unlock(&mutex);
				break;
			}
			usleep (3000);
		}
		if(TYPE_DV == 23){
			DelDVFromScene(DeviceDelScene[i], SceneUnicastId, DEL_SCENE_RGB);
			sleep (1);
		}
		else{
			DelDVFromScene(DeviceDelScene[i], SceneUnicastId, DEL_SCENE_CCT);
			sleep (1);
		}
	}
	string delDT = "UPDATE EventTrigger SET ValueCreate = 0 where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
	DB_Write( delDT);
	while (true){
		if(pthread_mutex_trylock(&mutex) == 0){
			IsProcessDone = true;
			pthread_mutex_unlock(&mutex);
			break;
		}
		usleep (3000);
	}
}



void CreateSceneDelay(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	string EVENT_TRIGGER_ID = DATA["SCENE_ID"].GetString();
	int SCENE_TYPE_ID = DATA["SCENE_TYPE_ID"].GetInt();
	ADR = -1;
	string CheckTypeScene = "SELECT EventTriggerTypeId FROM EventTrigger WHERE EventTriggerId = '"+ EVENT_TRIGGER_ID +"';";
	DB_Read( "ADR", CheckTypeScene);
	int TypeScene = ADR;
	// cout << "Type Scene: " << TypeScene << endl;
	if(TypeScene != 0 && TypeScene != -1 && TypeScene != 10){
		DelScene(mosq, jobj);
	}
	int SceneUnicastId = CreateSceneUnicastId();
	string creGroupID = "INSERT OR REPLACE INTO EventTriggerID (SceneUnicastID, EventTriggerId, ValueCreate, IsSuccess)"
			" values ("+ to_string(SceneUnicastId) + ",'"+ EVENT_TRIGGER_ID +"', 1, -1); ";
	DB_Write( creGroupID);
	string addEvent = "INSERT OR REPLACE INTO EventTrigger (EventTriggerId, GroupId, EventTriggerTypeId, SceneUnicastID, "
			"HasTimer, Priority, StartAt, EndAt) "
			"values ('" + EVENT_TRIGGER_ID + "', '" + EVENT_TRIGGER_ID + "', 10, " + to_string(SceneUnicastId) + ","
					"0,1,'','');";
	DB_Write( addEvent);
	int TIME_DELAY = 0;
	if(SCENE_TYPE_ID == 1){
		StringBuffer sendToGW;
		Writer<StringBuffer> json(sendToGW);
		json.StartObject();
		json.Key("CMD");
		json.String("CREATE_SCENE_DELAY");
		json.Key("DATA");
		json.StartObject();
		json.Key("SCENE_ID");
		json.String(const_cast<char*>(EVENT_TRIGGER_ID.c_str()));
		json.Key("SCENE_TYPE_ID");
		json.Int(SCENE_TYPE_ID);
		json.Key("SCENE_UNICATS_ID");
		json.Int(SceneUnicastId);
		json.Key("SUCCESS");
		json.StartArray();
		const Value& DEVICES = DATA["DEVICES"];
		for (rapidjson::SizeType i = 0; i < DEVICES.Size(); i++){
			string DEVICE_ID = DEVICES[i]["DEVICE_ID"].GetString();
			json.String(const_cast<char*>(DEVICE_ID.c_str()));
			int DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
			TIME_DELAY = TIME_DELAY + DEVICES[i]["DELAY"].GetInt();
			string DeviceIntoScene =
					"INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping (EventTriggerId, DeviceId, DeviceUnicastId, typerun) values ('"
							+ EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', "
							+ to_string(DEVICE_UNICAST) + ", 1);";
			// cout << DeviceIntoScene << endl;
			DB_Write( DeviceIntoScene);
			const Value& PROPERTIES = DEVICES[i]["PROPERTIES"];
			for (rapidjson::SizeType j = 0; j < PROPERTIES.Size(); j++){
				int ID = PROPERTIES[j]["ID"].GetInt();
				int VALUE = PROPERTIES[j]["VALUE"].GetInt();
				string DeviceValueIntoScene =
						"INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue (EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) values ('"
								+ EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', "
								+ to_string(DEVICE_UNICAST) + ", " + to_string(ID)
								+ ", " + to_string(VALUE) +", " + to_string(TIME_DELAY) +");";
				// cout << DeviceValueIntoScene << endl;
				DB_Write( DeviceValueIntoScene);
			}
		}
		json.EndArray();
		json.Key("FAILED");
		json.StartArray();
		json.EndArray();
		json.EndObject();
		json.EndObject();
		string s = sendToGW.GetString();
		cout << s <<endl;
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
	else if(SCENE_TYPE_ID == 0){
		StringBuffer sendToGW;
		Writer<StringBuffer> json(sendToGW);
		json.StartObject();
		json.Key("CMD");
		json.String("CREATE_SCENE_DELAY");
		json.Key("DATA");
		json.StartObject();
		json.Key("SCENE_ID");
		json.String(const_cast<char*>(EVENT_TRIGGER_ID.c_str()));
		json.Key("SCENE_TYPE_ID");
		json.Int(SCENE_TYPE_ID);
		json.Key("SCENE_UNICATS_ID");
		json.Int(SceneUnicastId);
		json.Key("SUCCESS");
		json.StartArray();
		const Value& GROUPS = DATA["GROUPS"];
		for (rapidjson::SizeType i = 0; i < GROUPS.Size(); i++){
			string GROUP_ID = GROUPS[i]["GROUP_ID"].GetString();
			json.String(const_cast<char*>(GROUP_ID.c_str()));
			int GROUP_UNICAST = GROUP_UNICAST_ID(GROUP_ID);
			TIME_DELAY = TIME_DELAY + GROUPS[i]["DELAY"].GetInt();
			string GroupIntoScene =
					"INSERT OR REPLACE INTO EventTriggerOutputGroupingMapping (EventTriggerId, GroupingId, GroupUnicastId, typerun) values ('"
							+ EVENT_TRIGGER_ID + "', '" + GROUP_ID + "', "
							+ to_string(GROUP_UNICAST) + ", 1);";
			// cout << GroupIntoScene << endl;
			DB_Write( GroupIntoScene);
			const Value& PROPERTIES = GROUPS[i]["PROPERTIES"];
			for (rapidjson::SizeType j = 0; j < PROPERTIES.Size(); j++){
				int ID = PROPERTIES[j]["ID"].GetInt();
				int VALUE = PROPERTIES[j]["VALUE"].GetInt();
				string GroupValueIntoScene =
						"INSERT OR REPLACE INTO EventTriggerOutputGroupingSetupValue (EventTriggerId, GroupingId, GroupUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) values ('"
								+ EVENT_TRIGGER_ID + "', '" + GROUP_ID + "', "
								+ to_string(GROUP_UNICAST) + ", " + to_string(ID)
								+ ", " + to_string(VALUE) +", " + to_string(TIME_DELAY) +");";
				// cout << GroupValueIntoScene <<
				DB_Write( GroupValueIntoScene);
			}
		}
		json.EndArray();
		json.Key("FAILED");
		json.StartArray();
		json.EndArray();
		json.EndObject();
		json.EndObject();
		string s = sendToGW.GetString();
		cout << s <<endl;
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
}

void EditSceneDelay(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	string EVENT_TRIGGER_ID = DATA["SCENE_ID"].GetString();
	int SCENE_TYPE_ID = DATA["SCENE_TYPE_ID"].GetInt();
	ADR = -1;
	string CheckTypeScene = "SELECT EventTriggerTypeId FROM EventTrigger WHERE EventTriggerId = '"+ EVENT_TRIGGER_ID +"';";
	DB_Read( "ADR", CheckTypeScene);
	int TypeScene = ADR;
	// cout << "Type Scene: " << TypeScene << endl;
	int TIME_DELAY = 0;
	if(TypeScene != 0 && TypeScene != -1 && TypeScene != 10){
		DelScene(mosq, jobj);
	}
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutex) == 0){
			if(IsProcessDone == false){
				FlagCheckLock = true;
			}
			pthread_mutex_unlock(&mutex);
		}
		usleep (3000);
	}
	string DelSceneDvMapping = "DELETE FROM EventTriggerOutputDeviceMapping WHERE EventTriggerId = '"+ EVENT_TRIGGER_ID +"'";
	DB_Write( DelSceneDvMapping);
	string DelSceneDvValue = "DELETE FROM EventTriggerOutputDeviceSetupValue WHERE EventTriggerId = '"+ EVENT_TRIGGER_ID +"'";
	DB_Write( DelSceneDvValue);
	string DelSceneGrMapping = "DELETE FROM EventTriggerInputGroupingMapping WHERE EventTriggerId = '"+ EVENT_TRIGGER_ID +"'";
	DB_Write( DelSceneGrMapping);
	string DelSceneGrValue = "DELETE FROM EventTriggerOutputGroupingSetupValue WHERE EventTriggerId = '"+ EVENT_TRIGGER_ID +"'";
	DB_Write( DelSceneGrValue);
	if(SCENE_TYPE_ID == 1){
		StringBuffer sendToGW;
		Writer<StringBuffer> json(sendToGW);
		json.StartObject();
		json.Key("CMD");
		json.String("EDIT_SCENE_DELAY");
		json.Key("DATA");
		json.StartObject();
		json.Key("SCENE_ID");
		json.String(const_cast<char*>(EVENT_TRIGGER_ID.c_str()));
		json.Key("SCENE_TYPE_ID");
		json.Int(SCENE_TYPE_ID);
		json.Key("SUCCESS");
		json.StartArray();
		const Value& DEVICES = DATA["DEVICES"];
		for (rapidjson::SizeType i = 0; i < DEVICES.Size(); i++){
			string DEVICE_ID = DEVICES[i]["DEVICE_ID"].GetString();
			int DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
			json.String(const_cast<char*>(DEVICE_ID.c_str()));
			TIME_DELAY = TIME_DELAY + DEVICES[i]["DELAY"].GetInt();
			string DeviceIntoScene =
					"INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping (EventTriggerId, DeviceId, DeviceUnicastId, typerun) values ('"
							+ EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', "
							+ to_string(DEVICE_UNICAST) + ", 1);";
			// cout << DeviceIntoScene << endl;
			DB_Write( DeviceIntoScene);
			const Value& PROPERTIES = DEVICES[i]["PROPERTIES"];
			for (rapidjson::SizeType j = 0; j < PROPERTIES.Size(); j++){
				int ID = PROPERTIES[j]["ID"].GetInt();
				int VALUE = PROPERTIES[j]["VALUE"].GetInt();
				string DeviceValueIntoScene =
						"INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue (EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) values ('"
								+ EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', "
								+ to_string(DEVICE_UNICAST) + ", " + to_string(ID)
								+ ", " + to_string(VALUE) +", " + to_string(TIME_DELAY) +");";
				// cout << DeviceValueIntoScene << endl;
				DB_Write( DeviceValueIntoScene);
			}
		}
		json.EndArray();
		json.Key("FAILED");
		json.StartArray();
		json.EndArray();
		json.EndObject();
		json.EndObject();
		string s = sendToGW.GetString();
		cout << s <<endl;
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
	else if(SCENE_TYPE_ID == 0){
		StringBuffer sendToGW;
		Writer<StringBuffer> json(sendToGW);
		json.StartObject();
		json.Key("CMD");
		json.String("EDIT_SCENE_DELAY");
		json.Key("DATA");
		json.StartObject();
		json.Key("SCENE_ID");
		json.String(const_cast<char*>(EVENT_TRIGGER_ID.c_str()));
		json.Key("SCENE_TYPE_ID");
		json.Int(SCENE_TYPE_ID);
		json.Key("SUCCESS");
		json.StartArray();
		const Value& GROUPS = DATA["GROUPS"];
		for (rapidjson::SizeType i = 0; i < GROUPS.Size(); i++){
			string GROUP_ID = GROUPS[i]["GROUP_ID"].GetString();
			json.String(const_cast<char*>(GROUP_ID.c_str()));
			int GROUP_UNICAST = GROUP_UNICAST_ID(GROUP_ID);
			TIME_DELAY = TIME_DELAY + GROUPS[i]["DELAY"].GetInt();
			string GroupIntoScene =
					"INSERT OR REPLACE INTO EventTriggerOutputGroupingMapping (EventTriggerId, GroupingId, GroupUnicastId, typerun) values ('"
							+ EVENT_TRIGGER_ID + "', '" + GROUP_ID + "', "
							+ to_string(GROUP_UNICAST) + ", 1);";
			// cout << GroupIntoScene << endl;
			DB_Write( GroupIntoScene);
			const Value& PROPERTIES = GROUPS[i]["PROPERTIES"];
			for (rapidjson::SizeType j = 0; j < PROPERTIES.Size(); j++){
				int ID = PROPERTIES[j]["ID"].GetInt();
				int VALUE = PROPERTIES[j]["VALUE"].GetInt();
				string GroupValueIntoScene =
						"INSERT OR REPLACE INTO EventTriggerOutputGroupingSetupValue (EventTriggerId, GroupingId, GroupUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) values ('"
								+ EVENT_TRIGGER_ID + "', '" + GROUP_ID + "', "
								+ to_string(GROUP_UNICAST) + ", " + to_string(ID)
								+ ", " + to_string(VALUE) +", " + to_string(TIME_DELAY) +");";
				// cout << GroupValueIntoScene <<
				DB_Write( GroupValueIntoScene);
			}
		}
		json.EndArray();
		json.Key("FAILED");
		json.StartArray();
		json.EndArray();
		json.EndObject();
		json.EndObject();
		string s = sendToGW.GetString();
		cout << s <<endl;
		MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
	}
	string EditScene = "UPDATE EventTrigger SET EventTriggerTypeId = 10 where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
	// cout << EditScene << endl;
	DB_Write( EditScene);
}

void DeleteSceneDelay(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	string EVENT_TRIGGER_ID = DATA["SCENE_ID"].GetString();
	ADR = -1;
	string CheckTypeScene = "SELECT EventTriggerTypeId FROM EventTrigger WHERE EventTriggerId = '"+ EVENT_TRIGGER_ID +"';";
	DB_Read( "ADR", CheckTypeScene);
	int TypeScene = ADR;
	// cout << "Type Scene: " << TypeScene << endl;
	if(TypeScene != 0 && TypeScene != -1 && TypeScene != 10){
		DelScene(mosq, jobj);
	}
	string DelScene = "DELETE FROM EventTrigger WHERE EventTriggerId = '"+ EVENT_TRIGGER_ID +"'";
	DB_Write( DelScene);
	string DelSceneDvMapping = "DELETE FROM EventTriggerOutputDeviceMapping WHERE EventTriggerId = '"+ EVENT_TRIGGER_ID +"'";
	DB_Write( DelSceneDvMapping);
	string DelSceneDvValue = "DELETE FROM EventTriggerOutputDeviceSetupValue WHERE EventTriggerId = '"+ EVENT_TRIGGER_ID +"'";
	DB_Write( DelSceneDvValue);
	string DelSceneGrMapping = "DELETE FROM EventTriggerInputGroupingMapping WHERE EventTriggerId = '"+ EVENT_TRIGGER_ID +"'";
	DB_Write( DelSceneGrMapping);
	string DelSceneGrValue = "DELETE FROM EventTriggerOutputGroupingSetupValue WHERE EventTriggerId = '"+ EVENT_TRIGGER_ID +"'";
	DB_Write( DelSceneGrValue);
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("DELETE_SCENE_DELAY");
	json.Key("DATA");
	json.StartObject();
	json.Key("SCENE_ID");
	json.String(const_cast<char*>(EVENT_TRIGGER_ID.c_str()));
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	cout << s <<endl;
	MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
}
