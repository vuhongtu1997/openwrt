#include "JSON_AHG.hpp"
#include <sqlite3.h>
#include <iostream>
#include <vector>
#include "CONTROL/AHG_CONTROL.hpp"
#include "CONFIG/AHG_CONFIG_SCENE.hpp"
#include "CONFIG/AHG_CONFIG_SCENE_REMOTE.hpp"
#include "CONFIG/AHG_CONFIG_ROOM.hpp"
#include "CONFIG/AHG_CONFIG_SCENE_SCREEN.hpp"
#include "CONFIG/AHG_CONFIG_SCENE_PIR.hpp"
#include "CONFIG/AHG_CONFIG_RULE.hpp"
#include "CONFIG/AHG_CONFIG_HC.hpp"
#include "CONFIG/AHG_CONFIG_HCL.hpp"
#include "CONFIG/AHG_CONFIG_SWITCH.hpp"

int NumberOfDeviceForDelScene = 0;
int NumberOfStandardControl = 0;

int numDeviceOnline = 0;
int numDvUnicast = 0;
int numDvUnicastDelScene = 0;
string deviceOnline[200] = {""};
int ArrDvUnicast[256] = {0};
int DeviceDelScene[256] = {0};

int ArrInfoDvSceneDelay[256][4] = {0};
int IndexSceneDelay = 0;

string DvIdInfo[200] = {""};
int DvUnicastIdInfo[200] = {0};

int IdxDv = 0;

/*
 * TODO: AutoUpdateDevice
 */
int numDeviceOff = 0;
int vri_deviceOff[100];

int ArrayOfDevice[200] = {0};
int *ArrDvAddGroup;
int idx_dv = 0;

int DeviceValue[10] = {0};
int DeviceIdValue[10] = {0};
int NumDvValue = 0;

/*ScreenTouch*/
string ST_array_icon[18] = {"01d", "02d", "03d", "04d", "09d", "10d", "11d",
							"13d", "50d", "01n", "02n", "03n", "04n", "09n", "10n", "11n", "13n",
							"50n"};
//-----------------convert

string Duyto_string(char *duytesst, unsigned int lenght)
{
	string Convert2Str = "";
	for (unsigned int CV = 0; CV < lenght; CV++)
	{
		Convert2Str = Convert2Str + duytesst[CV];
	}
	return Convert2Str;
}

/*-----------------------------------------------DATABASE-------------------------------------------------------*/

/*-------------------------SQL---------------------------*/
int ADR;
long long TimeStamp;
string tempStr;
int TYPE_DV;
int DeviceAttributeId, DeviceAttributeExtension, DeviceUnicastId;
int DeviceAttributeValue;

string Id;
string CONTROL;
string DeviceId;

static int SQLADR(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		ADR = atoi((const char *)argv[0]);
	}
	catch (exception &e)
	{
	}
	return 0;
}

static int SQLTIMESTAMP(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		TimeStamp = atoll((const char *)argv[0]);
	}
	catch (exception &e)
	{
	}
	return 0;
}

static int SQLTYPEDV(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		TYPE_DV = atoi((const char *)argv[0]);
	}
	catch (exception &e)
	{
	}
	return 0;
}

static int DEL_SCENE(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		DeviceDelScene[numDvUnicastDelScene] = atoi((const char *)argv[0]);
		numDvUnicastDelScene++;
	}
	catch (exception &e)
	{
	}
	return 0;
}
static int SQL_DEVICE_UPDATE(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		arrayID[numProperties] = (atoi((const char *)argv[0]));
		arrayValue[numProperties] = (atoi((const char *)argv[1]));
		numProperties++;
	}
	catch (exception &e)
	{
	}
	return 0;
}
static int SQLCONTROL(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		CONTROL = "";
		CONTROL = (const char *)(argv[0]);
		deviceUpdate[numberDeviceUpdate] = CONTROL;
		// cout << "-------------" << deviceUpdate[numberDeviceUpdate] << "----------" << numberDeviceUpdate << endl;
		numberDeviceUpdate++;
	}
	catch (exception &e)
	{
	}
	return 0;
}
static int SQL_GET_STATUS(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		deviceOnline[numDeviceOnline] = (const char *)(argv[0]);
		// cout << "____________________________ " << deviceOnline[numDeviceOnline] << endl;
		numDeviceOnline++;
	}
	catch (exception &e)
	{
	}
	return 0;
}
static int SQL_GET_UNICAST(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		ArrDvUnicast[numDvUnicast] = atoi((const char *)argv[0]);
		numDvUnicast++;
	}
	catch (exception &e)
	{
	}
	return 0;
}
static int GET_DEVICE_CHECK_ONLINE(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		t_DeviceCheckOnline Temp_DeviceCheckOnline = {0};
		Temp_DeviceCheckOnline.DeviceUnicastID = atoi((const char *)argv[0]);
		Temp_DeviceCheckOnline.TypeDevice = atoi((const char *)argv[1]);
		Temp_DeviceCheckOnline.FirmVersion = (const char *)(argv[2]);
		Temp_DeviceCheckOnline.DeviceUUID = (const char *)(argv[3]);
		T_DeviceCheckOnline.push_back(Temp_DeviceCheckOnline);
	}
	catch (exception &e)
	{
	}
	return 0;
}
static int GET_DEVICE_UNICAST_CHECK_VALUE(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		t_Device T_TempDevice = {0};
		T_TempDevice.DeviceUUID = (const char *)(argv[0]);
		T_TempDevice.DeviceUnicastID = atoi((const char *)argv[1]);
		T_TempDevice.TypeDevice = atoi((const char *)argv[2]);
		T_Device.push_back(T_TempDevice);
	}
	catch (exception &e)
	{
	}
	return 0;
}

static int SQL_GET_DeviceOff(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		vri_deviceOff[numDeviceOff] = (atoi((const char *)argv[0]));
		numDeviceOff++;
	}
	catch (exception &e)
	{
	}
	return 0;
}

static int SQL_GetDvInfo(void *data, int argc, char **argv, char **azColName)
{
	DvIdInfo[IdxDv] = (const char *)(argv[0]);
	DvUnicastIdInfo[IdxDv] = atoi((const char *)argv[1]);
	IdxDv++;
	return 0;
}

static int SQL_ResetHC(void *data, int argc, char **argv, char **azColName)
{
	deviceReset[numDeviceReset] = atoi((const char *)argv[0]);
	// cout << "Device " << numDeviceReset << " : " << deviceReset[numDeviceReset] << endl;
	numDeviceReset++;
	return 0;
}

static int SQL_CheckDvValue(void *data, int argc, char **argv, char **azColName)
{
	DeviceIdValue[NumDvValue] = atoi((const char *)argv[0]);
	DeviceValue[NumDvValue] = atoi((const char *)argv[1]);
	NumDvValue++;
	return 0;
}

static int SQL_CheckSceneDelay(void *data, int argc, char **argv, char **azColName)
{
	ArrInfoDvSceneDelay[IndexSceneDelay][0] = atoi((const char *)argv[0]);
	ArrInfoDvSceneDelay[IndexSceneDelay][1] = atoi((const char *)argv[1]);
	ArrInfoDvSceneDelay[IndexSceneDelay][2] = atoi((const char *)argv[2]);
	ArrInfoDvSceneDelay[IndexSceneDelay][3] = atoi((const char *)argv[3]);
	IndexSceneDelay++;
	return 0;
}

static int GetDomitoryId(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		dormitoryId = (const char *)(argv[0]);
	}
	catch (exception &e)
	{
	}
	return 0;
}

static int GetDeviceFromRuleDeviceInput(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		t_DeviceFromRuleDeviceInput DeviceFromRuleDeviceInput;
		DeviceFromRuleDeviceInput.DeviceId = (const char *)(argv[0]);
		DeviceFromRuleDeviceInput.DeviceUnicastId = atoi((const char *)argv[1]);
		DeviceFromRuleDeviceInput.DeviceAttributeId = atoi((const char *)argv[2]);
		ListDeviceFromRuleDeviceInput.push_back(DeviceFromRuleDeviceInput);
	}
	catch (exception &e)
	{
	}
	return 0;
}

static int GetDeviceValue(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		QueueMsgRSP(atoi((const char *)argv[0]), atoi((const char *)argv[1]), atoi((const char *)argv[2]), 1);
	}
	catch (exception &e)
	{
	}
	return 0;
}

static int GetDeviceVersion(void *data, int argc, char **argv, char **azColName)
{
	try
	{
		tempStr = (const char *)(argv[0]);
	}
	catch (exception &e)
	{
	}
	return 0;
}

/*-------------------------DB---------------------------*/

int DB_Read(string control, string sql)
{
	sqlite3 *DB;
	int exit = 0;
	do
	{
		exit = sqlite3_open("/root/rd.Sqlite", &DB);
		usleep(1000);
	} while (exit != SQLITE_OK);
	char *messaggeError;

	if (control.compare("ADR") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), SQLADR, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("TIMESTAMP") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), SQLTIMESTAMP, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("CONTROL") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), SQLCONTROL, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("TYPE_DEVICE") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), SQLTYPEDV, 0, &messaggeError) != SQLITE_OK)
		{
			// cout << messaggeError << endl;
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("DEL_SCENE") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), DEL_SCENE, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("GET_DV_INFO") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), SQL_GetDvInfo, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("DEVICE_ONLINE") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), SQL_GET_STATUS, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("DEVICE_OFFLINE") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), SQL_GET_DeviceOff, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("DEVICE_UNICAST") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), SQL_GET_UNICAST, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("GET_DEVICE_CHECK_ONLINE") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), GET_DEVICE_CHECK_ONLINE, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("GET_DEVICE_UNICAST_CHECK_VALUE") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), GET_DEVICE_UNICAST_CHECK_VALUE, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("GET_DEVICEATTRIBUTE") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), SQL_DEVICE_UPDATE, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("RESET_HC") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), SQL_ResetHC, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("CHECK_DEVICE_VALUE") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), SQL_CheckDvValue, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("CHECK_SCENE_DELAY") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), SQL_CheckSceneDelay, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("GET_DOMITORYID") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), GetDomitoryId, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("GET_DEVICEFROMRULEDEVICEINPUT") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), GetDeviceFromRuleDeviceInput, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("GET_DEVICE_VALUE") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), GetDeviceValue, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	else if (control.compare("GET_DEVICE_VERSION") == 0)
	{
		while (sqlite3_exec(DB, sql.c_str(), GetDeviceVersion, 0, &messaggeError) != SQLITE_OK)
		{
			sqlite3_free(messaggeError);
			usleep(1000);
		}
	}
	if (exit != SQLITE_OK)
	{
		sqlite3_free(messaggeError);
	}
	sqlite3_close(DB);
	return (0);
}

int DB_Write(string sql)
{
	sqlite3 *DBWrite;
	int exit;
	do
	{
		exit = sqlite3_open("/root/rd.Sqlite", &DBWrite);
		usleep(1000);
	} while (exit != SQLITE_OK);
	char *messaggeError = 0;
	while (sqlite3_exec(DBWrite, const_cast<char *>(sql.c_str()), NULL, 0, &messaggeError) != SQLITE_OK)
	{
		sqlite3_free(messaggeError);
		usleep(1000);
	}
	sqlite3_close(DBWrite);
	return (0);
}

void InsertIntoEventInputDVMapping(string RuleId, string DeviceId, int DeviceUnicastId)
{
	string AddDeviceIntoRule = "INSERT OR REPLACE INTO EventTriggerInputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId) "
							   "values ('" +
							   RuleId + "', '" + DeviceId + "', " + to_string(DeviceUnicastId) + ");";
	DB_Write(AddDeviceIntoRule);
}
void InsertIntoEventInputDVValue(string RuleId, string DeviceId, int DeviceUnicastId, int Properties, int TpyeComare, int Value1, int Value2)
{
	string AddDeviceValueIntoRule = "INSERT OR REPLACE INTO EventTriggerInputDeviceSetupValue(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, ComparisonOperatorId, DeviceAttributeValue, DeviceAttributeValueMAX) "
									"values ('" +
									RuleId + "', '" + DeviceId + "', " + to_string(DeviceUnicastId) + "," + to_string(Properties) + ", " + to_string(TpyeComare) + ", " + to_string(Value1) + ", " + to_string(Value2) + ");";
	DB_Write(AddDeviceValueIntoRule);
}

void InsertIntoEvent(string EventId, string GroupId, int EventTypeId, int SceneUnicastId, int Priority, string Name,
					 int LogicEvent, int HasTimer, string StartAt, string EndAt, int ValueCreate, int Status, int HasRepeater, int Monday,
					 int Tuesday, int Wednesday, int Thurday, int Friday, int Staturday, int Sunday, int HasNoti, int Fade, string Room, int NotiDelay)
{
	string AddEvent = "INSERT OR REPLACE INTO EventTrigger(EventTriggerId, GroupId, EventTriggerTypeId, SceneUnicastID, Priority, Name, LogicalOperatorID, HasTimer, StartAt, "
					  "EndAt, ValueCreate, StatusID, HasRepeater, EachMonday, EachTuesday, EachWednesday, EachThursday, EachFriday, EachSaturday, EachSunday, NotificationUsed, FADE_IN, RoomId, NotificationDelayTime) "
					  "values ('" +
					  EventId + "', '" + GroupId + "', " + to_string(EventTypeId) + "," + to_string(SceneUnicastId) + ", " + to_string(Priority) + ", '" + Name + "', " + to_string(LogicEvent) + ","
																																																  " " +
					  to_string(HasTimer) + ", '" + StartAt + "', '" + EndAt + "', " + to_string(ValueCreate) + ", " + to_string(Status) + ", " + to_string(HasRepeater) + ", " + to_string(Monday) + ", " + to_string(Tuesday) + ""
																																																								  ", " +
					  to_string(Wednesday) + ", " + to_string(Thurday) + ", " + to_string(Friday) + ", " + to_string(Staturday) + ", " + to_string(Sunday) + ", " + to_string(HasNoti) + ", " + to_string(Fade) + ","
																																																				  " '" +
					  Room + "', " + to_string(NotiDelay) + ");";
	cout << AddEvent << endl;
	DB_Write(AddEvent);
}

// Điều khiển đèn chiếu sáng

/*-----------------------------------------------APP---------------------------------------------------------*/

void ScanStop(string cmd)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> jsonAHG(sendToGW);
	if (cmd.compare("SCAN") == 0)
	{
		jsonAHG.StartObject();
		jsonAHG.Key("CMD");
		jsonAHG.String("SCAN");
		jsonAHG.EndObject();
		string s = sendToGW.GetString();
		ExeCMD("echo > /etc/scanDevice \"1\"");
		MqttSend(mosq, const_cast<char *>(s.c_str()));
	}
	else if (cmd.compare("STOP") == 0)
	{
		jsonAHG.StartObject();
		jsonAHG.Key("CMD");
		jsonAHG.String("STOP");
		jsonAHG.EndObject();
		string s = sendToGW.GetString();
		ExeCMD("echo > /etc/scanDevice \"0\"");
		MqttSend(mosq, const_cast<char *>(s.c_str()));
	}
}

void ScanStopPairingDevice(struct mosquitto *mosq, char *jobj)
{
	Document document;
	document.Parse(jobj);
	if (document.IsObject())
	{
		if (document.HasMember("CMD") && document["CMD"].IsString() && document.HasMember("DATA") && document["DATA"].IsObject())
		{
			string cmd = document["CMD"].GetString();
			const Value &data = document["DATA"];
			if (data.HasMember("DEVICE_ID") && data["DEVICE_ID"].IsString())
			{
				string deviceId = data["DEVICE_ID"].GetString();
				uint16_t deviceUnicastId = DEVICE_UNICAST_ID(deviceId);
				string sql = "SELECT MAX(DeviceUnicastId) FROM Device;";
				numDvUnicast = 0;
				DB_Read("DEVICE_UNICAST", sql);
				if (numDvUnicast == 1)
				{
					uint16_t deviceUnicastPair = ArrDvUnicast[0] + 8;
					StringBuffer sendToGW;
					Writer<StringBuffer> jsonAHG(sendToGW);

					jsonAHG.StartObject();
					jsonAHG.Key("CMD");
					jsonAHG.String(cmd.c_str());
					jsonAHG.Key("DATA");
					jsonAHG.StartObject();
					jsonAHG.Key("DEVICE_UNICAST_PARENT");
					jsonAHG.Int(deviceUnicastId);
					jsonAHG.Key("DEVICE_UNICAST_ID");
					jsonAHG.Int(deviceUnicastPair);
					jsonAHG.EndObject();
					jsonAHG.EndObject();
					string s = sendToGW.GetString();
					MqttSend(mosq, const_cast<char *>(s.c_str()));
				}
			}
		}
	}
}

void SendDeviceToGW(struct mosquitto *mosq, int idDevice, int idControl, int value, bool HasACK)
{
	string keyControl[3] = {"VALUE_ONOFF", "VALUE_DIM", "VALUE_CCT"};
	string keyCmd[3] = {"ONOFF", "DIM", "CCT"};
	if (idControl == 2 && idDevice < 49152)
	{
		idDevice++;
	}
	if (idControl == 1 && value == 0)
	{
		idControl = 0;
	}
	// cout << idDevice << " : " << idControl << " : " << value << endl;
	// cout << keyControl[idControl] << " : " << value << endl;
	StringBuffer sendToGW;
	Writer<StringBuffer> jsonAHG(sendToGW);
	jsonAHG.StartObject();
	jsonAHG.Key("CMD");
	jsonAHG.String(const_cast<char *>(keyCmd[idControl].c_str()));
	if (HasACK == false)
	{
		jsonAHG.Key("ACK");
		jsonAHG.Bool(false);
	}
	jsonAHG.Key("DATA");
	jsonAHG.StartObject();
	jsonAHG.Key("DEVICE_UNICAST_ID");
	jsonAHG.Int(idDevice);
	jsonAHG.Key(const_cast<char *>(keyControl[idControl].c_str()));
	jsonAHG.Int(value);
	jsonAHG.EndObject();
	jsonAHG.EndObject();
	string s = sendToGW.GetString();
	cout << s << endl;
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

void SendDVAddScene(int DVUnicast, int SceneUnicast, int Mode, int SceneRGB)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("ADDSCENE");
	json.Key("DATA");
	json.StartObject();
	json.Key("SCENEID");
	json.Int(SceneUnicast);
	if (Mode == ADD_SCENE_CCT)
	{
		json.Key("CCT");
		json.StartObject();
		json.Key("DEVICE_UNICAST_ID");
		json.StartArray();
		json.Int(DVUnicast);
		json.EndArray();
		json.EndObject();
	}
	if (Mode == ADD_SCENE_RGB)
	{
		json.Key("RGB_CCT");
		json.StartArray();
		json.StartObject();
		json.Key("DEVICE_UNICAST_ID");
		json.Int(DVUnicast);
		json.Key("SRGBID");
		json.Int(SceneRGB);
		json.EndObject();
		json.EndArray();
	}
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	cout << s << endl;
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

void ResetDB()
{
	string DelDevice = "DELETE FROM Device;";
	DB_Write(DelDevice);
	string DelDeviceAttributeValue = "DELETE FROM DeviceAttributeValue;";
	DB_Write(DelDeviceAttributeValue);
	string DelEventTrigger = "DELETE FROM EventTrigger;";
	DB_Write(DelEventTrigger);
	string DelEventTriggerID = "DELETE FROM EventTriggerID;";
	DB_Write(DelEventTriggerID);
	string DelEventTriggerInputDeviceMapping = "DELETE FROM EventTriggerInputDeviceMapping;";
	DB_Write(DelEventTriggerInputDeviceMapping);
	string DelEventTriggerInputGroupingMapping = "DELETE FROM EventTriggerInputGroupingMapping;";
	DB_Write(DelEventTriggerInputGroupingMapping);
	string DelEventTriggerOutputDeviceMapping = "DELETE FROM EventTriggerOutputDeviceMapping;";
	DB_Write(DelEventTriggerOutputDeviceMapping);
	string DelEventTriggerOutputDeviceSetupValue = "DELETE FROM EventTriggerOutputDeviceSetupValue;";
	DB_Write(DelEventTriggerOutputDeviceSetupValue);
	string DelEventTriggerOutputGroupingMapping = "DELETE FROM EventTriggerOutputGroupingMapping;";
	DB_Write(DelEventTriggerOutputGroupingMapping);
	string DelEventTriggerOutputGroupingSetupValue = "DELETE FROM EventTriggerOutputGroupingSetupValue;";
	DB_Write(DelEventTriggerOutputGroupingSetupValue);
	string DelEventTriggerOutputSceneMapping = "DELETE FROM EventTriggerOutputSceneMapping;";
	DB_Write(DelEventTriggerOutputSceneMapping);
	string DelGROUPID = "DELETE FROM GROUPID;";
	DB_Write(DelGROUPID);
	string DelGROUPING = "DELETE FROM GROUPING;";
	DB_Write(DelGROUPING);
	string DelQueue = "DELETE FROM QueueMsgRsp;";
	DB_Write(DelQueue);
	string DelGroupingDeviceMapping = "DELETE FROM GroupingDeviceMapping;";
	DB_Write(DelGroupingDeviceMapping);
	string DelSystemConfiguration = "DELETE FROM SystemConfiguration;";
	DB_Write(DelSystemConfiguration);
	string DelUserData = "DELETE FROM UserData;";
	DB_Write(DelUserData);

	ExeCMD("uci set network.wan.ifname='eth0'");
	ExeCMD("uci commit network");
	ExeCMD("/etc/init.d/network restart");
	ExeCMD("uci del wireless.wifinet1");
	ExeCMD("uci commit wireless");
	ExeCMD("wifi");
	ExeCMD("rm /root/device_key.txt");
	ExeCMD("rm /etc/Dormitory.txt");
	ExeCMD("RESET_BLE");
	sleep(15);
	ExeCMD("reboot -f");
}

void DelNode(struct mosquitto *mosq, char *jobj)
{
	pthread_mutex_lock(&mutex);
	ResetDataResetNode();
	pthread_mutex_unlock(&mutex);
	Document document;
	document.Parse(jobj);
	int TemNum = 0;
	if (document.HasMember("DATA"))
	{
		const Value &data = document["DATA"];
		pthread_mutex_lock(&mutex);
		numDeviceReset = TemNum = data.Size();
		pthread_mutex_unlock(&mutex);
		// cout << "So luong node bi xoa:" << numDeviceReset << endl;
		std::vector<int> listChildDevice;
		std::vector<string> listChildDeviceId;
		if (TemNum != 0)
		{
			StringBuffer sendToGW;
			Writer<StringBuffer> jsonAHG(sendToGW);
			jsonAHG.StartObject();
			jsonAHG.Key("CMD");
			jsonAHG.String("RESETNODE");
			jsonAHG.Key("DATA");
			jsonAHG.StartObject();
			jsonAHG.Key("DEVICE_UNICAST_ID");
			jsonAHG.StartArray();
			for (rapidjson::SizeType i = 0; i < data.Size(); i++)
			{
				string deviceId = data[i].GetString();
				int deviceUnicastId = DEVICE_UNICAST_ID(deviceId);
				deviceReset[i] = deviceUnicastId;
				uint16_t typeDev = TYPE_DEVICE(deviceId);
				if (typeDev == SEFTPOWER_REMOTE_1 || typeDev == SEFTPOWER_REMOTE_2 || typeDev == SEFTPOWER_REMOTE_3 || typeDev == SEFTPOWER_REMOTE_6)
				{
					listChildDevice.push_back(deviceUnicastId);
					listChildDeviceId.push_back(deviceId);
				}
				else
					jsonAHG.Int(deviceUnicastId);
			}
			jsonAHG.EndArray();
			jsonAHG.EndObject();
			jsonAHG.EndObject();
			string s = sendToGW.GetString();
			MqttSend(mosq, const_cast<char *>(s.c_str()));
			pthread_mutex_lock(&mutex);
			isResetNode = true;
			pthread_mutex_unlock(&mutex);
		}

		if (listChildDevice.size() > 0)
		{
			StringBuffer delNode;
			Writer<StringBuffer> json(delNode);
			json.StartObject();
			json.Key("CMD");
			json.String("RESET_CHILD_DEVICE");
			json.Key("DATA");
			json.StartArray();
			json.StartObject();
			for (int i = 0; i < listChildDevice.size(); i++)
			{
				string sql = "SELECT ParentDeviceUnicastId FROM SubDevice WHERE ChildDeviceUnicastId = " + to_string(listChildDevice[i]) + ";";
				DB_Read("ADR", sql);
				uint16_t deviceUnicastParent = ADR;
				json.Key("DEVICE_UNICAST_PARENT");
				json.Int(deviceUnicastParent);
				json.Key("DEVICE_UNICAST_ID");
				json.Int(listChildDevice[i]);

				string deleteDevice = "Delete from Device Where DeviceId = '" + listChildDeviceId[i] + "';";
				DB_Write(deleteDevice);
				string deleteSubDevice = "Delete from SubDevice Where ChildDeviceId = '" + listChildDeviceId[i] + "';";
				DB_Write(deleteSubDevice);
			}
			json.EndObject();
			json.EndArray();
			json.EndObject();
			string s1 = delNode.GetString();
			MqttSend(mosq, const_cast<char *>(s1.c_str()));
			pthread_mutex_lock(&mutex);
			isResetNode = true;
			pthread_mutex_unlock(&mutex);
		}
	}
}

void SendEditScene(int DvUnicast, int SceneUnicast, int Mode, int SceneRGB)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("EDITSCENE");
	json.Key("DATA");
	json.StartObject();
	json.Key("SCENEID");
	json.Int(SceneUnicast);
	if (Mode == ADD_SCENE_CCT)
	{
		json.Key("CCT");
		json.StartObject();
		json.Key("DEVICE_UNICAST_ID");
		json.StartArray();
		json.Int(DvUnicast);
		json.EndArray();
		json.EndObject();
	}
	else if (Mode == ADD_SCENE_RGB)
	{
		json.Key("RGB_CCT");
		json.StartArray();
		json.StartObject();
		json.Key("DEVICE_UNICAST_ID");
		json.Int(DvUnicast);
		json.Key("SRGBID");
		json.Int(SceneRGB);
		json.EndObject();
		json.EndArray();
	}
	else if (Mode == EDIT_SCENE_CCT_TO_RGB)
	{
		json.Key("CCT_DELSCENE");
		json.StartArray();
		json.Int(DvUnicast);
		json.EndArray();
		json.Key("RGB_CCT");
		json.StartArray();
		json.StartObject();
		json.Key("DEVICE_UNICAST_ID");
		json.Int(DvUnicast);
		json.Key("SRGBID");
		json.Int(SceneRGB);
		json.EndObject();
		json.EndArray();
	}
	else if (Mode == EDIT_SCENE_RGB_TO_CCT)
	{
		json.Key("RGB_DELSCENE");
		json.StartArray();
		json.Int(DvUnicast);
		json.EndArray();
		json.Key("CCT");
		json.StartObject();
		json.Key("DEVICE_UNICAST_ID");
		json.StartArray();
		json.Int(DvUnicast);
		json.EndArray();
		json.EndObject();
	}
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

void DelDVFromScene(int DvUnicast, int SceneUnicast, int Mode)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("DELSCENE");
	json.Key("DATA");
	json.StartObject();
	if (Mode == DEL_SCENE_CCT)
	{
		json.Key("DEVICE_UNICAST_ID");
		json.StartArray();
		json.Int(DvUnicast);
		json.EndArray();
	}
	else if (Mode == DEL_SCENE_RGB)
	{
		json.Key("DEVICE_RGB_UNICAST_ID");
		json.StartArray();
		json.Int(DvUnicast);
		json.EndArray();
	}
	json.Key("SCENEID");
	json.Int(SceneUnicast);
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	cout << s << endl;
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

void DelDVFromGR(int DvUnicast, int GrUnicast)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("DELGROUP");
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.StartArray();
	json.Int(DvUnicast);
	json.EndArray();
	json.Key("GROUP_UNICAST_ID");
	json.Int(GrUnicast);
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

void UpdateDataScreenTouch(struct mosquitto *mosq, char *jobj)
{
	Document document;
	document.Parse(jobj);
	string main = document["main"].GetString();
	string description = document["description"].GetString();
	string icon = document["icon"].GetString();
	int StatusWeather = 0;
	for (int i = 0; i < 17; i++)
	{
		if (icon.compare(ST_array_icon[i]) == 0)
		{
			StatusWeather = i;
			break;
		}
	}
	double temp = document["temp"].GetDouble();
	pthread_mutex_lock(&mutex);
	screenTouch_statusOutWeather = StatusWeather;
	screenTouch_tempOutWeather = temp;
	pthread_mutex_unlock(&mutex);
	numDvUnicast = 0;
	string GetDVScreenTouch = "SELECT DeviceUnicastId FROM DEVICE WHERE CategoryId = 23003;";
	DB_Read("DEVICE_UNICAST", GetDVScreenTouch);
	for (int i = 0; i < numDvUnicast; i++)
	{
		StringBuffer sendToApp;
		Writer<StringBuffer> json(sendToApp);
		json.StartObject();
		json.Key("CMD");
		json.String("WEATHER_OUT_SCREEN_TOUCH");
		json.Key("DATA");
		json.StartObject();
		json.Key("DEVICE_UNICAST_ID");
		json.Int(ArrDvUnicast[i]);
		json.Key("STATUS");
		json.Int(StatusWeather);
		json.Key("TEMPERATURE");
		json.Int(temp);
		json.EndObject();
		json.EndObject();

		cout << sendToApp.GetString() << endl;
		string s = sendToApp.GetString();
		MqttSend(mosq, const_cast<char *>(s.c_str()));
	}
}

void *DB(void *argv)
{
	bool CheckRingDB = false;
	while (1)
	{
		string Item_Pop = "";
		if (!QueueDB.empty())
		{
			Item_Pop = QueueDB.front();
			CheckRingDB = true;
			QueueDB.pop();
		}
		if (CheckRingDB == true)
		{
			CheckRingDB = false;
			DB_Write(Item_Pop);
		}
		usleep(10000);
	}
	return 0;
}

void Check_Cmd(struct mosquitto *mosq, char *jobj)
{
	Document document;
	document.Parse(jobj);
	int checkMac = 0;
	if (document.IsObject())
	{
		while (true)
		{
			if (pthread_mutex_trylock(&mutexLog) == 0)
			{
				WriteIntoLog("<APP -> HC>", jobj);
				pthread_mutex_unlock(&mutexLog);
				break;
			}
			usleep(3000);
		}
		if (document.HasMember("cmd"))
		{
			string cmdWeather = document["cmd"].GetString();
			if (cmdWeather.compare("outWeather") == 0)
			{
				UpdateDataScreenTouch(mosq, jobj);
			}			
		}
		if (document.HasMember("TO"))
		{
			checkMac = 2;
			const Value &to = document["TO"];
			if (to.HasMember("MAC") && to["MAC"].IsString())
			{
				string temp = to["MAC"].GetString();
				if (temp.compare(macHC) == 0)
				{
					checkMac = 1;
				}
			}
			if (to.HasMember("MAC") && to["MAC"].IsArray())
			{
				const Value &MAC = to["MAC"];
				for (rapidjson::SizeType i = 0; i < MAC.Size(); i++)
				{
					const Value &a = MAC[i];
					string temp = MAC[i].GetString();
					if (temp == macHC)
					{
						checkMac = 1;
						break;
					}
				}
			}
		}
		if (checkMac < 2)
		{
			if (document.HasMember("CMD") || document.HasMember("cmd"))
			{
				string cmd = "";
				if (document.HasMember("CMD"))
				{
					cmd = document["CMD"].GetString();
				}
				if (document.HasMember("cmd"))
				{
					cmd = document["cmd"].GetString();
				}
				if ((cmd.compare("SCAN") == 0) || (cmd.compare("STOP") == 0))
				{
					ScanStop(cmd);
				}
				else if ((cmd.compare("SCAN_PAIRING_DEVICE") == 0) || ((cmd.compare("STOP_SCAN_PAIRING_DEVICE") == 0)))
				{
					ScanStopPairingDevice(mosq, jobj);
				}
				else if (cmd.compare("RESET_NODE") == 0)
				{
					DelNode(mosq, jobj);
				}
				else if (cmd.compare("DEVICE") == 0 || cmd.compare("DEVICE_CALIB") == 0)
				{
					ControlDevice(mosq, jobj);
				}
				else if (cmd.compare("DEVICE_UPDATE") == 0)
				{
					DeviceUpdate(mosq, jobj);
				}
				else if (cmd.compare("GROUP") == 0)
				{
					ControlGroup(mosq, jobj);
				}
				else if (cmd.compare("SCENE") == 0)
				{
					CallScene(mosq, jobj);
				}
				else if (cmd.compare("DEVICE_FLASH") == 0)
				{
					FlashDevice(mosq, jobj);
				}
				else if (cmd.compare("CREATE_GROUP") == 0)
				{
					CreateGroup(mosq, jobj);
				}
				else if (cmd.compare("ADD_DEVICE_TO_GROUP") == 0)
				{
					AddDeviceGroup(mosq, jobj);
				}
				else if (cmd.compare("DELETE_DEVICE_FROM_GROUP") == 0)
				{
					DelDeviceGroup(mosq, jobj);
				}
				else if (cmd.compare("DELETE_GROUP") == 0)
				{
					DelGroup(mosq, jobj);
				}
				else if (cmd.compare("CREATE_SCENE") == 0)
				{
					CreateScene(mosq, jobj);
				}
				else if (cmd.compare("EDIT_SCENE") == 0)
				{
					EditScene(mosq, jobj);
				}
				else if (cmd.compare("DELETE_SCENE") == 0)
				{
					DelScene(mosq, jobj);
				}
				else if (cmd.compare("CREATE_ROOM") == 0)
				{
					CreateRoom(mosq, jobj);
				}
				else if (cmd.compare("ADD_DEVICE_TO_ROOM") == 0)
				{
					AddDeviceToRoom(mosq, jobj);
				}
				else if (cmd.compare("REMOVE_DEVICE_FROM_ROOM") == 0)
				{
					DelDeviceFromRoom(mosq, jobj);
				}
				else if (cmd.compare("DELETE_ROOM") == 0)
				{
					DelRoom(mosq, jobj);
				}
				else if (cmd.compare("CHECK_ROOM") == 0)
				{
					CheckRoom(mosq, jobj);
				}
				else if (cmd.compare("SCENE_FOR_REMOTE") == 0)
				{
					CreateSceneForRemote(mosq, jobj);
				}
				else if (cmd.compare("DELETE_SCENE_FOR_REMOTE") == 0)
				{
					DelSceneForRemote(mosq, jobj);
				}
				else if (cmd.compare("SCENE_FOR_SCREEN") == 0)
				{
					SceneForScreen(mosq, jobj);
				}
				else if (cmd.compare("SCENE_FOR_SENSOR_LIGHT_PIR") == 0 || cmd.compare("EDIT_SCENE_FOR_SENSOR_LIGHT_PIR") == 0)
				{
					CreateSceneForSensorLightPIR(mosq, jobj);
				}
				else if (cmd.compare("REMOVE_SCENE_FOR_SENSOR_LIGHT_PIR") == 0)
				{
					DelSceneForSensorLightPIR(mosq, jobj);
				}
				else if (cmd.compare("COUNTDOWN") == 0)
				{
					CreateCountDown(mosq, jobj);
					ResetThread();
				}
				else if (cmd.compare("DELETE_COUNTDOWN") == 0)
				{
					DeleteCountDown(mosq, jobj);
					ResetThread();
				}
				else if (cmd.compare("CREATE_EVENT_TRIGGER") == 0)
				{
					CreateRule(mosq, jobj);
					ResetThread();
				}
				else if (cmd.compare("EDIT_EVENT_TRIGGER") == 0)
				{
					EditRule(mosq, jobj);
					ResetThread();
				}
				else if (cmd.compare("DELETE_EVENT_TRIGGER") == 0)
				{
					DelRule(mosq, jobj, true);
					ResetThread();
				}
				else if (cmd.compare("EVENT_TRIGGER_STATUS") == 0)
				{
					UpdateStatusRule(mosq, jobj);
					ResetThread();
				}
				else if (cmd.compare("RESET_HC") == 0)
				{
					ResetHC(mosq, jobj);
				}
				else if (cmd.compare("SENSOR_UPDATE") == 0)
				{
					UpdateValueSensor(mosq, jobj);
				}
				else if (cmd.compare("CREATE_HCL") == 0)
				{
					CreateHCL(mosq, jobj);
					ResetThread();
				}
				else if (cmd.compare("EDIT_HCL") == 0)
				{
					EditHCL(mosq, jobj);
					ResetThread();
				}
				else if (cmd.compare("HCL_RULE_STATUS") == 0)
				{
					UpdateStatusHCL(mosq, jobj);
					ResetThread();
				}
				else if (cmd.compare("VERSION_HC") == 0)
				{
					VersionHC(mosq, jobj);
				}
				else if (cmd.compare("ADD_DEVICE_SMARTHOME_TO_ROOM") == 0)
				{
					AddDeviceSmartHomeToRoom(mosq, jobj);
				}
				else if (cmd.compare("POWER_SWITCH_TIMEOUT") == 0)
				{
					CreateCountDownSwitch(mosq, jobj);
					ResetThread();
				}
				else if (cmd.compare("REMOVE_POWER_SWITCH_TIMEOUT") == 0)
				{
					DeleteCountDownSwitch(mosq, jobj);
					ResetThread();
				}
				else if (cmd.compare("CREATE_SCENE_DELAY") == 0)
				{
					CreateSceneDelay(mosq, jobj);
				}
				else if (cmd.compare("EDIT_SCENE_DELAY") == 0)
				{
					EditSceneDelay(mosq, jobj);
				}
				else if (cmd.compare("DELETE_SCENE_DELAY") == 0)
				{
					DeleteSceneDelay(mosq, jobj);
				}
				else if ((cmd.compare("TAP_TO_RUN") == 0) || (cmd.compare("ACTIVE_RULE") == 0))
				{
					TapToRun(mosq, jobj);
				}
				else if (cmd.compare("BACKUP") == 0)
				{
					BackupHC(mosq, jobj);
				}
				else if (cmd.compare("SWITCH_DEVICE") == 0)
				{
					ControlSwitchDevice(mosq, jobj);
				}
				else if (cmd.compare("STAIRS_SWITCH") == 0)
				{
					CreateSwitchCombine(jobj);
				}
				else if (cmd.compare("EDIT_STAIRS_SWITCH") == 0)
				{
					EditSwitchCombine(jobj);
				}
				else if (cmd.compare("DELETE_STAIRS_SWITCH") == 0)
				{
					DeleteSwitchCombine(jobj);
				}
				else if (cmd.compare("HC_CONNECT_TO_CLOUD") == 0)
				{
					HcConnectToCloud(jobj);
				}
				else if (cmd.compare("UPDATE_HC_MASTER") == 0)
				{
					UpdateHcMasterInfo(mosq, jobj);
				}
				else if (cmd.compare("ACTION_RULE") == 0)
				{
					ActionRule(mosq, jobj);
				}
				else if (cmd.compare("createRule") == 0)
				{
					RuleV2(mosq, jobj);
					ResetThread();
				}
				else if (cmd.compare("editRule") == 0)
				{
					EditRuleV2(mosq, jobj);
					ResetThread();
				}
			}
			else
			{
				cout << "CMD lỗi" << endl;
			}
		}
	}
	else
	{
		while (true)
		{
			if (pthread_mutex_trylock(&mutexLog) == 0)
			{
				WriteIntoLog("<APP -> HC (bản tin lỗi)>", jobj);
				pthread_mutex_unlock(&mutexLog);
				break;
			}
			usleep(3000);
		}
	}
}

void HcConnectToCloud(char *jobj)
{
	Document document;
	document.Parse(jobj);
	const Value &DATA = document["DATA"];
	if (DATA.HasMember("DORMITORY_ID") && DATA.HasMember("REFRESH_TOKEN") && DATA.HasMember("LATITUDE") && DATA.HasMember("LONGITUDE"))
	{
		string DormitoryId = DATA["DORMITORY_ID"].GetString();
		string RefreshToken = DATA["REFRESH_TOKEN"].GetString();
		float Latitude = DATA["LATITUDE"].GetFloat();
		float Longitude = DATA["LONGITUDE"].GetFloat();
		if (dormitoryId == DormitoryId)
		{
			string sql = "INSERT OR REPLACE INTO UserData (Id, RefreshToken, DormitoryId, Latitude, Longitude) values (1, '" + RefreshToken + "', '" + DormitoryId + "', " + to_string(Latitude) + ", " + to_string(Longitude) + ");";
			DB_Write(sql);
		}
	}
}

bool check_countdown = 0;
string event_trigger_id_countdown = "";

int CreateGroupUnicastId()
{
	int groupID;
	ADR = 0;
	string sql = "SELECT GroupUnicastId FROM GROUPING WHERE GroupUnicastId < 52348 ORDER BY GroupUnicastId DESC LIMIT 1;";
	DB_Read("ADR", sql);
	if (ADR < 49152 || ADR > 49232)
	{
		groupID = 49152;
	}
	else
	{
		groupID = ADR + 1;
	}
	return groupID;
}

int CreateSceneUnicastId()
{
	int sceneID;
	ADR = 0;
	string sql = "SELECT SceneUnicastID FROM EventTriggerID ORDER BY SceneUnicastID DESC LIMIT 1;";
	DB_Read("ADR", sql);
	if (ADR == 0 || ADR > 65000)
	{
		sceneID = 1;
	}
	else
	{
		sceneID = ADR + 1;
	}
	return sceneID;
}

int GetNextRoomId()
{
	int RoomId = 0;
	ADR = 0;
	string sql = "SELECT DISTINCT GroupUnicastId from GROUPING where RoomId NOTNULL AND GroupUnicastId >= 52348 AND CategoryId = 0 ORDER BY GroupUnicastId DESC LIMIT 1;";
	DB_Read("ADR", sql);
	if(ADR == 0)
		RoomId = ADR;
	else
		RoomId = ADR + 256 - ID_START;
	return RoomId;
}

float GetDeviceVersion(string DEVICE_ID)
{
	tempStr = "0";
	string sql = "SELECT FirmwareVersion from Device where DeviceId = '" + DEVICE_ID + "';";
	DB_Read("GET_DEVICE_VERSION", sql);
	float version = stof(tempStr);
	return version;
}

int SCENE_UNICAST_ID(string SCENE_ID)
{
	string GroupId = "SELECT SceneUnicastID FROM EventTrigger WHERE EventTriggerId ='" + SCENE_ID + "' AND SceneUnicastID IS NOT NULL;";
	ADR = 0;
	DB_Read("ADR", GroupId);
	int GROUP_UNICAST = ADR;
	return GROUP_UNICAST;
}

int GROUP_UNICAST_ID(string GROUP_ID)
{
	string GroupId = "SELECT GroupUnicastId FROM GROUPING WHERE GroupingId ='" + GROUP_ID + "';";
	ADR = 0;
	DB_Read("ADR", GroupId);
	int GROUP_UNICAST = ADR;
	return GROUP_UNICAST;
}

int DEVICE_UNICAST_ID(string DEVICE_ID)
{
	string checkID = "SELECT DeviceUnicastId FROM Device WHERE DeviceId = '" + DEVICE_ID + "' AND DeviceTypeId = 1;";
	ADR = 0;
	DB_Read("ADR", checkID);
	int DEVICE_UNICAST = ADR;
	return DEVICE_UNICAST;
}

int PARENT_DEVICE_UNICAST_ID(string DEVICE_ID)
{
	string checkID = "SELECT ParentDeviceUnicastId FROM SubDevice WHERE ChildDeviceId = '" + DEVICE_ID + "';";
	ADR = 0;
	DB_Read("ADR", checkID);
	int DEVICE_UNICAST = ADR;
	return DEVICE_UNICAST;
}

int PARENT_DEVICE_UNICAST_ID(int DEVICE_UNICAST_ID)
{
	string checkID = "SELECT ParentDeviceUnicastId FROM SubDevice WHERE ChildDeviceUnicastId = " + to_string(DEVICE_UNICAST_ID) + ";";
	ADR = 0;
	DB_Read("ADR", checkID);
	int DEVICE_UNICAST = ADR;
	return DEVICE_UNICAST;
}

int TYPE_DEVICE(string DEVICE_ID)
{
	string Check_Type_Device = "SELECT CategoryId FROM Device WHERE DeviceId = '" + DEVICE_ID + "';";
	TYPE_DV = 0;
	DB_Read("TYPE_DEVICE", Check_Type_Device);
	int Temp_TypeDv = TYPE_DV;
	return Temp_TypeDv;
}

int TYPE_DEVICE(int DEVICE_UNICAST_ID)
{
	string Check_Type_Device = "SELECT CategoryId FROM Device WHERE DeviceUnicastId = " + to_string(DEVICE_UNICAST_ID) + ";";
	TYPE_DV = 0;
	DB_Read("TYPE_DEVICE", Check_Type_Device);
	int Temp_TypeDv = TYPE_DV;
	return Temp_TypeDv;
}
