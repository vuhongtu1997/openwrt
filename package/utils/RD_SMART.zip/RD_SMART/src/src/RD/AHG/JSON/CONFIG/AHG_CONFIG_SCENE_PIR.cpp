/*
 * AHG_CONFIG_SCENE_PIR.cpp
 *
 *  Created on: Dec 23, 2021
 *      Author: rd
 */

#include <iostream>
#include "AHG_CONFIG_SCENE_PIR.hpp"

/*
{
   "CMD": "SCENE_FOR_SENSOR_LIGHT_PIR",
   "DATA": {
     "DEVICE_ID": "aa3549d4-5471-4d75-b0b2- b70fa5c10fb2",
     "SCENE_ID": "aa3549d4-5471-4d75-b0b2-  b70fa5c10fb2",
     "PIR_VALUE": 1,
     "LUX": [200, 600]
   }
 }
*/
void CreateSceneForSensorLightPIR(struct mosquitto *mosq, char* jobj){
	int ComparisionOperator = -1;
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	if(DATA.HasMember("SCENE_ID")){
		string DEVICE_ID = DATA["DEVICE_ID"].GetString();
		int DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
		string SCENE_PIR = DATA["SCENE_ID"].GetString();
		int pirValue = DATA["PIR_VALUE"].GetInt();
		int DeviceTypeId = TYPE_DEVICE(DEVICE_ID);
		scenebeforePir = SCENE_PIR;
		ADR = -1;
		string checkADR = "SELECT SceneUnicastID from EventTrigger where EventTriggerId='"+SCENE_PIR+"';";
		DB_Read( "ADR", checkADR);
		int SceneUnicastId = ADR;
		StringBuffer sendToGW;
		Writer<StringBuffer> json(sendToGW);
		json.StartObject();
		json.Key("CMD");
		json.String("ADDSCENE_LIGHT_PIR_SENSOR");
		json.Key("DATA");
		json.StartObject();
		json.Key("TYPESCENE");json.Int(0);
		json.Key("DEVICE_UNICAST_ID");
		json.Int(DEVICE_UNICAST);
		json.Key("TYPE");json.Int(2);
		json.Key("TYPE_DEV");json.Int(DeviceTypeId);
		if(DATA.HasMember("LUX")){
			json.Key("LIGHT_SENSOR");
			json.StartObject();
			const Value& LUX = DATA["LUX"];
			lowlux = LUX[0].GetInt();
			highlux = LUX[1].GetInt();
			json.Key("CONDITION");
			if(lowlux == -1 && highlux != -1){
				ComparisionOperator = 4;
			}
			if(highlux == -1 && lowlux != -1){
				ComparisionOperator = 6;
			}
			if(highlux != -1 && lowlux != -1){
				ComparisionOperator = 7;
			}
			if(highlux == lowlux){
				ComparisionOperator = 1;
			}
			json.Int(ComparisionOperator);
			json.Key("LOW_LUX");
			json.Int(lowlux);
			json.Key("HIGHT_LUX");
			json.Int(highlux);
			json.EndObject();
		}
		json.Key("PIR_SENSOR");
		json.StartObject();
		json.Key("PIR");
		json.Int(pirValue);
		json.EndObject();
		json.Key("SCENEID");
		json.Int(SceneUnicastId);
		json.EndObject();
		json.EndObject();

		string s = sendToGW.GetString();
		MqttSend(mosq, const_cast<char*>(s.c_str()));
	}
}

/*
{
  "CMD": "REMOVE_SCENE_FOR_SENSOR_LIGHT_PIR",
  "DEVICE_ID": "aa3549d4-5471-4d75-b0b2- b70fa5c10fb2",
  "DATA": [
    {
      "PIR_VALUE": 0,
      "EVENT_TRIGGER_ID": "aa3549d4-5471-4d75-b0b2-  b70fa5c10fb2"
    },
    {
      "PIR_VALUE": 1,
      "EVENT_TRIGGER_ID": "aa3549d4-5471-4d75-b0b2-  b70fa5c10fb2"
    }
  ]
}
*/
void DelSceneForSensorLightPIR(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	string DEVICE_ID = document["DEVICE_ID"].GetString();
	int DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
	const Value& DATA = document["DATA"];
	int DeviceTypeId = TYPE_DEVICE(DEVICE_ID);
	for (rapidjson::SizeType i = 0; i < DATA.Size(); i++){
		// string SCENE_ID = DATA[i]["EVENT_TRIGGER_ID"].GetString();
		// ADR = 0;
		// string checkADR = "SELECT SceneUnicastID from EventTrigger where EventTriggerId='"+SCENE_ID+"';";
		// DB_Read( "ADR", checkADR);
		StringBuffer sendToGW;
		Writer<StringBuffer> json(sendToGW);
		json.StartObject();
		json.Key("CMD");
		json.String("ADDSCENE_LIGHT_PIR_SENSOR");
		json.Key("DATA");
		json.StartObject();
		json.Key("DEVICE_UNICAST_ID");
		json.Int(DEVICE_UNICAST);
		json.Key("TYPE_DEV");
		json.Int(DeviceTypeId);
		json.Key("TYPE");
		json.Int(1);
		json.Key("SCENEID");
		json.Int(0);
		json.Key("PIR_SENSOR");
		json.StartObject();
		json.Key("PIR");
		json.Int(DATA[i]["PIR_VALUE"].GetInt());
		json.EndObject();
		json.EndObject();
		json.EndObject();
		string s = sendToGW.GetString();
		cout<<s<<endl;
		MqttSend(mosq, const_cast<char*>(s.c_str()));
	}
}
