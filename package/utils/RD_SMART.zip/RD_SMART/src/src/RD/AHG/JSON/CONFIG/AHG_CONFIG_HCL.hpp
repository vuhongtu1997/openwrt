/*
 * AHG_CONFIG_HCL.hpp
 *
 *  Created on: Dec 23, 2021
 *      Author: rd
 */

#ifndef SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_HCL_HPP_
#define SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_HCL_HPP_

#include "../JSON_AHG.hpp"

//HCL
void CreateHCL(struct mosquitto *mosq, char* jobj);
void EditHCL(struct mosquitto *mosq, char* jobj);
void DeleteHCL(struct mosquitto *mosq, char* jobj);
void UpdateStatusHCL(struct mosquitto *mosq, char* jobj);

#endif /* SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_HCL_HPP_ */
