/*
 * AHG_CONTROL.cpp
 *
 *  Created on: Dec 23, 2021
 *      Author: rd
 */

#include <iostream>
#include "AHG_CONTROL.hpp"

int numberDeviceUpdate = 0;
string deviceUpdate[200] = {""};
int numProperties = 0;

int arrayID[200] = {0};
int arrayValue[200] = {0};

typedef struct
{
	int R;
	int G;
	int B;
	int DimOn;
	int DimOff;
	int DeviceUnicastId;
	int DeviceTypeId;
	int ButtonId;
} t_ControlSwitch;

static void ControlCurtain(struct mosquitto *mosq, int DVUnicaseID, int AttID, int AttValue, string Cmd)
{
	if (Cmd.compare("DEVICE") == 0)
	{
		Cmd = "DEVICE_CONTROL";
	}
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String(const_cast<char *>(Cmd.c_str()));
	json.Key("TYPE_DEV"), json.Int(22006);
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(DVUnicaseID);
	json.Key("PROPERTIES");
	json.StartArray();
	json.StartObject();
	json.Key("ID");
	json.Int(AttID);
	json.Key("VALUE");
	json.Int(AttValue);
	json.EndObject();
	json.EndArray();
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

static void ControlHSL(struct mosquitto *mosq, int DVUnicaseID, int Hvalue, int SValue, int LValue, bool IsColor)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> jsonAHG(sendToGW);
	jsonAHG.StartObject();
	jsonAHG.Key("CMD");
	jsonAHG.String("HSL");
	jsonAHG.Key("DATA");
	jsonAHG.StartObject();
	jsonAHG.Key("DEVICE_UNICAST_ID");
	jsonAHG.Int(DVUnicaseID);
	jsonAHG.Key("VALUE_H");
	jsonAHG.Int(Hvalue);
	jsonAHG.Key("VALUE_S");
	jsonAHG.Int(SValue);
	jsonAHG.Key("VALUE_L");
	jsonAHG.Int(LValue);
	jsonAHG.EndObject();
	jsonAHG.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
	if (IsColor)
	{
		QueueMsgRSP(DVUnicaseID, 5, LValue, 1);
	}
}

static void ControlModeRGB(struct mosquitto *mosq, int DVUnicaseID, int ModeRGB)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> jsonAHG(sendToGW);
	jsonAHG.StartObject();
	jsonAHG.Key("CMD");
	jsonAHG.String("CALLMODE_RGB");
	jsonAHG.Key("DATA");
	jsonAHG.StartObject();
	jsonAHG.Key("DEVICE_UNICAST_ID");
	jsonAHG.StartArray();
	jsonAHG.Int(DVUnicaseID);
	jsonAHG.EndArray();
	jsonAHG.Key("SRGBID");
	jsonAHG.Int(ModeRGB);
	jsonAHG.EndObject();
	jsonAHG.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

static void ControlButton(struct mosquitto *mosq, int DVUnicaseID, int AttID, int AttValue, int TypeDV)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> jsonAHG(sendToGW);
	jsonAHG.StartObject();
	jsonAHG.Key("CMD");
	jsonAHG.String("CONTROL_SWITCH");
	jsonAHG.Key("TYPE");
	jsonAHG.Int(TypeDV);
	jsonAHG.Key("DATA");
	jsonAHG.StartObject();
	jsonAHG.Key("DEVICE_UNICAST_ID");
	jsonAHG.Int(DVUnicaseID);
	jsonAHG.Key("SWITCH_STATUS");
	jsonAHG.StartObject();
	if (AttID == 11)
	{
		jsonAHG.Key("RELAY1");
	}
	if (AttID == 12)
	{
		jsonAHG.Key("RELAY2");
	}
	if (AttID == 13)
	{
		jsonAHG.Key("RELAY3");
	}
	if (AttID == 14)
	{
		jsonAHG.Key("RELAY4");
	}
	jsonAHG.Int(AttValue);
	jsonAHG.EndObject();
	jsonAHG.EndObject();
	jsonAHG.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

static void ControlActionTimePir(struct mosquitto *mosq, int DVUnicaseID, int ActionTime, int DeviceTypeId)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> jsonAHG(sendToGW);
	jsonAHG.StartObject();
	jsonAHG.Key("CMD");
	jsonAHG.String("TIME_ACTION_PIR");
	jsonAHG.Key("DATA");
	jsonAHG.StartObject();
	jsonAHG.Key("DEVICE_UNICAST_ID");
	jsonAHG.Int(DVUnicaseID);
	jsonAHG.Key("TYPE_DEV");
	jsonAHG.Int(DeviceTypeId);
	jsonAHG.Key("TIME");
	jsonAHG.Int(ActionTime);
	jsonAHG.EndObject();
	jsonAHG.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

void ControlSwitch(t_ControlSwitch TempControlSwitch)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("DEVICE_CONTROL");
	json.Key("TYPE_DEV");
	json.Int(TempControlSwitch.DeviceTypeId);
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(TempControlSwitch.DeviceUnicastId);
	json.Key("PROPERTIES");
	json.StartArray();
	if (TempControlSwitch.ButtonId != -1)
	{
		json.StartObject();
		json.Key("ID");
		json.Int(TempControlSwitch.ButtonId);
		json.Key("VALUE");
		json.Int(1);
		json.EndObject();
	}
	json.StartObject();
	json.Key("ID");
	json.Int(64);
	json.Key("VALUE");
	json.Int(TempControlSwitch.R);
	json.EndObject();
	json.StartObject();
	json.Key("ID");
	json.Int(65);
	json.Key("VALUE");
	json.Int(TempControlSwitch.G);
	json.EndObject();
	json.StartObject();
	json.Key("ID");
	json.Int(66);
	json.Key("VALUE");
	json.Int(TempControlSwitch.B);
	json.EndObject();
	json.StartObject();
	json.Key("ID");
	json.Int(67);
	json.Key("VALUE");
	json.Int(TempControlSwitch.DimOn);
	json.EndObject();
	json.StartObject();
	json.Key("ID");
	json.Int(68);
	json.Key("VALUE");
	json.Int(TempControlSwitch.DimOff);
	json.EndObject();
	json.EndArray();
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

void ControlModeActionPir(int DeviceUnicastId, int DeviceType, int Mode)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("MODE_ACTION_PIR");
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(DeviceUnicastId);
	json.Key("TYPE_DEV");
	json.Int(DeviceType);
	json.Key("MODE");
	json.Int(Mode);
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

void ControlSensorSensi(int DeviceUnicastId, int DeviceType, int Mode)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("SENSOR_SENSI");
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(DeviceUnicastId);
	json.Key("TYPE_DEV");
	json.Int(DeviceType);
	json.Key("VALUE");
	json.Int(Mode);
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

void ControlCountDownSwitch(int DeviceUnicastId, int DeviceType, int Time)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("SWITCH_COUNTDOWN");
	json.Key("TYPE_DEV");
	json.Int(DeviceType);
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(DeviceUnicastId);
	json.Key("STATUS");
	json.Int(0);
	json.Key("TIME");
	json.Int(Time);
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

void ControlDistance(int DeviceUnicastId, int Value)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("SET_DISTANCE_RADA");
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(DeviceUnicastId);
	json.Key("VALUE");
	json.Int(Value);
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

static void ControlAllButtonSwitch(int DeviceUnicastId, uint16_t DeviceType, int Value)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("DEVICE_CONTROL");
	json.Key("TYPE_DEV");
	json.Int(DeviceType);
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(DeviceUnicastId);
	json.Key("PROPERTIES");
	json.StartArray();
	json.StartObject();
	json.Key("ID");
	json.Int(65535);
	json.Key("VALUE");
	json.Int(1);
	json.EndObject();
	json.StartObject();
	json.Key("ID");
	json.Int(0);
	json.Key("VALUE");
	json.Int(Value);
	json.EndObject();
	json.EndArray();
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

static void ControlStartStatus(int DeviceUnicastId, int DeviceType, int Value)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("STATUS_STARTUP");
	json.Key("TYPE_DEV");
	json.Int(DeviceType);
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(DeviceUnicastId);
	json.Key("STATUS");
	json.Int(Value);
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

static void ControlModeInputSwitch(int DeviceUnicastId, int Value)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("MODE_INPUT_SWITCH_ONOFF");
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(DeviceUnicastId);
	json.Key("MODE");
	json.Int(Value);
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

static void ControlModeHeatLamp(int DeviceUnicastId, int Value)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("MODE_AIRCONDITIONLIGHT");
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(DeviceUnicastId);
	json.Key("MODE");
	json.Int(Value);
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

static void ControlHeatLamp(int DeviceUnicastId, int Value, int AttId)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("CONTROL_AIRCONDITIONLIGHT");
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(DeviceUnicastId);
	json.Key("OBJECT");
	int obj_temp = 0;
	switch (AttId)
	{
		case 142:
			obj_temp = 2;
		break;
		case 143:
			obj_temp = 3;
		break;
		case 144:
			obj_temp = 1;
		break;
	}
	json.Int(obj_temp);
	json.Key("STATUS");
	json.Int(Value);
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

static void SetTimeHeatLamp(int DeviceUnicastId, int Value, int AttId)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	string temp_cmd = "";
	switch (AttId)
	{
		case 145:
			temp_cmd = "TIMER_0FF_AIRCONDITIONLIGHT";
		break;
		case 146:
			temp_cmd = "TIMER_DRY_AIRCONDITIONLIGHT";
		break;
		case 147:
			temp_cmd = "PERIOD_DRY_AIRCONDITIONLIGHT";
		break;
	}
	json.String(const_cast<char *>(temp_cmd.c_str()));
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(DeviceUnicastId);
	string key = "TIME";
	if (AttId == 147)
	{
		key = "PERIOD";
	}
	json.Key(const_cast<char *>(key.c_str()));
	json.Int(Value);
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

void ControlDevice(struct mosquitto *mosq, char *jobj)
{
	int H, S, L;
	H = S = L = -1;
	t_ControlSwitch TempControlSwitch = {-1, -1, -1, -1, -1, -1};
	Document document;
	document.Parse(jobj);
	string Cmd = document["CMD"].GetString();
	if (document.HasMember("DATA"))
	{
		const Value &DATA = document["DATA"];
		if (DATA.HasMember("DEVICE_ID") && DATA.HasMember("PROPERTIES"))
		{
			if (DATA.HasMember("BUTTON_VALUE"))
			{
				TempControlSwitch.ButtonId = DATA["BUTTON_VALUE"].GetInt();
			}
			string DEVICE_ID = DATA["DEVICE_ID"].GetString();
			int TempDeviceTypeId = TempControlSwitch.DeviceTypeId = TYPE_DEVICE(DEVICE_ID);
			int DEVICE_UNICAST = 0;
			if (DATA.HasMember("DEVICE_UNICAST_ID"))
			{
				DEVICE_UNICAST = DATA["DEVICE_UNICAST_ID"].GetInt();
			}
			else
			{
				DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
			}
			if (DEVICE_UNICAST != 0)
			{
				const Value &PROPERTIES = DATA["PROPERTIES"];
				for (rapidjson::SizeType i = 0; i < PROPERTIES.Size(); i++)
				{
					const Value &a = PROPERTIES[i];
					if (a.HasMember("ID") && a.HasMember("VALUE"))
					{
						int ID = a["ID"].GetInt();
						int VALUE = a["VALUE"].GetInt();
						if ((ID == ATTRIBUTE_HUE) || (ID == ATTRIBUTE_SATURATION) || (ID == ATTRIBUTE_LIGHTNESS))
						{
							if (ID == ATTRIBUTE_HUE)
							{
								H = a["VALUE"].GetInt();
							}
							else if (ID == ATTRIBUTE_SATURATION)
							{
								S = a["VALUE"].GetInt();
							}
							else if (ID == ATTRIBUTE_LIGHTNESS)
							{
								L = a["VALUE"].GetInt();
							}
							if (H >= 0 && S >= 0 && L >= 0)
							{
								bool IsColor = false;
								if (DATA.HasMember("IS_COLOR"))
								{
									IsColor = true;
								}
								ControlHSL(mosq, DEVICE_UNICAST, H, S, L, IsColor);
								H = S = L = -1;
							}
						}
						else if ((ID == 64) || (ID == 65) || (ID == 66) || (ID == 67) || (ID == 68))
						{
							if (ID == 64)
							{
								TempControlSwitch.R = a["VALUE"].GetInt();
							}
							else if (ID == 65)
							{
								TempControlSwitch.G = a["VALUE"].GetInt();
							}
							else if (ID == 66)
							{
								TempControlSwitch.B = a["VALUE"].GetInt();
							}
							else if (ID == 67)
							{
								TempControlSwitch.DimOn = a["VALUE"].GetInt();
							}
							else if (ID == 68)
							{
								TempControlSwitch.DimOff = a["VALUE"].GetInt();
							}
							if (TempControlSwitch.R >= 0 && TempControlSwitch.G >= 0 && TempControlSwitch.B >= 0 && TempControlSwitch.DimOn >= 0 && TempControlSwitch.DimOff >= 0)
							{
								TempControlSwitch.DeviceUnicastId = DEVICE_UNICAST;
								ControlSwitch(TempControlSwitch);
							}
						}
						else if (ID == 23)
						{
							ControlModeRGB(mosq, DEVICE_UNICAST, VALUE);
						}
						else if (ID == 17)
						{
							ControlActionTimePir(mosq, DEVICE_UNICAST, VALUE, TempDeviceTypeId);
						}
						else if (ID == 12 || ID == 13 || ID == 14 || ID == 11)
						{
							ControlButton(mosq, DEVICE_UNICAST, ID, VALUE, TempDeviceTypeId);
						}
						else if (ID == 0 || ID == 1 || ID == 2)
						{
							SendDeviceToGW(mosq, DEVICE_UNICAST, ID, VALUE, true);
						}
						else if (ID == 54 || ID == 55 || ID == 56 || ID == 57 || ID == 63)
						{
							ControlCurtain(mosq, DEVICE_UNICAST, ID, VALUE, Cmd);
						}
						else if (ID == 70)
						{
							ControlModeActionPir(DEVICE_UNICAST, TempDeviceTypeId, VALUE);
						}
						else if (ID == 75)
						{
							ControlSensorSensi(DEVICE_UNICAST, TempDeviceTypeId, VALUE);
						}
						else if (ID == 25)
						{
							ControlCountDownSwitch(DEVICE_UNICAST, TempDeviceTypeId, VALUE);
						}
						else if (ID == 124)
						{
							ControlDistance(DEVICE_UNICAST, VALUE);
						}
						else if (ID == 136)
						{
							ControlAllButtonSwitch(DEVICE_UNICAST, TempDeviceTypeId, VALUE);
						}
						else if (ID == 76)
						{
							ControlStartStatus(DEVICE_UNICAST, TempDeviceTypeId, VALUE);
						}
						else if (ID == 125)
						{
							ControlModeInputSwitch(DEVICE_UNICAST, VALUE);
						}
						else if (ID == 141)
						{
							ControlModeHeatLamp(DEVICE_UNICAST, VALUE);
						}
						else if (ID == 142 || ID == 143 || ID == 144)
						{
							ControlHeatLamp(DEVICE_UNICAST, VALUE, ID);
						}
						else if (ID == 145 || ID == 146 || ID == 147)
						{
							SetTimeHeatLamp(DEVICE_UNICAST, VALUE, ID);
						}
					}
				}
				if (TempControlSwitch.R < 0 && TempControlSwitch.G < 0 && TempControlSwitch.B < 0 && TempControlSwitch.DimOn >= 0 && TempControlSwitch.DimOff >= 0)
				{
					TempControlSwitch.DeviceUnicastId = DEVICE_UNICAST;
					ControlSwitch(TempControlSwitch);
				}
			}
		}
	}
}

void DeviceUpdateValue(struct mosquitto *mosq)
{
	bool FlagCheckLock = false;
	while (FlagCheckLock == false)
	{
		if (pthread_mutex_trylock(&mutexUpdateDvValue) == 0)
		{
			StringBuffer sendToGW;
			Writer<StringBuffer> jsonAHG(sendToGW);
			jsonAHG.StartObject();
			jsonAHG.Key("CMD");
			jsonAHG.String("DEVICE_UPDATE");
			jsonAHG.Key("DATA");
			jsonAHG.StartArray();
			for (int i = 0; i < T_Device.size(); i++)
			{
				if (T_Device[i].AttDevice[0] > 0)
				{
					jsonAHG.StartObject();
					jsonAHG.Key("DEVICE_ID");
					string DeviceId = T_Device[i].DeviceUUID;
					jsonAHG.String(const_cast<char *>(DeviceId.c_str()));
					jsonAHG.Key("DEVICE_UNICAST_ID");
					jsonAHG.Int(T_Device[i].DeviceUnicastID);
					jsonAHG.Key("PROPERTIES");
					jsonAHG.StartArray();
					TimeStamp = 0;
					string sql = "SELECT UpdateTime FROM DeviceAttributeValue WHERE DeviceUnicastId = " + to_string(T_Device[i].DeviceUnicastID) + " AND UpdateTime NOTNULL ORDER BY UpdateTime DESC LIMIT 1;";
					DB_Read("TIMESTAMP", sql);
					if (TimeStamp > 0)
					{
						jsonAHG.StartObject();
						jsonAHG.Key("ID");
						jsonAHG.Int(165);
						jsonAHG.Key("VALUE");
						jsonAHG.Int64(TimeStamp);
						jsonAHG.EndObject();
					}
					for (int j = 1; j <= T_Device[i].AttDevice[0] / 2; j++)
					{
						jsonAHG.StartObject();
						jsonAHG.Key("ID");
						int id = T_Device[i].AttDevice[j * 2 - 1];
						jsonAHG.Int(id);
						jsonAHG.Key("VALUE");
						jsonAHG.Int(T_Device[i].AttDevice[j * 2]);
						jsonAHG.EndObject();
					}					
					jsonAHG.EndArray();
					jsonAHG.EndObject();
				}
			}
			jsonAHG.EndArray();
			jsonAHG.EndObject();

			string s = sendToGW.GetString();
			cout << s << endl;
			MqttSendAPP(mosq, const_cast<char *>(s.c_str()), false);
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutexUpdateDvValue);
			break;
		}
		usleep(3000);
	}
}

void DeviceUpdateStatus(struct mosquitto *mosq)
{
	bool FlagCheckLock = false;
	while (FlagCheckLock == false)
	{
		if (pthread_mutex_trylock(&mutexDvOnline) == 0)
		{
			if (T_DeviceCheckOnline.size())
			{
				// cout << T_DeviceCheckOnline.size() << endl;
				StringBuffer sendToApp;
				Writer<StringBuffer> json(sendToApp);
				json.StartObject();
				json.Key("CMD");
				json.String("DEVICE_UPDATE");
				json.Key("DATA");
				json.StartArray();
				for (int i = 0; i < T_DeviceCheckOnline.size(); i++)
				{
					json.StartObject();
					string DeviceId = T_DeviceCheckOnline[i].DeviceUUID;
					json.Key("DEVICE_ID");
					json.String(const_cast<char *>(DeviceId.c_str()));
					json.Key("PROPERTIES");
					json.StartArray();
					json.StartObject();
					json.Key("ID");
					json.Int(62);
					json.Key("VALUE");
					json.Int(T_DeviceCheckOnline[i].CurrentStatus);
					json.EndObject();
					json.EndArray();
					json.EndObject();
				}
				json.EndArray();
				json.EndObject();
				string s = sendToApp.GetString();
				cout << s << endl;
				MqttSendAPP(mosq, const_cast<char *>(s.c_str()), false);
				FlagCheckLock = true;
			}
			pthread_mutex_unlock(&mutexDvOnline);
			break;
		}
		usleep(3000);
	}
}

void ControlGroup(struct mosquitto *mosq, char *jobj)
{
	int H = -1;
	int S = -1;
	int L = -1;
	Document document;
	document.Parse(jobj);
	const Value &DATA = document["DATA"];
	if (DATA.HasMember("GROUP_ID") && DATA.HasMember("PROPERTIES"))
	{
		string GROUP_ID = DATA["GROUP_ID"].GetString();
		int GROUP_UNICAST;
		if (DATA.HasMember("GROUP_UNICAST_ID"))
		{
			GROUP_UNICAST = DATA["GROUP_UNICAST_ID"].GetInt();
		}
		else
		{
			GROUP_UNICAST = GROUP_UNICAST_ID(GROUP_ID);
		}
		const Value &PROPERTIES = DATA["PROPERTIES"];
		for (rapidjson::SizeType i = 0; i < PROPERTIES.Size(); i++)
		{
			const Value &a = PROPERTIES[i];

			if (a.HasMember("ID") && a.HasMember("VALUE"))
			{
				int ID = a["ID"].GetInt();
				int VALUE = a["VALUE"].GetInt();
				if ((ID == ATTRIBUTE_HUE) || (ID == ATTRIBUTE_SATURATION) || (ID == ATTRIBUTE_LIGHTNESS))
				{
					if (ID == ATTRIBUTE_HUE)
					{
						H = a["VALUE"].GetInt();
					}
					else if (ID == ATTRIBUTE_SATURATION)
					{
						S = a["VALUE"].GetInt();
					}
					else if (ID == ATTRIBUTE_LIGHTNESS)
					{
						L = a["VALUE"].GetInt();
					}
					if (H >= 0 && S >= 0 && L >= 0)
					{
						bool IsColor = false;
						if (DATA.HasMember("IS_COLOR"))
						{
							IdxDv = 0;
							string GET_DV_INFO = "SELECT DeviceId, DeviceUnicastId FROM GroupingDeviceMapping WHERE GroupingId = '" + GROUP_ID + "'; ";
							DB_Read("GET_DV_INFO", GET_DV_INFO);
							int NumDv = IdxDv;
							for (int j = 0; j < NumDv; j++)
							{
								QueueMsgRSP(DvUnicastIdInfo[j], 5, L, 1);
							}
						}
						ControlHSL(mosq, GROUP_UNICAST, H, S, L, IsColor);
						H = -1;
						S = -1;
						L = -1;
					}
				}
				else if (ID == 23)
				{
					ControlModeRGB(mosq, GROUP_UNICAST, VALUE);
				}
				else if (ID == 0 || ID == 1 || ID == 2)
				{
					SendDeviceToGW(mosq, GROUP_UNICAST, ID, VALUE, true);
				}
			}
		}
	}
}

static void SapxepSceneDelay(int IndexSapxep)
{
	int TempIndex = IndexSceneDaleyCurrent + IndexSapxep + 1;
	if (TempIndex > SIZE_SCENE_DELAY - 1)
	{
		TempIndex = TempIndex - SIZE_SCENE_DELAY;
	}
	int TempIndexNext = TempIndex + 1;
	if (TempIndexNext > SIZE_SCENE_DELAY - 1)
	{
		TempIndexNext = TempIndexNext - SIZE_SCENE_DELAY;
	}
	for (int k = 0; k < SIZE_SCENE_DELAY; k++)
	{
		ArrSceneDelay[TempIndexNext][0] = ArrSceneDelay[TempIndex][0];
		ArrSceneDelay[TempIndexNext][1] = ArrSceneDelay[TempIndex][1];
		ArrSceneDelay[TempIndexNext][2] = ArrSceneDelay[TempIndex][2];
		ArrSceneDelay[TempIndexNext][3] = ArrSceneDelay[TempIndex][3];
		ArrSceneDelay[TempIndexNext][4] = ArrSceneDelay[TempIndex][4];
		ArrSceneDelay[TempIndexNext][5] = ArrSceneDelay[TempIndex][5];
	}
}

static void GetDvSceneDelay(string SceneId)
{
	IndexSceneDelay = 0;
	string CheckSceneDelay = "SELECT DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time FROM EventTriggerOutputDeviceSetupValue"
							 " WHERE EventTriggerId = '" +
							 SceneId + "' ORDER BY Time ASC, DeviceUnicastId ASC, DeviceAttributeId DESC;";
	// cout << CheckSceneDelay << endl;
	DB_Read("CHECK_SCENE_DELAY", CheckSceneDelay);
	for (int i = 0; i < IndexSceneDelay; i++)
	{
		//		ArrInfoDvSceneDelay[i][3] += GetSecondTimeNow()+1;
		ArrInfoDvSceneDelay[i][3] += GetSecondTimeNow();
		if (ArrInfoDvSceneDelay[i][3] > 86400)
		{
			ArrInfoDvSceneDelay[i][3] = ArrInfoDvSceneDelay[i][3] - 86400;
		}
		cout << ArrInfoDvSceneDelay[i][3] << endl;
		int TypeUnicast = 0;
		if (ArrInfoDvSceneDelay[i][0] > 49152)
		{
			TypeUnicast = 2;
		}
		else
		{
			TypeUnicast = 1;
		}
		bool FlagCheckLock = false;
		while (FlagCheckLock == false)
		{
			if (pthread_mutex_trylock(&mutexSceneDelay) == 0)
			{
				FlagCheckSceneDelay = true;
				for (int j = 0; j < SIZE_SCENE_DELAY; j++)
				{
					int TempIndex = -1;
					TempIndex = IndexSceneDaleyCurrent + j + 1;
					if (TempIndex >= SIZE_SCENE_DELAY)
					{
						TempIndex = TempIndex - SIZE_SCENE_DELAY;
					}
					if (ArrInfoDvSceneDelay[i][3] < ArrSceneDelay[TempIndex][4])
					{
						SapxepSceneDelay(j);
						ArrSceneDelay[TempIndex][0] = TypeUnicast;
						ArrSceneDelay[TempIndex][1] = ArrInfoDvSceneDelay[i][0];
						ArrSceneDelay[TempIndex][2] = ArrInfoDvSceneDelay[i][1];
						ArrSceneDelay[TempIndex][3] = ArrInfoDvSceneDelay[i][2];
						ArrSceneDelay[TempIndex][4] = ArrInfoDvSceneDelay[i][3];
						ArrSceneDelay[TempIndex][5] = 1;
						break;
					}
					else if (ArrSceneDelay[TempIndex][4] == -1)
					{
						// cout << TempIndex << endl;
						ArrSceneDelay[TempIndex][0] = TypeUnicast;
						ArrSceneDelay[TempIndex][1] = ArrInfoDvSceneDelay[i][0];
						ArrSceneDelay[TempIndex][2] = ArrInfoDvSceneDelay[i][1];
						ArrSceneDelay[TempIndex][3] = ArrInfoDvSceneDelay[i][2];
						ArrSceneDelay[TempIndex][4] = ArrInfoDvSceneDelay[i][3];
						ArrSceneDelay[TempIndex][5] = 1;
						break;
					}
				}
				for (int k = 0; k < SIZE_SCENE_DELAY; k++)
				{
					if (ArrSceneDelay[k][0] == -1)
					{
						break;
					}
					for (int m = 0; m < 6; m++)
					{
						// cout << ArrSceneDelay[k][m] << " -- ";
					}
					// cout << endl;
				}
				FlagCheckLock = true;
				pthread_mutex_unlock(&mutexSceneDelay);
				break;
			}
			usleep(3000);
		}
	}
}

static void GetGrSceneDelay(string SceneId)
{
	IndexSceneDelay = 0;
	string CheckSceneDelay = "SELECT GroupUnicastId, DeviceAttributeId, DeviceAttributeValue, Time FROM EventTriggerOutputGroupingSetupValue"
							 " WHERE EventTriggerId = '" +
							 SceneId + "' ORDER BY Time ASC, GroupUnicastId ASC, DeviceAttributeId DESC;";
	// cout << CheckSceneDelay << endl;
	DB_Read("CHECK_SCENE_DELAY", CheckSceneDelay);
	for (int i = 0; i < IndexSceneDelay; i++)
	{
		//		ArrInfoDvSceneDelay[i][3] += GetSecondTimeNow()+1;
		ArrInfoDvSceneDelay[i][3] += GetSecondTimeNow();
		if (ArrInfoDvSceneDelay[i][3] > 86400)
		{
			ArrInfoDvSceneDelay[i][3] = ArrInfoDvSceneDelay[i][3] - 86400;
		}
		// cout << ArrInfoDvSceneDelay[i][3] << endl;
		int TypeUnicast = 0;
		if (ArrInfoDvSceneDelay[i][0] > 49152)
		{
			TypeUnicast = 2;
		}
		else
		{
			TypeUnicast = 1;
		}
		bool FlagCheckLock = false;
		while (FlagCheckLock == false)
		{
			if (pthread_mutex_trylock(&mutexSceneDelay) == 0)
			{
				FlagCheckSceneDelay = true;
				for (int j = 0; j < SIZE_SCENE_DELAY; j++)
				{
					int TempIndex = -1;
					TempIndex = IndexSceneDaleyCurrent + j + 1;
					if (TempIndex >= SIZE_SCENE_DELAY)
					{
						TempIndex = TempIndex - SIZE_SCENE_DELAY;
					}
					if (ArrInfoDvSceneDelay[i][3] < ArrSceneDelay[TempIndex][4])
					{
						SapxepSceneDelay(j);
						ArrSceneDelay[TempIndex][0] = TypeUnicast;
						ArrSceneDelay[TempIndex][1] = ArrInfoDvSceneDelay[i][0];
						ArrSceneDelay[TempIndex][2] = ArrInfoDvSceneDelay[i][1];
						ArrSceneDelay[TempIndex][3] = ArrInfoDvSceneDelay[i][2];
						ArrSceneDelay[TempIndex][4] = ArrInfoDvSceneDelay[i][3];
						ArrSceneDelay[TempIndex][5] = 1;
						break;
					}
					else if (ArrSceneDelay[TempIndex][4] == -1)
					{
						// cout << TempIndex << endl;
						ArrSceneDelay[TempIndex][0] = TypeUnicast;
						ArrSceneDelay[TempIndex][1] = ArrInfoDvSceneDelay[i][0];
						ArrSceneDelay[TempIndex][2] = ArrInfoDvSceneDelay[i][1];
						ArrSceneDelay[TempIndex][3] = ArrInfoDvSceneDelay[i][2];
						ArrSceneDelay[TempIndex][4] = ArrInfoDvSceneDelay[i][3];
						ArrSceneDelay[TempIndex][5] = 1;
						break;
					}
				}
				for (int k = 0; k < SIZE_SCENE_DELAY; k++)
				{
					if (ArrSceneDelay[k][0] == -1)
					{
						break;
					}
					for (int m = 0; m < 6; m++)
					{
						cout << ArrSceneDelay[k][m];
					}
					cout << endl;
				}
				FlagCheckLock = true;
				pthread_mutex_unlock(&mutexSceneDelay);
				break;
			}
			usleep(3000);
		}
	}
}

#if REMOVE_ARR_SCENE_DELAY
static void InitArr()
{
	bool FlagCheckLock = false;
	while (FlagCheckLock == false)
	{
		if (pthread_mutex_trylock(&mutexSceneDelay) == 0)
		{
			for (int k = 0; k < SIZE_SCENE_DELAY; k++)
			{
				for (int m = 0; m < 6; m++)
				{
					ArrSceneDelay[k][m] = -1;
				}
				cout << endl;
			}
			IndexSceneDaleyCurrent = 0;
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutexSceneDelay);
			break;
		}
		usleep(3000);
	}
}
#endif

void CallScene(struct mosquitto *mosq, char *jobj)
{
	Document document;
	document.Parse(jobj);
	const Value &DATA = document["DATA"];
	if (DATA.HasMember("SCENE_ID"))
	{
		string SCENE_ID = DATA["SCENE_ID"].GetString();
		ADR = -1;
		string CheckTypeScene = "SELECT EventTriggerTypeId FROM EventTrigger WHERE EventTriggerId = '" + SCENE_ID + "' AND EventTriggerTypeId IS NOT NULL;";
		// cout << CheckTypeScene << endl;
		DB_Read("ADR", CheckTypeScene);
		int TypeScene = ADR;
		if (TypeScene != 10 && TypeScene != 2)
		{
			int SCENE_UNICAST = 0;
			if (DATA.HasMember("SCENE_UNICAST_ID"))
			{
				SCENE_UNICAST = DATA["SCENE_UNICAST_ID"].GetInt();
			}
			else
			{
				SCENE_UNICAST = SCENE_UNICAST_ID(SCENE_ID);
			}
			StringBuffer sendToGW;
			Writer<StringBuffer> jsonAHG(sendToGW);
			jsonAHG.StartObject();
			jsonAHG.Key("CMD");
			jsonAHG.String("CALLSCENE");
			jsonAHG.Key("DATA");
			jsonAHG.StartObject();
			jsonAHG.Key("SCENEID");
			jsonAHG.Int(SCENE_UNICAST);
			jsonAHG.EndObject();
			jsonAHG.EndObject();
			string s = sendToGW.GetString();
			cout << s << endl;
			MqttSend(mosq, const_cast<char *>(s.c_str()));
			if (TypeScene == 1)
			{
				string EditScene = "UPDATE EventTrigger SET EventTriggerTypeId = 3 WHERE EventTriggerId = '" + SCENE_ID + "';";
				DB_Write(EditScene);
			}
		}
		if (TypeScene == 10)
		{
#if REMOVE_ARR_SCENE_DELAY
			InitArr();
#endif
			GetDvSceneDelay(SCENE_ID);
			GetGrSceneDelay(SCENE_ID);
		}
	}
}

void FlashDevice(struct mosquitto *mosq, char *jobj)
{
	Document document;
	document.Parse(jobj);
	const Value &DATA = document["DATA"];
	if (DATA.HasMember("DEVICE_ID"))
	{
		string DEVICE_ID = DATA["DEVICE_ID"].GetString();
		int DEVICE_UNICAST = 0;
		if (DATA.HasMember("DEVICE_UNICAST_ID"))
		{
			DEVICE_UNICAST = DATA["DEVICE_UNICAST_ID"].GetInt();
		}
		else
		{
			DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
		}

		bool FlagCheckLock = false;
		while (FlagCheckLock == false)
		{
			if (pthread_mutex_trylock(&mutexUpdateDvValue) == 0)
			{
				int IndexDevice = -1;
				IndexDevice = SearchDeviceUpdateValue(DEVICE_UNICAST);
				for (int i = 1; i <= (T_Device[IndexDevice].AttDevice[0] / 2); i++)
				{
					if (T_Device[IndexDevice].AttDevice[i * 2 - 1] == 0)
					{
						int Value = T_Device[IndexDevice].AttDevice[i * 2];
						StringBuffer sendToGW;
						Writer<StringBuffer> jsonAHG(sendToGW);
						jsonAHG.StartObject();
						jsonAHG.Key("CMD");
						jsonAHG.String("ONOFF");
						jsonAHG.Key("TIME");
						jsonAHG.Int(0);
						jsonAHG.Key("DATA");
						jsonAHG.StartObject();
						jsonAHG.Key("DEVICE_UNICAST_ID");
						jsonAHG.Int(DEVICE_UNICAST);
						if (Value == 1)
						{
							jsonAHG.Key("VALUE_ONOFF");
							jsonAHG.Int(0);
						}
						else if (Value == 0)
						{
							jsonAHG.Key("VALUE_ONOFF");
							jsonAHG.Int(1);
						}
						jsonAHG.EndObject();
						jsonAHG.EndObject();
						string s = sendToGW.GetString();
						MqttSend(mosq, const_cast<char *>(s.c_str()));
						break;
					}
				}
				FlagCheckLock = true;
				pthread_mutex_unlock(&mutexUpdateDvValue);
			}
			usleep(3000);
		}
	}
}

void DeviceUpdate(struct mosquitto *mosq, char *jobj)
{
	DeviceUpdateValue(mosq);
	DeviceUpdateStatus(mosq);
}

void TapToRun(struct mosquitto *mosq, char *jobj)
{
	MqttSendGW2Logic(mosq, jobj);
}

void ControlColorSwitchRGB(int TempDeviceUnicastId, int TempTypeDevice, int TempH, int TempS, int TempL)
{
	// cout << "gui cho GW" << endl;
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("DEVICE_CONTROL");
	json.Key("TYPE_DEV");
	json.Int(TempTypeDevice);
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(TempDeviceUnicastId);
	json.Key("PROPERTIES");
	json.StartArray();
	json.StartObject();
	json.Key("ID");
	json.Int(3);
	json.Key("VALUE");
	json.Int(TempH);
	json.EndObject();
	json.StartObject();
	json.Key("ID");
	json.Int(4);
	json.Key("VALUE");
	json.Int(TempS);
	json.EndObject();
	json.StartObject();
	json.Key("ID");
	json.Int(5);
	json.Key("VALUE");
	json.Int(TempL);
	json.EndObject();
	json.EndArray();
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	cout << s << endl;
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

void ControlSwitchDevice(struct mosquitto *mosq, char *jobj)
{
	int TempDeviceUnicastId = -1;
	int TempH = -1;
	int TempS = -1;
	int TempL = -1;
	int TempOnOff = -1;
	Document document;
	document.Parse(jobj);
	const Value &DATA = document["DATA"];
	if (DATA.HasMember("DEVICE_ID"))
	{
		string TempDeviceId = DATA["DEVICE_ID"].GetString();
		const Value &LIST_BUTTON = DATA["LIST_BUTTON"];
		for (rapidjson::SizeType i = 0; i < LIST_BUTTON.Size(); i++)
		{
			int TempTypeDevice = TYPE_DEVICE(TempDeviceId);
			int ButtonId = LIST_BUTTON[i]["BUTTON_ID"].GetInt();
			if (ButtonId != 11)
			{
				TempDeviceId = to_string(ButtonId) + "-" + TempDeviceId;
				TempDeviceUnicastId = DEVICE_UNICAST_ID(TempDeviceId);
			}
			else
			{
				TempDeviceUnicastId = DEVICE_UNICAST_ID(TempDeviceId);
			}
			const Value &PROPERTIES = LIST_BUTTON[i]["PROPERTIES"];
			for (rapidjson::SizeType j = 0; j < PROPERTIES.Size(); j++)
			{
				if (PROPERTIES[j].HasMember("ID") && PROPERTIES[j].HasMember("VALUE"))
				{
					int TempId = PROPERTIES[j]["ID"].GetInt();
					int TempValue = PROPERTIES[j]["VALUE"].GetInt();
					if (TempId == 0)
					{
						TempOnOff = TempValue;
						SendDeviceToGW(mosq, TempDeviceUnicastId, TempId, TempOnOff, true);
					}
					else if (TempId == 3)
					{
						TempH = TempValue;
					}
					else if (TempId == 4)
					{
						TempS = TempValue;
					}
					else if (TempId == 5)
					{
						TempL = TempValue;
					}
				}
			}
			if (TempH >= 0 && TempS >= 0 && TempL >= 0)
			{
				ControlColorSwitchRGB(TempDeviceUnicastId, TempTypeDevice, TempH, TempS, TempL);
			}
		}
	}
}

static void AddDeviceIntoArrDelay(int deviceUnicatsId, int attId, int attValue, int timeDelay)
{
	bool FlagCheckLock = false;
	timeDelay += GetSecondTimeNow();
	if (timeDelay > 86400)
	{
		timeDelay = timeDelay - 86400;
	}
	while (FlagCheckLock == false)
	{
		if (pthread_mutex_trylock(&mutexSceneDelay) == 0)
		{
			FlagCheckSceneDelay = true;
			for (int j = 0; j < SIZE_SCENE_DELAY; j++)
			{
				int TempIndex = -1;
				TempIndex = IndexSceneDaleyCurrent + j + 1;
				if (TempIndex >= SIZE_SCENE_DELAY)
				{
					TempIndex = TempIndex - SIZE_SCENE_DELAY;
				}
				if (timeDelay < ArrSceneDelay[TempIndex][4])
				{
					SapxepSceneDelay(j);
					ArrSceneDelay[TempIndex][0] = 1;
					ArrSceneDelay[TempIndex][1] = deviceUnicatsId;
					ArrSceneDelay[TempIndex][2] = attId;
					ArrSceneDelay[TempIndex][3] = attValue;
					ArrSceneDelay[TempIndex][4] = timeDelay;
					ArrSceneDelay[TempIndex][5] = 1;
					break;
				}
				else if (ArrSceneDelay[TempIndex][4] == -1)
				{
					ArrSceneDelay[TempIndex][0] = 1;
					ArrSceneDelay[TempIndex][1] = deviceUnicatsId;
					ArrSceneDelay[TempIndex][2] = attId;
					ArrSceneDelay[TempIndex][3] = attValue;
					ArrSceneDelay[TempIndex][4] = timeDelay;
					ArrSceneDelay[TempIndex][5] = 1;
					break;
				}
			}
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutexSceneDelay);
			break;
		}
		usleep(300);
	}
}

void ActionRule(struct mosquitto *mosq, char *jobj)
{
	Document document;
	document.Parse(jobj);
	const Value &DATA = document["DATA"];
	if (DATA.HasMember("OUTPUT") && DATA["OUTPUT"].IsArray())
	{
		const Value &listHc = DATA["OUTPUT"];
		for (rapidjson::SizeType i = 0; i < listHc.Size(); i++)
		{
			const Value &tempHc = listHc[i];
			if (tempHc.HasMember("HcMac") && tempHc["HcMac"].IsString())
			{
				string tempMacHc = tempHc["HcMac"].GetString();
				if (tempMacHc == macHC)
				{
					int delayTime = 0;
					if (tempHc.HasMember("DeviceOutput") && tempHc["DeviceOutput"].IsArray())
					{
						for (rapidjson::SizeType j = 0; j < tempHc["DeviceOutput"].Size(); j++)
						{
							const Value &tempDevice = tempHc["DeviceOutput"][j];
							if (tempDevice.HasMember("OutputDeviceId") && tempDevice["OutputDeviceId"].IsString() &&
									tempDevice.HasMember("DeviceAttributeId") && tempDevice["DeviceAttributeId"].IsInt() &&
									tempDevice.HasMember("DeviceAttributeValue") && tempDevice["DeviceAttributeValue"].IsInt())
							{
								string deviceId = tempDevice["OutputDeviceId"].GetString();
								int deviceUnicastId = DEVICE_UNICAST_ID(deviceId);
								if (deviceUnicastId != 0)
								{
									int deviceAttributeId = tempDevice["DeviceAttributeId"].GetInt();
									if (deviceAttributeId >= 11 && deviceAttributeId <= 16)
									{										
										deviceUnicastId = deviceUnicastId + deviceAttributeId - 11;
										deviceAttributeId = 0;
									}
									int deviceAttributeValue = tempDevice["DeviceAttributeValue"].GetInt();
									if (tempDevice.HasMember("DelayTime") && tempDevice["DelayTime"].IsInt())
									{
										int tempDelay = tempDevice["DelayTime"].GetInt();
										delayTime += tempDelay;
									}
									AddDeviceIntoArrDelay(deviceUnicastId, deviceAttributeId, deviceAttributeValue, delayTime);
								}
							}							
						}
					}
					if (tempHc.HasMember("SceneOutput") && tempHc["SceneOutput"].IsArray())
					{
						for (rapidjson::SizeType j = 0; j < tempHc["SceneOutput"].Size(); j++)
						{
							const Value &tempScene = tempHc["SceneOutput"][j];
							if (tempScene.HasMember("OutputSceneId") && tempScene["OutputSceneId"].IsString())
							{
								string sceneId = tempScene["OutputSceneId"].GetString();
								int sceneUnicastId = SCENE_UNICAST_ID(sceneId);
								if (sceneUnicastId != 0)
								{
									if (tempScene.HasMember("DelayTime") && tempScene["DelayTime"].IsInt())
									{
										int tempDelay = tempScene["DelayTime"].GetInt();
										delayTime += tempDelay;
										ADR = -1;
										string CheckTypeScene = "SELECT EventTriggerTypeId FROM EventTrigger WHERE EventTriggerId = '" + sceneId + "' AND EventTriggerTypeId IS NOT NULL;";
										DB_Read("ADR", CheckTypeScene);
										int TypeScene = ADR;
										if(TypeScene == 10){
											GetDvSceneDelay(sceneId, delayTime);
											GetGrSceneDelay(sceneId, delayTime);
										}
										else
										{
											AddSceneIntoArrCallScene(sceneUnicastId, delayTime);
										}
									}
								}
							}							
						}
					}
				}
			}
		}
	}
}
