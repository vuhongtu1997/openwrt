/*
 * AHG_CONFIG_SCENE_CURTAIN.cpp
 *
 *  Created on: Mar 15, 2022
 *      Author: rd
 */

#include "AHG_CONFIG_SCENE_CURTAIN.hpp"

void CreateSceneForCurtain(struct mosquitto *mosq, char* jobj){

}

void DelSceneForCurtain(struct mosquitto *mosq, char* jobj){

}
