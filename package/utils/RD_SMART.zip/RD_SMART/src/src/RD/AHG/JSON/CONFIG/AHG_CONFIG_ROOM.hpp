/*
 * AHG_CONFIG_ROOM.hpp
 *
 *  Created on: Dec 23, 2021
 *      Author: rd
 */

#ifndef SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_ROOM_HPP_
#define SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_ROOM_HPP_

#include "../JSON_AHG.hpp"
#include "AHG_CONFIG_GROUP.hpp"
#include "../../../ShareData.hpp"

using namespace std;

//ROOM
void CreateRoom(struct mosquitto *mosq, char* jobj);
void AddDeviceToRoom(struct mosquitto *mosq, char* jobj);
void DelDeviceFromRoom(struct mosquitto *mosq, char* jobj);
void DelRoom(struct mosquitto *mosq, char* jobj);
void CheckRoom(struct mosquitto *mosq, char* jobj);

void AddDeviceSmartHomeToRoom(struct mosquitto *mosq, char* jobj);

#endif /* SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_ROOM_HPP_ */
