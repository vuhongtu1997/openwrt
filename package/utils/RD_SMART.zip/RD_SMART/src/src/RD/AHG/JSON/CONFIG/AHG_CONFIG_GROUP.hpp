/*
 * AHG_CONFIG_GROUP.hpp
 *
 *  Created on: Mar 17, 2022
 *      Author: rd
 */

#ifndef SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_GROUP_HPP_
#define SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_GROUP_HPP_

#include "../JSON_AHG.hpp"

void CreateGroup(struct mosquitto *mosq, char* jobj);
void AddDeviceGroup(struct mosquitto *mosq, char* jobj);
void DelDeviceGroup(struct mosquitto *mosq, char* jobj);
void DelGroup(struct mosquitto *mosq, char* jobj);
void AddDeviceToGroup(struct mosquitto *mosq, int DeviceUnicastId, int GroupUnicastId, int ElementUnicastId);
void DelDeviceFromGroup(struct mosquitto *mosq, int DeviceUnicatId, int GroupUnicastId, int ElementUnicastId);

#endif /* SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_GROUP_HPP_ */
