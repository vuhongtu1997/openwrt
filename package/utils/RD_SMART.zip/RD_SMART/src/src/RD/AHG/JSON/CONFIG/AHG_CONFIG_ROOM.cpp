/*
 * AHG_CONFIG_ROOM.cpp
 *
 *  Created on: Dec 23, 2021
 *      Author: rd
 */

#include <iostream>
#include "AHG_CONFIG_ROOM.hpp"

void MqttSendGW(string s){
	MqttSend(mosq, const_cast<char*>(s.c_str()));
}

static void ControlRGBBeforAddScene(int DeviceUnicastId, int H, int S, int L){
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");json.String("HSL");
	json.Key("ACK");json.Bool(false);
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");json.Int(DeviceUnicastId);
	json.Key("VALUE_H");json.Int(H);
	json.Key("VALUE_S");json.Int(S);
	json.Key("VALUE_L");json.Int(L);
	json.EndObject();
	json.EndObject();
	MqttSendGW(sendToGW.GetString());
	usleep(200000);
	MqttSendGW(sendToGW.GetString());
}

static void ControlModeRGBBeforAddScene(int DeviceUnicastId, int ModeRGB){
	StringBuffer sendToGW;
	Writer<StringBuffer> jsonAHG(sendToGW);
	jsonAHG.StartObject();
	jsonAHG.Key("CMD");jsonAHG.String("CALLMODE_RGB");
	jsonAHG.Key("DATA");
	jsonAHG.StartObject();
	jsonAHG.Key("DEVICE_UNICAST_ID");
	jsonAHG.StartArray();
	jsonAHG.Int(DeviceUnicastId);
	jsonAHG.EndArray();
	jsonAHG.Key("SRGBID");jsonAHG.Int(ModeRGB);
	jsonAHG.EndObject();
	jsonAHG.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char*>(s.c_str()));
}

static void SendDVAddRoom(int DVUnicast, int SceneUnicast, int RoomUnicast)
{
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("ADD_DEV_TO_ROOM");
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(DVUnicast);
	json.Key("GROUP_ID");
	json.Int(RoomUnicast);
	json.Key("SCENE_ID");
	json.Int(SceneUnicast);
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	cout << s << endl;
	MqttSend(mosq, const_cast<char *>(s.c_str()));
}

void CreateRoom(struct mosquitto *mosq, char* jobj){
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutex) == 0){
			if(IsProcessDone == false){
				ResetDataRoom();
				IsProcessRoom = CREATE_ROOM;
				FlagCheckLock = true;
			}
			pthread_mutex_unlock(&mutex);
		}
		usleep (3000);
	}
	MqttSend(mosq, "{\"CMD\":\"START_PROCESS_ROOM\"}");
	Document document;
	document.Parse(jobj);
	bool FlagCheckDvIntoRoom = false;
	const Value& DATA = document["DATA"];
	string ROOM_ID = "";
	int RoomUnicastId = 0;
	if(DATA.HasMember("GROUPS")){
		const Value& GROUPS = DATA["GROUPS"];
		for (rapidjson::SizeType i = 0; i < GROUPS.Size(); i++){
			const Value& a = GROUPS[i];
			if(a.HasMember("GROUP_ID")){
				int DEVICE_TYPE_ID;
				string NAME = "";
				string GROUP_ID = a["GROUP_ID"].GetString();
				if(a.HasMember("DEVICE_TYPE_ID") && a.HasMember("NAME")){
					DEVICE_TYPE_ID = a["DEVICE_TYPE_ID"].GetInt();
					NAME = a["NAME"].GetString();
				}
				if(i == 0){
					ROOM_ID = GROUP_ID;
					RoomUnicastId = GetNextRoomId();
					string creRoom = "INSERT OR REPLACE INTO QueueMsgRsp (RqId, Msg) values ('"+ GROUP_ID +"', '1'); ";
					DB_Write( creRoom);
				}
				//ADD DEVICE TO GROUP
				int GroupUnicastId = RoomUnicastId + BleTypeToGroupId(DEVICE_TYPE_ID) + ID_START;
				string creGroup = "INSERT OR REPLACE INTO GROUPING (GroupingId, GroupUnicastId, Name, CategoryId, RoomId)"
						" values ('"+ GROUP_ID + "', "+ to_string(GroupUnicastId) + ", '"+ NAME + "', "+ to_string(DEVICE_TYPE_ID) +", '"+ROOM_ID+"'); ";
				DB_Write( creGroup);
				if(a.HasMember("DEVICES") && a["DEVICES"].Size() > 0){
					FlagCheckDvIntoRoom = true;
					const Value& DEVICES = a["DEVICES"];
					for (rapidjson::SizeType j = 0; j < DEVICES.Size(); j++){
						const Value& b = DEVICES[j];
						string DEVICE_ID = b.GetString();
						int DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
						int DeviceType = TYPE_DEVICE(DEVICE_ID)/10000;
						float DeviceVersion = GetDeviceVersion(DEVICE_ID);
						if(DEVICE_UNICAST != 0){
							string addDeviceGr = "INSERT OR REPLACE INTO GroupingDeviceMapping (GroupUnicastId, GroupingId, DeviceId, DeviceUnicastId, IsSuccess)"
									" values ("+ to_string(GroupUnicastId) + ",'"+ GROUP_ID + "', '"+ DEVICE_ID + "' ,"+ to_string(DEVICE_UNICAST) + ", 0);";
							DB_Write(addDeviceGr);
							if (DeviceType != 3)
							{
								int temp = PARENT_DEVICE_UNICAST_ID(DEVICE_ID);
								if (temp == 0)
								{
									temp = DEVICE_UNICAST;
								}
								if (DeviceVersion < 3)
								{
									AddDeviceToGroup(mosq, temp, GroupUnicastId, DEVICE_UNICAST);
								}
								while (true){
									if(pthread_mutex_trylock(&mutex) == 0){
										numDeviceGroupRoom++;
										DeviceGroupRoom[i][0] = GroupUnicastId;
										for(int indexdv=0; indexdv<256; indexdv++){
											if(DeviceGroupRoom[i][indexdv]==0){
												DeviceGroupRoom[i][indexdv] = DEVICE_UNICAST;
												break;
											}
										}
										pthread_mutex_unlock(&mutex);
										break;
									}
									usleep (3000);
								}
							}
						}
					}
				}
			}
		}
	}
	if(DATA.HasMember("SCENES")){
		int H = -1;
		int S = -1;
		int L = -1;
		const Value& SCENE = DATA["SCENES"];
		int SceneUnicastId = RoomUnicastId + ID_START;
		for (rapidjson::SizeType i = 0; i < SCENE.Size(); i++){
			const Value& c = SCENE[i];
			string EVENT_TRIGGER_ID = c["SCENE_ID"].GetString();
			int SceneUnicastId =+ i;
			string creGroupID = "INSERT OR REPLACE INTO EventTriggerID (SceneUnicastID, EventTriggerId, ValueCreate, IsSuccess)"
					" values ("+ to_string(SceneUnicastId) + ",'"+ EVENT_TRIGGER_ID +"', 1, 0); ";
			DB_Write( creGroupID);
			// cout << "CREATE ROOM TP3: "<<endl;
			string addEvent = "INSERT OR REPLACE INTO EventTrigger (EventTriggerId, GroupId, EventTriggerTypeId, SceneUnicastID, RoomId)"
							"values ('"+ EVENT_TRIGGER_ID +"','"+ EVENT_TRIGGER_ID +"', 3, "+ to_string(SceneUnicastId)	+", '" + ROOM_ID + "');";
			DB_Write( addEvent);
			if(c.HasMember("GROUPS")){
				const Value& GROUPS = c["GROUPS"];
				//ADD DEVICE SCENE
				for (rapidjson::SizeType j = 0; j < GROUPS.Size(); j++){
					const Value& a = GROUPS[j];
					string GROUP_ID = a["GROUP_ID"].GetString();
					int GROUP_UNICAST = GROUP_UNICAST_ID(GROUP_ID);
					string SelectDvFromGroup = "SELECT DeviceId, DeviceUnicastId FROM GroupingDeviceMapping WHERE GroupingId = '" + GROUP_ID + "';";
					IdxDv = 0;
					DB_Read( "GET_DV_INFO", SelectDvFromGroup);
					const Value& PROPERTIES = a["PROPERTIES"];
					for (rapidjson::SizeType m = 0; m < PROPERTIES.Size(); m++){
						const Value& b = PROPERTIES[m];
						if(b.HasMember("ID") && b.HasMember("VALUE") && FlagCheckDvIntoRoom == true){
							int ID = b["ID"].GetInt();
							int VALUE = b["VALUE"].GetInt();
							if((ID == ATTRIBUTE_HUE)||(ID == ATTRIBUTE_SATURATION)||(ID == ATTRIBUTE_LIGHTNESS)){
								if(ID == ATTRIBUTE_HUE){
									H = b["VALUE"].GetInt();
								}else if(ID == ATTRIBUTE_SATURATION){
									S = b["VALUE"].GetInt();
								}else if(ID == ATTRIBUTE_LIGHTNESS){
									L = b["VALUE"].GetInt();
								}
								if(H >= 0 && S >= 0 && L >= 0){
									ControlRGBBeforAddScene(GROUP_UNICAST, H, S, L);
									H = -1;
									S = -1;
									L = -1;
								}
							}
							else if(ID==23){
								ControlModeRGBBeforAddScene(GROUP_UNICAST, VALUE);
							}
							else
							{
								SendDeviceToGW(mosq, GROUP_UNICAST, ID, VALUE, false);
								usleep(200000);
								SendDeviceToGW(mosq, GROUP_UNICAST, ID, VALUE, false);
							}
						}
					}
					StringBuffer sendToAPP;
					Writer<StringBuffer> jsonAPP(sendToAPP);
					jsonAPP.StartObject();
					jsonAPP.Key("CMD");
					jsonAPP.String("DEVICE");
					jsonAPP.Key("DATA");
					jsonAPP.StartArray();
					for(int k=0; k<IdxDv; k++){
						string DEVICE_ID = DvIdInfo[k];
						float DeviceVersion = GetDeviceVersion(DEVICE_ID);
						cout << "Device version: " << DeviceVersion << endl;
						int DeviceType = TYPE_DEVICE(DEVICE_ID)/10000;
						int DEVICE_UNICAST = DvUnicastIdInfo[k];
						if (DeviceType !=3)
						{
							jsonAPP.StartObject();							
							jsonAPP.Key("DEVICE_ID");
							jsonAPP.String(const_cast<char*>(DEVICE_ID.c_str()));
							jsonAPP.Key("PROPERTIES");
							jsonAPP.StartArray();
							string addsql = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, IsSuccess)"\
									"values('" + EVENT_TRIGGER_ID + "', '"+DvIdInfo[k]+"', "+to_string(DvUnicastIdInfo[k])+", 0);";
							cout << addsql << endl;
							DB_Write( addsql);
							while (true){
								if(pthread_mutex_trylock(&mutex) == 0){
									DeviceSceneRoom[i][0] = SceneUnicastId;
									for(int indexdv=0; indexdv<256; indexdv++){
										if(DeviceSceneRoom[i][indexdv]==0){
											DeviceSceneRoom[i][indexdv] = DEVICE_UNICAST;
											numDeviceSceneRoom ++;
											break;
										}
									}
									TimeOut = GetSecondTimeNow();
									pthread_mutex_unlock(&mutex);
									break;
								}
								usleep (3000);
							}
							if(PROPERTIES.Size() > 1){
								if (DeviceVersion < 3)
									SendDVAddScene(DEVICE_UNICAST, SceneUnicastId, ADD_SCENE_CCT, 0);
								for (rapidjson::SizeType i = 0; i < PROPERTIES.Size(); i++){
									jsonAPP.StartObject();
									const Value& b = PROPERTIES[i];
									int ID = b["ID"].GetInt();
									int VALUE = b["VALUE"].GetInt();
									jsonAPP.Key("ID");
									jsonAPP.Int(ID);
									jsonAPP.Key("VALUE");
									jsonAPP.Int(VALUE);
									string UpdateDvValueScene = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time)"\
											"values('" + EVENT_TRIGGER_ID + "', '"+DvIdInfo[k]+"', "+to_string(DvUnicastIdInfo[k])+", "+to_string(ID)+" ,"+to_string(VALUE)+", '0:0');";
									PushMsgToQueueDb_AHG(UpdateDvValueScene);
									jsonAPP.EndObject();
								}
								jsonAPP.EndArray();
								jsonAPP.EndObject();
							}
							else if(PROPERTIES.Size() == 1){
								const Value& b = PROPERTIES[0];
								jsonAPP.StartObject();
								int ID = b["ID"].GetInt();

								int VALUE = b["VALUE"].GetInt();
								jsonAPP.Key("ID");
								jsonAPP.Int(ID);
								jsonAPP.Key("VALUE");
								jsonAPP.Int(VALUE);
								jsonAPP.EndObject();
								if(ID==23){
									if (DeviceVersion < 3)
										SendDVAddScene(DEVICE_UNICAST, SceneUnicastId, ADD_SCENE_RGB, VALUE);
								}
								else{
									if (DeviceVersion < 3)
										SendDVAddScene(DEVICE_UNICAST, SceneUnicastId, ADD_SCENE_CCT, 0);
								}
								string addDeviceS = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
										"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
										"values ('"+EVENT_TRIGGER_ID+"', '"+DEVICE_ID+"', "+to_string(DEVICE_UNICAST)+", "+to_string(ID)+", "+to_string(VALUE)+", '0:0');";
								PushMsgToQueueDb_AHG(addDeviceS);
								jsonAPP.EndArray();
								jsonAPP.EndObject();
							}
						}
						if (DeviceVersion >= 3 && i == 0)
						{							
							SendDVAddRoom(DEVICE_UNICAST, RoomUnicastId + ID_START, RoomUnicastId + ID_START);
						}
					}
					jsonAPP.EndArray();
					jsonAPP.EndObject();
					string s = sendToAPP.GetString();
					MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
				}
			}
		}
	}
	while (true){
		if(pthread_mutex_trylock(&mutex) == 0){
			IsProcessDone = true;
			pthread_mutex_unlock(&mutex);
			break;
		}
		usleep (3000);
	}
	MqttSend(mosq, "{\"CMD\":\"STOP_PROCESS_ROOM\"}");
}

void AddDeviceToRoom(struct mosquitto *mosq, char* jobj){
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutex) == 0){
			if(IsProcessDone == false){
				ResetDataRoom();
				IsProcessRoom = ADD_DEVICE_TO_ROOM;
				FlagCheckLock = true;
			}
			pthread_mutex_unlock(&mutex);
		}
		usleep (3000);
	}
	MqttSend(mosq, "{\"CMD\":\"START_PROCESS_ROOM\"}");
	Document document;
	document.Parse(jobj);
	int DeviceUnicastIdIntoRoom[200];
	string DeviceIdIntoRoom[200];
	int t = 0;
	string RoomId = "";
	int RoomUnicastId = 0;
	const Value& DATA = document["DATA"];
	if(DATA.HasMember("GROUPS")){
		const Value& GROUPS = DATA["GROUPS"];
		numGroupRoom = GROUPS.Size();
		for (rapidjson::SizeType i = 0; i < GROUPS.Size(); i++){
			const Value& a = GROUPS[i];
			if(a.HasMember("GROUP_ID") && a.HasMember("DEVICE_TYPE_ID") && a.HasMember("NAME")){
				string GROUP_ID = a["GROUP_ID"].GetString();
				int Temp = 0;
				Temp = GROUP_UNICAST_ID(GROUP_ID);
				int DEVICE_TYPE_ID = a["DEVICE_TYPE_ID"].GetInt();
				string NAME = a["NAME"].GetString();
				int GroupUnicastId = 0;
				//ADD DEVICE TO GROUP
				if(Temp == 0){
					// string creGroupID = "INSERT OR REPLACE INTO GROUPID (GroupUnicastId, GroupingId, ValueCreate,IsSuccess)"
					// 		" values ("+ to_string(GroupUnicastId) + ",'"+ GROUP_ID +"', 1,2); ";
					// DB_Write( creGroupID);
					if(i == 0){
						RoomId = GROUP_ID;
						RoomUnicastId = GetNextRoomId();
					}
					string creGroup = "INSERT OR REPLACE INTO GROUPING (GroupingId, GroupUnicastId, Name, CategoryId, RoomId)"
							" values ('"+ GROUP_ID + "', "+ to_string(GroupUnicastId) + ", '"+ NAME + "', "+ to_string(DEVICE_TYPE_ID) + ", '"+RoomId+"'); ";
					DB_Write( creGroup);
				}
				else{
					GroupUnicastId = Temp;
				}
				while (true){
					if(pthread_mutex_trylock(&mutex) == 0){
						DeviceGroupRoom[i][0] = GroupUnicastId;
						DeviceRoomGroupSuccess[i][0] = GroupUnicastId;
						pthread_mutex_unlock(&mutex);
						break;
					}
					usleep (3000);
				}
				if(a.HasMember("DEVICES")){
					const Value& DEVICES = a["DEVICES"];
					for (rapidjson::SizeType j = 0; j < DEVICES.Size(); j++){
						const Value& b = DEVICES[j];
						string DEVICE_ID = b.GetString();
						int DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
						int DeviceType = TYPE_DEVICE(DEVICE_ID)/10000;
						float DeviceVersion = GetDeviceVersion(DEVICE_ID);
						if(DEVICE_UNICAST != 0)
						{
							if (DeviceType !=3)
							{
								int temp = PARENT_DEVICE_UNICAST_ID(DEVICE_ID);
								if (temp == 0)
								{
									temp = DEVICE_UNICAST;
								}
								if (DeviceVersion < 3)
								{
									AddDeviceToGroup(mosq, temp, GroupUnicastId, DEVICE_UNICAST);
								}
								while (true){
									if(pthread_mutex_trylock(&mutex) == 0){
										numDeviceGroupRoom++;
										for(int indexdv=0; indexdv<256; indexdv++){
											if(DeviceGroupRoom[i][indexdv]==0){
												DeviceGroupRoom[i][indexdv] = DEVICE_UNICAST;
												break;
											}
										}
										pthread_mutex_unlock(&mutex);
										break;
									}
									usleep (3000);
								}
							}
							string addDeviceGr = "INSERT OR REPLACE INTO GroupingDeviceMapping (GroupUnicastId, GroupingId, DeviceId, DeviceUnicastId,IsSuccess)"
									" values ("+ to_string(GroupUnicastId) + ",'"+ GROUP_ID + "', '"+ DEVICE_ID + "' ,"+ to_string(DEVICE_UNICAST) + ", 2);";
							DB_Write( addDeviceGr);
						}
						if(i==0 && DEVICE_UNICAST != 0 && DeviceType !=3){
							DeviceUnicastIdIntoRoom[t] = DEVICE_UNICAST;
							DeviceIdIntoRoom[t] = DEVICE_ID;
							t++;
						}
					}
				}
			}
		}
	}
	if(DATA.HasMember("SCENES")){
		int H = -1;
		int S = -1;
		int L = -1;
		const Value& SCENE = DATA["SCENES"];
		int SceneUnicastId = RoomUnicastId + ID_START;
		for (rapidjson::SizeType i = 0; i < SCENE.Size(); i++){
			const Value& c = SCENE[i];
			string EVENT_TRIGGER_ID = c["SCENE_ID"].GetString();
			int SceneUnicastId =+ i;
			string addEvent = "INSERT OR REPLACE INTO EventTrigger (EventTriggerId, GroupId, EventTriggerTypeId, SceneUnicastID, RoomId)"
							"values ('"+ EVENT_TRIGGER_ID +"','"+ EVENT_TRIGGER_ID +"', 1, "+ to_string(SceneUnicastId)	+", '" + RoomId + "');";
			DB_Write( addEvent);
			string updateIsSuccessEvent = "INSERT OR REPLACE INTO EventTriggerID (SceneUnicastID, EventTriggerId, ValueCreate, IsSuccess)"
					" values ("+ to_string(SceneUnicastId)	+", '"+ EVENT_TRIGGER_ID +"', 1, 2);";
			cout << updateIsSuccessEvent << endl;
			DB_Write( updateIsSuccessEvent);
			if(c.HasMember("GROUPS")){
				const Value& GROUPS = c["GROUPS"];
				for (rapidjson::SizeType j = 0; j < GROUPS.Size(); j++){
					const Value& a = GROUPS[j];
					string GROUP_ID = a["GROUP_ID"].GetString();
					int GROUP_UNICAST = GROUP_UNICAST_ID(GROUP_ID);
					const Value& PROPERTIES = a["PROPERTIES"];
					for (rapidjson::SizeType m = 0; m < PROPERTIES.Size(); m++){
						const Value& b = PROPERTIES[m];
						if(b.HasMember("ID") && b.HasMember("VALUE") && t != 0){
							int ID = b["ID"].GetInt();
							int VALUE = b["VALUE"].GetInt();
							if((ID == ATTRIBUTE_HUE)||(ID == ATTRIBUTE_SATURATION)||(ID == ATTRIBUTE_LIGHTNESS)){
								if(ID == ATTRIBUTE_HUE){
									H = b["VALUE"].GetInt();
								}else if(ID == ATTRIBUTE_SATURATION){
									S = b["VALUE"].GetInt();
								}else if(ID == ATTRIBUTE_LIGHTNESS){
									L = b["VALUE"].GetInt();
								}
								if(H >= 0 && S >= 0 && L >= 0){
									ControlRGBBeforAddScene(GROUP_UNICAST, H, S, L);
									H = -1;
									S = -1;
									L = -1;
								}
							}
							else if(ID==23){
								ControlModeRGBBeforAddScene(GROUP_UNICAST, VALUE);
							}
							else {
								SendDeviceToGW(mosq, GROUP_UNICAST, ID, VALUE, false);
								usleep(200000);
								SendDeviceToGW(mosq, GROUP_UNICAST, ID, VALUE, false);
							}
						}
					}
					StringBuffer sendToAPP;
					Writer<StringBuffer> jsonAPP(sendToAPP);
					jsonAPP.StartObject();
					jsonAPP.Key("CMD");
					jsonAPP.String("DEVICE");
					jsonAPP.Key("DATA");
					jsonAPP.StartArray();
					for(int k=0; k<t; k++){
						string DEVICE_ID = DeviceIdIntoRoom[k];
						float DeviceVersion = GetDeviceVersion(DEVICE_ID);
						int DeviceType = TYPE_DEVICE(DEVICE_ID)/10000;
						int DEVICE_UNICAST = DeviceUnicastIdIntoRoom[k];
						if (DeviceType !=3)
						{							
							jsonAPP.StartObject();
							jsonAPP.Key("DEVICE_ID");
							jsonAPP.String(const_cast<char*>(DEVICE_ID.c_str()));
							jsonAPP.Key("PROPERTIES");
							jsonAPP.StartArray();
							string addDeviceS = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId,IsSuccess) "
											"values ('"+EVENT_TRIGGER_ID+"', '"+DEVICE_ID+"', "+to_string(DEVICE_UNICAST)+",2);";
							cout << addDeviceS <<endl;
							DB_Write( addDeviceS);
							while (true){
								if(pthread_mutex_trylock(&mutex) == 0){
									DeviceSceneRoom[i][0] = SceneUnicastId;
									for(int indexdv=0; indexdv<256; indexdv++){
										if(DeviceSceneRoom[i][indexdv]==0){
											DeviceSceneRoom[i][indexdv] = DEVICE_UNICAST;
											numDeviceSceneRoom ++;
											break;
										}
									}
									TimeOut = GetSecondTimeNow();
									pthread_mutex_unlock(&mutex);
									break;
								}
								usleep (3000);
							}
							if(PROPERTIES.Size() > 1){
								if (DeviceVersion < 3)
									SendDVAddScene(DEVICE_UNICAST, SceneUnicastId, ADD_SCENE_CCT, 0);
								for (rapidjson::SizeType m = 0; m < PROPERTIES.Size(); m++){
									jsonAPP.StartObject();
									const Value& c = PROPERTIES[m];
									int ID = c["ID"].GetInt();
									int VALUE = c["VALUE"].GetInt();
									jsonAPP.Key("ID");
									jsonAPP.Int(ID);
									jsonAPP.Key("VALUE");
									jsonAPP.Int(VALUE);
									string UpdateValueDV = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time)"\
											"values('" + EVENT_TRIGGER_ID + "', '"+DEVICE_ID+"', "+to_string(DEVICE_UNICAST)+", "+to_string(ID)+" ,"+to_string(VALUE)+", '0:0');";
									PushMsgToQueueDb_AHG(UpdateValueDV);
									jsonAPP.EndObject();
								}
								jsonAPP.EndArray();
								jsonAPP.EndObject();
							}
							else if(PROPERTIES.Size() == 1){
								const Value& c = PROPERTIES[0];
								jsonAPP.StartObject();
								int ID = c["ID"].GetInt();
								int VALUE = c["VALUE"].GetInt();
								jsonAPP.Key("ID");
								jsonAPP.Int(ID);
								jsonAPP.Key("VALUE");
								jsonAPP.Int(VALUE);
								jsonAPP.EndObject();
								if(ID==23){
									if (DeviceVersion < 3)
										SendDVAddScene(DEVICE_UNICAST, SceneUnicastId, ADD_SCENE_RGB, VALUE);
								}
								else{
									if (DeviceVersion < 3)
										SendDVAddScene(DEVICE_UNICAST, SceneUnicastId, ADD_SCENE_CCT, 0);
								}
								string UpdateValueDV = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time)"\
												"values('" + EVENT_TRIGGER_ID + "', '"+DEVICE_ID+"', "+to_string(DEVICE_UNICAST)+", "+to_string(ID)+" ,"+to_string(VALUE)+", '0:0');";
								PushMsgToQueueDb_AHG(UpdateValueDV);
								jsonAPP.EndArray();
								jsonAPP.EndObject();
							}
						}
						if (DeviceVersion >= 3 && i == 0)
						{							
							SendDVAddRoom(DEVICE_UNICAST, SceneUnicastId, RoomUnicastId + ID_START);
						}						
					}
					jsonAPP.EndArray();
					jsonAPP.EndObject();
					string s = sendToAPP.GetString();
					MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
				}
			}
		}
	}
	while (true){
		if(pthread_mutex_trylock(&mutex) == 0){
			IsProcessDone = true;
			pthread_mutex_unlock(&mutex);
			break;
		}
		usleep (3000);
	}
	MqttSend(mosq, "{\"CMD\":\"STOP_PROCESS_ROOM\"}");
}

void DelDeviceFromRoom(struct mosquitto *mosq, char* jobj){
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutex) == 0){
			if(IsProcessDone == false){
				ResetDataRoom();
				IsProcessRoom = REMOVE_DEVICE_FROM_ROOM;
				FlagCheckLock = true;
			}
			pthread_mutex_unlock(&mutex);
		}
		usleep (3000);
	}
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	if(DATA.HasMember("GROUPS")){
		const Value& GROUPS = DATA["GROUPS"];
		numGroupRoom = GROUPS.Size();
		for (rapidjson::SizeType i = 0; i < GROUPS.Size(); i++){
			const Value& a = GROUPS[i];
			string GROUP_ID = a["GROUP_ID"].GetString();
			if(i == 0){
				string creRoom = "INSERT OR REPLACE INTO QueueMsgRsp (RqId, Msg) values ('"+ GROUP_ID +"', '1'); ";
				DB_Write( creRoom);
			}
			int GROUP_UNICAST = 0;
			if(a.HasMember("GROUP_UNICAST_ID")){
				GROUP_UNICAST = a["GROUP_UNICAST_ID"].GetInt();
			}
			else{
				GROUP_UNICAST = GROUP_UNICAST_ID(GROUP_ID);
			}
			if(a.HasMember("DEVICES")){
				const Value& DEVICES = a["DEVICES"];
				for (rapidjson::SizeType j = 0; j < DEVICES.Size(); j++){
					const Value& b = DEVICES[j];
					string DEVICE_ID = b.GetString();
					int DeviceType = TYPE_DEVICE(DEVICE_ID)/10000;
					if (DeviceType !=3)
					{
						int device_unicast_id = DEVICE_UNICAST_ID(DEVICE_ID);
						int temp = PARENT_DEVICE_UNICAST_ID(DEVICE_ID);
						if (temp == 0)
						{
							temp = device_unicast_id;
						}
						DelDeviceFromGroup(mosq, temp, GROUP_UNICAST, device_unicast_id);
						while (true){
							if(pthread_mutex_trylock(&mutex) == 0){
								numDeviceGroupRoom++;
								DeviceGroupRoom[i][0] = GROUP_UNICAST;
								for(int indexdv=0; indexdv<256; indexdv++){
									if(DeviceGroupRoom[i][indexdv]==0){
										DeviceGroupRoom[i][indexdv] = device_unicast_id;
										break;
									}
								}
								pthread_mutex_unlock(&mutex);
								break;
							}
							usleep (3000);
						}
					}
					else
					{
						string DelDevice = "DELETE FROM GroupingDeviceMapping WHERE GroupingId = '"+ GROUP_ID +"' AND DeviceId = '"+ DEVICE_ID +"'";
						DB_Write(DelDevice);
					}
				}
			}
		}
	}
	if(DATA.HasMember("SCENES")){
		MqttSend(mosq, DEL_LIST_SCENE);
		const Value& SCENES = DATA["SCENES"];
		for (rapidjson::SizeType i = 0; i < SCENES.Size(); i++){
			const Value& a = SCENES[i];
			string EVENT_TRIGGER_ID = a["SCENE_ID"].GetString();
			ADR = -1;
			string CheckTypeScene = "SELECT EventTriggerTypeId FROM EventTrigger WHERE EventTriggerId = '"+ EVENT_TRIGGER_ID +"';";
			DB_Read( "ADR", CheckTypeScene);
			int TypeScene = ADR;
			// cout << "Type Scene: " << TypeScene << endl;
			if(TypeScene != 0 && TypeScene != -1 && TypeScene != 10){
				int SceneUnicastId = -1;
				if(a.HasMember("SCENE_UNICAST_ID")){
					SceneUnicastId = a["SCENE_UNICAST_ID"].GetInt();
				}
				else{
					ADR = -1;
					string checkAdrS = "SELECT SceneUnicastID FROM EventTrigger where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
					// cout << checkAdrS << endl;
					DB_Read( "ADR", checkAdrS);
					SceneUnicastId = ADR;
					// cout << SceneUnicastId << endl;
				}
				if(a.HasMember("DEVICES")){
					const Value& DEVICES = a["DEVICES"];
					for (rapidjson::SizeType j = 0; j < DEVICES.Size(); j++){
						const Value& b = DEVICES[j];
						string DEVICE_ID = b.GetString();
						int DeviceType = TYPE_DEVICE(DEVICE_ID)/10000;
						if (DeviceType !=3)
						{
							int device_unicast_id = DEVICE_UNICAST_ID(DEVICE_ID);
							string adr = "SELECT DeviceAttributeId FROM EventTriggerOutputDeviceSetupValue WHERE EventTriggerId = '"+EVENT_TRIGGER_ID+"' AND DeviceUnicastId = "+to_string(device_unicast_id)+" ORDER BY DeviceAttributeId DESC LIMIT 1;";
							TYPE_DV = 0;
							DB_Read( "TYPE_DEVICE", adr);
							while (true){
								if(pthread_mutex_trylock(&mutex) == 0){
									DeviceSceneRoom[i][0] = SceneUnicastId;
									for(int indexdv=0; indexdv<256; indexdv++){
										if(DeviceSceneRoom[i][indexdv]==0){
											DeviceSceneRoom[i][indexdv] = device_unicast_id;
											numDeviceSceneRoom ++;
											break;
										}
									}
									TimeOut = GetSecondTimeNow();
									pthread_mutex_unlock(&mutex);
									break;
								}
								usleep (3000);
							}
							if(TYPE_DV == 23){
								DelDVFromScene(device_unicast_id, SceneUnicastId, DEL_SCENE_RGB);
							}
							else{
								DelDVFromScene(device_unicast_id, SceneUnicastId, DEL_SCENE_CCT);
							}
						}
					}
				}
			}
			else{
				if(a.HasMember("DEVICES")){
					const Value& DEVICES = a["DEVICES"];
					for (rapidjson::SizeType j = 0; j < DEVICES.Size(); j++){
						const Value& b = DEVICES[j];
						string DEVICE_ID = b.GetString();
						string DelSceneDvMapping = "DELETE FROM EventTriggerOutputDeviceMapping WHERE EventTriggerId = '"+ EVENT_TRIGGER_ID +"' AND DeviceId = '"+ DEVICE_ID +"'";
						DB_Write( DelSceneDvMapping);
						string DelSceneDvValue = "DELETE FROM EventTriggerOutputDeviceSetupValue WHERE EventTriggerId = '"+ EVENT_TRIGGER_ID +"' AND DeviceId = '"+ DEVICE_ID +"'";
						DB_Write( DelSceneDvValue);
					}
				}
			}
		}
	}
	while (true){
		if(pthread_mutex_trylock(&mutex) == 0){
			IsProcessDone = true;
			pthread_mutex_unlock(&mutex);
			break;
		}
		usleep (3000);
	}
}

void DelRoom(struct mosquitto *mosq, char* jobj){
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutex) == 0){
			if(IsProcessDone == false){
				ResetDataRoom();
				IsProcessRoom = DELETE_ROOM;
				FlagCheckLock = true;
			}
			pthread_mutex_unlock(&mutex);
		}
		usleep (3000);
	}
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	if(DATA.HasMember("GROUPS")){
		const Value& GROUP = DATA["GROUPS"];
		string ROOM_ID = "";
		for(rapidjson::SizeType i=0; i<GROUP.Size(); i++){
			const Value& a = GROUP[i];
			string GROUP_ID = a.GetString();
			int GROUP_UNICAST;
			if(DATA.HasMember("GROUP_UNICAST_ID")){
				GROUP_UNICAST = DATA["GROUP_UNICAST_ID"].GetInt();
			}
			else{
				GROUP_UNICAST = GROUP_UNICAST_ID(GROUP_ID);
			}
			numDvUnicast= 0;
			if(i == 0){
				string creRoom = "INSERT OR REPLACE INTO QueueMsgRsp (RqId, Msg) values ('"+ GROUP_ID +"', '1'); ";
				DB_Write( creRoom);
				ROOM_ID = GROUP_ID;
				numDvUnicast = 0;
				string GetAdrScreenTouch = "SELECT DeviceUnicastId FROM Device WHERE RoomId = '"+ROOM_ID+"'AND CategoryId = 23003;";
				DB_Read( "DEVICE_UNICAST", GetAdrScreenTouch);
				for(int j=0; j<numDvUnicast; j++){
					StringBuffer sendToGW;
					Writer<StringBuffer> json(sendToGW);
					json.StartObject();
					json.Key("CMD");json.String("DELALL_SCENE_SCREENTOUCH");
					json.Key("DATA");
						json.StartObject();
						json.Key("DEVICE_UNICAST_ID");
						json.Int(ArrDvUnicast[j]);
						json.EndObject();
					json.EndObject();
					string s = sendToGW.GetString();
					MqttSend(mosq, const_cast<char*>(s.c_str()));
					string DelDvFromEventTriggerInput = "DELETE FROM EventTriggerInputDeviceMapping WHERE DeviceUnicastId = " + to_string(ArrDvUnicast[j]) + ";";
					DB_Write( DelDvFromEventTriggerInput);
				}
			}
			string CheckListDv = "SELECT DeviceUnicastId FROM GroupingDeviceMapping WHERE GroupingId = '" + GROUP_ID + "';";
			// cout << CheckListDv << endl;
			DB_Read("DEVICE_UNICAST",CheckListDv);
			for(int m=0;m<numDvUnicast;m++){
				int temp = PARENT_DEVICE_UNICAST_ID(ArrDvUnicast[m]);
				if (temp == 0)
				{
					temp = ArrDvUnicast[m];
				}
				int DeviceType = TYPE_DEVICE(temp)/10000;
				if (DeviceType !=3)
				{
					DelDeviceFromGroup(mosq, temp, GROUP_UNICAST, ArrDvUnicast[m]);
					while (true){
						if(pthread_mutex_trylock(&mutex) == 0){
							numDeviceGroupRoom++;
							DeviceGroupRoom[i][0] = GROUP_UNICAST;
							for(int indexdv=0; indexdv<256; indexdv++){
								if(DeviceGroupRoom[i][indexdv]==0){
									DeviceGroupRoom[i][indexdv] = ArrDvUnicast[m];
									break;
								}
							}
							pthread_mutex_unlock(&mutex);
							break;
						}
						usleep (3000);
					}
				}
				else
				{
					string DelDevice = "DELETE FROM GroupingDeviceMapping WHERE GroupingId = '"+ GROUP_ID +"' AND DeviceUnicastId = "+ to_string(temp) +"";
					DB_Write(DelDevice);
				}
			}
		}
	}
	if(DATA.HasMember("SCENES")){
		MqttSend(mosq, DEL_LIST_SCENE);
		const Value& SCENE = DATA["SCENES"];
		for(rapidjson::SizeType i=0; i<SCENE.Size(); i++){
			string EVENT_TRIGGER_ID = SCENE[i].GetString();
			ADR = -1;
			string CheckTypeScene = "SELECT EventTriggerTypeId FROM EventTrigger WHERE EventTriggerId = '"+ EVENT_TRIGGER_ID +"';";
			DB_Read( "ADR", CheckTypeScene);
			int TypeScene = ADR;
			// cout << "Type Scene: " << TypeScene << endl;
			if(TypeScene != 0 && TypeScene != -1 && TypeScene != 10){
				ADR = -1;
				string checkAdrS = "SELECT SceneUnicastID FROM EventTrigger where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
				DB_Read( "ADR", checkAdrS);
				int SceneUnicastId = ADR;
				numDvUnicastDelScene= 0;
				string adr = "SELECT DeviceUnicastId FROM EventTriggerOutputDeviceMapping WHERE EventTriggerId = '"+EVENT_TRIGGER_ID+"';";
				DB_Read( "DEL_SCENE", adr);
				int NumDVDelScene = numDvUnicastDelScene;
				for(int j=0; j< NumDVDelScene; j++){
					int DeviceType = TYPE_DEVICE(DeviceDelScene[j])/10000;
					if (DeviceType !=3)
					{
						while (true){
							if(pthread_mutex_trylock(&mutex) == 0){
								DeviceSceneRoom[i][0] = SceneUnicastId;
								for(int indexdv=0; indexdv<256; indexdv++){
									if(DeviceSceneRoom[i][indexdv]==0){
										DeviceSceneRoom[i][indexdv] = DeviceDelScene[j];
										numDeviceSceneRoom ++;
										break;
									}
								}
								TimeOut = GetSecondTimeNow();
								pthread_mutex_unlock(&mutex);
								break;
							}
							usleep (3000);
						}
						string adr = "SELECT DeviceAttributeId FROM EventTriggerOutputDeviceSetupValue WHERE EventTriggerId = '"+EVENT_TRIGGER_ID+"' AND DeviceUnicastId = "+to_string(ArrDvUnicast[j])+" ORDER BY DeviceAttributeId ASC;";
						TYPE_DV = 0;
						DB_Read( "TYPE_DEVICE", adr);
						if(TYPE_DV == 23){
							DelDVFromScene(DeviceDelScene[j], SceneUnicastId, DEL_SCENE_RGB);
						}
						else{
							DelDVFromScene(DeviceDelScene[j], SceneUnicastId, DEL_SCENE_CCT);
						}
					}
				}
			}
			else{
				string DelEvenID = "DELETE FROM EventTrigger where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
				DB_Write( DelEvenID);
				string DelEventDvInputMapping = "DELETE FROM EventTriggerInputDeviceMapping where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
				DB_Write( DelEventDvInputMapping);
				string DelEventDvInputValue = "DELETE FROM EventTriggerInputDeviceSetupValue where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
				DB_Write( DelEventDvInputValue);
				string DelEventDvOutputMapping = "DELETE FROM EventTriggerOutputDeviceMapping where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
				DB_Write( DelEventDvOutputMapping);
				string DelEventDvOutputValue = "DELETE FROM EventTriggerOutputDeviceSetupValue where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
				DB_Write( DelEventDvOutputValue);
				string DelEventGrOutputMapping = "DELETE FROM EventTriggerOutputGroupingMapping where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
				DB_Write( DelEventGrOutputMapping);
				string DelEventGrOutputValue = "DELETE FROM EventTriggerOutputGroupingSetupValue where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
				DB_Write( DelEventGrOutputValue);
				string DelEventSceneOutputMapping = "DELETE FROM EventTriggerOutputSceneMapping where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
				DB_Write( DelEventSceneOutputMapping);
			}
		}
	}
	if(DATA.HasMember("EVENT_TRIGGER")){
		const Value& EVENT_TRIGGER = DATA["EVENT_TRIGGER"];
		for(rapidjson::SizeType i=0; i<EVENT_TRIGGER.Size(); i++){
			string EVENT_TRIGGER_ID = EVENT_TRIGGER[i].GetString();
			string DelEvenID = "DELETE FROM EventTrigger where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
			DB_Write( DelEvenID);
			string DelEventDvInputMapping = "DELETE FROM EventTriggerInputDeviceMapping where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
			DB_Write( DelEventDvInputMapping);
			string DelEventDvInputValue = "DELETE FROM EventTriggerInputDeviceSetupValue where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
			DB_Write( DelEventDvInputValue);
			string DelEventDvOutputMapping = "DELETE FROM EventTriggerOutputDeviceMapping where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
			DB_Write( DelEventDvOutputMapping);
			string DelEventDvOutputValue = "DELETE FROM EventTriggerOutputDeviceSetupValue where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
			DB_Write( DelEventDvOutputValue);
			string DelEventGrOutputMapping = "DELETE FROM EventTriggerOutputGroupingMapping where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
			DB_Write( DelEventGrOutputMapping);
			string DelEventGrOutputValue = "DELETE FROM EventTriggerOutputGroupingSetupValue where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
			DB_Write( DelEventGrOutputValue);
			string DelEventSceneOutputMapping = "DELETE FROM EventTriggerOutputSceneMapping where EventTriggerId ='"+EVENT_TRIGGER_ID+"';";
			DB_Write( DelEventSceneOutputMapping);
		}
	}
	while (true){
		if(pthread_mutex_trylock(&mutex) == 0){
			IsProcessDone = true;
			pthread_mutex_unlock(&mutex);
			break;
		}
		usleep (3000);
	}
}

void CheckRoom(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	string ROOM_ID = DATA["ROOM_ID"].GetString();
	CONTROL = "";
	string CheckMsg = "SELECT Msg FROM QueueMsgRsp where RqId ='"+ROOM_ID+"';";
	DB_Read( "CONTROL", CheckMsg);
	MqttSendAPP(mosq, const_cast<char*>(CONTROL.c_str()), true);
}

void AddDeviceSmartHomeToRoom(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	string ROOM_ID = DATA["ROOM_ID"].GetString();
	string DEVICE_ID = DATA["DEVICE_ID"].GetString();
	ADR = -1;
	string CheckTypeDevice = "SELECT CategoryId FROM Device WHERE DeviceId = '"+DEVICE_ID+"';";
	// cout << CheckTypeDevice <<endl;
	DB_Read( "ADR", CheckTypeDevice);
	int TypeDV = ADR;
	if(TypeDV == 23003 || TypeDV == 23005 || TypeDV == 23007){
		StringBuffer sendToGW;
		Writer<StringBuffer> json(sendToGW);
		json.StartObject();
		json.Key("CMD");
		json.String("ROOM_DEVICE");
		json.Key("DATA");
			json.StartObject();
			json.Key("DEVICE_UNICAST_ID");
			json.Int(DEVICE_UNICAST_ID(DEVICE_ID));
			json.Key("GROUPID");
			json.Int(GROUP_UNICAST_ID(ROOM_ID));
			json.EndObject();
		json.EndObject();
		string s = sendToGW.GetString();
		MqttSend(mosq, const_cast<char*>(s.c_str()));
	}
	string UpdateDeviceToRoom = "UPDATE Device SET RoomId = '"+ROOM_ID+"' WHERE DeviceId = '"+DEVICE_ID+"';";
	DB_Write( UpdateDeviceToRoom);
	MqttSendAPP(mosq, jobj, true);
}
