/*
 * AHG_CONFIG_RULE.hpp
 *
 *  Created on: Dec 23, 2021
 *      Author: rd
 */

#ifndef SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_RULE_HPP_
#define SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_RULE_HPP_

#include "../JSON_AHG.hpp"

//RULE
void CreateCountDown(struct mosquitto *mosq, char* jobj);
void DeleteCountDown(struct mosquitto *mosq, char* jobj);
void CreateCountDownSwitch(struct mosquitto *mosq, char* jobj);
void DeleteCountDownSwitch(struct mosquitto *mosq, char* jobj);
void CreateRuleOutPut(struct mosquitto *mosq, char* jobj, string EVENT_TRIGGER_ID, string START_AT, string END_AT, int TYPE_RUN);
void CreateRuleInput(struct mosquitto *mosq, char* jobj, string EVENT_TRIGGER_ID);
void CreateRule(struct mosquitto *mosq, char* jobj);
void EditRule(struct mosquitto *mosq, char* jobj);
void EditRuleV2(struct mosquitto *mosq, char *jobj);
void DelRule(struct mosquitto *mosq, char* jobj, bool sendMsg);
void UpdateStatusRule(struct mosquitto *mosq, char* jobj);
void RuleV2(struct mosquitto *mosq, char* jobj);

#endif /* SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_RULE_HPP_ */
