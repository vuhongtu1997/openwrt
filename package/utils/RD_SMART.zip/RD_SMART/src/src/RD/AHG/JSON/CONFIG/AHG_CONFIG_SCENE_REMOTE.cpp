/*
 * AHG_CONFIG_SCENE_REMOTE.cpp
 *
 *  Created on: Dec 23, 2021
 *      Author: rd
 */

#include <iostream>
#include <sstream>
#include "AHG_CONFIG_SCENE_REMOTE.hpp"

static void CreateNormalSceneRemote(uint16_t DeviceUnicastParent, int DeviceUnicastId, uint16_t TypeDev, int SceneUnicastId, string DeviceType, string Button, int Mode){
	StringBuffer sendToGW;
	Writer<StringBuffer> jsonAHG(sendToGW);
	jsonAHG.StartObject();
	jsonAHG.Key("CMD");
	jsonAHG.String(const_cast<char*>(DeviceType.c_str()));
	jsonAHG.Key("DATA");
	jsonAHG.StartObject();
	if (DeviceUnicastParent > 0)
	{
		jsonAHG.Key("DEVICE_UNICAST_PARENT_ID");
		jsonAHG.Int(DeviceUnicastParent);
	}
	jsonAHG.Key("DEVICE_UNICAST_ID");
	jsonAHG.Int(DeviceUnicastId);
	jsonAHG.Key("DEVICE_TYPE_ID");
	jsonAHG.Int(TypeDev);
	jsonAHG.Key("BUTTONID");
	jsonAHG.String(const_cast<char*>(Button.c_str()));
	jsonAHG.Key("MODEID");
	jsonAHG.Int(Mode);
	jsonAHG.Key("SCENEID");
	jsonAHG.Int(SceneUnicastId);
	jsonAHG.Key("SRGBID");
	jsonAHG.Int(0);
	jsonAHG.EndObject();
	jsonAHG.EndObject();
	string s = sendToGW.GetString();
	cout<<s<<endl;
	MqttSend(mosq, const_cast<char*>(s.c_str()));
}

void CreateSceneForRemote(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	string DEVICE_ID = DATA["DEVICE_ID"].GetString();
	int DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
	int DEVICE_TYPE_ID = DATA["DEVICE_TYPE_ID"].GetInt();
	string EVENT_TRIGGER_ID = DATA["SCENE_ID"].GetString();
	string BUTTON_VALUE = DATA["BUTTON_VALUE"].GetString();
	int MODE_VALUE = DATA["MODE_VALUE"].GetInt();
	int ButtonId = 0;
	if(BUTTON_VALUE.compare("BUTTON_1") == 0){
		ButtonId = 11;
	}
	else if(BUTTON_VALUE.compare("BUTTON_2") == 0){
		ButtonId = 12;
	}
	else if(BUTTON_VALUE.compare("BUTTON_3") == 0){
		ButtonId = 13;
	}
	else if(BUTTON_VALUE.compare("BUTTON_4") == 0){
		ButtonId = 14;
	}
	else if(BUTTON_VALUE.compare("BUTTON_5") == 0){
		ButtonId = 15;
	}
	else if(BUTTON_VALUE.compare("BUTTON_6") == 0){
		ButtonId = 16;
	}
	ADR = -1;
	string CheckTypeScene = "SELECT EventTriggerTypeId FROM EventTrigger WHERE EventTriggerId = '"+EVENT_TRIGGER_ID+"';";
	DB_Read( "ADR", CheckTypeScene);
	int TypeScene = ADR;
	int DeviceUnicastId = DEVICE_UNICAST_ID(DEVICE_ID);
	int SceneUnicastId = SCENE_UNICAST_ID(EVENT_TRIGGER_ID);
	string DvTypeId = "";
	uint16_t deviceUnicastParent = 0;
	if(DEVICE_TYPE_ID == 23002 || DEVICE_TYPE_ID == 23006){
		DvTypeId = "ADDSCENE_REMOTE_AC";
	}
	else if(DEVICE_TYPE_ID == 23001 || DEVICE_TYPE_ID == 23004 || DEVICE_TYPE_ID == 23005 || DEVICE_TYPE_ID == 23007){
		DvTypeId = "ADDSCENE_REMOTE_DC";
	}
	else if (DEVICE_TYPE_ID == SEFTPOWER_REMOTE_1 || DEVICE_TYPE_ID == SEFTPOWER_REMOTE_2 || DEVICE_TYPE_ID == SEFTPOWER_REMOTE_3 || DEVICE_TYPE_ID == SEFTPOWER_REMOTE_6){
		DvTypeId = "ADDSCENE_REMOTE_DC";
		if (DATA.HasMember("DEVICE_PARENT_ID") && DATA["DEVICE_PARENT_ID"].IsString())
		{
			string deviceParentId = DATA["DEVICE_PARENT_ID"].GetString();
			deviceUnicastParent = DEVICE_UNICAST_ID(deviceParentId);
		}
	}
	// cout << "tạo scene: " << TypeScene << endl;
	// InsertIntoEventInputDVMapping(EVENT_TRIGGER_ID, DEVICE_ID, DEVICE_UNICAST);
	// InsertIntoEventInputDVValue(EVENT_TRIGGER_ID, DEVICE_ID, DEVICE_UNICAST, ButtonId, 1, MODE_VALUE, 0);
	CreateNormalSceneRemote(deviceUnicastParent,DeviceUnicastId, DEVICE_TYPE_ID, SceneUnicastId, DvTypeId, BUTTON_VALUE, MODE_VALUE);
}

void DelSceneForRemote(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	string DEVICE_ID = DATA["DEVICE_ID"].GetString();
	int DEVICE_TYPE_ID = DATA["DEVICE_TYPE_ID"].GetInt();
	string EVENT_TRIGGER_ID = DATA["SCENE_ID"].GetString();
	sceneIdDelRemote = EVENT_TRIGGER_ID;
	string BUTTON_VALUE = DATA["BUTTON_VALUE"].GetString();
	int MODE_VALUE = DATA["MODE_VALUE"].GetInt();
	ADR = -1;
	string sqlCheckDevice = "SELECT DeviceUnicastId FROM Device WHERE DeviceId='" + DEVICE_ID + "' AND DeviceTypeId = 1;";
	DB_Read( "ADR", sqlCheckDevice);
	int DeviceUnicastId = ADR;
	string cmd = "";
	uint16_t deviceUnicastParent = 0;
	if(DEVICE_TYPE_ID == 23001 || 
		DEVICE_TYPE_ID == 23004 || 
		DEVICE_TYPE_ID == 23005 || 
		DEVICE_TYPE_ID == 23002 || 
		DEVICE_TYPE_ID == 23006 || 
		DEVICE_TYPE_ID == SEFTPOWER_REMOTE_1 || 
		DEVICE_TYPE_ID == SEFTPOWER_REMOTE_2 || 
		DEVICE_TYPE_ID == SEFTPOWER_REMOTE_3 ||
		DEVICE_TYPE_ID == SEFTPOWER_REMOTE_6 ){
		StringBuffer sendToGW;
		Writer<StringBuffer> json(sendToGW);
		json.StartObject();
			json.Key("CMD");
			if(DEVICE_TYPE_ID == 23002 || DEVICE_TYPE_ID == 23006){
				cmd = "DELSCENE_REMOTE_AC";
			}
			else if(DEVICE_TYPE_ID == 23001 || DEVICE_TYPE_ID == 23004 || DEVICE_TYPE_ID == 23005){
				cmd = "DELSCENE_REMOTE_DC";
			}
			else if(DEVICE_TYPE_ID == SEFTPOWER_REMOTE_1 || DEVICE_TYPE_ID == SEFTPOWER_REMOTE_2 || DEVICE_TYPE_ID == SEFTPOWER_REMOTE_3 || DEVICE_TYPE_ID == SEFTPOWER_REMOTE_6){
				cmd = "DELSCENE_REMOTE_DC";
				if (DATA.HasMember("DEVICE_PARENT_ID") && DATA["DEVICE_PARENT_ID"].IsString())
				{
					string deviceParentId = DATA["DEVICE_PARENT_ID"].GetString();
					deviceUnicastParent = DEVICE_UNICAST_ID(deviceParentId);
				}
			}
			json.String(const_cast<char*>(cmd.c_str()));
			json.Key("DATA");
			json.StartObject();
				json.Key("DEVICE_UNICAST_ID"); json.Int(DeviceUnicastId);
				if (deviceUnicastParent > 0)
				{
					json.Key("DEVICE_UNICAST_PARENT_ID");
					json.Int(deviceUnicastParent);
				}
				json.Key("DEVICE_TYPE_ID"); json.Int(DEVICE_TYPE_ID);
				json.Key("BUTTONID");json.String(const_cast<char*>(BUTTON_VALUE.c_str()));
				json.Key("MODEID");json.Int(MODE_VALUE);
			json.EndObject();
		json.EndObject();

		string s = sendToGW.GetString();
		cout<<s<<endl;
		MqttSend(mosq, const_cast<char*>(s.c_str()));
	}
	if(DEVICE_TYPE_ID == 23007){
		cmd = "ADDSCENE_REMOTE_DC";
		CreateNormalSceneRemote(0, DeviceUnicastId, DEVICE_TYPE_ID, 0, cmd, BUTTON_VALUE, MODE_VALUE);
	}
}

void ResetRemote(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	string DEVICE_ID = DATA["DEVICE_ID"].GetString();
	int DEVICE_TYPE_ID = DATA["DEVICE_TYPE_ID"].GetInt();
	ADR = -1;
	string sqlCheckDevice = "SELECT DeviceUnicastId FROM Device WHERE DeviceId='" + DEVICE_ID + "' AND DeviceTypeId = 1;";
	DB_Read( "ADR", sqlCheckDevice);
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
		json.Key("CMD");
		string DvTypeId = "";
		if(DEVICE_TYPE_ID == 23002 || DEVICE_TYPE_ID == 23006){
			DvTypeId = "ADDSCENE_REMOTE_AC";
		}
		if(DEVICE_TYPE_ID == 23001 || DEVICE_TYPE_ID == 23004 || DEVICE_TYPE_ID == 23005 || DEVICE_TYPE_ID == 23007){
			DvTypeId = "ADDSCENE_REMOTE_DC";
		}
		json.String(const_cast<char*>(DvTypeId.c_str()));
		json.Key("DATA");
		json.StartObject();
			json.Key("DEVICE_UNICAST_ID");json.Int(ADR);
		json.EndObject();
	json.EndObject();

	string s = sendToGW.GetString();
	cout<<s<<endl;
	MqttSend(mosq, const_cast<char*>(s.c_str()));
}
