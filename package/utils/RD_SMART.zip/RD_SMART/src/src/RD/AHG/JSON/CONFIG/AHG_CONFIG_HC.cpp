/*
 * AHG_CONFIG_HC.cpp
 *
 *  Created on: Dec 23, 2021
 *      Author: rd
 */

#include "AHG_CONFIG_HC.hpp"
#include <iostream>

void ResetHC(struct mosquitto *mosq, char* jobj){
	ResetDataResetNode();
	Document document;
	document.Parse(jobj);
	StringBuffer sendToGW;
	Writer<StringBuffer> jsonAHG(sendToGW);
		jsonAHG.StartObject();
		jsonAHG.Key("CMD");
		jsonAHG.String("RESETHC");
		jsonAHG.EndObject();
		string s = sendToGW.GetString();
		MqttSend(mosq, const_cast<char*>(s.c_str()));
		MqttSendAPP(mosq, "{\"CMD\":\"RESET_HC\",\"DATA\":{\"STATUS\":\"SUCCESS\"}}", true);
		ResetDB();
}

void UpdateValueSensor(struct mosquitto *mosq, char* jobj){
	ResetDataResetNode();
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	string DEVICE_ID = DATA["DEVICE_ID"].GetString();
	NumDvValue = 0;
	string CheckDvUnicastId = "SELECT DeviceUnicastId from Device where DeviceId='"+DEVICE_ID+"';";
	// cout << CheckDvUnicastId << endl;
	ADR = -1;
	DB_Read( "ADR", CheckDvUnicastId);
	int DvUnicastId = ADR;
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("ASK_PM_SENSOR");
	json.Key("DATA");
	json.StartObject();
		json.Key("DEVICE_UNICAST_ID");
		json.Int(DvUnicastId);
	json.EndObject();
	json.EndObject();

	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char*>(s.c_str()));
}

void VersionHC(struct mosquitto *mosq, char* jobj){
	FILE *file;
	char TempVerHC[16] = {0};
	file = fopen("/etc/version.txt", "r");
	if(!file){
		cout << "Can not open this file" << endl;
	}
	else{
		cout << "File is open" << endl;
	}
	fgets(TempVerHC, 16, file);
	fclose(file);
	char VerHC[16] = {0};
	for(int i=0; i<16; i++){
		if(TempVerHC[i] == '\n')
			break;
		VerHC[i]=TempVerHC[i];
	}
	char MacHC[20] = {0};
	GetMacAddress(MacHC);
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	json.StartObject();
	json.Key("CMD");
	json.String("VERSION_HC");
	json.Key("DATA");
		json.StartObject();
			json.Key("MAC");
			json.String(MacHC);
			json.Key("VERSION_HC");
			json.String(VerHC);
		json.EndObject();
	json.EndObject();
	string s = sendToApp.GetString();
	MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
}

void BackupHC(struct mosquitto *mosq, char* jobj){
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");json.String("BACKUP");
	json.Key("DATA");
	json.StartObject();
	json.Key("DIRECTORY");
	json.String("/root/rd.Sqlite");
	json.EndObject();
	json.EndObject();

	string s = sendToGW.GetString();
	cout<<s<<endl;
	MqttSend(mosq, const_cast<char*>(s.c_str()));
}

void UpdateHcMasterInfo(struct mosquitto *mosq, char* jobj)
{
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	if(DATA.HasMember("MAC") && DATA.HasMember("IP") && DATA.HasMember("PASS_MQTT") &&
		DATA["MAC"].IsString() && DATA["IP"].IsString() && DATA["PASS_MQTT"].IsString())
	{
		string mac = DATA["MAC"].GetString();
		string ip = DATA["IP"].GetString();
		string pass = DATA["PASS_MQTT"].GetString();
		if (mac != HcMasterInfo.Mac || ip != HcMasterInfo.Ip || pass != HcMasterInfo.PassMqtt)
		{
			// if (HcMasterInfo.Ip == "" || HcMasterInfo.Mac == "")
			// {
				HcMasterInfo.Ip = ip;
				HcMasterInfo.Mac = mac;
				HcMasterInfo.PassMqtt = pass;
				SetHcMasterInfo();
				string GetStatusHC = "ping -c3 " + HcMasterInfo.Ip;
				int result = system(GetStatusHC.c_str());
				if (result == 0)
				{
					pthread_create(&ThreadMqttMaster, NULL, MqttMaster, NULL);
				}
			// }
			// else
			// {
			// 	pthread_cancel(ThreadMqttMasterId);
			// 	pthread_join(ThreadMqttMasterId, NULL);
			// 	sleep (10);
			// 	string GetStatusHC = "ping -c3 " + HcMasterInfo.Ip;
			// 	int result = system(GetStatusHC.c_str());
			// 	if (result == 0)
			// 	{
			// 		pthread_create(&ThreadMqttMaster, NULL, MqttMaster, NULL);
			// 	}
			// }
		}
	}
}
