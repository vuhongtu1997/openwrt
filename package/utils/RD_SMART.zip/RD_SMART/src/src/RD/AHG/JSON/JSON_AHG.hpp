#ifndef RD_JSON_JSON_HPP_
#define RD_JSON_JSON_HPP_

#include "../../ShareData.hpp"
#include "../../GHA/JSON/JSON_GHA.hpp"
#include "../../MQTT/MQTT.hpp"

using namespace std;
using namespace rapidjson;

extern int DeviceValue[10];
extern int DeviceIdValue[10];
extern int NumDvValue;

extern int arrayID[200];
extern int arrayValue[200];
extern string deviceUpdate[200];
extern int numberDeviceUpdate;
extern int numProperties;

extern string DvIdInfo[200];
extern int DvUnicastIdInfo[200];
extern int ArrDvUnicast[256];
extern int DeviceDelScene[256];
extern int IdxDv;

extern int idx_dv;

extern int ADR;
extern long long TimeStamp;
extern string CONTROL;
extern int TYPE_DV;
extern int numDvUnicast;
extern int numDvUnicastDelScene;

extern int ArrInfoDvSceneDelay[256][4];
extern int IndexSceneDelay;

extern bool check_countdown;
extern string event_trigger_id_countdown;

extern queue<string> AHG_Msg;
extern queue<string> GHA_Msg;

void* AHG_MQTT(void *argv);
void* DB(void *argv);

//Parse Json APP
int JsonParseApp(char * jobj);
void Check_Cmd(struct mosquitto *mosq, char * jobj);

void SendDeviceToGW(struct mosquitto *mosq, int idDevice, int idControl, int value, bool HasACK);

void SendDVAddScene(int DVUnicast, int SceneUnicast, int Mode, int SceneRGB);
void SendEditScene(int DvUnicast, int SceneUnicast, int Mode, int SceneRGB);
void DelDVFromScene(int DvUnicast, int SceneUnicast, int Mode);

void AddGrToRoom(int DVUnicast, int GRUnicast);
void DelDVFromGR(int DvUnicast, int GrUnicast);

void ScanStop(string cmd);
void ScanStopPairingDevice(struct mosquitto *mosq, char *jobj);
void DelNode(struct mosquitto *mosq, char* jobj);

//GROUP
void CreateGroup(struct mosquitto *mosq, char* jobj);
void AddDeviceGroup(struct mosquitto *mosq, char* jobj);
void DelDeviceGroup(struct mosquitto *mosq, char* jobj);
void DelGroup(struct mosquitto *mosq, char* jobj);

void HcConnectToCloud(char* jobj);

/*-----------------------------------------------DATABASE---------------------------------------------------------*/

int DB_Read(string control, string sql);
int DB_Write(string sql);

void InsertIntoEventInputDVMapping(string RuleId, string DeviceId, int DeviceUnicastId);
void InsertIntoEventInputDVValue(string RuleId, string DeviceId, int DeviceUnicastId, int Properties, int TpyeComare, int Value1, int Value2);
void InsertIntoEvent(string EventId, string GroupId, int EventTypeId, int SceneUnicastId, int Priority, string Name,
					int LogicEvent, int HasTimer, string StartAt, string EndAt, int ValueCreate, int Status, int HasRepeater, int Monday,
					int Tuesday, int Wednesday, int Thurday, int Friday, int Staturday, int Sunday, int HasNoti, int Fade, string Room, int NotiDelay);

/*-----------------------------------------------#---------------------------------------------------------*/

int CreateGroupUnicastId();
int CreateSceneUnicastId();
int GetNextRoomId();
float GetDeviceVersion(string DEVICE_ID);
int SCENE_UNICAST_ID(string SCENE_ID);
int GROUP_UNICAST_ID(string GROUP_ID);
int DEVICE_UNICAST_ID(string DEVICE_ID);
int PARENT_DEVICE_UNICAST_ID(string DEVICE_ID);
int PARENT_DEVICE_UNICAST_ID(int DEVICE_UNICAST_ID);
int TYPE_DEVICE(string DEVICE_ID);
int TYPE_DEVICE(int DEVICE_UNICAST_ID);

#endif /* RD_JSON_JSON_HPP_ */
