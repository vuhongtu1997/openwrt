/*
 * AHG_CONTROL.hpp
 *
 *  Created on: Dec 23, 2021
 *      Author: rd
 */

#ifndef SRC_RD_AHG_JSON_CONTROL_AHG_CONTROL_HPP_
#define SRC_RD_AHG_JSON_CONTROL_AHG_CONTROL_HPP_

#include "../JSON_AHG.hpp"

//****************Điều khiển*******************

void ControlDevice(struct mosquitto *mosq, char* jobj);
void DeviceUpdate(struct mosquitto *mosq, char* jobj);
void ControlGroup(struct mosquitto *mosq, char* jobj);
void CallScene(struct mosquitto *mosq, char* jobj);
void FlashDevice(struct mosquitto *mosq, char* jobj);
void TapToRun(struct mosquitto *mosq, char *jobj);
void ControlSwitchDevice(struct mosquitto *mosq, char *jobj);
void ActionRule(struct mosquitto *mosq, char *jobj);

#endif /* SRC_RD_AHG_JSON_CONTROL_AHG_CONTROL_HPP_ */
