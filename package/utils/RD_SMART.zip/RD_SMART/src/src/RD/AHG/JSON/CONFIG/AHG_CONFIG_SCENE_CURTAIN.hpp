/*
 * AHG_CONFIG_SCENE_CURTAIN.hpp
 *
 *  Created on: Mar 15, 2022
 *      Author: rd
 */

#ifndef SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_SCENE_CURTAIN_HPP_
#define SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_SCENE_CURTAIN_HPP_

void CreateSceneForCurtain(struct mosquitto *mosq, char* jobj);
void DelSceneForCurtain(struct mosquitto *mosq, char* jobj);

#endif /* SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_SCENE_CURTAIN_HPP_ */
