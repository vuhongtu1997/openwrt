/*
 * AHG_CONFIG_RULE.cpp
 *
 *  Created on: Dec 23, 2021
 *      Author: rd
 */

#include <iostream>
#include "AHG_CONFIG_RULE.hpp"

void CreateCountDown(struct mosquitto *mosq, char *jobj)
{
	Document document;
	document.Parse(jobj);
	const Value &DATA = document["DATA"];
	string EVENT_TRIGGER_ID = DATA["EVENT_TRIGGER_ID"].GetString();
	string START_AT = DATA["START_AT"].GetString();
	string SCENE_ID = DATA["SCENE_ID"].GetString();

	ADR = -1;
	string sqlSceneUnicastId = "SELECT SceneUnicastID FROM EventTrigger WHERE EventTriggerId = '" + SCENE_ID + "';";
	DB_Read("ADR", sqlSceneUnicastId);

	string addEvent = "INSERT OR REPLACE INTO EventTrigger (EventTriggerId, GroupId, EventTriggerTypeId, "
					  "HasTimer, Priority, StartAt, StatusID, HasRepeater, LogicalOperatorID, FADE_IN) "
					  "values ('" +
					  EVENT_TRIGGER_ID + "', '" + EVENT_TRIGGER_ID + "', 2,"
																	 "1,1,'" +
					  START_AT + "',1 , 0, -1, 0);";
	cout << addEvent << endl;
	DB_Write(addEvent);

	string addSceneS = "INSERT OR REPLACE INTO EventTriggerOutputSceneMapping(EventTriggerId, SceneId, SceneUnicastId, Time) "
					   "values ('" +
					   EVENT_TRIGGER_ID + "', '" + SCENE_ID + "', " + to_string(ADR) + ",'" + START_AT + "');";
	cout << addSceneS << endl;
	DB_Write(addSceneS);
}

void DeleteCountDown(struct mosquitto *mosq, char *jobj)
{
	Document document;
	document.Parse(jobj);
	const Value &DATA = document["DATA"];
	string EVENT_TRIGGER_ID = DATA["EVENT_TRIGGER_ID"].GetString();
	string sqlEV = "DELETE FROM EVENTTRIGGER WHERE EventTriggerId = '" + EVENT_TRIGGER_ID + "';";
	DB_Write(sqlEV);

	string sqlSV = "DELETE FROM EventTriggerOutputSceneMapping WHERE EventTriggerId = '" + EVENT_TRIGGER_ID + "';";
	DB_Write(sqlSV);
}

void CreateCountDownSwitch(struct mosquitto *mosq, char *jobj)
{
	Document document;
	document.Parse(jobj);
	const Value &DATA = document["DATA"];
	string EVENT_TRIGGER_ID = DATA["EVENT_TRIGGER_ID"].GetString();
	string DEVICE_ID = DATA["DEVICE_ID"].GetString();
	string BUTTON_ID = DATA["BUTTON"].GetString();
	string CHANGE_AT = DATA["CHANGE_AT"].GetString();
	int CHANGE_TO = DATA["CHANGE_TO"].GetInt();
	int TempCategoryIdId = TYPE_DEVICE(DEVICE_ID);
	int DeviceUnicastId = DEVICE_UNICAST_ID(DEVICE_ID);
	int ButtonId = 0;
	if (BUTTON_ID.compare("BUTTON_1") == 0)
	{
		ButtonId = 11;
	}
	else if (BUTTON_ID.compare("BUTTON_2") == 0)
	{
		ButtonId = 12;
	}
	else if (BUTTON_ID.compare("BUTTON_3") == 0)
	{
		ButtonId = 13;
	}
	else if (BUTTON_ID.compare("BUTTON_4") == 0)
	{
		ButtonId = 14;
	}
	if (TempCategoryIdId == SWITCH_RGB_1 || TempCategoryIdId == SWITCH_RGB_1_NL || TempCategoryIdId == SWITCH_RGB_2 || TempCategoryIdId == SWITCH_RGB_3 || TempCategoryIdId == SWITCH_RGB_4 ||
			TempCategoryIdId == SWITCH_RGB_1_V || TempCategoryIdId == SWITCH_RGB_2_V || TempCategoryIdId == SWITCH_RGB_3_V || TempCategoryIdId == SWITCH_RGB_4_V || TempCategoryIdId == SOCKET_SWITCH_1 ||
			TempCategoryIdId == SWITCH_RGB_1N || TempCategoryIdId == SWITCH_RGB_2N || TempCategoryIdId == SWITCH_RGB_3N || TempCategoryIdId == SWITCH_RGB_4N ||
			TempCategoryIdId == SWITCH_RGB_1N_V || TempCategoryIdId == SWITCH_RGB_2N_V || TempCategoryIdId == SWITCH_RGB_3N_V || TempCategoryIdId == SWITCH_RGB_4N_V ||
			TempCategoryIdId == CDT_1 || TempCategoryIdId == CDT_2 || TempCategoryIdId == CDT_3 ||
			TempCategoryIdId == CDT_1_N || TempCategoryIdId == CDT_2_N || TempCategoryIdId == CDT_3_N ||
			TempCategoryIdId == SWITCH_RGB_BLEWF_1 || TempCategoryIdId == SWITCH_RGB_BLEWF_2 || TempCategoryIdId == SWITCH_RGB_BLEWF_3 || TempCategoryIdId == SWITCH_RGB_BLEWF_4 ||
			TempCategoryIdId == CDT_BLEWF_1 || TempCategoryIdId == CDT_BLEWF_2 || TempCategoryIdId == CDT_BLEWF_3)
	{
		DeviceUnicastId = DeviceUnicastId + ButtonId % 10 - 1;
		// cout << DeviceUnicastId << endl;
		ButtonId = 0;
		CONTROL = "";
		string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(DeviceUnicastId) + " AND DeviceTypeId = " + to_string(DEVICE_BLE) + ";";
		cout << sql << endl;
		DB_Read("CONTROL", sql);
		DEVICE_ID = CONTROL;
	}
		string AddEvent = "INSERT OR REPLACE INTO EventTrigger (EventTriggerId, GroupId, EventTriggerTypeId, "
						  "HasTimer, Priority, StartAt, StatusID, HasRepeater, LogicalOperatorID, FADE_IN) "
						  "values ('" + EVENT_TRIGGER_ID + "', '" + EVENT_TRIGGER_ID + "', 2,1,1,'" + CHANGE_AT + "',1 , 0, -1, 0);";
		cout << AddEvent << endl;
		DB_Write(AddEvent);
		string AddDvToEventMapping = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
									 "values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DeviceUnicastId) + ", 0);";
		cout << AddDvToEventMapping << endl;
		DB_Write(AddDvToEventMapping);
		string AddDvToEventValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
								   "(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
								   "values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DeviceUnicastId) + ", " + to_string(ButtonId) + ", " + to_string(CHANGE_TO) + ", '" + CHANGE_AT + "');";
		cout << AddDvToEventValue << endl;
		DB_Write(AddDvToEventValue);
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	json.StartObject();
	json.Key("CMD");
	json.String("POWER_SWITCH_TIMEOUT");
	json.Key("DATA");
	json.StartObject();
	json.Key("EVENT_TRIGGER_ID");
	json.String(const_cast<char *>(EVENT_TRIGGER_ID.c_str()));
	json.Key("DEVICE_ID");
	json.String(const_cast<char *>(DEVICE_ID.c_str()));
	json.Key("STATUS");
	json.String("SUCCESS");
	json.EndObject();
	json.EndObject();

	string s = sendToApp.GetString();
	MqttSendAPP(mosq, const_cast<char *>(s.c_str()), true);
}

void DeleteCountDownSwitch(struct mosquitto *mosq, char *jobj)
{
	Document document;
	document.Parse(jobj);
	const Value &DATA = document["DATA"];
	string EVENT_TRIGGER_ID = DATA["EVENT_TRIGGER_ID"].GetString();
	string DelDvEvent = "DELETE FROM EventTrigger WHERE EventTriggerId = '" + EVENT_TRIGGER_ID + "';";
	DB_Write(DelDvEvent);
	string DelDvEventValue = "DELETE FROM EventTriggerOutputDeviceSetupValue WHERE EventTriggerId = '" + EVENT_TRIGGER_ID + "';";
	DB_Write(DelDvEventValue);
	string DelDvEventMapping = "DELETE FROM EventTriggerOutputDeviceMapping WHERE EventTriggerId = '" + EVENT_TRIGGER_ID + "';";
	DB_Write(DelDvEventMapping);

	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("POWER_SWITCH_TIMEOUT");
	json.Key("DATA");
	json.StartObject();
	json.Key("EVENT_TRIGGER_ID");
	json.String(const_cast<char *>(EVENT_TRIGGER_ID.c_str()));
	json.Key("STATUS");
	json.String("SUCCESS");
	json.EndObject();
	json.EndObject();

	string s = sendToGW.GetString();
	cout << s << endl;
	MqttSendAPP(mosq, const_cast<char *>(s.c_str()), true);
}

void CreateRuleOutPut(struct mosquitto *mosq, char *jobj, string EVENT_TRIGGER_ID, string START_AT, string END_AT, int TYPE_RUN)
{
	Document RuleTime;
	RuleTime.Parse(jobj);
	if (RuleTime.IsObject())
	{
		const Value &DATA_RuleTime = RuleTime["DATA"];
		if (DATA_RuleTime.HasMember("OUTPUT_DEVICES"))
		{
			const Value &OUTPUT_DEVICES = DATA_RuleTime["OUTPUT_DEVICES"];
			for (rapidjson::SizeType i = 0; i < OUTPUT_DEVICES.Size(); i++)
			{
				string DEVICE_ID = OUTPUT_DEVICES[i]["DEVICE_ID"].GetString();
				int TempCategoryId = TYPE_DEVICE(DEVICE_ID);
				int DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
				const Value &PROPERTIES = OUTPUT_DEVICES[i]["PROPERTIES"];
				if (DEVICE_UNICAST != 0)
				{
					if (TYPE_RUN == 1)
					{
						string addDevice = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
										"values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", 0);";
						DB_Write(addDevice);
						addDevice = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
									"values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", 1);";
						DB_Write(addDevice);
						string addDeviceValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
												"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
												"values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", 0, 0, '" + END_AT + "');";
						DB_Write(addDeviceValue);
					}
					else
					{
						string addDeviceValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
												"values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", 0);";
						DB_Write(addDeviceValue);
					}
					for (rapidjson::SizeType i = 0; i < PROPERTIES.Size(); i++)
					{
						int ID = PROPERTIES[i]["ID"].GetInt();
						int VALUE = PROPERTIES[i]["VALUE"].GetInt();
						if (TempCategoryId == SWITCH_RGB_1 || TempCategoryId == SWITCH_RGB_1_NL	||
								TempCategoryId == SWITCH_RGB_2 || TempCategoryId == SWITCH_RGB_3 ||
								TempCategoryId == SWITCH_RGB_4 || TempCategoryId == CDT_1 ||
								TempCategoryId == CDT_2 || TempCategoryId == CDT_3 ||
								TempCategoryId == CDT_2_N || TempCategoryId == CDT_3_N ||
								TempCategoryId == CDT_4 || TempCategoryId == SWITCH_RGB_1_V || 
								TempCategoryId == SWITCH_RGB_2_V || TempCategoryId == SWITCH_RGB_3_V || 
								TempCategoryId == SWITCH_RGB_4_V || TempCategoryId == SOCKET_SWITCH_1 ||
								TempCategoryId == SWITCH_RGB_1N || TempCategoryId == SWITCH_RGB_2N ||
								TempCategoryId == SWITCH_RGB_3N || TempCategoryId == SWITCH_RGB_4N ||
								TempCategoryId == SWITCH_RGB_1N_V || TempCategoryId == SWITCH_RGB_2N_V ||
								TempCategoryId == SWITCH_RGB_3N_V || TempCategoryId == SWITCH_RGB_4N_V ||
								TempCategoryId == CT_AT_2N || TempCategoryId == CT_AT_3N ||
								TempCategoryId == CT_AT_5N || TempCategoryId == CDT_1_N ||
								TempCategoryId == SWITCH_RGB_BLEWF_1 || TempCategoryId == SWITCH_RGB_BLEWF_2 ||
								TempCategoryId == SWITCH_RGB_BLEWF_3 || TempCategoryId == SWITCH_RGB_BLEWF_4 ||
								TempCategoryId == CDT_BLEWF_1 || TempCategoryId == CDT_BLEWF_2 || TempCategoryId == CDT_BLEWF_3){
							DEVICE_UNICAST = ID % 10 + DEVICE_UNICAST - 1;
							CONTROL = "";
							string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(DEVICE_UNICAST) + " AND DeviceTypeId = " + to_string(DEVICE_BLE) + ";";
							DB_Read("CONTROL", sql);
							DEVICE_ID = CONTROL;
							ID = ATTRIBUTE_ONOFF;
							string addDevice = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
								"values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", 0);";
							DB_Write(addDevice);
							string addDeviceValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
													"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
													"values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", " + to_string(ID) + ", " + to_string(VALUE) + ", '" + START_AT + "');";
							DB_Write(addDeviceValue);
						}
						else{
							string addDevice = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
								"values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", 0);";
							DB_Write(addDevice);
							string addDeviceValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
													"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
													"values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", " + to_string(ID) + ", " + to_string(VALUE) + ", '" + START_AT + "');";
							DB_Write(addDeviceValue);
						}
					}
				}
			}
		}
		if (DATA_RuleTime.HasMember("OUTPUT_GROUPS"))
		{
			const Value &OUTPUT_GROUPS = DATA_RuleTime["OUTPUT_GROUPS"];
			for (rapidjson::SizeType i = 0; i < OUTPUT_GROUPS.Size(); i++)
			{
				string GROUP_ID = OUTPUT_GROUPS[i]["GROUP_ID"].GetString();
				// cout << GROUP_ID << endl;
				int GROUP_UNICAST = GROUP_UNICAST_ID(GROUP_ID);
				const Value &PROPERTIES = OUTPUT_GROUPS[i]["PROPERTIES"];
				if (GROUP_UNICAST != 0)
				{
					if (TYPE_RUN == 1)
					{
						string addGroup = "INSERT OR REPLACE INTO EventTriggerOutputGroupingMapping(EventTriggerId, GroupingId, GroupUnicastId, typerun) "
										"values ('" +
										EVENT_TRIGGER_ID + "', '" + GROUP_ID + "', " + to_string(GROUP_UNICAST) + ", 0);";
						cout << addGroup << endl;
						DB_Write(addGroup);
						string addGroup1 = "INSERT OR REPLACE INTO EventTriggerOutputGroupingMapping(EventTriggerId, GroupingId, GroupUnicastId, typerun) "
										"values ('" +
										EVENT_TRIGGER_ID + "', '" + GROUP_ID + "', " + to_string(GROUP_UNICAST) + ", 1);";
						DB_Write(addGroup1);
						string addGroup2 = "INSERT OR REPLACE INTO EventTriggerOutputGroupingSetupValue"
										"(EventTriggerId, GroupingId, GroupUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
										"values ('" +
										EVENT_TRIGGER_ID + "', '" + GROUP_ID + "', " + to_string(GROUP_UNICAST) + ", 0, 0, '" + END_AT + "');";
						cout << addGroup2 << endl;
						DB_Write(addGroup2);
					}
					else
					{
						string addDeviceS = "INSERT OR REPLACE INTO EventTriggerOutputGroupingMapping(EventTriggerId, GroupingId, GroupUnicastId, typerun) "
											"values ('" +
											EVENT_TRIGGER_ID + "', '" + GROUP_ID + "', " + to_string(GROUP_UNICAST) + ", 0);";
						DB_Write(addDeviceS);
					}
					for (rapidjson::SizeType i = 0; i < PROPERTIES.Size(); i++)
					{
						int ID = PROPERTIES[i]["ID"].GetInt();
						int VALUE = PROPERTIES[i]["VALUE"].GetInt();
						string addDeviceS = "INSERT OR REPLACE INTO EventTriggerOutputGroupingSetupValue"
											"(EventTriggerId, GroupingId, GroupUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
											"values ('" +
											EVENT_TRIGGER_ID + "', '" + GROUP_ID + "', " + to_string(GROUP_UNICAST) + ", " + to_string(ID) + ", " + to_string(VALUE) + ", '" + START_AT + "');";
						cout << addDeviceS << endl;
						DB_Write(addDeviceS);
					}
				}
			}
		}
		if (DATA_RuleTime.HasMember("OUTPUT_SCENES"))
		{
			const Value &OUTPUT_SCENES = DATA_RuleTime["OUTPUT_SCENES"];
			int TIME_DELAY = 0;
			for (rapidjson::SizeType i = 0; i < OUTPUT_SCENES.Size(); i++)
			{
				if (OUTPUT_SCENES[i].IsObject())
				{
					string SCENE_ID = OUTPUT_SCENES[i]["SCENE_ID"].GetString();
					TIME_DELAY = TIME_DELAY + OUTPUT_SCENES[i]["TIME"].GetInt();
					int SceneUnicastId = SCENE_UNICAST_ID(SCENE_ID);
					if (SceneUnicastId > 0)
					{
						string AddScene = "INSERT OR REPLACE INTO EventTriggerOutputSceneMapping(EventTriggerId, SceneId, SceneUnicastId, Time) "
										  "values ('" +
										  EVENT_TRIGGER_ID + "', '" + SCENE_ID + "', " + to_string(SceneUnicastId) + ", " + to_string(TIME_DELAY) + ");";
						cout << AddScene <<endl;
						DB_Write(AddScene);
					}
				}
				if (OUTPUT_SCENES[i].IsString())
				{
					string SCENE_ID = OUTPUT_SCENES[i]["SCENE_ID"].GetString();
					int SceneUnicastId = SCENE_UNICAST_ID(SCENE_ID);
					if (SceneUnicastId > 0)
					{
						string AddScene = "INSERT OR REPLACE INTO EventTriggerOutputSceneMapping(EventTriggerId, SceneId, SceneUnicastId, Time) "
										  "values ('" +
										  EVENT_TRIGGER_ID + "', '" + SCENE_ID + "', " + to_string(SceneUnicastId) + ", " + to_string(TIME_DELAY) + ");";
						DB_Write(AddScene);
					}
				}
			}
		}
			//		if(DATA_RuleTime.HasMember("OUTPUT_ROOMS")){
			//			const Value& OUTPUT_ROOMS = DATA_RuleTime["OUTPUT_ROOMS"];
			//			for(rapidjson::SizeType i=0; i<OUTPUT_ROOMS.Size(); i++){
			//				const Value& a = OUTPUT_ROOMS[i];
			//				string RoomId = a.GetString();
			//				int GROUP_UNICAST = GROUP_UNICAST_ID(RoomId);
			//				string addGroup = "INSERT OR REPLACE INTO EventTriggerOutputGroupingMapping(EventTriggerId, GroupingId, GroupUnicastId, typerun) "
			//						"values ('"+EVENT_TRIGGER_ID+"', '"+RoomId+"', "+to_string(GROUP_UNICAST)+", 0);";
			//				DB_Write( addGroup);
			//				string addGroup2 = "INSERT OR REPLACE INTO EventTriggerOutputGroupingSetupValue"
			//						"(EventTriggerId, GroupingId, GroupUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
			//						"values ('"+EVENT_TRIGGER_ID+"', '"+RoomId+"', "+to_string(GROUP_UNICAST)+", 0, 1, '" + END_AT +"');";
			//				DB_Write( addGroup2);
			//			}
			//		}
	}
}

void CreateRuleOutPutV2(struct mosquitto *mosq, char *jobj, string EVENT_TRIGGER_ID, string START_AT, string END_AT, int TYPE_RUN)
{
	Document RuleTime;
	RuleTime.Parse(jobj);
	if (RuleTime.IsObject())
	{
		const Value &DATA_RuleTime = RuleTime["data"];
		if (DATA_RuleTime.HasMember("output"))
		{
			int TIME_DELAY = 0;
			const Value &OUTPUT = DATA_RuleTime["output"];
			for (rapidjson::SizeType i = 0; i < OUTPUT.Size(); i++)
			{
				if (OUTPUT[i].HasMember("devId"))
				{
					string DEVICE_ID = OUTPUT[i]["devId"].GetString();
					int TempCategoryId = TYPE_DEVICE(DEVICE_ID);
					int DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
					const Value &PROPERTIES = OUTPUT[i]["data"];
					if (DEVICE_UNICAST != 0)
					{
						string addDeviceValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
												"values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", 0);";
						DB_Write(addDeviceValue);
						for (rapidjson::SizeType i = 0; i < PROPERTIES.Size(); i++)
						{
							int ID = PROPERTIES[i]["id"].GetInt();
							int VALUE = PROPERTIES[i]["value"].GetInt();
							if (TempCategoryId == SWITCH_RGB_1 || TempCategoryId == SWITCH_RGB_1_NL	||
									TempCategoryId == SWITCH_RGB_2 || TempCategoryId == SWITCH_RGB_3 ||
									TempCategoryId == SWITCH_RGB_4 || TempCategoryId == CDT_1 ||
									TempCategoryId == CDT_2 || TempCategoryId == CDT_3 ||
									TempCategoryId == CDT_2_N || TempCategoryId == CDT_3_N ||
									TempCategoryId == CDT_4 || TempCategoryId == SWITCH_RGB_1_V || 
									TempCategoryId == SWITCH_RGB_2_V || TempCategoryId == SWITCH_RGB_3_V || 
									TempCategoryId == SWITCH_RGB_4_V || TempCategoryId == SOCKET_SWITCH_1 ||
									TempCategoryId == SWITCH_RGB_1N || TempCategoryId == SWITCH_RGB_2N ||
									TempCategoryId == SWITCH_RGB_3N || TempCategoryId == SWITCH_RGB_4N ||
									TempCategoryId == SWITCH_RGB_1N_V || TempCategoryId == SWITCH_RGB_2N_V ||
									TempCategoryId == SWITCH_RGB_3N_V || TempCategoryId == SWITCH_RGB_4N_V ||
									TempCategoryId == CT_AT_2N || TempCategoryId == CT_AT_3N ||
									TempCategoryId == CT_AT_5N || TempCategoryId == CDT_1_N ||
									TempCategoryId == SWITCH_RGB_BLEWF_1 || TempCategoryId == SWITCH_RGB_BLEWF_2 ||
									TempCategoryId == SWITCH_RGB_BLEWF_3 || TempCategoryId == SWITCH_RGB_BLEWF_4 ||
									TempCategoryId == CDT_BLEWF_1 || TempCategoryId == CDT_BLEWF_2 || TempCategoryId == CDT_BLEWF_3){
								DEVICE_UNICAST = ID % 10 + DEVICE_UNICAST - 1;
								CONTROL = "";
								string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(DEVICE_UNICAST) + " AND DeviceTypeId = " + to_string(DEVICE_BLE) + ";";
								DB_Read("CONTROL", sql);
								DEVICE_ID = CONTROL;
								ID = ATTRIBUTE_ONOFF;
								string addDevice = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
									"values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", 0);";
								DB_Write(addDevice);
								string addDeviceValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
														"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
														"values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", " + to_string(ID) + ", " + to_string(VALUE) + ", '" + START_AT + "');";
								DB_Write(addDeviceValue);
							}
							else{
								string addDevice = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
									"values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", 0);";
								DB_Write(addDevice);
								string addDeviceValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
														"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
														"values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", " + to_string(ID) + ", " + to_string(VALUE) + ", '" + START_AT + "');";
								DB_Write(addDeviceValue);
							}
						}
					}
				}
				if (OUTPUT[i].HasMember("time"))
				{
					int time = OUTPUT[i]["time"].GetInt();
					TIME_DELAY = TIME_DELAY + time;
				}
				if (OUTPUT[i].HasMember("groupId"))
				{
					string GROUP_ID = OUTPUT[i]["groupId"].GetString();
					int TempCategoryId = TYPE_DEVICE(GROUP_ID);
					int GROUP_UNICAST = GROUP_UNICAST_ID(GROUP_ID);
					const Value &PROPERTIES = OUTPUT[i]["data"];
					if (GROUP_UNICAST != 0)
					{
						string addDeviceS = "INSERT OR REPLACE INTO EventTriggerOutputGroupingMapping(EventTriggerId, GroupingId, GroupUnicastId, typerun) "
											"values ('" +
											EVENT_TRIGGER_ID + "', '" + GROUP_ID + "', " + to_string(GROUP_UNICAST) + ", 0);";
						DB_Write(addDeviceS);
						for (rapidjson::SizeType i = 0; i < PROPERTIES.Size(); i++)
						{
							int ID = PROPERTIES[i]["id"].GetInt();
							int VALUE = PROPERTIES[i]["value"].GetInt();
							string addDevice = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
									"values ('" + EVENT_TRIGGER_ID + "', '" + GROUP_ID + "', " + to_string(GROUP_UNICAST) + ", 0);";
							DB_Write(addDevice);
							string addDeviceValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
													"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
													"values ('" + EVENT_TRIGGER_ID + "', '" + GROUP_ID + "', " + to_string(GROUP_UNICAST) + ", " + to_string(ID) + ", " + to_string(VALUE) + ", '" + START_AT + "');";
							DB_Write(addDeviceValue);
						}
					}
				}
				if (OUTPUT[i].HasMember("sceneId"))
				{
					string SCENE_ID = OUTPUT[i]["sceneId"].GetString();
					int SceneUnicastId = SCENE_UNICAST_ID(SCENE_ID);
					if (SceneUnicastId > 0)
					{
						string AddScene = "INSERT OR REPLACE INTO EventTriggerOutputSceneMapping(EventTriggerId, SceneId, SceneUnicastId, Time) "
										  "values ('" +
										  EVENT_TRIGGER_ID + "', '" + SCENE_ID + "', " + to_string(SceneUnicastId) + ", " + to_string(TIME_DELAY) + ");";
						cout << AddScene <<endl;
						DB_Write(AddScene);
					}
				}
			}
		}		
	}
}

void CreateRuleInput(struct mosquitto *mosq, char *jobj, string EVENT_TRIGGER_ID)
{
	// cout << jobj << endl;
	Document RuleOrInput;
	RuleOrInput.Parse(jobj);
	if (RuleOrInput.IsObject())
	{
		const Value &DATA_RuleOrInput = RuleOrInput["DATA"];
		if (DATA_RuleOrInput.HasMember("INPUT_DEVICES"))
		{
			const Value &DATA_DV_RuleOrInput = DATA_RuleOrInput["INPUT_DEVICES"];
			// cout << "test1" << endl;
			for (rapidjson::SizeType i = 0; i < DATA_DV_RuleOrInput.Size(); i++)
			{
				string DEVICE_ID = DATA_DV_RuleOrInput[i]["DEVICE_ID"].GetString();
				int DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
				if (DATA_DV_RuleOrInput[i].HasMember("FACE_ID"))
				{
					DEVICE_ID = DATA_DV_RuleOrInput[i]["FACE_ID"].GetString();
				}
				if (DATA_DV_RuleOrInput[i].HasMember("ZONE_ID"))
				{
					DEVICE_ID = DATA_DV_RuleOrInput[i]["ZONE_ID"].GetString();
				}
				const Value &DEVICE_ATTRIBUTE = DATA_DV_RuleOrInput[i]["DEVICE_ATTRIBUTE"];
				int DEVICE_ATTRIBUTE_ID = DEVICE_ATTRIBUTE["ID"].GetInt();
				const Value &VALUE = DEVICE_ATTRIBUTE["VALUE"];
				int LowValue = VALUE[0].GetInt();
				int HightValue = VALUE[1].GetInt();
				if (DEVICE_ATTRIBUTE_ID >= 113 && DEVICE_ATTRIBUTE_ID <= 119)
				{
					DEVICE_UNICAST = LowValue;
				}
				if (DEVICE_ATTRIBUTE_ID == 21 || DEVICE_ATTRIBUTE_ID == 22)
				{
					LowValue = LowValue * 10;
					HightValue = HightValue * 10;
				}
				int TempCategoryId = TYPE_DEVICE(DEVICE_ID);
				if (TempCategoryId == SWITCH_RGB_1 || TempCategoryId == SWITCH_RGB_1_NL	||
						TempCategoryId == SWITCH_RGB_2 || TempCategoryId == SWITCH_RGB_3 ||
						TempCategoryId == SWITCH_RGB_4 || TempCategoryId == CDT_1 ||
						TempCategoryId == CDT_2 || TempCategoryId == CDT_3 ||
						TempCategoryId == CDT_2_N || TempCategoryId == CDT_3_N ||
						TempCategoryId == CDT_4 || TempCategoryId == SWITCH_RGB_1_V ||
						TempCategoryId == SWITCH_RGB_2_V || TempCategoryId == SWITCH_RGB_3_V ||
						TempCategoryId == SWITCH_RGB_4_V || TempCategoryId == SOCKET_SWITCH_1 ||
						TempCategoryId == SWITCH_RGB_1N || TempCategoryId == SWITCH_RGB_2N ||
						TempCategoryId == SWITCH_RGB_3N || TempCategoryId == SWITCH_RGB_4N ||
						TempCategoryId == SWITCH_RGB_1N_V || TempCategoryId == SWITCH_RGB_2N_V ||
						TempCategoryId == SWITCH_RGB_3N_V || TempCategoryId == SWITCH_RGB_4N_V ||
						TempCategoryId == CT_AT_2N || TempCategoryId == CT_AT_3N ||
						TempCategoryId == CT_AT_5N || TempCategoryId == CDT_1_N ||
						TempCategoryId == SWITCH_RGB_BLEWF_1 || TempCategoryId == SWITCH_RGB_BLEWF_2 ||
						TempCategoryId == SWITCH_RGB_BLEWF_3 || TempCategoryId == SWITCH_RGB_BLEWF_4 ||
						TempCategoryId == CDT_BLEWF_1 || TempCategoryId == CDT_BLEWF_2 || TempCategoryId == CDT_BLEWF_3)
				{
					DEVICE_UNICAST = DEVICE_UNICAST + DEVICE_ATTRIBUTE_ID % 10 - 1;
					CONTROL = "";
					string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(DEVICE_UNICAST) + " AND DeviceTypeId = " + to_string(DEVICE_BLE) + ";";
					DB_Read("CONTROL", sql);
					DEVICE_ID = CONTROL;
					DEVICE_ATTRIBUTE_ID = ATTRIBUTE_ONOFF;
				}
				string InsertIntoEventTriggerInputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerInputDeviceMapping (EventTriggerId, DeviceId, DeviceUnicastId) values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ");";
				DB_Write(InsertIntoEventTriggerInputDeviceMapping);
				int ComparisionOperator = 0;
				if (LowValue == -1 && HightValue != -1)
				{
					ComparisionOperator = 4;
				}
				if (HightValue == -1 && LowValue != -1)
				{
					ComparisionOperator = 6;
				}
				if (HightValue != -1 && LowValue != -1)
				{
					ComparisionOperator = 7;
				}
				if (HightValue == LowValue)
				{
					ComparisionOperator = 1;
				}
				if (ComparisionOperator == 7)
				{
					string InserrtDeviceValue = "INSERT OR REPLACE INTO EventTriggerInputDeviceSetupValue "
								 "(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, ComparisonOperatorId, DeviceAttributeValue, DeviceAttributeValueMAX)"
								 "values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", " + to_string(DEVICE_ATTRIBUTE_ID) + "," + to_string(ComparisionOperator) + "," + to_string(LowValue) + "," + to_string(HightValue) + ");";
					cout << InserrtDeviceValue << endl;
					DB_Write(InserrtDeviceValue);
				}
				if (ComparisionOperator == 6)
				{
					string InserrtDeviceValue = "INSERT OR REPLACE INTO EventTriggerInputDeviceSetupValue "
								 "(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, ComparisonOperatorId, DeviceAttributeValue)"
								 "values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", " + to_string(DEVICE_ATTRIBUTE_ID) + "," + to_string(ComparisionOperator) + "," + to_string(LowValue) + ");";
					cout << InserrtDeviceValue << endl;
					DB_Write(InserrtDeviceValue);
				}
				if (ComparisionOperator == 4 || ComparisionOperator == 1)
				{
					string InserrtDeviceValue = "INSERT OR REPLACE INTO EventTriggerInputDeviceSetupValue "
								 "(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, ComparisonOperatorId, DeviceAttributeValue)"
								 "values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", " + to_string(DEVICE_ATTRIBUTE_ID) + "," + to_string(ComparisionOperator) + "," + to_string(HightValue) + ");";
					cout << InserrtDeviceValue << endl;
					DB_Write(InserrtDeviceValue);
				}
			}
		}
	}
}

void CreateRuleInputV2(struct mosquitto *mosq, char *jobj, string EVENT_TRIGGER_ID)
{
	// cout << jobj << endl;
	Document RuleOrInput;
	RuleOrInput.Parse(jobj);
	if (RuleOrInput.IsObject())
	{
		const Value &DATA= RuleOrInput["data"];
		if (DATA.HasMember("input"))
		{
			const Value &DATA_INPUT= DATA["input"];
			if (DATA_INPUT.HasMember("device"))
			{
				const Value &DATA_DV_RuleOrInput = DATA_INPUT["device"];
				for (rapidjson::SizeType i = 0; i < DATA_DV_RuleOrInput.Size(); i++)
				{
					string DEVICE_ID = DATA_DV_RuleOrInput[i]["id"].GetString();
					int DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
					const Value &DEVICE_ATTRIBUTE = DATA_DV_RuleOrInput[i]["data"];
					int DEVICE_ATTRIBUTE_ID = DEVICE_ATTRIBUTE["id"].GetInt();
					// const Value &VALUE = DEVICE_ATTRIBUTE["value"];
					int LowValue = DEVICE_ATTRIBUTE["value"].GetInt();
					int HightValue = 0;
					string op =  DEVICE_ATTRIBUTE["op"].GetString();
					int ComparisionOperator = 0;
					if (op == ">=" || ">")
					{
						ComparisionOperator = 6;
					}
					if (op == "<=" || "<")
					{
						ComparisionOperator = 4;
					}
					if (op == "==")
					{
						ComparisionOperator = 1;
						HightValue = LowValue; 
					}
					if (DEVICE_ATTRIBUTE_ID >= 113 && DEVICE_ATTRIBUTE_ID <= 119)
					{
						DEVICE_UNICAST = LowValue;
					}
					if (DEVICE_ATTRIBUTE_ID == 21 || DEVICE_ATTRIBUTE_ID == 22)
					{
						LowValue = LowValue * 10;
						HightValue = HightValue * 10;
					}
					int TempCategoryId = TYPE_DEVICE(DEVICE_ID);
					if (TempCategoryId == SWITCH_RGB_1 || TempCategoryId == SWITCH_RGB_1_NL	||
							TempCategoryId == SWITCH_RGB_2 || TempCategoryId == SWITCH_RGB_3 ||
							TempCategoryId == SWITCH_RGB_4 || TempCategoryId == CDT_1 ||
							TempCategoryId == CDT_2 || TempCategoryId == CDT_3 ||
							TempCategoryId == CDT_2_N || TempCategoryId == CDT_3_N ||
							TempCategoryId == CDT_4 || TempCategoryId == SWITCH_RGB_1_V ||
							TempCategoryId == SWITCH_RGB_2_V || TempCategoryId == SWITCH_RGB_3_V ||
							TempCategoryId == SWITCH_RGB_4_V || TempCategoryId == SOCKET_SWITCH_1 ||
							TempCategoryId == SWITCH_RGB_1N || TempCategoryId == SWITCH_RGB_2N ||
							TempCategoryId == SWITCH_RGB_3N || TempCategoryId == SWITCH_RGB_4N ||
							TempCategoryId == SWITCH_RGB_1N_V || TempCategoryId == SWITCH_RGB_2N_V ||
							TempCategoryId == SWITCH_RGB_3N_V || TempCategoryId == SWITCH_RGB_4N_V ||
							TempCategoryId == CT_AT_2N || TempCategoryId == CT_AT_3N ||
							TempCategoryId == CT_AT_5N || TempCategoryId == CDT_1_N ||
							TempCategoryId == SWITCH_RGB_BLEWF_1 || TempCategoryId == SWITCH_RGB_BLEWF_2 ||
							TempCategoryId == SWITCH_RGB_BLEWF_3 || TempCategoryId == SWITCH_RGB_BLEWF_4 ||
							TempCategoryId == CDT_BLEWF_1 || TempCategoryId == CDT_BLEWF_2 || TempCategoryId == CDT_BLEWF_3)
					{
						DEVICE_UNICAST = DEVICE_UNICAST + DEVICE_ATTRIBUTE_ID % 10 - 1;
						CONTROL = "";
						string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(DEVICE_UNICAST) + " AND DeviceTypeId = " + to_string(DEVICE_BLE) + ";";
						DB_Read("CONTROL", sql);
						DEVICE_ID = CONTROL;
						DEVICE_ATTRIBUTE_ID = ATTRIBUTE_ONOFF;
					}
					string InsertIntoEventTriggerInputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerInputDeviceMapping (EventTriggerId, DeviceId, DeviceUnicastId) values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ");";
					DB_Write(InsertIntoEventTriggerInputDeviceMapping);					
					if (LowValue == -1 && HightValue != -1)
					{
						ComparisionOperator = 4;
					}
					if (HightValue == -1 && LowValue != -1)
					{
						ComparisionOperator = 6;
					}
					if (HightValue != -1 && LowValue != -1)
					{
						ComparisionOperator = 7;
					}
					if (HightValue == LowValue)
					{
						ComparisionOperator = 1;
					}
					if (ComparisionOperator == 7)
					{
						string InserrtDeviceValue = "INSERT OR REPLACE INTO EventTriggerInputDeviceSetupValue "
									"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, ComparisonOperatorId, DeviceAttributeValue, DeviceAttributeValueMAX)"
									"values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", " + to_string(DEVICE_ATTRIBUTE_ID) + "," + to_string(ComparisionOperator) + "," + to_string(LowValue) + "," + to_string(HightValue) + ");";
						cout << InserrtDeviceValue << endl;
						DB_Write(InserrtDeviceValue);
					}
					if (ComparisionOperator == 6)
					{
						string InserrtDeviceValue = "INSERT OR REPLACE INTO EventTriggerInputDeviceSetupValue "
									"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, ComparisonOperatorId, DeviceAttributeValue)"
									"values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", " + to_string(DEVICE_ATTRIBUTE_ID) + "," + to_string(ComparisionOperator) + "," + to_string(LowValue) + ");";
						cout << InserrtDeviceValue << endl;
						DB_Write(InserrtDeviceValue);
					}
					if (ComparisionOperator == 4 || ComparisionOperator == 1)
					{
						string InserrtDeviceValue = "INSERT OR REPLACE INTO EventTriggerInputDeviceSetupValue "
									"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, ComparisonOperatorId, DeviceAttributeValue)"
									"values ('" + EVENT_TRIGGER_ID + "', '" + DEVICE_ID + "', " + to_string(DEVICE_UNICAST) + ", " + to_string(DEVICE_ATTRIBUTE_ID) + "," + to_string(ComparisionOperator) + "," + to_string(LowValue) + ");";
						cout << InserrtDeviceValue << endl;
						DB_Write(InserrtDeviceValue);
					}
				}
			}			
		}
	}
}

void CreateRule(struct mosquitto *mosq, char *jobj)
{
	Document document;
	document.Parse(jobj);
	const Value &DATA = document["DATA"];
	string EVENT_TRIGGER_ID = DATA["EVENT_TRIGGER_ID"].GetString();
	//	string GROUP_ID = DATA["GROUP_ID"].GetString();
	int EVENT_TRIGGER_TYPE_ID = 2;
	int PRIORITY = DATA["PRIORITY"].GetInt();
	int FADE_IN = 0;
	int FADE_OUT = 0;
	int FADE = 0;
	if (DATA.HasMember("FADE_IN"))
	{
		FADE_IN = DATA["FADE_IN"].GetInt();
		FADE = FADE_IN;
	}
	if (DATA.HasMember("FADE_OUT"))
	{
		FADE_OUT = DATA["FADE_OUT"].GetInt();
	}
	if (FADE_IN == -1 && FADE_OUT == -1)
	{
		FADE = 0;
	}
	if (FADE_IN == -1 && FADE_OUT != -1)
	{
		FADE = FADE_OUT;
	}
	if (FADE_IN != -1 && FADE_OUT == -1)
	{
		FADE = FADE_IN;
	}
	// cout << "FADE: " << FADE << " -- "
		//  << "FADEIN: " << FADE_IN << endl;
	string START_AT, END_AT;
	int HasTimer = 0;
	int LogicalOperatorId = -1, TPYE_RUN = 0;
	if (DATA.HasMember("START_AT") && DATA.HasMember("END_AT"))
	{
		START_AT = DATA["START_AT"].GetString();
		END_AT = DATA["END_AT"].GetString();
		HasTimer = 1;
	}
	else if (DATA.HasMember("START_AT") && !DATA.HasMember("END_AT"))
	{
		START_AT = DATA["START_AT"].GetString();
		HasTimer = 1;
	}
	if (DATA.HasMember("LOGICAL_OPERATOR_ID"))
	{
		LogicalOperatorId = DATA["LOGICAL_OPERATOR_ID"].GetInt();
	}
	if (DATA.HasMember("TURN_OFF_AT"))
	{
		TPYE_RUN = 1;
		END_AT = DATA["TURN_OFF_AT"].GetString();
	}
	int StatusId = DATA["STATUS"].GetInt();
	string addEvent = "INSERT OR REPLACE INTO EventTrigger (EventTriggerId, GroupId, StatusID, HasRepeater, EventTriggerTypeId, "
					  "HasTimer, Priority, StartAt, EndAt, LogicalOperatorID, FADE_IN) "
					  "values ('" + EVENT_TRIGGER_ID + "', '" + EVENT_TRIGGER_ID + "', " + to_string(StatusId) + ",0, " + to_string(EVENT_TRIGGER_TYPE_ID) + ","
					  "" +to_string(HasTimer) + "," + to_string(PRIORITY) + ",'" + START_AT + "','" + END_AT + "', " + to_string(LogicalOperatorId) + ", " + to_string(FADE) + ");";
	cout << addEvent << endl;
	DB_Write(addEvent);

	if (DATA.HasMember("EACH_DAY"))
	{
		const Value &EACH_DAY = DATA["EACH_DAY"];
		for (rapidjson::SizeType i = 0; i < EACH_DAY.Size(); i++)
		{
			string a = EACH_DAY[i].GetString();
			string updateDay = "UPDATE EventTrigger SET " + a + " = 1, HasRepeater = 1 WHERE EventTriggerId= '" + EVENT_TRIGGER_ID + "';";
			DB_Write(updateDay);
		}
	}

	// RULE theo thời gian
	if (LogicalOperatorId == -1 || LogicalOperatorId == -2)
	{
		CreateRuleOutPut(mosq, jobj, EVENT_TRIGGER_ID, START_AT, END_AT, TPYE_RUN);
	}

	// RULE theo inputdevice OR
	else if (LogicalOperatorId == 0 || LogicalOperatorId == 1 || LogicalOperatorId == 2 || LogicalOperatorId == 3)
	{
		CreateRuleInput(mosq, jobj, EVENT_TRIGGER_ID);
		CreateRuleOutPut(mosq, jobj, EVENT_TRIGGER_ID, START_AT, END_AT, TPYE_RUN);
	}

	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("EVENT_TRIGGER");
	json.Key("DATA");
	json.StartObject();
	json.Key("EVENT_TRIGGER_ID");
	json.String(const_cast<char *>(EVENT_TRIGGER_ID.c_str()));
	json.Key("STATUS");
	json.String("SUCCESS");
	json.EndObject();
	json.EndObject();

	string s = sendToGW.GetString();
	MqttSendAPP(mosq, const_cast<char *>(s.c_str()), true);
}

void RuleV2(struct mosquitto *mosq, char *jobj)
{
	Document document;
	document.Parse(jobj);
	const Value &DATA = document["data"];
	string EVENT_TRIGGER_ID = DATA["id"].GetString();
	int EVENT_TRIGGER_TYPE_ID = 2;
	int PRIORITY = 0;
	int FADE_IN = 0;
	int FADE_OUT = 0;
	int FADE = 0;
	string START_AT, END_AT;
	int HasTimer = 0;
	int LogicalOperatorId = -1, TPYE_RUN = 0;
	int HasTimeActive = 0;
	int EachDay[7] = {0};
	int HasRepeater = 0;
	if (DATA.HasMember("time"))
	{
		const Value &time = DATA["time"];
		if (time.HasMember("start") && time.HasMember("end") && time["start"].IsString()  && time["end"].IsString())
		{
			START_AT = time["start"].GetString();
			END_AT = time["end"].GetString();
			HasTimer = 1;
			HasTimeActive = 1;
		}
		if (time.HasMember("repeat") && time["repeat"].IsInt())
		{
			int Repeat = time["repeat"].GetInt();
			if (Repeat > 0)
			{
				EachDay[0] = Repeat & 1;
				EachDay[1] = Repeat >> 1 & 1;
				EachDay[2] = Repeat >> 2 & 1;
				EachDay[3] = Repeat >> 3 & 1;
				EachDay[4] = Repeat >> 4 & 1;
				EachDay[5] = Repeat >> 5 & 1;
				EachDay[6] = Repeat >> 6 & 1;
				HasRepeater = 1;
			}
		}
	}
	
	if (DATA.HasMember("type"))
	{
		LogicalOperatorId = DATA["type"].GetInt();
		if (HasTimeActive == 1)
		{
			if (LogicalOperatorId == 0)
				LogicalOperatorId = 1;
			if (LogicalOperatorId == 1)
				LogicalOperatorId = 2;
		}
	}
	if (DATA.HasMember("input"))
	{
		const Value &input = DATA["input"];
		if (input.HasMember("timer"))
		{
			const Value &timer = input["timer"];
			for (rapidjson::SizeType i = 0; i < timer.Size(); i++)
			{
				START_AT = timer["time"].GetString();
				if (timer.HasMember("repeat") && timer["repeat"].IsInt())
				{
					int Repeat = timer["repeat"].GetInt();
					if (Repeat > 0)
					{
						EachDay[0] = Repeat & 1;
						EachDay[1] = Repeat >> 1 & 1;
						EachDay[2] = Repeat >> 2 & 1;
						EachDay[3] = Repeat >> 3 & 1;
						EachDay[4] = Repeat >> 4 & 1;
						EachDay[5] = Repeat >> 5 & 1;
						EachDay[6] = Repeat >> 6 & 1;
						HasRepeater = 1;
					}
				}
			}
		}
	}
	if (HasRepeater)
	{
		for (int i = 0; i < 7; i++)
		{
			if (EachDay[i])
			{
				string a = "";
				string updateDay = "";
				switch (i)
				{
					case 0:
						a = "EachMonday";
						updateDay = "UPDATE EventTrigger SET " + a + " = 1 WHERE EventTriggerId= '" + EVENT_TRIGGER_ID + "';";
						DB_Write(updateDay);
					break;
					case 1:
						a = "EachTuesday";
						updateDay = "UPDATE EventTrigger SET " + a + " = 1 WHERE EventTriggerId= '" + EVENT_TRIGGER_ID + "';";
						DB_Write(updateDay);
					break;
					case 2:
						a = "EachWednesday";
						updateDay = "UPDATE EventTrigger SET " + a + " = 1 WHERE EventTriggerId= '" + EVENT_TRIGGER_ID + "';";
						DB_Write(updateDay);
					break;
					case 3:
						a = "EachThursday";
						updateDay = "UPDATE EventTrigger SET " + a + " = 1 WHERE EventTriggerId= '" + EVENT_TRIGGER_ID + "';";
						DB_Write(updateDay);
					break;
					case 4:
						a = "EachFriday";
						updateDay = "UPDATE EventTrigger SET " + a + " = 1 WHERE EventTriggerId= '" + EVENT_TRIGGER_ID + "';";
						DB_Write(updateDay);
					break;
					case 5:
						a = "EachSaturday";
						updateDay = "UPDATE EventTrigger SET " + a + " = 1 WHERE EventTriggerId= '" + EVENT_TRIGGER_ID + "';";
						DB_Write(updateDay);
					break;
					case 6:
						a = "EachSunday";
						updateDay = "UPDATE EventTrigger SET " + a + " = 1 WHERE EventTriggerId= '" + EVENT_TRIGGER_ID + "';";
						DB_Write(updateDay);
					break;
				}
			}
		}
	}
	int StatusId = 1;
	string addEvent = "INSERT OR REPLACE INTO EventTrigger (EventTriggerId, GroupId, StatusID, HasRepeater, EventTriggerTypeId, "
					  "HasTimer, Priority, StartAt, EndAt, LogicalOperatorID, FADE_IN) "
					  "values ('" + EVENT_TRIGGER_ID + "', '" + EVENT_TRIGGER_ID + "', " + to_string(StatusId) + ", " + to_string(HasRepeater) + ", " + to_string(EVENT_TRIGGER_TYPE_ID) + ","
					  "" +to_string(HasTimer) + "," + to_string(PRIORITY) + ",'" + START_AT + "','" + END_AT + "', " + to_string(LogicalOperatorId) + ", " + to_string(FADE) + ");";
	cout << addEvent << endl;
	DB_Write(addEvent);		

	// RULE theo thời gian
	if (LogicalOperatorId == -1 || LogicalOperatorId == -2)
	{
		CreateRuleOutPutV2(mosq, jobj, EVENT_TRIGGER_ID, START_AT, END_AT, TPYE_RUN);
	}

	// RULE theo inputdevice OR
	else if (LogicalOperatorId == 0 || LogicalOperatorId == 1 || LogicalOperatorId == 2 || LogicalOperatorId == 3)
	{
		CreateRuleInputV2(mosq, jobj, EVENT_TRIGGER_ID);
		CreateRuleOutPutV2(mosq, jobj, EVENT_TRIGGER_ID, START_AT, END_AT, TPYE_RUN);
	}

	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("cmd");
	json.String("createRuleRsp");
	json.Key("data");
	json.StartObject();
	json.Key("id");
	json.String(const_cast<char *>(EVENT_TRIGGER_ID.c_str()));
	json.Key("code");
	json.Int(0);
	json.EndObject();
	json.EndObject();

	string s = sendToGW.GetString();
	MqttSendAPP(mosq, const_cast<char *>(s.c_str()), true);
}

void DelRule(struct mosquitto *mosq, char *jobj, bool sendMsg)
{
	Document document;
	document.Parse(jobj);
	const Value &DATA = document["DATA"];
	string EVENT_TRIGGER_ID = DATA["EVENT_TRIGGER_ID"].GetString();
		string sqlEV = "DELETE FROM EVENTTRIGGER WHERE EventTriggerId = '" + EVENT_TRIGGER_ID + "';";
	DB_Write(sqlEV);
		string sqlD = "DELETE FROM EventTriggerOutputDeviceMapping WHERE EventTriggerId = '" + EVENT_TRIGGER_ID + "';";
	DB_Write(sqlD);
		string sqlG = "DELETE FROM EventTriggerOutputGroupingMapping WHERE EventTriggerId = '" + EVENT_TRIGGER_ID + "';";
	DB_Write(sqlG);
		string sqlDV = "DELETE FROM EventTriggerOutputDeviceSetupValue WHERE EventTriggerId = '" + EVENT_TRIGGER_ID + "';";
	DB_Write(sqlDV);
		string sqlGV = "DELETE FROM EventTriggerOutputGroupingSetupValue WHERE EventTriggerId = '" + EVENT_TRIGGER_ID + "';";
	DB_Write(sqlGV);
		string sqlSV = "DELETE FROM EventTriggerOutputSceneMapping WHERE EventTriggerId = '" + EVENT_TRIGGER_ID + "';";
	DB_Write(sqlSV);
		string sqlDVInput = "DELETE FROM EventTriggerInputDeviceMapping WHERE EventTriggerId = '" + EVENT_TRIGGER_ID + "';";
	DB_Write(sqlDVInput);
		string sqlDVInputVl = "DELETE FROM EventTriggerInputDeviceSetupValue WHERE EventTriggerId = '" + EVENT_TRIGGER_ID + "';";
	DB_Write(sqlDVInputVl);
	if (sendMsg == true)
	{
		StringBuffer sendToGW;
		Writer<StringBuffer> json(sendToGW);
		json.StartObject();
		json.Key("CMD");
		json.String("DELETE_EVENT_TRIGGER");
		json.Key("DATA");
		json.StartObject();
		json.Key("EVENT_TRIGGER_ID");
		json.String(const_cast<char *>(EVENT_TRIGGER_ID.c_str()));
		json.Key("STATUS");
		json.String("SUCCESS");
		json.EndObject();
		json.EndObject();

		string s = sendToGW.GetString();
		cout << s << endl;
		MqttSendAPP(mosq, const_cast<char *>(s.c_str()), true);
	}
}

void EditRule(struct mosquitto *mosq, char *jobj)
{
	DelRule(mosq, jobj, false);
	CreateRule(mosq, jobj);
}

void EditRuleV2(struct mosquitto *mosq, char *jobj)
{
	DelRule(mosq, jobj, false);
	RuleV2(mosq, jobj);
}

void UpdateStatusRule(struct mosquitto *mosq, char *jobj)
{
	Document document;
	document.Parse(jobj);
	const Value &DATA = document["DATA"];
	string EVENT_TRIGGER_ID = DATA["EVENT_TRIGGER_ID"].GetString();
	int Status = DATA["STATUS_ID"].GetInt();
	string UpdateRule = "UPDATE EventTrigger SET StatusID = " + to_string(Status) + " WHERE EventTriggerId = '" + EVENT_TRIGGER_ID + "';";
	DB_Write(UpdateRule);
	if (DATA.HasMember("HCL_IDS"))
	{
		const Value &HCL = DATA["HCL_IDS"];
		for (rapidjson::SizeType i = 0; i < HCL.Size(); i++)
		{
			string HCL_ID = HCL[i].GetString();
			string UpdateRule = "UPDATE EventTrigger SET StatusID = " + to_string(Status) + " WHERE EventTriggerId = '" + HCL_ID + "';";
			DB_Write(UpdateRule);
		}
	}
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("EVENT_TRIGGER_STATUS");
	json.Key("DATA");
	json.StartObject();
	json.Key("EVENT_TRIGGER_ID");
	json.String(const_cast<char *>(EVENT_TRIGGER_ID.c_str()));
	json.Key("STATUS");
	json.String("SUCCESS");
	json.EndObject();
	json.EndObject();

	string s = sendToGW.GetString();
	cout << s << endl;
	MqttSendAPP(mosq, const_cast<char *>(s.c_str()), true);
}

