/*
 * JSON_AHG.cpp
 *
 *  Created on: Apr 10, 2021
 *      Author: rd
 */

#include "../AHG/JSON/JSON_AHG.hpp"

queue<string> AHG_Msg;
queue<string> GHA_Msg;

int JsonParseApp(char * jobj){
	AHG_Msg.push(jobj);
	return 0;
}

void* AHG_MQTT(void *argv){
	bool send_massage = false;
	while(1){
		string Item_Pop = "";
		if(!AHG_Msg.empty()){
			Item_Pop = AHG_Msg.front();
			send_massage = true;
			AHG_Msg.pop();
		}
		if(send_massage == true){
			send_massage = false;
			// cout <<Item_Pop<<endl;
			Check_Cmd(mosq, const_cast<char*>(Item_Pop.c_str()));
			// cout <<Item_Pop<<endl;
		}
		usleep(10000);
	}
	return 0;
}
