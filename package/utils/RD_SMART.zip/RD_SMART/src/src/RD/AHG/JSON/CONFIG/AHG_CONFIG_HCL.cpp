/*
 * AHG_CONFIG_HCL.cpp
 *
 *  Created on: Dec 23, 2021
 *      Author: rd
 */

#include <iostream>
#include "AHG_CONFIG_HCL.hpp"
#include "AHG_CONFIG_RULE.hpp"

int ArrFade[24] = {0};
int ArrTime[24] = {0};
int ArrPercent[24] = {0};
int CountTime = 0;

int PathMinute(char* a){
	char h[4] = {0};
	char m[4] = {0};
//	char s[4] = {0};
	int temp = 0;
	int timer;
	unsigned int LenghtInputTime = strlen(a);
	int k = 0;
	for(unsigned int i=0; i<LenghtInputTime; i++){
		if(a[i] == '\0'){
			break;
		}
		if(a[i] == ':'){
			temp++;
			k = i;
		}
		else{
			if(temp == 0){
				h[i] = a[i];
			}
			else if(temp == 1){
				m[i-(k+1)] = a[i];
			}
//			else if(temp == 2){
//				s[i-(k+1)] = a[i];
//			}
		}
	}
	timer = atoi(h) * 60 + atoi(m);

	return timer;
}

void PartTime(string TimeOld, string TimeNew){
	CountTime = 0;
	for(int i=0; i<24; i++){
		ArrFade[i] = ArrPercent[i] = ArrTime[i] = 0;
	}
	int IntTimeOld = PathMinute(const_cast<char*>(TimeOld.c_str()));
	int IntTimeNew = PathMinute(const_cast<char*>(TimeNew.c_str()));
	int SumTime = IntTimeNew - IntTimeOld;
	if(SumTime%60 == 0){
		int Hour = SumTime/60;
		int PercentPerStep = 100/Hour;
		int Residual = 100-PercentPerStep*Hour;
		for(int i=0; i<Hour; i++){
			ArrFade[i] = 60;
			if(i == 0){
				ArrTime[i] = IntTimeOld;
			}
			else{
				ArrTime[i] = ArrTime[i-1] + ArrFade[i];
			}
			if(Residual != 0 && i >= Hour-Residual){
				ArrPercent[i] = PercentPerStep + 1;
			}
			else{
				ArrPercent[i] = PercentPerStep;
			}
			CountTime ++;
		}
	}
	if(SumTime%60 != 0 && SumTime/60 > 0){
		int Hour = SumTime/60;
		int PercentPerStepHour = 6000/SumTime;
		for(int i=0; i<Hour; i++){
			ArrFade[i] = 60;
			if(i == 0){
				ArrTime[i] = IntTimeOld;
			}
			else{
				ArrTime[i] = ArrTime[i-1] + ArrFade[i];
			}
			ArrPercent[i] = PercentPerStepHour;
			CountTime ++;
		}
		int Minute = SumTime%60;
		ArrFade[CountTime] = Minute;
		ArrTime[CountTime] =  ArrTime[CountTime-1] + 60;
		ArrPercent[CountTime] = 100 - PercentPerStepHour*Hour;
		CountTime ++;
	}
	if(SumTime%60 != 0 && SumTime/60 == 0){
		ArrFade[CountTime] = SumTime;
		ArrTime[CountTime] =  IntTimeOld;
		ArrPercent[CountTime] = 100;
		CountTime ++;
	}
	for(int i=0; i<CountTime; i++){
		if(i != 0){
			ArrPercent[i] = ArrPercent[i] + ArrPercent[i-1];
		}
	}
}

string PartHour(int a){
	int h = a/60;
	int m = a%60;
	string timerCheck = to_string(h) + ":" + to_string(m) + ":0";

	return timerCheck;
}

void CreateHCL(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	string EVENT_TRIGGER_ID = DATA["EVENT_TRIGGER_ID"].GetString();
	int STATUS = DATA["STATUS"].GetInt();
	string GROUP_ID = DATA["GROUP_ID"].GetString();
	int GROUP_UNICAST = GROUP_UNICAST_ID(GROUP_ID);
	string AddEvent = "INSERT OR REPLACE INTO EventTrigger (EventTriggerId, GroupId, StatusID, EventTriggerTypeId, HasRepeater) "
			"values ('" + EVENT_TRIGGER_ID + "', '" + EVENT_TRIGGER_ID + "', " + to_string(STATUS) +", 4, 0);";
	cout << AddEvent << endl;
	DB_Write( AddEvent);
	string AddGroup = "INSERT OR REPLACE INTO EventTriggerOutputGroupingMapping (EventTriggerId, GroupingId, GroupUnicastId, typerun) "
			"values ('" + EVENT_TRIGGER_ID + "', '" + GROUP_ID + "', " + to_string(GROUP_UNICAST) +", 0);";
	cout << AddGroup << endl;
	DB_Write( AddGroup);
	if(DATA.HasMember("EACH_DAY")){
		const Value& EACH_DAY = DATA["EACH_DAY"];
		for (rapidjson::SizeType i = 0; i < EACH_DAY.Size(); i++){
			string a = EACH_DAY[i].GetString();
			string updateDay = "UPDATE EventTrigger SET " + a + " = 1, HasRepeater = 1 WHERE EventTriggerId= '"+EVENT_TRIGGER_ID+"';";
			cout << updateDay << endl;
			DB_Write( updateDay);
		}
	}
	const Value& STATES = DATA["STATES"];
	int DimValue = 0;
	int TempDimValue = 0;
	int CCTValue = 0;
	int TempCCTValue = 0;
	string Time = "";
	for(rapidjson::SizeType i = 0; i < STATES.Size(); i++){
		cout << "State: "<<i<< endl;
		string StrTempTime = STATES[i]["TIME"].GetString();
		const Value& PROPERTIES = STATES[i]["PROPERTIES"];
		for(rapidjson::SizeType k = 0; k < PROPERTIES.Size(); k++){
			const Value& a = PROPERTIES[k];
			int ID = a["ID"].GetInt();
			int VALUE = a["VALUE"].GetInt();
			switch (ID){
				case 1:{
					TempDimValue = VALUE;
					if(i == 0){
						int IntTimeStart = PathMinute(const_cast<char*>(StrTempTime.c_str())) - 2;
						string AddGroupValueStart = "INSERT OR REPLACE INTO EventTriggerOutputGroupingSetupValue"
								"(EventTriggerId, GroupingId, GroupUnicastId, DeviceAttributeId, DeviceAttributeValue, Time, Fade) "
								"values ('"+EVENT_TRIGGER_ID+"', '"+GROUP_ID+"', "+to_string(GROUP_UNICAST)+", "+to_string(ID)+", "+to_string(TempDimValue)+", '"+ PartHour(IntTimeStart) +"', 1);";
						cout << AddGroupValueStart << endl;
						DB_Write( AddGroupValueStart);
						DimValue = TempDimValue;
						break;
					}
					if(i != 0){
						PartTime(Time, StrTempTime);
						for(int j=0; j<CountTime; j++){
							int DvValue = 0;
							if(DimValue < TempDimValue){
								DvValue = ((abs(TempDimValue-DimValue))*ArrPercent[j]/100) + DimValue;
							}
							else{
								DvValue = DimValue - (abs(TempDimValue-DimValue))*(ArrPercent[j])/100;
							}
							string AddGroupValue = "INSERT OR REPLACE INTO EventTriggerOutputGroupingSetupValue"
									"(EventTriggerId, GroupingId, GroupUnicastId, DeviceAttributeId, DeviceAttributeValue, Time, Fade) "
									"values ('"+EVENT_TRIGGER_ID+"', '"+GROUP_ID+"', "+to_string(GROUP_UNICAST)+", "+to_string(ID)+", "+to_string(DvValue)+", '" + PartHour(ArrTime[j]) +"', "+to_string(ArrFade[j])+");";
							cout << AddGroupValue << endl;
							DB_Write( AddGroupValue);
						}
						DimValue = TempDimValue;
					}
//					if(i == (STATES.Size()-1)){
//						string AddGroupValue = "INSERT OR REPLACE INTO EventTriggerOutputGroupingSetupValue"
//								"(EventTriggerId, GroupingId, GroupUnicastId, DeviceAttributeId, DeviceAttributeValue, Time, Fade) "
//								"values ('"+EVENT_TRIGGER_ID+"', '"+GROUP_ID+"', "+to_string(GROUP_UNICAST)+", "+to_string(ID)+", "+to_string(TempDimValue)+", 0, 1);";
//						cout << AddGroupValue << endl;
//						DB_Write( AddGroupValue);
//						DimValue = TempDimValue;
//					}
					break;
				};
				case 2:{
					TempCCTValue = VALUE;
					if(i == 0){
						int IntTimeStart = PathMinute(const_cast<char*>(StrTempTime.c_str())) - 2;
						string AddGroupValueStart = "INSERT OR REPLACE INTO EventTriggerOutputGroupingSetupValue"
								"(EventTriggerId, GroupingId, GroupUnicastId, DeviceAttributeId, DeviceAttributeValue, Time, Fade) "
								"values ('"+EVENT_TRIGGER_ID+"', '"+GROUP_ID+"', "+to_string(GROUP_UNICAST)+", "+to_string(ID)+", "+to_string(TempCCTValue)+", '"+ PartHour(IntTimeStart) +"', 1);";
						cout << AddGroupValueStart << endl;
						DB_Write( AddGroupValueStart);
						break;
					}
					if(i !=0 ){
						PartTime(Time, StrTempTime);
						for(int j=0; j<CountTime; j++){
							int DvValue = 0;
							if(CCTValue < TempCCTValue){
								DvValue = ((abs(TempCCTValue-CCTValue))*ArrPercent[j]/100) + CCTValue;
							}
							else{
								DvValue = CCTValue - ((abs(TempCCTValue-CCTValue))*(ArrPercent[j])/100);
							}
							string AddGroupValue = "INSERT OR REPLACE INTO EventTriggerOutputGroupingSetupValue"
									"(EventTriggerId, GroupingId, GroupUnicastId, DeviceAttributeId, DeviceAttributeValue, Time, Fade) "
									"values ('"+EVENT_TRIGGER_ID+"', '"+GROUP_ID+"', "+to_string(GROUP_UNICAST)+", "+to_string(ID)+", "+to_string(DvValue)+", '" + PartHour(ArrTime[j]) +"', "+to_string(ArrFade[j])+");";
							cout << AddGroupValue << endl;
							DB_Write( AddGroupValue);
						}
						CCTValue = TempCCTValue;
					}
					break;
				}
			}
		}
		Time = StrTempTime;
	}
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");
	json.String("EVENT_TRIGGER");
	json.Key("DATA");
	json.StartObject();
	json.Key("EVENT_TRIGGER_ID");
	json.String(const_cast<char*>(EVENT_TRIGGER_ID.c_str()));
	json.Key("STATUS");
	json.String("SUCCESS");
	json.EndObject();
	json.EndObject();

	string s = sendToGW.GetString();
	cout<<s<<endl;
	MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
}

void EditHCL(struct mosquitto *mosq, char* jobj){
	DelRule(mosq, jobj, false);
	CreateHCL(mosq,jobj);
}

void DeleteHCL(struct mosquitto *mosq, char* jobj){
	DelRule(mosq, jobj, true);
}

void UpdateStatusHCL(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	string EVENT_TRIGGER_ID = DATA["EVENT_TRIGGER_ID"].GetString();
	int STATUS = DATA["STATUS_ID"].GetInt();
	string UpdateStatusHCL = "UPDATE EventTrigger SET StatusID = "+to_string(STATUS)+" WHERE EventTriggerId = '"+EVENT_TRIGGER_ID+"';";
	DB_Write( UpdateStatusHCL);
	if(DATA.HasMember("DISABLE")){
		const Value& DISABLE = DATA["DISABLE"];
		for(rapidjson::SizeType i = 0; i < DISABLE.Size(); i++){
			const Value& EVENT = DISABLE[i];
			string EVENT_ID = EVENT.GetString();
			string UpdateStatusEvent = "UPDATE EventTrigger SET StatusID = 0 WHERE EventTriggerId = '"+EVENT_ID+"';";
			DB_Write( UpdateStatusEvent);
		}
	}
	CheckHCL.EvenTriggerId = EVENT_TRIGGER_ID;
	CheckHCL.Time = LocalTime("time");
	if(STATUS == 1){
		CheckHCL.Status = true;
	}
	else{
		CheckHCL.Status = false;
	}
}

