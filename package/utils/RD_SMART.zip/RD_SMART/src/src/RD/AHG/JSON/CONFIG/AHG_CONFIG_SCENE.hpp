/*
 * AHG_CONFIG_SCENE.hpp
 *
 *  Created on: Dec 23, 2021
 *      Author: vuhongtu
 */

#ifndef SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_SCENE_HPP_
#define SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_SCENE_HPP_

#include "../JSON_AHG.hpp"

void CreateScene(struct mosquitto *mosq, char* jobj);
void EditScene(struct mosquitto *mosq, char* jobj);
void DelScene(struct mosquitto *mosq, char* jobj);

void CreateSceneDelay(struct mosquitto *mosq, char* jobj);
void EditSceneDelay(struct mosquitto *mosq, char* jobj);
void DeleteSceneDelay(struct mosquitto *mosq, char* jobj);

#endif /* SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_SCENE_HPP_ */
