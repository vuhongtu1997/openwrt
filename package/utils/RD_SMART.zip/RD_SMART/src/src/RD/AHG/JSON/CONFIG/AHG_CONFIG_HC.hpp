/*
 * AHG_CONFIG_HC.hpp
 *
 *  Created on: Dec 23, 2021
 *      Author: rd
 */

#ifndef SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_HC_HPP_
#define SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_HC_HPP_

#include "../JSON_AHG.hpp"

//HC
void ResetHC(struct mosquitto *mosq, char* jobj);
void UpdateValueSensor(struct mosquitto *mosq, char* jobj);
void VersionHC(struct mosquitto *mosq, char* jobj);
void BackupHC(struct mosquitto *mosq, char* jobj);
void UpdateHcMasterInfo(struct mosquitto *mosq, char* jobj);

#endif /* SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_HC_HPP_ */
