/*
 * AHG_CONFIG_SWITCH.hpp
 *
 *  Created on: Aug 9, 2022
 *      Author: rd
 */

#ifndef SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_SWITCH_HPP_
#define SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_SWITCH_HPP_

void CreateSwitchCombine(char* jobj);
void EditSwitchCombine(char* jobj);
void DeleteSwitchCombine(char* jobj);

#endif /* SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_SWITCH_HPP_ */
