/*
 * AHG_CONFIG_SCENE_REMOTE.hpp
 *
 *  Created on: Dec 23, 2021
 *      Author: rd
 */

#ifndef SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_SCENE_REMOTE_HPP_
#define SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_SCENE_REMOTE_HPP_

#include "../JSON_AHG.hpp"

//SCENE FOR REMOTE
void CreateSceneForRemote(struct mosquitto *mosq, char* jobj);
void DelSceneForRemote(struct mosquitto *mosq, char* jobj);
void ResetRemote(struct mosquitto *mosq, char* jobj);

#endif /* SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_SCENE_REMOTE_HPP_ */
