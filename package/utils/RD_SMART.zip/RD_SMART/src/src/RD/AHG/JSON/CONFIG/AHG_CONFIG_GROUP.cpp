/*
 * AHG_CONFIG_GROUP.cpp
 *
 *  Created on: Mar 17, 2022
 *      Author: rd
 */

#include "AHG_CONFIG_GROUP.hpp"

void AddDeviceToGroup(struct mosquitto *mosq, int DeviceUnicastId, int GroupUnicastId, int ElementUnicastId){
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");json.String("ADDGROUP");
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");
	json.Int(DeviceUnicastId);
	json.Key("ELEMENT_UNICAST_ID");
	json.Int(ElementUnicastId);
	json.Key("GROUP_UNICAST_ID");json.Int(GroupUnicastId);
	json.EndObject();
	json.EndObject();

	string s = sendToGW.GetString();
	cout<<s<<endl;
	MqttSend(mosq, const_cast<char*>(s.c_str()));
}

void CreateGroup(struct mosquitto *mosq, char* jobj){
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutex) == 0){
			if(IsProcessDone == false){
				ResetDataGroup();
				IsProcessGroup = CREATE_GROUP;
				FlagCheckLock = true;
			}
			pthread_mutex_unlock(&mutex);
		}
		usleep (3000);
	}
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	if(DATA.HasMember("GROUP_ID") && DATA.HasMember("NAME") && DATA.HasMember("DEVICES")){
		string GROUP_ID = DATA["GROUP_ID"].GetString();
		string NAME = DATA["NAME"].GetString();
		//ADD DEVICE TO GROUP
		int GroupUnicastId = CreateGroupUnicastId();

		// string creGroupID = "INSERT OR REPLACE INTO GROUPID (GroupUnicastId, GroupingId, ValueCreate)"
		// 		" values ("+ to_string(GroupUnicastId) + ",'"+ GROUP_ID +"', 1); ";
		// DB_Write( creGroupID);
		string creGroup = "INSERT OR REPLACE INTO GROUPING (GroupingId, GroupUnicastId, Name)"
				" values ('"+ GROUP_ID + "', "+ to_string(GroupUnicastId) + ", '"+ NAME + "'); ";
		DB_Write( creGroup);
		const Value& DEVICES = DATA["DEVICES"];
		while (true){
			if(pthread_mutex_trylock(&mutex) == 0){
				ShareGroupUnicastId = GroupUnicastId;
				ShareGroupId = GROUP_ID;
				numDeviceGroup = DEVICES.Size();
				pthread_mutex_unlock(&mutex);
				break;
			}
			usleep (3000);
		}
		if(DEVICES.Size()==0){
			StringBuffer sendToGW;
			Writer<StringBuffer> jsonAHG(sendToGW);
			jsonAHG.StartObject();
				jsonAHG.Key("CMD");jsonAHG.String("CREAT_GROUP");
				jsonAHG.Key("DATA");
				jsonAHG.StartObject();
					jsonAHG.Key("GROUP_ID");jsonAHG.String(const_cast<char*>(GROUP_ID.c_str()));
					jsonAHG.Key("GROUP_UNCAST_ID");jsonAHG.Int(GroupUnicastId);
					jsonAHG.Key("SUCCESS");
						jsonAHG.StartArray();
						jsonAHG.EndArray();
					jsonAHG.Key("FAILED");
						jsonAHG.StartArray();
						jsonAHG.EndArray();
				jsonAHG.EndObject();
			jsonAHG.EndObject();

			string s = sendToGW.GetString();
			cout<<s<<endl;
			MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
		}
		else {
			const Value& DEVICES = DATA["DEVICES"];
			for (rapidjson::SizeType i = 0; i < DEVICES.Size(); i++){
				const Value& a = DEVICES[i];
				string DEVICE_ID = a.GetString();
				int DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
				int temp = PARENT_DEVICE_UNICAST_ID(DEVICE_ID);
				if (temp == 0)
				{
					temp = DEVICE_UNICAST;
				}
				AddDeviceToGroup(mosq, temp, GroupUnicastId, DEVICE_UNICAST);
				while (true){
					if(pthread_mutex_trylock(&mutex) == 0){
						DeviceGroup[i] = DEVICE_UNICAST;
						TimeOut = GetSecondTimeNow();
						pthread_mutex_unlock(&mutex);
						break;
					}
					usleep (3000);
				}
				string addDeviceGr = "INSERT OR REPLACE INTO GroupingDeviceMapping (GroupUnicastId, GroupingId, DeviceId, DeviceUnicastId)"
						" values ("+ to_string(GroupUnicastId) + ",'"+ GROUP_ID + "', '"+ DEVICE_ID + "' ,"+ to_string(DEVICE_UNICAST) + ");";
				DB_Write( addDeviceGr);
			}
		}
	}
	while (true){
		if(pthread_mutex_trylock(&mutex) == 0){
			IsProcessDone = true;
			pthread_mutex_unlock(&mutex);
			break;
		}
		usleep (3000);
	}
}

void AddDeviceGroup(struct mosquitto *mosq, char* jobj){
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutex) == 0){
			if(IsProcessDone == false){
				ResetDataGroup();
				IsProcessGroup = ADD_DEVICE_TO_GROUP;
				FlagCheckLock = true;
			}
			pthread_mutex_unlock(&mutex);
		}
		usleep (3000);
	}
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	if(DATA.HasMember("GROUP_ID") && DATA.HasMember("NAME") && DATA.HasMember("DEVICES")){
		string GROUP_ID = DATA["GROUP_ID"].GetString();
		string NAME = DATA["NAME"].GetString();
		//ADD DEVICE TO GROUP
		int GroupUnicastId = GROUP_UNICAST_ID(GROUP_ID);
		if(GroupUnicastId == 0){
			GroupUnicastId = CreateGroupUnicastId();
		}

		// string creGroupID = "INSERT OR REPLACE INTO GROUPID (GroupUnicastId, GroupingId, ValueCreate)"
		// 		" values ("+ to_string(GroupUnicastId) + ",'"+ GROUP_ID +"', 1); ";
		// DB_Write( creGroupID);
		string creGroup = "INSERT OR REPLACE INTO GROUPING (GroupingId, GroupUnicastId, Name)"
				" values ('"+ GROUP_ID + "', "+ to_string(GroupUnicastId) + ", '"+ NAME + "'); ";
		DB_Write( creGroup);
		const Value& DEVICES = DATA["DEVICES"];
		while (true){
			if(pthread_mutex_trylock(&mutex) == 0){
				ShareGroupUnicastId = GroupUnicastId;
				ShareGroupId = GROUP_ID;
				numDeviceGroup = DEVICES.Size();
				pthread_mutex_unlock(&mutex);
				break;
			}
			usleep (3000);
		}
		if(DEVICES.Size()==0){
			StringBuffer sendToGW;
			Writer<StringBuffer> jsonAHG(sendToGW);
			jsonAHG.StartObject();
				jsonAHG.Key("CMD");jsonAHG.String("CREAT_GROUP");
				jsonAHG.Key("DATA");
				jsonAHG.StartObject();
					jsonAHG.Key("GROUP_ID");jsonAHG.String(const_cast<char*>(GROUP_ID.c_str()));
					jsonAHG.Key("GROUP_UNCAST_ID");jsonAHG.Int(GroupUnicastId);
					jsonAHG.Key("SUCCESS");
						jsonAHG.StartArray();
						jsonAHG.EndArray();
					jsonAHG.Key("FAILED");
						jsonAHG.StartArray();
						jsonAHG.EndArray();
				jsonAHG.EndObject();
			jsonAHG.EndObject();

			string s = sendToGW.GetString();
			cout<<s<<endl;
			MqttSendAPP(mosq, const_cast<char*>(s.c_str()), true);
		}
		else {
			const Value& DEVICES = DATA["DEVICES"];
			for (rapidjson::SizeType i = 0; i < DEVICES.Size(); i++){
				const Value& a = DEVICES[i];
				string DEVICE_ID = a.GetString();
				int DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
				int temp = PARENT_DEVICE_UNICAST_ID(DEVICE_ID);
				if (temp == 0)
				{
					temp = DEVICE_UNICAST;
				}
				AddDeviceToGroup(mosq, temp, GroupUnicastId, DEVICE_UNICAST);
				while (true){
					if(pthread_mutex_trylock(&mutex) == 0){
						DeviceGroup[i] = DEVICE_UNICAST;
						TimeOut = GetSecondTimeNow();
						pthread_mutex_unlock(&mutex);
						break;
					}
					usleep (3000);
				}
				string addDeviceGr = "INSERT OR REPLACE INTO GroupingDeviceMapping (GroupUnicastId, GroupingId, DeviceId, DeviceUnicastId)"
						" values ("+ to_string(GroupUnicastId) + ",'"+ GROUP_ID + "', '"+ DEVICE_ID + "' ,"+ to_string(DEVICE_UNICAST) + ");";
				DB_Write( addDeviceGr);
			}
		}
	}
	while (true){
		if(pthread_mutex_trylock(&mutex) == 0){
			IsProcessDone = true;
			pthread_mutex_unlock(&mutex);
			break;
		}
		usleep (3000);
	}
}

void DelDeviceFromGroup(struct mosquitto *mosq, int DeviceUnicatId, int GroupUnicastId, int ElementUnicastId){
	StringBuffer sendToGW;
	Writer<StringBuffer> jsonAHG(sendToGW);
	jsonAHG.StartObject();
	jsonAHG.Key("CMD");
	jsonAHG.String("DELGROUP");
	jsonAHG.Key("DATA");
	jsonAHG.StartObject();
	jsonAHG.Key("DEVICE_UNICAST_ID");
	jsonAHG.Int(DeviceUnicatId);
	jsonAHG.Key("ELEMENT_UNICAST_ID");
	jsonAHG.Int(ElementUnicastId);
	jsonAHG.Key("GROUP_UNICAST_ID");
	jsonAHG.Int(GroupUnicastId);
	jsonAHG.EndObject();
	jsonAHG.EndObject();

	string s = sendToGW.GetString();
	cout << s << endl;
	MqttSend(mosq, const_cast<char*>(s.c_str()));
}

void DelDeviceGroup(struct mosquitto *mosq, char* jobj){
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutex) == 0){
			if(IsProcessDone == false){
				ResetDataGroup();
				IsProcessGroup = REMOVE_DEVICE_FROM_GROUP;
				FlagCheckLock = true;
			}
			pthread_mutex_unlock(&mutex);
		}
		usleep (3000);
	}
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	if(DATA.HasMember("GROUP_ID") && DATA.HasMember("DEVICES")){
		string GROUP_ID = DATA["GROUP_ID"].GetString();
		int GroupUnicastId = 0;
		if(DATA.HasMember("GROUP_UNICAST_ID")){
			GroupUnicastId = DATA["GROUP_UNICAST_ID"].GetInt();
		}
		else{
			GroupUnicastId = GROUP_UNICAST_ID(GROUP_ID);
		}
		const Value& DEVICES = DATA["DEVICES"];
		while (true){
			if(pthread_mutex_trylock(&mutex) == 0){
				ShareGroupUnicastId = GroupUnicastId;
				ShareGroupId = GROUP_ID;
				numDeviceGroup = DEVICES.Size();
				pthread_mutex_unlock(&mutex);
				break;
			}
			usleep (3000);
		}
		for (rapidjson::SizeType i = 0; i < DEVICES.Size(); i++){
			const Value& a = DEVICES[i];
			string DEVICE_ID = a.GetString();
			int DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
			int temp = PARENT_DEVICE_UNICAST_ID(DEVICE_ID);
			if (temp == 0)
			{
				temp = DEVICE_UNICAST;
			}
			DelDeviceFromGroup(mosq, temp, GroupUnicastId, DEVICE_UNICAST);
			while (true){
				if(pthread_mutex_trylock(&mutex) == 0){
					DeviceGroup[i] = DEVICE_UNICAST;
					TimeOut = GetSecondTimeNow();
					pthread_mutex_unlock(&mutex);
					break;
				}
				usleep (3000);
			}
		}
	}
	while (true){
		if(pthread_mutex_trylock(&mutex) == 0){
			IsProcessDone = true;
			pthread_mutex_unlock(&mutex);
			break;
		}
		usleep (3000);
	}
}

void DelGroup(struct mosquitto *mosq, char* jobj){
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutex) == 0){
			if(IsProcessDone == false){
				ResetDataGroup();
				IsProcessGroup = DELETE_GROUP;
				FlagCheckLock = true;
			}
			pthread_mutex_unlock(&mutex);
		}
		usleep (3000);
	}
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	string GROUP_ID = DATA["GROUP_ID"].GetString();
	int GroupUnicastId = 0;
	if(DATA.HasMember("GROUP_UNICAST_ID")){
		GroupUnicastId = DATA["GROUP_UNICAST_ID"].GetInt();
	}
	else{
		GroupUnicastId = GROUP_UNICAST_ID(GROUP_ID);
	}
	string GetDVIntoGroup = "SELECT DeviceUnicastId FROM GroupingDeviceMapping WHERE GroupingId = '"+GROUP_ID+"';";
	// cout << GetDVIntoGroup << endl;
	numDvUnicast = 0;
	DB_Read( "DEVICE_UNICAST", GetDVIntoGroup);
	while (true){
		if(pthread_mutex_trylock(&mutex) == 0){
			ShareGroupUnicastId = GroupUnicastId;
			ShareGroupId = GROUP_ID;
			numDeviceGroup = numDvUnicast;
			pthread_mutex_unlock(&mutex);
			break;
		}
		usleep (3000);
	}
	for(int i=0; i<numDvUnicast; i++){
		int temp = PARENT_DEVICE_UNICAST_ID(ArrDvUnicast[i]);
		if (temp == 0)
		{
			temp = ArrDvUnicast[i];
		}
		DelDeviceFromGroup(mosq, temp, GroupUnicastId, ArrDvUnicast[i]);
		while (true){
			if(pthread_mutex_trylock(&mutex) == 0){
				DeviceGroup[i] = ArrDvUnicast[i];
				TimeOut = GetSecondTimeNow();
				pthread_mutex_unlock(&mutex);
				break;
			}
			usleep (3000);
		}
	}
	string DelGroup = "INSERT OR REPLACE INTO GROUPID (GroupingId, GroupUnicastId, ValueCreate)"
				" values ('', "+ to_string(GroupUnicastId) + ", 0);";
	// cout << DelGroup << endl;
	DB_Write( DelGroup);
	while (true){
		if(pthread_mutex_trylock(&mutex) == 0){
			IsProcessDone = true;
			pthread_mutex_unlock(&mutex);
			break;
		}
		usleep (3000);
	}
}


