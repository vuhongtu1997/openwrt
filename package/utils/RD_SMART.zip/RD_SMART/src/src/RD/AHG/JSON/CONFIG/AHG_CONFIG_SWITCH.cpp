/*
 * AHG_CONFIG_SWITCH.cpp
 *
 *  Created on: Aug 9, 2022
 *      Author: rd
 */
#include <iostream>
#include "AHG_CONFIG_GROUP.hpp"
#include "AHG_CONFIG_SWITCH.hpp"

#define OLDER_SWITCH 	1
#define	NEW_SWITCH		2

using namespace std;
void ConnectionButton(int TempDeviceUnicastUd, int TempGroupUnicastId, int TempCategoryIdId){
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");json.String("SWITCH_CONTROL_COMBINE");
	json.Key("TYPE");json.Int(TempCategoryIdId);
	json.Key("DATA");
	json.StartObject();
	json.Key("DEVICE_UNICAST_ID");json.Int(TempDeviceUnicastUd);
	json.Key("ID");json.Int(TempGroupUnicastId);
	json.EndObject();
	json.EndObject();

	string s = sendToGW.GetString();
	cout<<s<<endl;
	MqttSend(mosq, const_cast<char*>(s.c_str()));
}

void CreateSwitchCombine(char* jobj){
	int TempGroupUnicastId = 0;
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	if(DATA.HasMember("ID") && DATA.HasMember("LIST_BUTTON_LINK")){
		string TempUUId = DATA["ID"].GetString();
		int TempDeviceTypeId = DATA["DEVICE_TYPE_ID"].GetInt();
		if (TempDeviceTypeId == OLDER_SWITCH) {
			string AddEvent = "INSERT OR REPLACE INTO EventTrigger (EventTriggerId) values ('" + TempUUId + "');";
			cout<<AddEvent<<endl;
			DB_Write( AddEvent);
			for(int i=1; i<=4; i++){
				string TempId = to_string(i) + "-" + TempUUId;
				string AddSubEvent = "INSERT OR REPLACE INTO EventTrigger (EventTriggerId, GroupId, EventTriggerTypeId, StatusID, LogicalOperatorID, FADE_IN) values ('" + TempId + "', '" + TempId + "', 2, 1, 1, 0);";
				cout<<AddSubEvent<<endl;
				DB_Write(AddSubEvent);

				string AddSubEventIntoSubEventTrigger = "INSERT OR REPLACE INTO SubEventTrigger (EventTriggerId, SubEventTriggerId) values ('" + TempUUId + "', '" + TempId + "');";
				cout<<AddSubEventIntoSubEventTrigger<<endl;
				DB_Write(AddSubEventIntoSubEventTrigger);
			}
		}
		else{
			TempGroupUnicastId = CreateGroupUnicastId();
			string CreateGroupId = "INSERT OR REPLACE INTO GROUPID (GroupUnicastId, GroupingId, ValueCreate)"
					" values ("+ to_string(TempGroupUnicastId) + ",'"+ TempUUId +"', 1); ";
			DB_Write(CreateGroupId);
			string CreateGroup = "INSERT OR REPLACE INTO GROUPING (GroupingId, GroupUnicastId)"
					" values ('"+ TempUUId + "', "+ to_string(TempGroupUnicastId) + "); ";
			DB_Write(CreateGroup);
		}
		const Value& LIST_BUTTON_LINK = DATA["LIST_BUTTON_LINK"];
		for(rapidjson::SizeType i = 0; i < LIST_BUTTON_LINK.Size(); i++){
			string TempDeviceId = LIST_BUTTON_LINK[i]["DEVICE_ID"].GetString();
			int TempButtonId = LIST_BUTTON_LINK[i]["BUTTON_ID"].GetInt();
			int TempDeviceUnicastId = DEVICE_UNICAST_ID(TempDeviceId);
			int TempCategoryIdId =  TYPE_DEVICE(TempDeviceId);
			if (TempDeviceTypeId == NEW_SWITCH) {
				int TempElementUnicastId = TempDeviceUnicastId;
				string SubDeviceId = TempDeviceId;
				if(TempButtonId != 11){
					TempElementUnicastId = TempButtonId%10 + TempDeviceUnicastId - 1;
					// cout << TempElementUnicastId << "----" << TempButtonId%10 << endl;
					CONTROL = "";
					string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = "+ to_string(TempElementUnicastId) +";";
					DB_Read("CONTROL", sql);
					SubDeviceId = CONTROL;
				}
				AddDeviceToGroup(mosq, TempDeviceUnicastId, TempGroupUnicastId, TempElementUnicastId);
				ConnectionButton(TempElementUnicastId, TempGroupUnicastId, TempCategoryIdId);
				string TempAddDeviceGroup = "INSERT OR REPLACE INTO GroupingDeviceMapping (GroupUnicastId, GroupingId, DeviceId, DeviceUnicastId)"
						" values ("+ to_string(TempGroupUnicastId) + ",'"+ TempUUId + "', '"+ SubDeviceId + "' ,"+ to_string(TempElementUnicastId) + ");";
				DB_Write(TempAddDeviceGroup);
			}
			else{
				if(i == 0){
					string Rule1InsertIntoEventTriggerInputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerInputDeviceMapping "
							"(EventTriggerId, DeviceId, DeviceUnicastId) values ('1-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempButtonId)+");";
					DB_Write(Rule1InsertIntoEventTriggerInputDeviceMapping);
					string Rule2InsertIntoEventTriggerInputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerInputDeviceMapping "
							"(EventTriggerId, DeviceId, DeviceUnicastId) values ('2-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempButtonId)+");";
					DB_Write(Rule2InsertIntoEventTriggerInputDeviceMapping);
					string Rule1IntertIntoEventTriggerInputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerInputDeviceSetupValue "
							"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, ComparisonOperatorId, DeviceAttributeValue, DeviceAttributeValueMAX)"
							"values ('1-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+",1,1,1)";
					DB_Write(Rule1IntertIntoEventTriggerInputDeviceSetupValue);
					string Rule2IntertIntoEventTriggerInputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerInputDeviceSetupValue "
							"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, ComparisonOperatorId, DeviceAttributeValue, DeviceAttributeValueMAX)"
							"values ('2-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+",1,0,0)";
					DB_Write(Rule2IntertIntoEventTriggerInputDeviceSetupValue);
					string Rule3IntertIntoEventTriggerOutputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
							"values ('3-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", 0);";
					DB_Write(Rule3IntertIntoEventTriggerOutputDeviceMapping);
					string Rule4IntertIntoEventTriggerOutputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
							"values ('4-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", 0);";
					DB_Write(Rule4IntertIntoEventTriggerOutputDeviceMapping);
					string Rule3IntertIntoEventTriggerOutputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
							"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
							"values ('3-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+", "+to_string(1)+", '""');";
					DB_Write(Rule3IntertIntoEventTriggerOutputDeviceSetupValue);
					string Rule4IntertIntoEventTriggerOutputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
							"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
							"values ('4-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+", "+to_string(0)+", '""');";
					DB_Write(Rule4IntertIntoEventTriggerOutputDeviceSetupValue);
				}
				else if(i == 1){
					string Rule3InsertIntoEventTriggerInputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerInputDeviceMapping "
							"(EventTriggerId, DeviceId, DeviceUnicastId) values ('3-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempButtonId)+");";
					DB_Write(Rule3InsertIntoEventTriggerInputDeviceMapping);
					string Rule4InsertIntoEventTriggerInputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerInputDeviceMapping "
							"(EventTriggerId, DeviceId, DeviceUnicastId) values ('4-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempButtonId)+");";
					DB_Write(Rule4InsertIntoEventTriggerInputDeviceMapping);
					string Rule3IntertIntoEventTriggerInputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerInputDeviceSetupValue "
							"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, ComparisonOperatorId, DeviceAttributeValue, DeviceAttributeValueMAX)"
							"values ('3-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+",1,1,1)";
					DB_Write(Rule3IntertIntoEventTriggerInputDeviceSetupValue);
					string Rule4IntertIntoEventTriggerInputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerInputDeviceSetupValue "
							"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, ComparisonOperatorId, DeviceAttributeValue, DeviceAttributeValueMAX)"
							"values ('4-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+",1,0,0)";
					DB_Write(Rule4IntertIntoEventTriggerInputDeviceSetupValue);
					string Rule1IntertIntoEventTriggerOutputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
							"values ('1-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", 0);";
					DB_Write(Rule1IntertIntoEventTriggerOutputDeviceMapping);
					string Rule2IntertIntoEventTriggerOutputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
							"values ('2-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", 0);";
					DB_Write(Rule2IntertIntoEventTriggerOutputDeviceMapping);
					string Rule1IntertIntoEventTriggerOutputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
							"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
							"values ('1-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+", "+to_string(1)+", '""');";
					DB_Write(Rule1IntertIntoEventTriggerOutputDeviceSetupValue);
					string Rule2IntertIntoEventTriggerOutputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
							"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
							"values ('2-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+", "+to_string(0)+", '""');";
					DB_Write(Rule2IntertIntoEventTriggerOutputDeviceSetupValue);
				}
			}
		}
	}
}

void EditSwitchCombine(char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	if(DATA.HasMember("ID")){
		string TempUUId = DATA["ID"].GetString();
		int TempDeviceTypeId = DATA["DEVICE_TYPE_ID"].GetInt();
		if(TempDeviceTypeId == NEW_SWITCH) {
			int TempGroupUnicastId = GROUP_UNICAST_ID(TempUUId);
			const Value& ADD_BUTTON = DATA["ADD_BUTTON"];
			for(rapidjson::SizeType i = 0; i < ADD_BUTTON.Size(); i++){
				string TempDeviceId = ADD_BUTTON[i]["DEVICE_ID"].GetString();
				int TempButtonId = ADD_BUTTON[i]["BUTTON_ID"].GetInt();
				int TempDeviceUnicastId = DEVICE_UNICAST_ID(TempDeviceId);
				int TempCategoryIdId =  TYPE_DEVICE(TempDeviceId);
				if (TempDeviceTypeId == NEW_SWITCH) {
					int TempElementUnicastId = TempDeviceUnicastId;
					string SubDeviceId = TempDeviceId;
					if(TempButtonId != 11){
						TempElementUnicastId = TempButtonId%10 + TempDeviceUnicastId - 1;
						CONTROL = "";
						string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = "+ to_string(TempElementUnicastId) +";";
						DB_Read("CONTROL", sql);
						SubDeviceId = CONTROL;
					}
					AddDeviceToGroup(mosq, TempDeviceUnicastId, TempGroupUnicastId, TempElementUnicastId);
					ConnectionButton(TempElementUnicastId, TempGroupUnicastId, TempCategoryIdId);
					string TempAddDeviceGroup = "INSERT OR REPLACE INTO GroupingDeviceMapping (GroupUnicastId, GroupingId, DeviceId, DeviceUnicastId)"
							" values ("+ to_string(TempGroupUnicastId) + ",'"+ TempUUId + "', '"+ SubDeviceId + "' ,"+ to_string(TempElementUnicastId) + ");";
					DB_Write(TempAddDeviceGroup);
				}
			}
			const Value& REMOVE_BUTTON = DATA["REMOVE_BUTTON"];
			for(rapidjson::SizeType i = 0; i < REMOVE_BUTTON.Size(); i++){
				string TempDeviceId = REMOVE_BUTTON[i]["DEVICE_ID"].GetString();
				int TempCategoryIdId =  TYPE_DEVICE(TempDeviceId);
				int TempButtonId = REMOVE_BUTTON[i]["BUTTON_ID"].GetInt();
				int TempDeviceUnicastId = DEVICE_UNICAST_ID(TempDeviceId);
				int TempElementUnicastId = TempDeviceUnicastId;
				if(TempButtonId != 11){
					TempElementUnicastId = TempDeviceUnicastId + TempButtonId%10 - 1;
				}
				DelDeviceFromGroup(mosq, TempDeviceUnicastId, TempGroupUnicastId, TempElementUnicastId);
				ConnectionButton(TempElementUnicastId, 0, TempCategoryIdId);
				string DeleteSwitchCombine = "DELETE FROM GroupingDeviceMapping WHERE GroupingId = '"+ TempUUId +"' AND DeviceUnicastId = "+ to_string(TempElementUnicastId) +";";
				DB_Write(DeleteSwitchCombine);
			}
		}
		else if(TempDeviceTypeId == OLDER_SWITCH){
			for(int i=1; i<=4; i++){
				string GetDeviceFromRuleDeviceInput = "SELECT DISTINCT DeviceId, DeviceUnicastId, DeviceAttributeId FROM EventTriggerOutputDeviceSetupValue WHERE EventTriggerId = '"+to_string(i)+"-"+TempUUId+"';";
				// cout << GetDeviceFromRuleDeviceInput << endl;
				DB_Read("GET_DEVICEFROMRULEDEVICEINPUT", GetDeviceFromRuleDeviceInput);
				string DeleteEventTriggerInputDeviceMapping = "DELETE FROM EventTriggerInputDeviceMapping WHERE EventTriggerId = '"+to_string(i)+"-"+TempUUId+"';";
				DB_Write(DeleteEventTriggerInputDeviceMapping);
				string DeleteEventTriggerInputDeviceSetupValue = "DELETE FROM EventTriggerInputDeviceSetupValue WHERE EventTriggerId = '"+to_string(i)+"-"+TempUUId+"';";
				DB_Write(DeleteEventTriggerInputDeviceSetupValue);
				string DeleteEventTriggerOutputDeviceMapping = "DELETE FROM EventTriggerOutputDeviceMapping WHERE EventTriggerId = '"+to_string(i)+"-"+TempUUId+"';";
				DB_Write(DeleteEventTriggerOutputDeviceMapping);
				string DeleteEventTriggerOutputDeviceSetupValue = "DELETE FROM EventTriggerOutputDeviceSetupValue WHERE EventTriggerId = '"+to_string(i)+"-"+TempUUId+"';";
				DB_Write(DeleteEventTriggerOutputDeviceSetupValue);
//				string DeleteSubEventTrigger = "DELETE FROM SubEventTrigger WHERE EventTriggerId = '"+to_string(i)+"-"+TempUUId+"';";
//				DB_Write(DeleteSubEventTrigger);
//				string DeleteEventTrigger = "DELETE FROM EventTrigger WHERE EventTriggerId = '"+to_string(i)+"-"+TempUUId+"';";
//				DB_Write(DeleteEventTrigger);
			}
//			string DeleteEventTrigger = "DELETE FROM EventTrigger WHERE EventTriggerId = '"+TempUUId+"';";
//			DB_Write(DeleteEventTrigger);
			const Value& ADD_BUTTON = DATA["ADD_BUTTON"];
			string TempDeviceId = "";
			int TempButtonId = 0;
			int TempDeviceUnicastId = 0;
			// cout << "so luong button thay the: " << ADD_BUTTON.Size() << endl;
			for(rapidjson::SizeType i = 0; i < ADD_BUTTON.Size(); i++){
				TempDeviceId = ADD_BUTTON[i]["DEVICE_ID"].GetString();
				TempButtonId = ADD_BUTTON[i]["BUTTON_ID"].GetInt();
				TempDeviceUnicastId = DEVICE_UNICAST_ID(TempDeviceId);
				if(i == 0){
					string Rule1InsertIntoEventTriggerInputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerInputDeviceMapping "
							"(EventTriggerId, DeviceId, DeviceUnicastId) values ('1-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempButtonId)+");";
					DB_Write(Rule1InsertIntoEventTriggerInputDeviceMapping);
					string Rule2InsertIntoEventTriggerInputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerInputDeviceMapping "
							"(EventTriggerId, DeviceId, DeviceUnicastId) values ('2-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempButtonId)+");";
					DB_Write(Rule2InsertIntoEventTriggerInputDeviceMapping);
					string Rule1IntertIntoEventTriggerInputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerInputDeviceSetupValue "
							"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, ComparisonOperatorId, DeviceAttributeValue, DeviceAttributeValueMAX)"
							"values ('1-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+",1,1,1)";
					DB_Write(Rule1IntertIntoEventTriggerInputDeviceSetupValue);
					string Rule2IntertIntoEventTriggerInputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerInputDeviceSetupValue "
							"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, ComparisonOperatorId, DeviceAttributeValue, DeviceAttributeValueMAX)"
							"values ('2-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+",1,0,0)";
					DB_Write(Rule2IntertIntoEventTriggerInputDeviceSetupValue);
					string Rule3IntertIntoEventTriggerOutputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
							"values ('3-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", 0);";
					DB_Write(Rule3IntertIntoEventTriggerOutputDeviceMapping);
					string Rule4IntertIntoEventTriggerOutputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
							"values ('4-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", 0);";
					DB_Write(Rule4IntertIntoEventTriggerOutputDeviceMapping);
					string Rule3IntertIntoEventTriggerOutputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
							"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
							"values ('3-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+", "+to_string(1)+", '""');";
					DB_Write(Rule3IntertIntoEventTriggerOutputDeviceSetupValue);
					string Rule4IntertIntoEventTriggerOutputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
							"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
							"values ('4-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+", "+to_string(0)+", '""');";
					DB_Write(Rule4IntertIntoEventTriggerOutputDeviceSetupValue);
				}
				else if(i == 1){
					string Rule3InsertIntoEventTriggerInputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerInputDeviceMapping "
							"(EventTriggerId, DeviceId, DeviceUnicastId) values ('3-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempButtonId)+");";
					DB_Write(Rule3InsertIntoEventTriggerInputDeviceMapping);
					string Rule4InsertIntoEventTriggerInputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerInputDeviceMapping "
							"(EventTriggerId, DeviceId, DeviceUnicastId) values ('4-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempButtonId)+");";
					DB_Write(Rule4InsertIntoEventTriggerInputDeviceMapping);
					string Rule3IntertIntoEventTriggerInputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerInputDeviceSetupValue "
							"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, ComparisonOperatorId, DeviceAttributeValue, DeviceAttributeValueMAX)"
							"values ('3-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+",1,1,1)";
					DB_Write(Rule3IntertIntoEventTriggerInputDeviceSetupValue);
					string Rule4IntertIntoEventTriggerInputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerInputDeviceSetupValue "
							"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, ComparisonOperatorId, DeviceAttributeValue, DeviceAttributeValueMAX)"
							"values ('4-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+",1,0,0)";
					DB_Write(Rule4IntertIntoEventTriggerInputDeviceSetupValue);
					string Rule1IntertIntoEventTriggerOutputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
							"values ('1-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", 0);";
					DB_Write(Rule1IntertIntoEventTriggerOutputDeviceMapping);
					string Rule2IntertIntoEventTriggerOutputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
							"values ('2-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", 0);";
					DB_Write(Rule2IntertIntoEventTriggerOutputDeviceMapping);
					string Rule1IntertIntoEventTriggerOutputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
							"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
							"values ('1-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+", "+to_string(1)+", '""');";
					DB_Write(Rule1IntertIntoEventTriggerOutputDeviceSetupValue);
					string Rule2IntertIntoEventTriggerOutputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
							"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
							"values ('2-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+", "+to_string(0)+", '""');";
					DB_Write(Rule2IntertIntoEventTriggerOutputDeviceSetupValue);
				}
			}
			if(ADD_BUTTON.Size() == 1){
				for(unsigned int i; i<ListDeviceFromRuleDeviceInput.size(); i++){
					// cout << ListDeviceFromRuleDeviceInput[i].DeviceUnicastId << " --- " << ListDeviceFromRuleDeviceInput[i].DeviceAttributeId << " --- " << ListDeviceFromRuleDeviceInput[i].DeviceUnicastId << endl;
					if(ListDeviceFromRuleDeviceInput[i].DeviceUnicastId != TempDeviceUnicastId){
						TempDeviceId = ListDeviceFromRuleDeviceInput[i].DeviceId;
						TempButtonId = ListDeviceFromRuleDeviceInput[i].DeviceAttributeId;
						TempDeviceUnicastId = ListDeviceFromRuleDeviceInput[i].DeviceUnicastId;
						string Rule3InsertIntoEventTriggerInputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerInputDeviceMapping "
								"(EventTriggerId, DeviceId, DeviceUnicastId) values ('3-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempButtonId)+");";
						DB_Write(Rule3InsertIntoEventTriggerInputDeviceMapping);
						string Rule4InsertIntoEventTriggerInputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerInputDeviceMapping "
								"(EventTriggerId, DeviceId, DeviceUnicastId) values ('4-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempButtonId)+");";
						DB_Write(Rule4InsertIntoEventTriggerInputDeviceMapping);
						string Rule3IntertIntoEventTriggerInputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerInputDeviceSetupValue "
								"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, ComparisonOperatorId, DeviceAttributeValue, DeviceAttributeValueMAX)"
								"values ('3-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+",1,1,1)";
						DB_Write(Rule3IntertIntoEventTriggerInputDeviceSetupValue);
						string Rule4IntertIntoEventTriggerInputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerInputDeviceSetupValue "
								"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, ComparisonOperatorId, DeviceAttributeValue, DeviceAttributeValueMAX)"
								"values ('4-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+",1,0,0)";
						DB_Write(Rule4IntertIntoEventTriggerInputDeviceSetupValue);
						string Rule1IntertIntoEventTriggerOutputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
								"values ('1-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", 0);";
						DB_Write(Rule1IntertIntoEventTriggerOutputDeviceMapping);
						string Rule2IntertIntoEventTriggerOutputDeviceMapping = "INSERT OR REPLACE INTO EventTriggerOutputDeviceMapping(EventTriggerId, DeviceId, DeviceUnicastId, typerun) "
								"values ('2-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", 0);";
						DB_Write(Rule2IntertIntoEventTriggerOutputDeviceMapping);
						string Rule1IntertIntoEventTriggerOutputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
								"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
								"values ('1-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+", "+to_string(1)+", '""');";
						DB_Write(Rule1IntertIntoEventTriggerOutputDeviceSetupValue);
						string Rule2IntertIntoEventTriggerOutputDeviceSetupValue = "INSERT OR REPLACE INTO EventTriggerOutputDeviceSetupValue"
								"(EventTriggerId, DeviceId, DeviceUnicastId, DeviceAttributeId, DeviceAttributeValue, Time) "
								"values ('2-"+TempUUId+"', '"+TempDeviceId+"', "+to_string(TempDeviceUnicastId)+", "+to_string(TempButtonId)+", "+to_string(0)+", '""');";
						DB_Write(Rule2IntertIntoEventTriggerOutputDeviceSetupValue);
						break;
					}
				}
				ListDeviceFromRuleDeviceInput.clear();
			}
		}
	}
}

void DeleteSwitchCombine(char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	if(DATA.HasMember("GROUP_ID")){
		string TempUUId = DATA["GROUP_ID"].GetString();
		int TempDeviceTypeId = DATA["DEVICE_TYPE_ID"].GetInt();
		if(TempDeviceTypeId == NEW_SWITCH) {
			int TempGroupUnicastId = GROUP_UNICAST_ID(TempUUId);
			string DeleteGroup = "INSERT OR REPLACE INTO GROUPID (GroupingId, GroupUnicastId, ValueCreate) values ('', "+ to_string(TempGroupUnicastId) + ", 0);";
			DB_Write(DeleteGroup);
			string GROUP_ID = DATA["GROUP_ID"].GetString();
			string GetDVIntoGroup = "SELECT DeviceUnicastId FROM GroupingDeviceMapping WHERE GroupingId = '"+GROUP_ID+"';";
			// cout << GetDVIntoGroup << endl;
			numDvUnicast = 0;
			DB_Read( "DEVICE_UNICAST", GetDVIntoGroup);
			string DeleteSwitchCombine = "DELETE FROM GroupingDeviceMapping WHERE GroupingId = '"+ TempUUId +"';";
			DB_Write(DeleteSwitchCombine);
			for(int i=0; i<numDvUnicast; i++){
				string GetDeviceUbicastId = "SELECT ParentDeviceUnicastId FROM SubDevice WHERE ChildDeviceUnicastId = "+ to_string(ArrDvUnicast[i]) +"";
				ADR = 0;
				DB_Read("ADR", GetDeviceUbicastId);
				int TempParentUnicastId = ArrDvUnicast[i];
				if(ADR != 0){
					TempParentUnicastId = ADR;
				}
				CONTROL = "";
				string sql = "SELECT DeviceId FROM Device WHERE DeviceUnicastId = " + to_string(ArrDvUnicast[i]) + ";";
				DB_Read("CONTROL", sql);
				int TempCategoryIdId =  TYPE_DEVICE(CONTROL);
				DelDeviceFromGroup(mosq, TempParentUnicastId, TempGroupUnicastId, ArrDvUnicast[i]);
				ConnectionButton(ArrDvUnicast[i], 0, TempCategoryIdId);
			}
		}
		else{
			for(int i=1; i<=4; i++){
				string DeleteEventTriggerInputDeviceMapping = "DELETE FROM EventTriggerInputDeviceMapping WHERE EventTriggerId = '"+to_string(i)+"-"+TempUUId+"';";
				cout << DeleteEventTriggerInputDeviceMapping << endl;
				DB_Write(DeleteEventTriggerInputDeviceMapping);
				string DeleteEventTriggerInputDeviceSetupValue = "DELETE FROM EventTriggerInputDeviceSetupValue WHERE EventTriggerId = '"+to_string(i)+"-"+TempUUId+"';";
				cout << DeleteEventTriggerInputDeviceSetupValue << endl;
				DB_Write(DeleteEventTriggerInputDeviceSetupValue);
				string DeleteEventTriggerOutputDeviceMapping = "DELETE FROM EventTriggerOutputDeviceMapping WHERE EventTriggerId = '"+to_string(i)+"-"+TempUUId+"';";
				cout << DeleteEventTriggerOutputDeviceMapping << endl;
				DB_Write(DeleteEventTriggerOutputDeviceMapping);
				string DeleteEventTriggerOutputDeviceSetupValue = "DELETE FROM EventTriggerOutputDeviceSetupValue WHERE EventTriggerId = '"+to_string(i)+"-"+TempUUId+"';";
				cout << DeleteEventTriggerOutputDeviceSetupValue << endl;
				DB_Write(DeleteEventTriggerOutputDeviceSetupValue);
				string DeleteEventTrigger = "DELETE FROM EventTrigger WHERE EventTriggerId = '"+to_string(i)+"-"+TempUUId+"';";
				cout << DeleteEventTrigger << endl;
				DB_Write(DeleteEventTrigger);
			}
			string DeleteEventTrigger = "DELETE FROM EventTrigger WHERE EventTriggerId = '"+TempUUId+"';";
			cout << DeleteEventTrigger << endl;
			DB_Write(DeleteEventTrigger);
			string DeleteSubEventTrigger = "DELETE FROM SubEventTrigger WHERE EventTriggerId = '"+TempUUId+"';";
			cout << DeleteSubEventTrigger << endl;
			DB_Write(DeleteSubEventTrigger);
		}
	}
}


