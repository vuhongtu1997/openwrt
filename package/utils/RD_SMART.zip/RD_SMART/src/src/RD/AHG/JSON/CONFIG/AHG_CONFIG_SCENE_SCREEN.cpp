/*
 * AHG_CONFIG_SCENE_SCREEN.cpp
 *
 *  Created on: Dec 23, 2021
 *      Author: rd
 */

#include "AHG_CONFIG_SCENE_SCREEN.hpp"
#include <iostream>

void SceneForScreen(struct mosquitto *mosq, char* jobj){
	Document document;
	document.Parse(jobj);
	const Value& DATA = document["DATA"];
	string DEVICE_ID = DATA["DEVICE_ID"].GetString();
	int DEVICE_UNICAST = DEVICE_UNICAST_ID(DEVICE_ID);
	if(DATA.HasMember("ROOM_ID")){
		string ROOM_ID = DATA["ROOM_ID"].GetString();
		string UpdateDeviceToRoom = "UPDATE Device SET RoomId = '"+ROOM_ID+"' WHERE DeviceId = '"+DEVICE_ID+"';";
		DB_Write( UpdateDeviceToRoom);
		StringBuffer sendToGW;
		Writer<StringBuffer> json(sendToGW);
		json.StartObject();
		json.Key("CMD");
		json.String("DEFAULT_ONOFF_SCREENTOUCH");
		json.Key("DATA");
			json.StartObject();
			json.Key("DEVICE_UNICAST_ID");
			json.Int(DEVICE_UNICAST);
			json.Key("GROUPID");
			json.Int(GROUP_UNICAST_ID(ROOM_ID));
			json.EndObject();
		json.EndObject();
		string s = sendToGW.GetString();
		MqttSend(mosq, const_cast<char*>(s.c_str()));
	}
	const Value& SCENES = DATA["SCENES"];
	for(rapidjson::SizeType i = 0; i < SCENES.Size(); i++){
		const Value& a = SCENES[i];
		string SCENE_ID = a["SCENE_ID"].GetString();
		ADR = -1;
		string sqlSceneUnicastId = "SELECT SceneUnicastID FROM EventTrigger WHERE EventTriggerId = '"+ SCENE_ID + "';";
		DB_Read( "ADR", sqlSceneUnicastId);
		string UpdateSceneScreen =
				"INSERT OR REPLACE INTO EventTriggerInputDeviceMapping (EventTriggerId, DeviceId, DeviceUnicastId) values ('"
						+ SCENE_ID + "', '" + DEVICE_ID + "', "
						+ to_string(DEVICE_UNICAST)+"); ";
		DB_Write( UpdateSceneScreen);
		int SCENE_ICON = a["SCENE_ICON"].GetInt();
		StringBuffer sendToGW;
		Writer<StringBuffer> json(sendToGW);
		json.StartObject();
		json.Key("CMD");
		json.String("ADDSCENE_SCREEN_TOUCH");
		json.Key("DATA");
			json.StartObject();
			json.Key("DEVICE_UNICAST_ID");
			json.Int(DEVICE_UNICAST);
			json.Key("SCENEID");
			json.Int(ADR);
			json.Key("ICONID");
			json.Int(SCENE_ICON);
			json.EndObject();
		json.EndObject();
		string s = sendToGW.GetString();
		MqttSend(mosq, const_cast<char*>(s.c_str()));
	}
	const Value& DEL_SCENES = DATA["DEL_SCENES"];
	for(rapidjson::SizeType i = 0; i < DEL_SCENES.Size(); i++){
		const Value& a = DEL_SCENES[i];
		string SCENE_ID = a.GetString();
		ADR = -1;
		string sqlSceneUnicastId = "SELECT SceneUnicastID FROM EventTrigger WHERE EventTriggerId = '"+ SCENE_ID + "';";
		DB_Read( "ADR", sqlSceneUnicastId);
		string DeleteSceneScreen =
				"DELETE FROM EventTriggerInputDeviceMapping WHERE EventTriggerId = '"
						+ SCENE_ID + "' AND DeviceId = '" + DEVICE_ID + "'; ";
		DB_Write( DeleteSceneScreen);
		StringBuffer sendToGW;
		Writer<StringBuffer> json(sendToGW);
		json.StartObject();
		json.Key("CMD");
		json.String("DELSCENE_SCREEN_TOUCH");
		json.Key("DATA");
			json.StartObject();
			json.Key("DEVICE_UNICAST_ID");
			json.Int(DEVICE_UNICAST);
			json.Key("SCENEID");
			json.Int(ADR);
			json.EndObject();
		json.EndObject();
		string s = sendToGW.GetString();
		MqttSend(mosq, const_cast<char*>(s.c_str()));
	}
}
