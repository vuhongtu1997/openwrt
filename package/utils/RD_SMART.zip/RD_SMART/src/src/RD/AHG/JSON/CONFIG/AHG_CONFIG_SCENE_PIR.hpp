/*
 * AHG_CONFIG_SCENE_PIR.hpp
 *
 *  Created on: Dec 23, 2021
 *      Author: rd
 */

#ifndef SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_SCENE_PIR_HPP_
#define SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_SCENE_PIR_HPP_

#include "../JSON_AHG.hpp"

//SCENE FOR SENSOR LIGHT & PIR
void CreateSceneForSensorLightPIR(struct mosquitto *mosq, char* jobj);
void DelSceneForSensorLightPIR(struct mosquitto *mosq, char* jobj);

#endif /* SRC_RD_AHG_JSON_CONFIG_AHG_CONFIG_SCENE_PIR_HPP_ */
