/*
 * SCENE_DELAY.cpp
 *
 *  Created on: Mar 20, 2022
 *      Author: rd
 */

#include "SCENE_DELAY.hpp"

pthread_t CallSceneDelay;

static void InitArr(){
	bool FlagCheckLock = false;
	while (FlagCheckLock == false){
		if(pthread_mutex_trylock(&mutexSceneDelay) == 0){
			for(int k=0; k<SIZE_SCENE_DELAY; k++){
				for(int m=0; m<6; m++){
					ArrSceneDelay[k][m] = -1;
				}
				// cout << endl;
			}
			FlagCheckLock = true;
			pthread_mutex_unlock(&mutexSceneDelay);
			break;
		}
		usleep (3000);
	}
}

static void SceneDelayRspDVCT(int UnicastId, int Properties, int Value){
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");json.String("CONTROL");
	json.Key("DATA");
	json.StartObject();
	json.Key("UNICAST_ID");
	json.Int(UnicastId);
	json.Key("PROPERTIES");
	json.StartArray();
	json.StartObject();
	json.Key("ID");
	json.Int(Properties);
	json.Key("VALUE");
	json.Int(Value);
	json.EndObject();
	json.EndArray();
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	cout << s << endl;
	MqttSendGW2Logic(mosq, const_cast<char*>(s.c_str()));
}

static void SceneDelayRspScene(int SceneUnicastId){
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");json.String("CONTROL");
	json.Key("DATA");
	json.StartObject();
	json.Key("SCENE_UNICAST_ID");
	json.Int(SceneUnicastId);
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	cout << s << endl;
	MqttSendGW2Logic(mosq, const_cast<char*>(s.c_str()));
}

static void ControlDeviceIntoSceneDelay(int UnicastId, int DeviceAttbuteId, int Value, int TypeControl){
	string keyControl[3] = {"VALUE_ONOFF","VALUE_DIM","VALUE_CCT"};
	string keyCmd[3]    = {"ONOFF","DIM","CCT"};
	int TempUnicastId = UnicastId;
	if(TypeControl == 1 || TypeControl == 2){
		if(DeviceAttbuteId == 2 && UnicastId < 49152){
			UnicastId ++;
		}
		StringBuffer sendToGW;
		Writer<StringBuffer> json(sendToGW);
		json.StartObject();
		json.Key("CMD");json.String(const_cast<char*>(keyCmd[DeviceAttbuteId].c_str()));
			json.Key("ACK");json.Bool(false);
			json.Key("DATA");
			json.StartObject();
			json.Key("DEVICE_UNICAST_ID");json.Int(UnicastId);
			json.Key(const_cast<char*>(keyControl[DeviceAttbuteId].c_str()));json.Int(Value);
			json.EndObject();
			json.EndObject();
		string s = sendToGW.GetString();
		cout << s << endl;
		MqttSend(mosq, const_cast<char*>(s.c_str()));
		SceneDelayRspDVCT(TempUnicastId, DeviceAttbuteId, Value);
	}
	if(TypeControl == 3){
		StringBuffer sendToGW;
		Writer<StringBuffer> json(sendToGW);
		json.StartObject();
		json.Key("CMD");json.String("CALLSCENE");
		json.Key("ACK");json.Bool(false);
		json.Key("DATA");
		json.StartObject();
		json.Key("SCENEID");json.Int(UnicastId);
		json.EndObject();
		json.EndObject();
		string s = sendToGW.GetString();
		MqttSend(mosq, const_cast<char*>(s.c_str()));
		SceneDelayRspScene(UnicastId);
	}
}

static void ControlModeRGB(int Mode, int DeviceUnicastId){
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");json.String("CALLMODE_RGB");
		json.Key("DATA");
		json.StartObject();
		json.Key("DEVICE_UNICAST_ID");
		json.StartArray();
		json.Int(DeviceUnicastId);
		json.EndArray();
		json.Key("SRGBID");json.Int(Mode);
		json.EndObject();
		json.EndObject();
	string s = sendToGW.GetString();
	MqttSend(mosq, const_cast<char*>(s.c_str()));
}

static void SceneDelayRspDVRGB(int UnicastId, int H, int S, int L){
	StringBuffer sendToGW;
	Writer<StringBuffer> json(sendToGW);
	json.StartObject();
	json.Key("CMD");json.String("CONTROL");
	json.Key("DATA");
	json.StartObject();
	json.Key("UNICAST_ID");
	json.Int(UnicastId);
	json.Key("PROPERTIES");
	json.StartArray();
	json.StartObject();
	json.Key("ID");
	json.Int(3);
	json.Key("VALUE");
	json.Int(H);
	json.EndObject();
	json.StartObject();
	json.Key("ID");
	json.Int(4);
	json.Key("VALUE");
	json.Int(S);
	json.EndObject();
	json.StartObject();
	json.Key("ID");
	json.Int(5);
	json.Key("VALUE");
	json.Int(L);
	json.EndObject();
	json.EndArray();
	json.EndObject();
	json.EndObject();
	string s = sendToGW.GetString();
	cout << s << endl;
	MqttSendGW2Logic(mosq, const_cast<char*>(s.c_str()));
}

int H = -1;
int S = -1;
int L = -1;
static int CheckControl (int index, int time){
	if(ArrSceneDelay[index][4] <= time + ArrSceneDelay[index][5]){
		if(ArrSceneDelay[index][4] >= time){
			if(ArrSceneDelay[index][0] == 3){
				//Control Scene
				// cout << "          Control Scene: " << ArrSceneDelay[index][1] << endl;
				// cout << GetSecondTimeNow() << endl;
				ControlDeviceIntoSceneDelay(ArrSceneDelay[index][1], ArrSceneDelay[index][2], ArrSceneDelay[index][3], ArrSceneDelay[index][0]);
			}
			else if(ArrSceneDelay[index][0] == 2){
				//Control Group
				// cout << "          Control Group: " << ArrSceneDelay[index][1] << endl;
				// cout << GetSecondTimeNow() << endl;
				if(ArrSceneDelay[index][2] == 0 || ArrSceneDelay[index][2] == 1 || ArrSceneDelay[index][2] == 2){
					ControlDeviceIntoSceneDelay(ArrSceneDelay[index][1], ArrSceneDelay[index][2], ArrSceneDelay[index][3], ArrSceneDelay[index][0]);
				}
				else if(ArrSceneDelay[index][2] == 3 || ArrSceneDelay[index][2] == 4 || ArrSceneDelay[index][2] == 5){
					if(ArrSceneDelay[index][2] == 5){
						L = ArrSceneDelay[index][3];
					}
					else if(ArrSceneDelay[index][2] == 4){
						S = ArrSceneDelay[index][3];
					}
					else if((ArrSceneDelay[index][2] == 3)){
						H = ArrSceneDelay[index][3];
					}
					if ((H != -1) && (S != -1) && (L != -1)){
						StringBuffer sendToGW;
						Writer<StringBuffer> json(sendToGW);
						json.StartObject();
						json.Key("CMD");json.String("HSL");
						json.Key("ACK");json.Bool(false);
						json.Key("DATA");
						json.StartObject();
						json.Key("DEVICE_UNICAST_ID");json.Int(ArrSceneDelay[index][1]);
						json.Key("VALUE_H");json.Int(H);
						json.Key("VALUE_S");json.Int(S);
						json.Key("VALUE_L");json.Int(L);
						json.EndObject();
						json.EndObject();
						string s = sendToGW.GetString();
						MqttSend(mosq, const_cast<char*>(s.c_str()));
						SceneDelayRspDVRGB(ArrSceneDelay[index][1], H, S, L);
						H = S = L = -1;
					}
				}
				else if(ArrSceneDelay[index][2] == 23){
					ControlModeRGB(ArrSceneDelay[index][3], ArrSceneDelay[index][1]);
				}
			}
			else if(ArrSceneDelay[index][0] == 1){
				//Control Device
				// cout << "          Control Device: " << ArrSceneDelay[index][1] << endl;
				// cout << GetSecondTimeNow() << endl;
				if(ArrSceneDelay[index][2] == 0 || ArrSceneDelay[index][2] == 1 || ArrSceneDelay[index][2] == 2){
					ControlDeviceIntoSceneDelay(ArrSceneDelay[index][1], ArrSceneDelay[index][2], ArrSceneDelay[index][3], ArrSceneDelay[index][0]);
				}
				else if(ArrSceneDelay[index][2] == 3 || ArrSceneDelay[index][2] == 4 || ArrSceneDelay[index][2] == 5){
					if(ArrSceneDelay[index][2] == 5){
						L = ArrSceneDelay[index][3];
					}
					else if(ArrSceneDelay[index][2] == 4){
						S = ArrSceneDelay[index][3];
					}
					else if(ArrSceneDelay[index][2] == 3){
						H = ArrSceneDelay[index][3];
					}
					if ((H != -1) && (S != -1) && (L != -1)){
						StringBuffer sendToGW;
						Writer<StringBuffer> json(sendToGW);
						json.StartObject();
						json.Key("CMD");json.String("HSL");
						json.Key("ACK");json.Bool(false);
						json.Key("DATA");
						json.StartObject();
						json.Key("DEVICE_UNICAST_ID");json.Int(ArrSceneDelay[index][1]);
						json.Key("VALUE_H");json.Int(H);
						json.Key("VALUE_S");json.Int(S);
						json.Key("VALUE_L");json.Int(L);
						json.EndObject();
						json.EndObject();
						string s = sendToGW.GetString();
						MqttSend(mosq, const_cast<char*>(s.c_str()));
						SceneDelayRspDVRGB(ArrSceneDelay[index][1], H, S, L);
						H = S = L = -1;
					}
				}
				else if(ArrSceneDelay[index][2] == 23){
					ControlModeRGB(ArrSceneDelay[index][3], ArrSceneDelay[index][1]);
				}
			}
			IndexSceneDaleyCurrent ++;
			if(IndexSceneDaleyCurrent >= SIZE_SCENE_DELAY){
				IndexSceneDaleyCurrent = IndexSceneDaleyCurrent-SIZE_SCENE_DELAY;
			}
			for(int j=0; j<6; j++){
				ArrSceneDelay[index][j] = -1;
			}
			return time;
		}
	}
	return 0;
}

void *SceneDelay(void *argv){
	InitArr();
	while(true){
		bool FlagCheckLock = false;
		while (FlagCheckLock == false){
			if(pthread_mutex_trylock(&mutexSceneDelay) == 0){
				if(FlagCheckSceneDelay == true){
					for(int i=0; i<SIZE_SCENE_DELAY; i++){
						int TempIndex = i + 1 + IndexSceneDaleyCurrent;
						if (TempIndex >= SIZE_SCENE_DELAY) {
							TempIndex = TempIndex - SIZE_SCENE_DELAY;
						}

						int TempIndexNext = TempIndex + 1;
						if (TempIndexNext >= SIZE_SCENE_DELAY) {
							TempIndexNext = TempIndexNext - SIZE_SCENE_DELAY;
						}

						int TimeNow = GetSecondTimeNow();
//						if(ArrSceneDelay[TempIndex][5] == -1){
//							FlagCheckSceneDelay = false;
//							break;
//						}
						while(CheckControl (TempIndex, TimeNow) != 0){
							TempIndex++;
							if (TempIndex >= SIZE_SCENE_DELAY) {
								TempIndex = TempIndex - SIZE_SCENE_DELAY;
							}
							if(ArrSceneDelay[TempIndex][5] == -1){
								FlagCheckSceneDelay = false;
								break;
							}
						}
						/*
						if(CheckControl (TempIndex, TimeNow)){
							if(ArrSceneDelay[TempIndexNext][5] == -1){
								FlagCheckSceneDelay = false;
								break;
							}
							else{
								for(int j=0; j<SIZE_SCENE_DELAY; j++){
									if(ArrSceneDelay[TempIndexNext][4] == TimeNow){
										CheckControl(TempIndexNext, TimeNow);
										TempIndexNext++;

										if (TempIndexNext >= SIZE_SCENE_DELAY) {
											TempIndexNext = TempIndexNext - SIZE_SCENE_DELAY;
										}
									}
									else{
										break;
									}
								}
							}

							cout<<"\nScene Delay Done!\n";
						}
						*/
					}
				}
				FlagCheckLock = true;
				pthread_mutex_unlock(&mutexSceneDelay);
				break;
			}
			usleep (3000);
		}
		usleep (200000);
	}
	return 0;
}

