/*
 * SCENE_DELAY.hpp
 *
 *  Created on: Mar 20, 2022
 *      Author: rd
 */

#ifndef SRC_RD_SCENEDELAY_SCENE_DELAY_HPP_
#define SRC_RD_SCENEDELAY_SCENE_DELAY_HPP_

#include "../ShareData.hpp"
#include "../MQTT/MQTT.hpp"

extern pthread_t CallSceneDelay;

void *SceneDelay(void *argv);

#endif /* SRC_RD_SCENEDELAY_SCENE_DELAY_HPP_ */
