#include "../RD/ShareData.hpp"

/*
 * Variable update device
 */
int timeOffLine = 0;
vector<t_Device> T_Device;
vector<t_DeviceCheckOnline> T_DeviceCheckOnline;
t_checkHCL CheckHCL = {"","",false};
string macHC = "";
t_HcMaster HcMasterInfo = {"","",""};

map<uint32_t, uint32_t> bleTypeToGroupIdList;

string TopicMultiHC = "";

bool sendMsgMultiHc = true;

vector<t_DeviceFromRuleDeviceInput> ListDeviceFromRuleDeviceInput;

struct RuleLog ruleLog;

int screenTouch_statusOutWeather = 0;
int screenTouch_tempOutWeather = 0;
int TimeOut = 0;

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutexMSG_App = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutexRSP_DV = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutex_DB = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutexDvOnline = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutexSceneDelay = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutexLog = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mutexUDP = PTHREAD_MUTEX_INITIALIZER;

pthread_mutex_t mutexUpdateDvValue;

pthread_t ThreadMqttMasterId;
pthread_t ThreadMqttMaster;

//Create AHG
string ShareGroupId = "";
int ShareGroupUnicastId = 0;
int IsProcessGroup = 0;
int numDeviceGroup = 0;
int DeviceGroup[256] = {0};
int numDeviceGroupSuccess = 0;
int DeviceGroupSuccess[256] = {0};

int ArrSceneDelay[SIZE_SCENE_DELAY][6] = {0};
int IndexSceneDaleyCurrent = 0;
bool FlagCheckSceneDelay = true;

bool IsProcessDone = false;

int IsProcessScene = 0;
string ShareSceneId="";
int ShareSceneUnicastId = 0 ;
int DeviceScene[256] = {0};
int numDeviceScene = 0;
int numDeviceSceneSuccess = 0;
int DeviceSceneSuccess[256] = {0};

bool isResetNode=false;
bool isResetHc = false;
int numDeviceReset = 0;
int numDeviceResetSuccess = 0;
int deviceReset[100] = {0};
int deviceResetSuccess[100] = {0};
int deviceResetFailed[100] = {0};

int IsProcessRoom = 0;
int numDeviceGroupRoom = 0;
int numDeviceGroupRoomSuccess = 0;
int numDeviceSceneRoom = 0;
int numDeviceSceneRoomSuccess = 0;
int DeviceGroupRoom[48][256] = {0};
int DeviceRoomGroupSuccess[48][256] = {0};
int DeviceSceneRoom[48][256] = {0};
int DeviceRoomSceneSuccess[48][256] = {0};
unsigned int  numGroupRoom = 0;
unsigned int  numSceneRoom = 0;

string sceneIdDelRemote = "";

int lowlux=0,highlux = 0;
string sceneafterPir ="";
string scenebeforePir = "";
//IR
string IR_DEVICE_ID = "";
int DEVICE_ATTRIBUTE_ID = 0;

string dormitoryId = "";

queue <string> QueueDB;

void ResetDataResetNode(){
	isResetHc = false;
	isResetNode=false;
	numDeviceReset = 0;
	numDeviceResetSuccess = 0;
	for(int i=0;i<100;i++){
		deviceReset[i] = 0;
		bool FlagCheckLock = false;
		while (FlagCheckLock == false){
			if(pthread_mutex_trylock(&mutexUpdateDvValue) == 0 && pthread_mutex_trylock(&mutexDvOnline) == 0){
				int IndexDvCheckOnline = SearchDeviceCheckOnline(deviceReset[i]);
				int IndexDvGetStatus = SearchDeviceUpdateValue(deviceReset[i]);
				if(IndexDvGetStatus != -1){
					DeleteRowDvValue(T_Device, IndexDvGetStatus);
				}
				if(IndexDvCheckOnline != -1){
					DeleteRowDvCheckOnline(T_DeviceCheckOnline, IndexDvCheckOnline);
				}
				FlagCheckLock = true;
				pthread_mutex_unlock(&mutexUpdateDvValue);
				pthread_mutex_unlock(&mutexDvOnline);
				break;
			}
			usleep (3000);
		}
		pthread_mutex_unlock(&mutex);
		deviceResetSuccess[i] = 0;
		deviceResetFailed[i] = 0;
	}
}
void ResetDataGroup(){
	IsProcessGroup = 0;
	for(int i=0;i<256;i++){
		DeviceGroup[i] = 0;
		DeviceGroupSuccess[i] = 0;
	}
	TimeOut = 0;
	numDeviceGroup = 0;
	numDeviceGroupSuccess = 0;
}
void ResetDataScene(){
	IsProcessScene = 0;
	for(int i=0;i<256;i++){
		DeviceScene[i] = 0;
		DeviceSceneSuccess[i] = 0;
	}
	TimeOut = 0;
	ShareSceneId = "";
	ShareSceneUnicastId = 0;
	numDeviceScene = 0;
	numDeviceSceneSuccess = 0;
}
void ResetDataRoom(){
	IsProcessRoom = 0;
	numDeviceGroupRoom = 0;
	numDeviceGroupRoomSuccess = 0;
	numDeviceSceneRoom = 0;
	numDeviceSceneRoomSuccess = 0;
	numGroupRoom = 0;
	numSceneRoom = 0;
	for(int i=0; i<48; i++){
		for(int j=0; j<256; j++){
			DeviceGroupRoom[i][j] = 0;
			DeviceRoomGroupSuccess[i][j] = 0;
			DeviceSceneRoom[i][j] = 0;
			DeviceRoomSceneSuccess[i][j] = 0;
		}
	}
}
string ExeCMD(const char* command)
{
	FILE *file;
	string msg_rsp = "";
	char msg_line[100]={0};
	file = popen(command, "r");
	if(file==NULL)
	{
		puts("lỗi");
		exit(1);
	}
	fgets(msg_line, 100, file);
	msg_rsp += msg_line;
	while(1)
	{
		fgets(msg_line, 100, file);
		if(feof(file))
		{
			break;
		}
		msg_rsp += msg_line;
	}
	pclose(file);
	return msg_rsp;
}

string LocalTime(string s){
	time_t now = time(0);
	struct tm  tstruct;
	char  buf[80];
	tstruct = *localtime(&now);
	if(s=="now")
		strftime(buf, sizeof(buf), "%Y-%m-%d %X", &tstruct);
	else if(s=="date")
		strftime(buf, sizeof(buf), "%Y-%m-%d", &tstruct);
	else if(s=="time")
		strftime(buf, sizeof(buf), "%X", &tstruct);
	return string(buf);
}

void WriteIntoLog(string cmd, string code){
	cout << code << endl;
	FILE * file;
	string FilePath= "/root/log_RD_SMART_"+LocalTime("date")+".txt";
	file = fopen(const_cast<char*>(FilePath.c_str()), "a");
	string Msg = "<" + LocalTime("now") + ">: " + cmd + ": " +code + "\n";
	fputs(const_cast<char*>(Msg.c_str()), file);
	fclose(file);
}

void PushItemToQueue(pthread_mutex_t KeyLock, string Msg, ringbuffer_t Queue, int SizeMsg){
	bool FlagCheckLock = false;
	while(FlagCheckLock == false){
		if(pthread_mutex_trylock(&KeyLock) == 0){
			if(ringBuffer_IsFull(&Queue) != true){
				char buffer_convert_ST2char_DB[SizeMsg] = {0};
				memcpy(buffer_convert_ST2char_DB, const_cast<char*>(Msg.c_str()), Msg.length());
				ringBuffer_Push((ringbuffer_t *)&Queue, (void*)&buffer_convert_ST2char_DB[0]);
				FlagCheckLock = true;
#if 0
				cout << "PUSH queue: "<< buffer_convert_ST2char_DB << endl;
				cout <<"------------------------sau khi push: "<< Queue.count << endl;
				char buffer_convert_ST2charPop_DB_Pop[SizeMsg] = {0};
				ringBuffer_Pop((ringbuffer_t *)&Queue, (void *)&buffer_convert_ST2charPop_DB_Pop[0]);
				cout <<"------------------------sau khi pop: "<< Queue.count << endl;
				cout << "POP queue: "<< buffer_convert_ST2charPop_DB_Pop << endl;
#endif
			}
			else{
				cout << " buffer đầy "<<endl;
			}
			pthread_mutex_unlock(&KeyLock);
		}
		usleep(100);
	}
}

void GetMacAddress(char *uc_Mac){
	struct ifreq s;
	unsigned char *mac = NULL;
	int fd = socket(PF_INET, SOCK_DGRAM, IPPROTO_IP);

	strcpy(s.ifr_name, "eth0");
	if (0 == ioctl(fd, SIOCGIFHWADDR, &s)) {
		mac = (unsigned char*) s.ifr_addr.sa_data;
	}
	sprintf((char*) uc_Mac, (const char*) "%.2x:%.2x:%.2x:%.2x:%.2x:%.2x",
			mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
	puts(uc_Mac);
}

int SearchDeviceCheckOnline(int Para){
	int lowerBound = 0; // chi muc ban dau
	int upperBound = T_DeviceCheckOnline.size() - 1; // chi muc cuoi
	int midPoint = -1;
	int comparisons = 0;
	int index = -1;

	while (lowerBound <= upperBound) {
		comparisons++;
		midPoint = lowerBound + (upperBound - lowerBound) / 2;
		if (T_DeviceCheckOnline[midPoint].DeviceUnicastID == Para) {
			index = midPoint;
			break;
		} else {
			if (T_DeviceCheckOnline[midPoint].DeviceUnicastID < Para) {
				lowerBound = midPoint + 1;
			} else {
				upperBound = midPoint - 1;
			}
		}
	}
	return index;
}

int SearchDeviceUpdateValue(int Para){
	int lowerBound = 0; // chi muc ban dau
	int upperBound = T_Device.size() - 1; // chi muc cuoi
	int midPoint = -1;
	int comparisons = 0;
	int index = -1;

	while (lowerBound <= upperBound) {
		comparisons++;
		midPoint = lowerBound + (upperBound - lowerBound) / 2;
		if (T_Device[midPoint].DeviceUnicastID == Para) {
			index = midPoint;
			break;
		} else {
			if (T_Device[midPoint].DeviceUnicastID < Para) {
				lowerBound = midPoint + 1;
			} else {
				upperBound = midPoint - 1;
			}
		}
	}
	return index;
}

int GetTimeNow(){
	time_t now = time(0);
	tm *ltm = localtime(&now);
	int h = ltm->tm_hour;
	int m = ltm->tm_min;
	if(m == 60){
		h ++;
		m = m - 60;
	}
	int timeNow = h*60 + m;
	return timeNow;
}

int GetSecondTimeNow(){
	int timeNow;
	time_t now = time(0);
	tm *ltm = localtime(&now);
	//gán biến
	int h = ltm->tm_hour;
	int m = ltm->tm_min;
	int s = 1 + ltm->tm_sec;
//setup Time
	if(m == 60){
		h ++;
		m = m - 60;
	}else if( s == 60 ){
		m ++;
		s = s - 60;
	}
	timeNow = h * 3600 + m * 60 + s;
	return timeNow;
}

unsigned long int GetTimrStamp()
{
	return time(NULL);
}

void PushMsgToQueueDb_AHG(string Msg){
	QueueDB.push(Msg);
}

void DeleteRowDvValue(vector<t_Device> &t_TempDevice, int TempIndex)
{
	t_TempDevice.erase(t_TempDevice.begin()+TempIndex);
}

void DeleteRowDvCheckOnline(vector<t_DeviceCheckOnline> &t_TempDevice, int TempIndex){
	t_TempDevice.erase(t_TempDevice.begin()+TempIndex);
}

int TimeCheckOnline(){
	int CountDeviceCCTV1 = 0;
	int CountDeviceCCTV2 = 0;
	int CountDeviceRGBCCTV1 = 0;
	int CountDeviceRGBCCTV2 = 0;
	int CountDeviceRGBV1 = 0;
	int CountDeviceRGBV2 = 0;
	int CountDeviceSmartHome = 0;
	for(int i=0; i<T_DeviceCheckOnline.size(); i++){
		if(T_DeviceCheckOnline[i].DeviceUnicastID == 0){
			break;
		}
		if(T_DeviceCheckOnline[i].TypeDevice/1000 == 12){
			if((T_DeviceCheckOnline[i].FirmVersion).compare("1.0") == 0){
				CountDeviceCCTV1 ++;
			}
			else{
				CountDeviceCCTV2 ++;
			}
		}
		else if(T_DeviceCheckOnline[i].TypeDevice/1000 == 13){
			if((T_DeviceCheckOnline[i].FirmVersion).compare("1.0") == 0){
				CountDeviceRGBV1 ++;
			}
			else{
				CountDeviceRGBV2 ++;
			}
		}
		else if(T_DeviceCheckOnline[i].TypeDevice/1000 == 14){
			if((T_DeviceCheckOnline[i].FirmVersion).compare("1.0") == 0){
				CountDeviceRGBCCTV1 ++;
			}
			else{
				CountDeviceRGBCCTV2 ++;
			}
		}
		else{
			CountDeviceSmartHome ++;
		}
	}
	int Time = CountDeviceCCTV1*7 + CountDeviceCCTV2*4 + CountDeviceRGBV1*7 + CountDeviceRGBV2*4 + CountDeviceRGBCCTV1*13 + CountDeviceRGBCCTV2*4 + CountDeviceSmartHome*4;
	return Time;
}
#if LOG_ACTIONS
/*
{
  "CMD": "SCENE_LOG",
  "DATA": [
    {
      "sceneId": "00000000-0000-0000-0000-000000000000",
      "sceneName": "string",
      "roomId": "00000000-0000-0000-0000-000000000000",
      "dormitoryId": "00000000-0000-0000-0000-000000000000",
      "endUserId": "00000000-0000-0000-0000-000000000000",
      "dormitoryOwnerId": "00000000-0000-0000-0000-000000000000",
      "commandSourceId": 1,
      "createdAt": "1970-01-01T00:00:00.000Z"
    }
  ]
}
*/

void SendLogScene(string sceneId){
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	json.StartObject();
		json.Key("CMD");json.String("SCENE_LOG");
		json.Key("DATA");
		json.StartArray();
		json.StartObject();
			json.Key("sceneId"); json.String(const_cast<char*>(sceneId.c_str()));
			json.Key("dormitoryId"); json.String(const_cast<char*>(dormitoryId.c_str()));
			json.Key("commandSourceId"); json.Int(SOURCE_ID);
			json.Key("createdAt"); json.String(const_cast<char*>(currentISO8601LocalTime().c_str()));
		json.EndObject();
		json.EndArray();
	json.EndObject();
	cout << sendToApp.GetString() << endl;
	string s = sendToApp.GetString();
	MqttSendAPP(mosq, const_cast<char*>(s.c_str()));
}

/*
{
  "CMD": "GROUP_LOG",
  "DATA": [
    {
      "groupId": "00000000-0000-0000-0000-000000000000",
      "groupName": "string",
      "roomId": "00000000-0000-0000-0000-000000000000",
      "dormitoryId": "00000000-0000-0000-0000-000000000000",
      "endUserId": "00000000-0000-0000-0000-000000000000",
      "dormitoryOwnerId": "00000000-0000-0000-0000-000000000000",
      "onlineStatusId": 1,
      "powerStatusId": 1,
      "commandSourceId": 1,
      "createdAt": "1970-01-01T00:00:00.000Z"
    }
  ]
}
*/

void SendLogGroup(string groupId){
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	json.StartObject();
		json.Key("CMD");json.String("GROUP_LOG");
		json.Key("DATA");
		json.StartArray();
		json.StartObject();
			json.Key("groupId"); json.String(const_cast<char*>(groupId.c_str()));
			json.Key("dormitoryId"); json.String(const_cast<char*>(dormitoryId.c_str()));
			json.Key("commandSourceId"); json.Int(SOURCE_ID);
			json.Key("createdAt"); json.String(const_cast<char*>(currentISO8601LocalTime().c_str()));
		json.EndObject();
		json.EndArray();
	json.EndObject();
	cout << sendToApp.GetString() << endl;
	string s = sendToApp.GetString();
	MqttSendAPP(mosq, const_cast<char*>(s.c_str()));
}

/*
{
  "CMD": "DEVICE_LOG",
  "DATA": [
    {
      "deviceId": "00000000-0000-0000-0000-000000000000",
      "deviceName": "string",
      "deviceTypeId": 1,
      "roomId": "00000000-0000-0000-0000-000000000000",
      "dormitoryId": "00000000-0000-0000-0000-000000000000",
      "dormOwnerId": "00000000-0000-0000-0000-000000000000",
      "endUserId": "00000000-0000-0000-0000-000000000000",
      "onlineStatusId": 1,
      "powerStatusId": 1,
      "commandSourceId": 1,
      "createdAt": "1970-01-01T00:00:00.000Z"
    }
  ]
}
*/

void SendLogDevice(string deviceId){
	StringBuffer sendToApp;
	Writer<StringBuffer> json(sendToApp);
	json.StartObject();
		json.Key("CMD");json.String("DEVICE_LOG");
		json.Key("DATA");
		json.StartArray();
		json.StartObject();
			json.Key("deviceId"); json.String(const_cast<char*>(deviceId.c_str()));
			json.Key("dormitoryId"); json.String(const_cast<char*>(dormitoryId.c_str()));
			json.Key("commandSourceId"); json.Int(SOURCE_ID);
			json.Key("createdAt"); json.String(const_cast<char*>(currentISO8601LocalTime().c_str()));
		json.EndObject();
		json.EndArray();
	json.EndObject();
	cout << sendToApp.GetString() << endl;
	string s = sendToApp.GetString();
	MqttSendAPP(mosq, const_cast<char*>(s.c_str()));
}
#endif

string currentISO8601LocalTime(){
	time_t now = time(0);
	struct tm  tstruct;
	char  buf[80];
	tstruct = *localtime(&now);
	strftime(buf, sizeof(buf), "%Y-%m-%dT%XZ", &tstruct);
	return string(buf);
}

string GenerateUUID(){
    string UUID = "";
    string Temp = "-";
	srand((int) time(0));
	int random;
	for (int i = 0; i < 16; i++) {
	    random = rand() % 256;
        std::ostringstream ss;
        ss << std::hex << random;
        std::string result = ss.str();
        if(result.length() == 1){
        	result = "0"+result;
        }
		UUID = UUID + result;
		if(i==3 || i==5|| i==7 || i==9){
            UUID = UUID + Temp;
        }
	}
	return UUID;
}

void InitDeviceTypeList()
{
	bleTypeToGroupIdList[BLE_ALL] = BLE_ROOM;
	bleTypeToGroupIdList[BLE_DOWNLIGHT_SMT] = BLE_DOWNLIGHT_SMT_GROUP;
	bleTypeToGroupIdList[BLE_DOWNLIGHT_COB_GOC_RONG] = BLE_DOWNLIGHT_COB_GOC_RONG_GROUP;
	bleTypeToGroupIdList[BLE_DOWNLIGHT_COB_GOC_HEP] = BLE_DOWNLIGHT_COB_GOC_HEP_GROUP;
	bleTypeToGroupIdList[BLE_DOWNLIGHT_COB_TRANG_TRI] = BLE_DOWNLIGHT_COB_TRANG_TRI_GROUP;
	bleTypeToGroupIdList[BLE_PANEL_TRON] = BLE_PANEL_TRON_GROUP;
	bleTypeToGroupIdList[BLE_PANEL_VUONG] = BLE_PANEL_VUONG_GROUP;
	bleTypeToGroupIdList[BLE_LED_OP_TRAN] = BLE_LED_OP_TRAN_GROUP;
	bleTypeToGroupIdList[BLE_LED_OP_TUONG] = BLE_LED_OP_TUONG_GROUP;
	bleTypeToGroupIdList[BLE_LED_CHIEU_TRANH] = BLE_LED_CHIEU_TRANH_GROUP;
	bleTypeToGroupIdList[BLE_TRACKLIGHT] = BLE_TRACKLIGHT_GROUP;
	bleTypeToGroupIdList[BLE_LED_THA_TRAN] = BLE_LED_THA_TRAN_GROUP;
	bleTypeToGroupIdList[BLE_LED_CHIEU_GUONG] = BLE_LED_CHIEU_GUONG_GROUP;
	bleTypeToGroupIdList[BLE_LED_DAY_LINEAR] = BLE_LED_DAY_LINEAR_GROUP;
	bleTypeToGroupIdList[BLE_LED_TUBE_M16] = BLE_LED_TUBE_M16_GROUP;
	bleTypeToGroupIdList[BLE_DEN_BAN] = BLE_DEN_BAN_GROUP;
	bleTypeToGroupIdList[BLE_LED_FLOOD] = BLE_LED_FLOOD_GROUP;
	bleTypeToGroupIdList[BLE_LED_DAY_RGB] = BLE_LED_DAY_RGB_GROUP;
	bleTypeToGroupIdList[BLE_LED_DAY_RGBCW] = BLE_LED_DAY_RGBCW_GROUP;
	bleTypeToGroupIdList[BLE_LED_BULB] = BLE_LED_BULB_GROUP;
	bleTypeToGroupIdList[BLE_DOWNLIGHT_RGBCW] = BLE_DOWNLIGHT_RGBCW_GROUP;
	bleTypeToGroupIdList[BLE_LED_OP_TRAN_LOA] = BLE_LED_OP_TRAN_LOA_GROUP;
	bleTypeToGroupIdList[BLE_LED_RLT03_06W] = BLE_LED_RLT03_06W_GROUP;
	bleTypeToGroupIdList[BLE_LED_RLT02_10W] = BLE_LED_RLT02_10W_GROUP;
	bleTypeToGroupIdList[BLE_LED_RLT02_20W] = BLE_LED_RLT02_20W_GROUP;
	bleTypeToGroupIdList[BLE_LED_RLT01_10W] = BLE_LED_RLT01_10W_GROUP;
	bleTypeToGroupIdList[BLE_LED_TRL08_20W] = BLE_LED_TRL08_20W_GROUP;
	bleTypeToGroupIdList[BLE_LED_TRL08_10W] = BLE_LED_TRL08_10W_GROUP;
	bleTypeToGroupIdList[BLE_LED_RLT03_12W] = BLE_LED_RLT03_12W_GROUP;
}

uint32_t BleTypeToGroupId(uint32_t deviceType)
{
	return bleTypeToGroupIdList[deviceType];
}

static bool get_str_config_entry(const char *name, char *value)
{
	struct uci_context *ctx;
	struct uci_ptr ptr;
	char path[128];
	ctx = uci_alloc_context();
	snprintf(path, 128, "%s", name);
	if ((uci_lookup_ptr(ctx, &ptr, path, true) != UCI_OK) || !ptr.o || !ptr.o->v.string)
	{
		uci_free_context(ctx);
		return false;
	}
	snprintf(value, 128, "%s", ptr.o->v.string);
	uci_free_context(ctx);
	return true;
}

static bool set_str_config_entry(const char *name, const char *section_name, const char *value)
{
	struct uci_context *ctx;
	struct uci_ptr ptr;
	char path[128];
	ctx = uci_alloc_context();
	snprintf(path, 128, "%s", name);
	if ((uci_lookup_ptr(ctx, &ptr, path, true) != UCI_OK))
	{
		uci_perror(ctx, "uci_lookup_ptr Error");
		uci_free_context(ctx);
		return false;
	}
	if (ptr.s == NULL)
	{
		if (uci_add_section(ctx, ptr.p, section_name, &ptr.s) != UCI_OK)
		{
			uci_perror(ctx, "UCI Error to add new section");
			uci_free_context(ctx);
			return false;
		}
	}
	ptr.option = section_name;
	ptr.value = value;
	if (uci_set(ctx, &ptr) != UCI_OK)
	{
		uci_perror(ctx, "UCI Error to set new option");
		uci_free_context(ctx);
		return false;
	}
	if (uci_commit(ctx, &ptr.p, false) != UCI_OK)
	{
		uci_perror(ctx, "UCI Error to commit changes");
		uci_free_context(ctx);
		return false;
	}
	uci_free_context(ctx);
	return true;
}

void SetHcMasterInfo(){
	set_str_config_entry((char *)CONFIG_ENV HC_MAC, HC_MAC, HcMasterInfo.Mac.c_str());
	set_str_config_entry((char *)CONFIG_ENV HC_IP, HC_IP, HcMasterInfo.Ip.c_str());
	set_str_config_entry((char *)CONFIG_ENV HC_PASS_MQTT, HC_PASS_MQTT, HcMasterInfo.PassMqtt.c_str());
}

void GetHcMasterInfo(){
	char str_temp[128];
	string value_temp;
	if (get_str_config_entry((char *)CONFIG_ENV HC_MAC, str_temp))
		HcMasterInfo.Mac = string(str_temp);
	else
		HcMasterInfo.Mac = "";
	
	if (get_str_config_entry((char *)CONFIG_ENV HC_IP, str_temp))
		HcMasterInfo.Ip = string(str_temp);
	else
		HcMasterInfo.Ip = "";

	if (get_str_config_entry((char *)CONFIG_ENV HC_PASS_MQTT, str_temp))
		HcMasterInfo.PassMqtt = string(str_temp);
	else
		HcMasterInfo.PassMqtt = "";
}