#ifndef SHAREDATA_HPP_
#define SHAREDATA_HPP_

#include <queue>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <sqlite3.h>
#include <string>
#include <mosquitto.h>
#include <iostream>
#include <pthread.h>
#include <ctime>
#include <cstdlib>
#include <list>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <linux/if.h>
#include <sys/socket.h>
#include <ifaddrs.h>
#include <netinet/in.h>
#include <map>

#include <fstream>
#include <sstream>

#include <chrono>
#include <iomanip>

#include "rapidjson/document.h"
#include "rapidjson/prettywriter.h"

#include "RINGBUFFER/RingBuffer.h"

#include "AHG/JSON/JSON_AHG.hpp"
#include "DVSTATUS/DeviceStatus.hpp"
#include <uci.h>

using namespace std;
using namespace rapidjson;

/*
 * Variable for device update
 */
#define TIMEWAIT	22

#define LOG_ACTIONS			0
extern int timeOffLine;
/*
 * RING BUFFER
 */
#define MAXLENGTHSTRING_QDB 				512
#define MAXITEM_QDB         				2048
#define MAXLENGTHSTRING_RSP_TO_DEVICE 		512
#define MAXITEM_RSP_TO_DEVICE         		1024
#define MAXLENGTHSTRING_MSG_TO_APP 			40960
#define MAXITEM_MSG_TO_APP         			10

extern int TimeOut;

extern ringbuffer_t queueSend2Database;
extern ringbuffer_t queueMSG_App;
extern ringbuffer_t queueRSP_DV;

#define DEVICE_BLE  1
#define DEVICE_IR   2

#define EVENT_TYPE_SCENE 1
#define EVENT_TYPE_RULE  2

#define ATTRIBUTE_ONOFF   		0
#define ATTRIBUTE_CCT	  		2
#define ATTRIBUTE_DIM	  		1
#define ATTRIBUTE_HUE     		3
#define ATTRIBUTE_SATURATION	4
#define ATTRIBUTE_LIGHTNESS   	5

#define ADD_SCENE_CCT 			1
#define ADD_SCENE_RGB			2
#define EDIT_SCENE_CCT_TO_RGB	3
#define EDIT_SCENE_RGB_TO_CCT	4
#define DEL_SCENE_CCT			5
#define DEL_SCENE_RGB			6

#define STATUS_ONLINE			1
#define STATUS_OFFLINE			0

#define CREATE_GROUP				1
#define ADD_DEVICE_TO_GROUP			2
#define REMOVE_DEVICE_FROM_GROUP	3
#define DELETE_GROUP				4

#define CREATE_SCENE				1
#define EDIT_SCENE					2
#define REMOVE_DEVICE_FROM_SCENE	3
#define DELETE_SCENE				4

#define CREATE_ROOM					1
#define ADD_DEVICE_TO_ROOM			2
#define REMOVE_DEVICE_FROM_ROOM		3
#define DELETE_ROOM					4

#define SIZE_SCENE_DELAY 			128

#define REMOVE_ARR_SCENE_DELAY		0

#define SOURCE_ID					2    //source: HC

#define SWITCH_RGB_1				22012
#define SWITCH_RGB_2				22013
#define SWITCH_RGB_3				22014
#define SWITCH_RGB_4				22015
#define SWITCH_RGB_1_V				22019
#define SWITCH_RGB_2_V				22020
#define SWITCH_RGB_3_V				22021
#define SWITCH_RGB_4_V				22022
#define SWITCH_RGB_1_NL				22016
#define CDT_1						24001
#define CDT_2						24002
#define CDT_3						24003
#define CDT_1_N						24006
#define CDT_2_N						24007
#define CDT_3_N						24008
#define CDT_4						24004
#define CDT_1_NL					24005
#define SCENE_AC_RGB				23006
#define SCENE_AC_RGB_V				23008
#define SWITCH_RGB_1N				22026
#define SWITCH_RGB_2N				22028
#define SWITCH_RGB_3N				22030
#define SWITCH_RGB_4N				22032
#define SWITCH_RGB_1N_V				22027
#define SWITCH_RGB_2N_V				22029
#define SWITCH_RGB_3N_V				22031
#define SWITCH_RGB_4N_V				22033
#define CT_AT_2N					22037
#define CT_AT_3N					22038
#define CT_AT_5N					22039
#define CDT_BLEWF_1					24009
#define CDT_BLEWF_2					24010
#define CDT_BLEWF_3					24011
#define SWITCH_RGB_BLEWF_1			22040
#define SWITCH_RGB_BLEWF_2			22041
#define SWITCH_RGB_BLEWF_3			22042
#define SWITCH_RGB_BLEWF_4			22043

#define SWITCH_ON_OFF				21001
#define SWITCH_ON_OFF_INPUT			21002

#define SOCKET_SWITCH_1				26003

#define SEFTPOWER_REMOTE_1    		27001
#define SEFTPOWER_REMOTE_2			27002
#define SEFTPOWER_REMOTE_3			27003
#define SEFTPOWER_REMOTE_6			27006


#define TAP_TO_RUN					-2
#define LOGIC_RULE_TIME				-1
#define LOGIC_RULE_HCL				4
#define LOGIC_RULE_OR				0
#define LOGIC_RULE_AND				1

#define TIME_UPDATE					7200

#define DEL_LIST_SCENE				"{\"CMD\":\"DEL_LIST_SCENE\"}"

#define CONFIG_ENV "hcInfo.@master[0]."
#define HC_MAC "mac"
#define HC_IP "ip"
#define HC_PASS_MQTT "pass_mqtt"

#define ID_START 0xD000

enum
{
	BLE_ALL = 0,
	BLE_DOWNLIGHT_SMT = 12001, // 0x010201,
	BLE_DOWNLIGHT_COB_GOC_RONG = 12002,
	BLE_DOWNLIGHT_COB_GOC_HEP = 12003,
	BLE_DOWNLIGHT_COB_TRANG_TRI = 12004,
	BLE_PANEL_TRON = 12005,
	BLE_PANEL_VUONG = 12006,
	BLE_LED_OP_TRAN = 12007,
	BLE_LED_OP_TUONG = 12008,
	BLE_LED_CHIEU_TRANH = 12009,
	BLE_TRACKLIGHT = 12010,
	BLE_LED_THA_TRAN = 12011,
	BLE_LED_CHIEU_GUONG = 12012,
	BLE_LED_DAY_LINEAR = 12013,
	BLE_LED_TUBE_M16 = 12014,
	BLE_DEN_BAN = 12015,
	BLE_LED_FLOOD = 12016,
	BLE_LED_RLT03_06W = 12020,
	BLE_LED_RLT02_10W = 12021,
	BLE_LED_RLT02_20W = 12022,
	BLE_LED_RLT01_10W = 12023,
	BLE_LED_TRL08_20W = 12024,
	BLE_LED_TRL08_10W = 12025,
	BLE_LED_RLT03_12W = 12026,
	BLE_LED_OP_TRAN_40W = 12027,
	BLE_LED_DAY_RGB = 13001,
	BLE_LED_DAY_RGBCW = 14001,
	BLE_LED_BULB = 14002,
	BLE_DOWNLIGHT_RGBCW = 14003,
	BLE_LED_OP_TRAN_LOA = 15001,

	BLE_SWITCH_ONOFF = 21001,

	BLE_SWITCH_1 = 22001,
	BLE_SWITCH_2 = 22002,
	BLE_SWITCH_3 = 22003,
	BLE_SWITCH_4 = 22004,
	BLE_SWITCH_WATER_HEATER = 22005,
	BLE_SWITCH_RGB_1 = 22012,
	BLE_SWITCH_RGB_2 = 22013,
	BLE_SWITCH_RGB_3 = 22014,
	BLE_SWITCH_RGB_4 = 22015,
	BLE_SWITCH_RGB_WATER_HEATER = 22016,
	BLE_SWITCH_RGB_1_SQUARE = 22019,
	BLE_SWITCH_RGB_2_SQUARE = 22020,
	BLE_SWITCH_RGB_3_SQUARE = 22021,
	BLE_SWITCH_RGB_4_SQUARE = 22022,
	BLE_SWITCH_RGB_1_V2 = 22026,
	BLE_SWITCH_RGB_1_SQUARE_V2 = 22027,
	BLE_SWITCH_RGB_2_V2 = 22028,
	BLE_SWITCH_RGB_2_SQUARE_V2 = 22029,
	BLE_SWITCH_RGB_3_V2 = 22030,
	BLE_SWITCH_RGB_3_SQUARE_V2 = 22031,
	BLE_SWITCH_RGB_4_V2 = 22032,
	BLE_SWITCH_RGB_4_SQUARE_V2 = 22033,

	BLE_SWITCH_2_CEILING = 22037,
	BLE_SWITCH_3_CEILING = 22038,
	BLE_SWITCH_5_CEILING = 22039,

	BLE_SWITCH_CURTAIN = 22006,
	BLE_SWITCH_RGB_CURTAIN = 22017,
	BLE_SWITCH_RGB_CURTAIN_SQUARE = 22024,
	BLE_SWITCH_RGB_CURTAIN_HCN = 22034,
	BLE_SWITCH_RGB_CURTAIN_SQUARE_V2 = 22035,

	BLE_SWITCH_ROOLING_DOOR = 22018,
	BLE_SWITCH_ROOLING_DOOR_V2 = 22025,
	BLE_SWITCH_ROOLING_DOOR_SQUARE = 22036,

	BLE_DC_SCENE_CONTACT = 23001, // 0x020301,
	BLE_AC_SCENE_CONTACT = 23002, // 0x020302,
	BLE_AC_SCENE_CONTACT_RGB = 23006,
	BLE_AC_SCENE_CONTACT_RGB_SQUARE = 23008,
	BLE_AC_SCENE_SCREEN_TOUCH = 23003,
	BLE_REMOTE_M3 = 23004,
	BLE_REMOTE_M3_V2 = 23007,
	BLE_REMOTE_M4 = 23005,

	BLE_SWITCH_ELECTRICAL_1 = 24001,
	BLE_SWITCH_ELECTRICAL_2 = 24002,
	BLE_SWITCH_ELECTRICAL_3 = 24003,
	BLE_SWITCH_ELECTRICAL_4 = 24004,
	BLE_SWITCH_ELECTRICAL_WATER_HEATER = 24005,

	// TODO: update this device
	BLE_SWITCH_RGB_SOCKET_1 = 26003,

	BLE_SEFTPOWER_REMOTE_1 = 27001,
	BLE_SEFTPOWER_REMOTE_2 = 27002,
	BLE_SEFTPOWER_REMOTE_3 = 27003,

	BLE_PM_SENSOR = 37001,
	BLE_TEMP_HUM_SENSOR = 38001, // 0x030801,
	BLE_PIR_LIGHT_SENSOR_DC = 32001,
	BLE_PIR_LIGHT_SENSOR_AC = 32002,
	BLE_PIR_LIGHT_SENSOR_DC_CB10 = 32006,
	BLE_PIR_LIGHT_SENSOR_DC_CB09 = 32007,
	BLE_RADA_LIGHT_SENSOR_AC_CB15 = 32008,
	BLE_PIR_LIGHT_SENSOR_AC_AMTRAN = 32004,

	// TODO: update this devices
	BLE_PIR_LIGHT_SENSOR_CB10 = 32006,
	BLE_PIR_LIGHT_SENSOR_CB09 = 32007,
	BLE_PIR_LIGHT_SENSOR_CB015_RADA = 32008,

	BLE_DOOR_SENSOR = 36001,
	BLE_DOOR_CB16_SENSOR = 36002,
	BLE_SMOKE_SENSOR = 33001,

	// TODO: update this device
	BLE_REPEATER = 91001,

	ZIGBEE_LUMI_PLUG = 0x02000001,
	ZIGBEE_LUMI_SENSOR_SWITCH = 0x02000002,
	ZIGBEE_LUMI_SENSOR_TEMP_HUM = 0x02000003,
	ZIGBEE_LUMI_SENSOR_WLEAK_AQ1 = 0x02000004,
	ZIGBEE_LUMI_SENSOR_MAGNET = 0x02000005,

	ZIGBEE_TUYA_SENSOR_MAGNET_TY0203 = 0x02010001,
	ZIGBEE_TUYA_SENSOR_PIR_RH3040 = 0x02010102,
	ZIGBEE_TUYA_SENSOR_HUMAN_PRESENCE_TS0225 = 0x02010103,

	MQTT_AI_HUB = 0x03000001,

	// CAMERA_TUYA = 0x04000001,
	// CAMERA_DAHUA = 0x04000002,
	// CAMERA_HKVISION = 0x04000003
	CAMERA_TUYA = 61001,
	CAMERA_DAHUA = 61002,
	CAMERA_HKVISION = 61003
};

enum
{
	BLE_ROOM = 0,
	BLE_DOWNLIGHT_SMT_GROUP = 1,
	BLE_DOWNLIGHT_COB_GOC_RONG_GROUP = 2,
	BLE_DOWNLIGHT_COB_GOC_HEP_GROUP = 3,
	BLE_DOWNLIGHT_COB_TRANG_TRI_GROUP = 4,
	BLE_PANEL_TRON_GROUP = 5,
	BLE_PANEL_VUONG_GROUP = 6,
	BLE_LED_OP_TRAN_GROUP = 7,
	BLE_LED_OP_TUONG_GROUP = 8,
	BLE_LED_CHIEU_TRANH_GROUP = 9,
	BLE_TRACKLIGHT_GROUP = 10,
	BLE_LED_THA_TRAN_GROUP = 11,
	BLE_LED_CHIEU_GUONG_GROUP = 12,
	BLE_LED_DAY_LINEAR_GROUP = 13,
	BLE_LED_TUBE_M16_GROUP = 14,
	BLE_DEN_BAN_GROUP = 15,
	BLE_LED_FLOOD_GROUP = 16,
	BLE_LED_DAY_RGB_GROUP = 17,
	BLE_LED_DAY_RGBCW_GROUP = 18,
	BLE_LED_BULB_GROUP = 19,
	BLE_DOWNLIGHT_RGBCW_GROUP = 20,
	BLE_LED_OP_TRAN_LOA_GROUP = 21,
	BLE_LED_RLT03_06W_GROUP = 23,
	BLE_LED_RLT02_10W_GROUP = 24,
	BLE_LED_RLT02_20W_GROUP = 25,
	BLE_LED_RLT01_10W_GROUP = 26,
	BLE_LED_TRL08_20W_GROUP = 27,
	BLE_LED_TRL08_10W_GROUP = 28,
	BLE_LED_RLT03_12W_GROUP = 29,
};

extern map<uint32_t, uint32_t> bleTypeToGroupIdList;

extern int screenTouch_statusOutWeather;
extern int screenTouch_tempOutWeather;

extern pthread_mutex_t mutex;
extern pthread_mutex_t mutexMSG_App;
extern pthread_mutex_t mutexRSP_DV;
extern pthread_mutex_t mutex_DB;
extern pthread_mutex_t mutexDvOnline;
extern pthread_mutex_t mutexSceneDelay;
extern pthread_mutex_t mutexLog;
extern pthread_mutex_t mutexUDP;

extern pthread_t ThreadMqttMasterId;
extern pthread_t ThreadMqttMaster;

//SceneDelay
extern int ArrSceneDelay[SIZE_SCENE_DELAY][6];
extern int IndexSceneDaleyCurrent;
extern bool FlagCheckSceneDelay;

// Check GHA
extern int numDeviceDelGroupSuccess;
extern int deviceDelGroupSuccess[256];
extern int numDeviceDelGroupFailed;
extern int deviceDelGroupFailed[256];

extern int IsProcessGroup;
extern string ShareGroupId;
extern int ShareGroupUnicastId;
extern int numDeviceGroup ;
extern int DeviceGroup[256];
extern int numDeviceGroupSuccess;
extern int DeviceGroupSuccess[256];

extern string macHC;

typedef struct{
	int DeviceUnicastID;
	int TypeDevice;
	int TimeCheck;
	string DeviceUUID;
	string FirmVersion;
	bool CurrentStatus;
	bool PreviousStatus;
}t_DeviceCheckOnline;

// extern t_DeviceCheckOnline T_DeviceCheckOnline[256];
extern vector<t_DeviceCheckOnline> T_DeviceCheckOnline;

typedef struct{
	string EvenTriggerId;
	string Time;
	bool Status;
}t_checkHCL;

extern t_checkHCL CheckHCL;

struct RuleLog{
	string EventTriggerId;
	int EventTriggerTypeId;
	string Name;
	int StatusId;
	string DormitoryId;
};

extern struct RuleLog ruleLog;

typedef struct{
	string Mac;
	string Ip;
	string PassMqtt;
}t_HcMaster;

extern t_HcMaster HcMasterInfo;

extern bool IsProcessDone;

extern int IsProcessScene;
extern string ShareSceneId;
extern int ShareSceneUnicastId;
extern int DeviceScene[256];
extern int numDeviceScene;
extern int numDeviceSceneSuccess;
extern int DeviceSceneSuccess[256];

extern int IsProcessRoom;
extern int numDeviceGroupRoom;
extern int numDeviceGroupRoomSuccess;
extern int numDeviceSceneRoom;
extern int numDeviceSceneRoomSuccess;
extern int DeviceGroupRoom[48][256];
extern int DeviceRoomGroupSuccess[48][256];
extern int DeviceSceneRoom[48][256];
extern int DeviceRoomSceneSuccess[48][256];
extern unsigned int numGroupRoom;
extern unsigned int numSceneRoom;

extern bool isResetNode;
extern bool isResetHc;
extern int numDeviceReset;
extern int numDeviceResetSuccess;
extern int deviceReset[100];
extern int deviceResetSuccess[100];
extern int deviceResetFailed[100];

extern string sceneIdDelRemote;

extern int lowlux,highlux;
extern string sceneafterPir;
extern string scenebeforePir;

extern pthread_mutex_t KeyLock;

extern string dormitoryId;

extern string HCId;

extern queue <string> QueueDB;

extern string TopicMultiHC;
extern bool sendMsgMultiHc;

void ResetDataResetNode();
void ResetDataGroup();
void ResetDataScene();
void ResetDataRoom();
string ExeCMD(const char* command);
void ResetDB();
string LocalTime(string s);
void WriteIntoLog(string cmd, string code);
void PushItemToQueue(pthread_mutex_t KeyLock, string Msg, ringbuffer_t Queue, int SizeMsg);
void GetMacAddress(char *uc_Mac);

typedef struct{
	int AttDevice[64];
	int DeviceUnicastID;
	int TypeDevice;
	string DeviceUUID;
}t_Device;

extern vector<t_Device> T_Device;

typedef struct{
	int DeviceUnicastId;
	int DeviceAttributeId;
	string DeviceId;
}t_DeviceFromRuleDeviceInput;

extern vector<t_DeviceFromRuleDeviceInput> ListDeviceFromRuleDeviceInput;

extern pthread_mutex_t mutexUpdateDvValue;


int SearchDeviceCheckOnline(int Para);
int SearchDeviceUpdateValue(int Para);

int GetTimeNow();
int GetSecondTimeNow();
unsigned long int GetTimrStamp();
void PushMsgToQueueDb_AHG(string Msg);

void DeleteRowDvValue(vector<t_Device> &t_TempDevice, int TempIndex);
void DeleteRowDvCheckOnline(vector<t_DeviceCheckOnline> &t_TempDevice, int TempIndex);
int TimeCheckOnline();

#if LOG_ACTIONS
void SendLogScene(string sceneId);
void SendLogGroup(string groupId);
void SendLogDevice(string deviceId);
#endif

string currentISO8601LocalTime();

string GenerateUUID();
void SetHcMasterInfo();
void GetHcMasterInfo();
void GetDvSceneDelay(string SceneId, int Delay);
void GetGrSceneDelay(string SceneId, int Delay);
void AddSceneIntoArrCallScene(int SceneUnicastId, int Delay);
void InitDeviceTypeList();
uint32_t BleTypeToGroupId(uint32_t deviceType);

#endif
